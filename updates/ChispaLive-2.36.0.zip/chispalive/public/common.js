// Utilidades compartidas por panel y overlays
const socket = io();

// ---------- Temas, fuentes y animaciones ----------
const THEMES = {
  chispa:   { name: 'Chispa Neón',  primary: '#ff6a2b', secondary: '#ff2e7e', accent: '#ffd23f', extra: ['#7c5cff', '#2ea7ff', '#2ee6a6', '#ff8f3f', '#c13cff'], bg: [14, 12, 22] },
  cyber:    { name: 'Cyber Azul',   primary: '#00e5ff', secondary: '#7c5cff', accent: '#00ffa3', extra: ['#2979ff', '#d500f9', '#18ffff', '#651fff', '#00b8d4'], bg: [6, 10, 24] },
  kawaii:   { name: 'Rosa Kawaii',  primary: '#ff7eb6', secondary: '#c77dff', accent: '#ffe066', extra: ['#ffadad', '#a0c4ff', '#bdb2ff', '#ffc6ff', '#9bf6ff'], bg: [36, 16, 40] },
  toxic:    { name: 'Tóxico',       primary: '#39ff14', secondary: '#00c853', accent: '#e6ff00', extra: ['#76ff03', '#1de9b6', '#c6ff00', '#00e676', '#64dd17'], bg: [6, 16, 8] },
  oro:      { name: 'Oro Real',     primary: '#ffcc33', secondary: '#ff8c00', accent: '#fff3b0', extra: ['#b8860b', '#ffd700', '#e09b2d', '#ffe08a', '#c58b00'], bg: [20, 14, 4] },
  terror:   { name: 'Terror',       primary: '#ff1e3c', secondary: '#7a0010', accent: '#f5f5f5', extra: ['#3d0008', '#b3001b', '#4a4a4a', '#d50000', '#1a1a1a'], bg: [8, 2, 4] },
  brainrot: { name: 'Brainrot',     primary: '#ff00e6', secondary: '#00f0ff', accent: '#fff200', extra: ['#00ff6a', '#ff6a00', '#7b00ff', '#ff0055', '#00a2ff'], bg: [12, 4, 24] },
  hielo:    { name: 'Hielo',        primary: '#7dd3fc', secondary: '#a5b4fc', accent: '#ffffff', extra: ['#38bdf8', '#c7d2fe', '#e0f2fe', '#818cf8', '#bae6fd'], bg: [8, 18, 32] },
};
const FONTS = {
  'Bricolage Grotesque': { label: 'Moderna',   pkg: 'bricolage-grotesque', w: [600, 800] },
  'Bungee':              { label: 'Gamer',     pkg: 'bungee', w: [400] },
  'Luckiest Guy':        { label: 'Cartoon',   pkg: 'luckiest-guy', w: [400] },
  'Fredoka':             { label: 'Redondita', pkg: 'fredoka', w: [500, 700] },
  'Press Start 2P':      { label: 'Pixel',     pkg: 'press-start-2p', w: [400] },
  'Russo One':           { label: 'Deportiva', pkg: 'russo-one', w: [400] },
  'Creepster':           { label: 'Terror',    pkg: 'creepster', w: [400] },
  'Bangers':             { label: 'Cómic',     pkg: 'bangers', w: [400] },
  'Outfit':              { label: 'Limpia',    pkg: 'outfit', w: [400, 600, 800] },
};
// ---------- Tienda de diseños (pieles de temporada para todos los overlays) ----------
const DESIGN_SKINS = {
  navidad:     { name: 'Navidad',       icon: '🎄', desc: 'Nieve cayendo, gorro de nieve en las tarjetas y colores rojo, verde y dorado.', font: 'Luckiest Guy', snd: 'jingle', burst: ['❄️','🎁','⭐','🔔'], moment: '🎅🦌', fx: 'snow',    colors: { primary: '#e53935', secondary: '#1b8a3a', accent: '#ffd54f' }, extra: ['#c62828', '#2e7d32', '#ffffff', '#ffb300', '#66bb6a'], bg: [10, 26, 16] },
  halloween:   { name: 'Halloween',     icon: '🎃', desc: 'Murciélagos volando, telarañas y colores naranja y morado.',                 font: 'Creepster',    snd: 'spooky', burst: ['🎃','🦇','👻','🍬'], moment: '👻', fx: 'bats',    colors: { primary: '#ff7a00', secondary: '#8e24aa', accent: '#b6ff3b' }, extra: ['#ff9800', '#6a1b9a', '#212121', '#ffeb3b', '#4a148c'], bg: [18, 8, 24] },
  anime:       { name: 'Anime',         icon: '🌸', desc: 'Pétalos de sakura, letra redondita y colores pastel.',                       font: 'Fredoka',      snd: 'kawaii', burst: ['🌸','✨','💫','⭐'], moment: '🌠', fx: 'sakura',  colors: { primary: '#ff8fc8', secondary: '#7ec8ff', accent: '#fff3a8' }, extra: ['#ffc6ff', '#a0c4ff', '#bdb2ff', '#caffbf', '#ffadad'], bg: [42, 20, 50] },
  anonuevo:    { name: 'Año Nuevo',     icon: '🎆', desc: 'Brillos dorados, letra gamer y negro con oro para la cuenta regresiva.',     font: 'Bungee',       snd: 'firework', burst: ['🎆','✨','🥂','🎉'], moment: '🎆', fx: 'sparkle', colors: { primary: '#ffd23f', secondary: '#b388ff', accent: '#ffffff' }, extra: ['#ffb300', '#7c4dff', '#e0e0e0', '#ffe082', '#651fff'], bg: [8, 8, 16] },
  // --- exclusivos: solo salen en cofres de Chispas ---
  oceano:      { name: 'Océano',        icon: '🌊', excl: 'raro',       desc: 'Burbujas subiendo, peces en la explosión y azules profundos.',              font: 'Fredoka',      snd: 'waves', burst: ['🐠','🫧','🐚','🌊'], moment: '🐋', fx: 'bubbles', colors: { primary: '#22d3ee', secondary: '#3b82f6', accent: '#a7f3d0' }, extra: ['#0ea5e9', '#2563eb', '#14b8a6', '#67e8f9', '#1e40af'], bg: [4, 18, 34] },
  infierno:    { name: 'Infierno',      icon: '🔥', excl: 'epico',      desc: 'Brasas que suben, llamas en cada regalo y rojo volcán.',                    font: 'Luckiest Guy', snd: 'inferno', burst: ['🔥','💥','☄️','🌋'], moment: '🐉', fx: 'embers', colors: { primary: '#ff5a1f', secondary: '#ffb020', accent: '#ffe08a' }, extra: ['#dc2626', '#f97316', '#facc15', '#7f1d1d', '#fb923c'], bg: [24, 6, 4] },
  galaxia:     { name: 'Galaxia',       icon: '🌌', excl: 'legendario', desc: 'Estrellas que titilan, estrellas fugaces y un ovni de vez en cuando.',     font: 'Bungee',       snd: 'cosmic', burst: ['🪐','⭐','☄️','🌌'], moment: '🛸', fx: 'stars', colors: { primary: '#a78bfa', secondary: '#22d3ee', accent: '#f0abfc' }, extra: ['#7c3aed', '#06b6d4', '#e879f9', '#4f46e5', '#c4b5fd'], bg: [8, 6, 26] },
  reydorado:   { name: 'Rey Dorado',    icon: '👑', excl: 'legendario', desc: 'Lluvia de oro, coronas y diamantes. Negro y dorado de lujo.',              font: 'Bungee',       snd: 'royalgold', burst: ['👑','💰','💎','🏆'], moment: '👑', fx: 'gold', colors: { primary: '#ffcc33', secondary: '#ffe9a8', accent: '#ffffff' }, extra: ['#d4a017', '#b8860b', '#fff1b8', '#8a6400', '#ffd700'], bg: [10, 8, 4] },
  sanvalentin: { name: 'San Valentín',  icon: '💘', desc: 'Corazones flotando y todo en rosa y rojo.',                                  font: 'Fredoka',      snd: 'kiss', burst: ['💖','💘','🌹','💕'], moment: '💘', fx: 'hearts',  colors: { primary: '#ff4d8d', secondary: '#ff1744', accent: '#ffd1e3' }, extra: ['#f06292', '#d50000', '#ff80ab', '#ffcdd2', '#c2185b'], bg: [42, 8, 22] },
};
// "Automático por fecha": elige solo el diseño de la temporada
function skinByDate(d = new Date()) {
  const m = d.getMonth() + 1, day = d.getDate();
  if ((m === 12 && day === 31) || (m === 1 && day <= 2)) return 'anonuevo';
  if (m === 12) return 'navidad';
  if (m === 10 && day >= 15) return 'halloween';
  if (m === 2 && day <= 14) return 'sanvalentin';
  return '';
}
const IS_OVERLAY = /\/overlay\//.test(location.pathname);
// cada overlay se identifica (ej. data-game="trivia") para que overlay.css pula cada juego por separado
if (IS_OVERLAY && window.GAME_KEY) document.documentElement.dataset.game = window.GAME_KEY;
const SKIN_Q = new URLSearchParams(location.search).get('skin');
function activeSkin(c) {
  if (!IS_OVERLAY) return null;
  const s = c?.skin || {}; let id = SKIN_Q ?? s.id;
  if (id === 'auto') id = skinByDate();
  return DESIGN_SKINS[id] ? { id, ...DESIGN_SKINS[id], opt: s } : null;
}
// los colores de cada piel también se usan en la ruleta y el fondo de las tarjetas
Object.entries(DESIGN_SKINS).forEach(([k, v]) => { THEMES['sk-' + k] = { name: v.name, ...v.colors, extra: v.extra, bg: v.bg }; });
const ANIMS = { pop: 'Pop', rebote: 'Rebote', zoom: 'Zoom', deslizar: 'Deslizar', giro: 'Giro', glitch: 'Glitch' };

let BRAND = {};
let VOLUME = 0.6;

function hexToRgb(h) {
  h = String(h || '#ffffff').replace('#', '');
  if (h.length === 3) h = h.split('').map(c => c + c).join('');
  const n = parseInt(h, 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}
const rgba = (hex, a) => `rgba(${hexToRgb(hex).join(',')},${a})`;

function loadFont(name) {
  const f = FONTS[name]; if (!f) return;
  f.w.forEach(w => {
    const id = `font-${f.pkg}-${w}`;
    if (document.getElementById(id)) return;
    const l = document.createElement('link'); l.id = id; l.rel = 'stylesheet';
    l.href = `/fonts/${f.pkg}/${w}.css`; // fuentes locales: funcionan sin internet
    document.head.appendChild(l);
  });
}

function wheelPalette() {
  const c = BRAND.colors || {}; const t = THEMES[BRAND.theme] || THEMES.chispa;
  return [c.primary, c.secondary, c.accent, ...t.extra].filter(Boolean);
}

// Aplica el estilo del canal a la página actual
function applyTheme(b) {
  BRAND = b || {};
  const c = BRAND.colors || THEMES.chispa;
  const t = THEMES[BRAND.theme] || THEMES.chispa;
  const g = (BRAND.glow ?? 70) / 100;
  const r = document.documentElement.style;
  r.setProperty('--spark', c.primary); r.setProperty('--spark2', c.secondary); r.setProperty('--gold', c.accent);
  r.setProperty('--glass', `rgba(${t.bg.join(',')},${(BRAND.opacity ?? 85) / 100})`);
  r.setProperty('--glow1', rgba(c.primary, 0.25 + g * 0.45));
  r.setProperty('--glow2', rgba(c.secondary, 0.3 + g * 0.6));
  r.setProperty('--glowk', g);
  r.setProperty('--radius', (BRAND.radius ?? 20) + 'px');
  r.setProperty('--font', `'${BRAND.font || 'Bricolage Grotesque'}'`);
  r.setProperty('--speed', BRAND.speed || 1);
  r.setProperty('--scale', (BRAND.scale || 100) / 100);
  r.setProperty('--enter', BRAND.animation || 'pop');
  VOLUME = (BRAND.volume ?? 60) / 100;
  loadFont(BRAND.font || 'Bricolage Grotesque'); loadFont('Outfit');
  document.querySelectorAll('[data-brand]').forEach(addBrandTag);
  if (BRAND.logo) { _logoImg = new Image(); _logoImg.src = BRAND.logo; } else _logoImg = null;
}
function addBrandTag(el) {
  el.querySelector(':scope > .brandtag')?.remove();
  if (!BRAND.showLogo || (!BRAND.logo && !BRAND.name)) return;
  const t = document.createElement('div'); t.className = 'brandtag' + (BRAND.name ? '' : ' noname');
  if (BRAND.logo) { const i = new Image(); i.src = BRAND.logo; t.appendChild(i); }
  if (BRAND.name) t.appendChild(document.createTextNode(BRAND.name));
  el.appendChild(t);
}
let _logoImg = null;

// ---------- Ajustes propios de cada juego ----------
// Cada overlay define window.GAME_KEY antes de cargar este archivo.
const gcfg = () => window.CFG?.games?.[window.GAME_KEY] || {};
const fx = k => gcfg().effects?.[k] !== false;
let _gameImg = null;
function applyGame() {
  const g = gcfg(), r = document.documentElement.style;
  if (g.anim) r.setProperty('--enter', g.anim);
  document.documentElement.classList.toggle('noglow', !fx('glow'));
  document.documentElement.classList.toggle('clasico', (window.CFG?.brand?.finish || BRAND.finish) === 'clasico'); // Acabado: Lujo (por defecto) o Clásico
  // Posición y escala propias del juego (se suman a "Mi estilo")
  r.setProperty('--scale', ((BRAND.scale || 100) / 100) * ((g.scale || 100) / 100));
  r.setProperty('--ox', (g.x || 0) + 'px'); r.setProperty('--oy', (g.y || 0) + 'px');
  if (g.image) { if (!_gameImg || _gameImg._src !== g.image) { _gameImg = new Image(); _gameImg.src = g.image; _gameImg._src = g.image; } } else _gameImg = null;
}
socket.on('config', c => {
  window.CFG = c;
  const g = c.games?.[window.GAME_KEY];
  // Diseño de la tienda (Navidad, Halloween...) encima de "Mi estilo"
  const sk = activeSkin(c); let brand = c.brand;
  if (sk) brand = { ...brand, ...(sk.opt.colors !== false ? { colors: sk.colors, theme: 'sk-' + sk.id } : {}), ...(sk.opt.font !== false ? { font: sk.font } : {}) };
  applySkinFx(sk); _skinNow = sk;
  // Colores propios del juego (si los activaste en su estudio)
  applyTheme(g?.colors?.custom ? { ...brand, colors: { primary: g.colors.primary, secondary: g.colors.secondary, accent: g.colors.accent } } : brand);
  applyGame();
  window.onConfig && window.onConfig(c);
});
socket.on('catalog', c => window.CATALOG = c);
// Reloj sincronizado con el servidor (para los temporizadores)
let TOFF = 0;
socket.on('state', s => { if (s.now) TOFF = s.now - Date.now(); });
const nowMs = () => Date.now() + TOFF;
function fmtTime(ms) {
  const s = Math.max(0, Math.ceil(ms / 1000)), h = Math.floor(s / 3600), m = Math.floor(s % 3600 / 60), ss = s % 60;
  return (h ? h + ':' + String(m).padStart(2, '0') : m) + ':' + String(ss).padStart(2, '0');
}
function gameImgEl(size = 40) {
  const g = gcfg(); if (!g.image) return null;
  const i = new Image(); i.src = g.image; i.className = 'gameimg'; i.style.width = i.style.height = size + 'px'; return i;
}
function avatarEl(user, size = 44) {
  const el = document.createElement(user?.avatar ? 'img' : 'div');
  el.className = 'avatar';
  el.style.width = el.style.height = size + 'px';
  if (user?.avatar) { el.src = user.avatar; el.referrerPolicy = 'no-referrer'; }
  else { el.textContent = (user?.name || '?').slice(0, 1).toUpperCase(); el.style.fontSize = size * 0.42 + 'px'; }
  return el;
}
// Cartel del premio de una meta ("🎁 ¡Giro gratis de la ruleta!")
function rewardBanner(text) {
  if (!text) return;
  if (!document.getElementById('rwb-css')) { const st = document.createElement('style'); st.id = 'rwb-css'; st.textContent = `.rwb{position:fixed;left:50%;top:50%;z-index:998;transform:translate(-50%,-50%);padding:18px 30px 20px;border-radius:24px;text-align:center;color:#fff;background:linear-gradient(135deg,var(--spark,#ff6a2b),var(--spark2,#ff2e7e));box-shadow:0 20px 60px rgba(0,0,0,.5),0 0 60px var(--glow2,rgba(255,46,126,.5));font-family:'Outfit',system-ui,sans-serif;animation:rwbIn .6s cubic-bezier(.2,1.5,.4,1) both;max-width:90vw}.rwb small{display:block;font-size:15px;font-weight:800;letter-spacing:.18em;opacity:.9}.rwb b{display:block;font-size:34px;font-weight:900;line-height:1.15;text-shadow:0 3px 10px rgba(0,0,0,.3)}.rwb.out{animation:rwbOut .45s ease-in forwards}@keyframes rwbIn{from{transform:translate(-50%,-50%) scale(.3) rotate(-6deg);opacity:0}}@keyframes rwbOut{to{transform:translate(-50%,-50%) scale(.6);opacity:0}}`; document.head.appendChild(st); }
  const el = document.createElement('div'); el.className = 'rwb';
  el.innerHTML = `<small>🎁 PREMIO PARA TODOS</small><b>${esc(text)}</b>`;
  document.body.appendChild(el); setTimeout(() => { el.classList.add('out'); setTimeout(() => el.remove(), 500); }, 5200);
}
function esc(s) { return String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }
// Variables en inglés ({user}, {gift}…) valen igual que en español
const VAR_EN = { user: 'usuario', gift: 'regalo', amount: 'cantidad', count: 'cantidad', coins: 'monedas', diamonds: 'diamantes', level: 'nivel', message: 'mensaje', prize: 'premio', viewers: 'espectadores' };
const enVars = s => String(s ?? '').replace(/\{(user|gift|amount|count|coins|diamonds|level|message|prize|viewers)\}/g, (m, k) => '{' + VAR_EN[k] + '}');
// Reemplaza {usuario} {regalo} {cantidad} {diamantes} {monedas} {nivel} en los textos
function fillText(tpl, d) {
  return enVars(tpl || '')
    .replaceAll('{usuario}', d.user?.name || '').replaceAll('{regalo}', d.giftName || '')
    .replaceAll('{cantidad}', d.count || 1).replaceAll('{diamantes}', d.diamonds || 0)
    .replaceAll('{monedas}', (d.total ?? d.diamonds ?? 0).toLocaleString('es')).replaceAll('{nivel}', (d.i ?? 0) + 1)
    .replace(/\b1x /, ''); // "1x Rose" queda como "Rose"
}

// =====================================================================
// SONIDOS: efectos sintetizados (no necesitan archivos) + tus propios MP3
// =====================================================================
const SFX = {
  tick: 'Tic', pop: 'Pop', coin: 'Moneda', gift: 'Regalo', bell: 'Campana', win: 'Victoria', fanfare: 'Fanfarria',
  levelup: 'Subir de nivel', magic: 'Magia', whoosh: 'Whoosh', boom: 'Explosión', oof: 'Oof (eliminado)',
  airhorn: 'Bocina', drum: 'Redoble', laser: 'Láser', boing: 'Boing',
  jingle: 'Cascabeles (Navidad)', spooky: 'Risa tenebrosa (Halloween)', kawaii: 'Brillitos (Anime)', firework: 'Fuegos artificiales', kiss: 'Corazón (San Valentín)',
  cannon: 'Cañonazo', impact: 'Golpe en piedra', arrow: 'Flechas', meteor: 'Bola de fuego', roar: 'Rugido de dragón', shieldup: 'Escudo mágico', clang: 'Choque metálico', hammer: 'Martillazos', crumble: 'Derrumbe', horn: 'Cuerno de guerra',
  // --- propios de cada juego ---
  bingoball: 'Bola de bingo', bingo: '¡Bingo!', rpsshake: 'Piedra, papel o tijera', rpsclash: 'Choque de manos', bid: 'Caja registradora (Subasta)', gavel: 'Martillo de subasta', ratchet: 'Tic de ruleta', sword: 'Espadazo', crown: 'Coronación', dice: 'Dados rodando', treasure: 'Tesoro de monedas', creak: 'Cofre que se abre', sadtrombone: 'Trombón triste', clink: 'Moneda en el frasco', gong: 'Gong', punch: 'Puñetazo', startgun: 'Disparo de largada', turbo: 'Turbo', slash: 'Tajo de espada', bossdown: 'Jefe derrotado', quiz: 'Pregunta de concurso', correct: 'Respuesta correcta', munch: 'Ñam ñam', whine: 'Mascota triste', ballot: 'Voto', kick: 'Patada al balón', crowd: 'Gol con hinchada', glove: 'Atajada', lever: 'Palanca del tragamonedas', reelstop: 'Rodillo que frena', payout: 'Lluvia de monedas', fuse: 'Mecha encendida', splash: 'Chapuzón', bubble: 'Burbujas', reelin: 'Carrete de pesca', letter: 'Letra destapada', buzzer: 'Chicharra', brick: 'Bloque que cae', creakwood: 'Crujido de torre', ticket: 'Boleto', squeak: 'Juguete chillón', clock: 'Reloj suma tiempo', alarm: 'Alarma', heartbeat: 'Latido',
};
// --- 2.34: un sonido propio para cada juego (ningún juego comparte sonidos de fábrica) ---
const SFX2_LABELS = {
  wordright: 'Adivina · Acierto', wordstart: 'Adivina · Empieza', almost: 'Adivina · ¡Casi!', nope: 'Adivina · Incorrecto', wordtick: 'Adivina · Reloj',
  quizchamp: 'Trivia · Campeón', lockin: 'Trivia · Respuesta fijada', quiztick: 'Trivia · Reloj',
  pollwin: 'Votación · Ganador', pollopen: 'Votación · Abre', pollswing: 'Votación · Cambio de líder', votegift: 'Votación · Voto con regalo', pollclose: 'Votación · Cierra',
  rpschamp: 'PPT · Campeón', rpsstart: 'PPT · Empieza', rpstie: 'PPT · Empate', rpspick: 'PPT · Elige', rpstick: 'PPT · Reloj', rpslose: 'PPT · Pierde', rpswin: 'PPT · Gana ronda',
  castlewin: 'Castillos · Victoria',
  pkwin: 'PK · Victoria', pkdraw: 'PK · Empate', pkswing: 'PK · Cambio de líder', lastseconds: 'PK · Últimos segundos', pklose: 'PK · Derrota', pkstart: 'PK · Empieza',
  rafflewin: 'Sorteo · Ganador', confirm: 'Sorteo · Confirmado', raffleopen: 'Sorteo · Abre', raffleloss: 'Sorteo · Sin ganador',
  towerwin: 'Torre · Récord', giantblock: 'Torre · Bloque gigante', towerfall: 'Torre · Se cae',
  defused: 'Bomba · Desactivada', toss: 'Bomba · Pase', fusejoin: 'Bomba · Se une', bombtick: 'Bomba · Reloj', bombshield: 'Bomba · Escudo',
  legendfish: 'Pesca · Legendario', epicfish: 'Pesca · Épico', fishschool: 'Pesca · Cardumen', trash: 'Pesca · Basura', escape: 'Pesca · Se escapa',
  evolve: 'Mascota · Evoluciona', xp: 'Mascota · Experiencia',
  checkered: 'Carrera · Bandera a cuadros', overtake: 'Carrera · Adelanta', slip: 'Carrera · Resbalón', nudge: 'Carrera · Empujón', raceevent: 'Carrera · Evento', raceshield: 'Carrera · Escudo',
  growgiant: 'Muñequitos · Gigante', grow: 'Muñequitos · Crece', dance: 'Muñequitos · Baile',
  jarfull: 'Frasco · Lleno', heartfull: 'Corazón · Meta llena', newking: 'Ranking · Nuevo líder',
  victorydrums: 'Batalla · Victoria', double: 'Batalla · Puntos dobles', tugwar: 'Batalla · Cambio de líder',
  finalbuzz: 'Subathon · Final', timex2: 'Subathon · Tiempo x2',
  bingonear: 'Bingo · ¡Casi bingo!', bingoopen: 'Bingo · Abre', bingotick: 'Bingo · Reloj', bingocard: 'Bingo · Cartón',
  bigwin: 'Tragamonedas · Gran premio', nearmiss: 'Tragamonedas · Casi', smallwin: 'Tragamonedas · Premio', slotlose: 'Tragamonedas · Nada',
  streak: 'Penales · Racha', wide: 'Penales · Afuera', post: 'Penales · Palo', firekick: 'Penales · Tiro de fuego',
  outbid: 'Subasta · Nuevo líder', snipe: 'Subasta · Último segundo', auctiontick: 'Subasta · Reloj',
  royaleentry: 'Royale · Entra', royalespin: 'Royale · Giro', duel: 'Royale · Duelo final',
  wheelready: 'Ruleta · Lista', luckyprize: 'Lucky Roll · Premio',
  redeem: 'Puntos · Canje', denied: 'Puntos · Sin puntos',
  bossspawn: 'Jefe · Aparece', bossrage: 'Jefe · Furia', bosshit: 'Jefe · Golpe',
};
function sfx2(name, t, T, N, seq) {
  const R = (a, b) => a + Math.random() * (b - a);
  switch (name) {
    // ---- exclusivos de cofres y diseños exclusivos ----
    case 'x_monedas': for (let i = 0; i < 14; i++) { const f = 1800 + Math.random() * 900; T(f, t + i * .06, .09, 'square', .07); T(f * 1.5, t + i * .06 + .03, .12, 'sine', .06); } T(2093, t + .9, .6, 'triangle', .15); return true;
    case 'x_8bit': seq([523, 659, 784, 1047, 784, 1047], .08, 'square', .12, .1); T(1319, t + .5, .45, 'square', .12); T(1047, t + .5, .45, 'square', .08); return true;
    case 'x_glitch': for (let i = 0; i < 10; i++) { T(200 + Math.random() * 1800, t + i * .035, .04, i % 2 ? 'square' : 'sawtooth', .1); N(t + i * .035, .02, .2, 'bandpass', 3000, 1000); } T(110, t + .38, .3, 'square', .15, 55); return true;
    case 'x_trueno': N(t, .05, .9, 'highpass', 3000, 8000); N(t + .03, 1.6, .7, 'lowpass', 900, 60); T(55, t + .05, 1.4, 'sine', .5, 30); return true;
    case 'x_coro': [262, 330, 392, 523, 659].forEach((f, i) => { T(f, t + i * .04, 1.6, 'sine', .1); T(f * 1.003, t + i * .04, 1.6, 'triangle', .05); }); N(t, 1.4, .06, 'bandpass', 2500, 3500); return true;
    case 'x_dragon': T(90, t, 1.3, 'sawtooth', .22, 45); T(135, t + .05, 1.1, 'sawtooth', .12, 70); N(t, 1.3, .45, 'bandpass', 700, 180); N(t + .9, .6, .3, 'lowpass', 2000, 200); return true;
    case 'waves': N(t, 1.4, .3, 'lowpass', 400, 1400); N(t + .7, 1, .2, 'lowpass', 1200, 300); T(880, t + .3, .2, 'sine', .06, 1320); return true;
    case 'inferno': N(t, .9, .5, 'lowpass', 2500, 300); T(110, t, .8, 'sawtooth', .14, 70); for (let i = 0; i < 6; i++) N(t + .1 + i * .1, .04, .3, 'highpass', 2000, 4000); return true;
    case 'cosmic': for (let i = 0; i < 8; i++) T(600 * Math.pow(1.19, i), t + i * .07, .5, 'sine', .08); T(2349, t + .6, .9, 'sine', .07, 1175); return true;
    case 'royalgold': seq([523, 659, 784, 1047], .1, 'triangle', .18, .35); for (let i = 0; i < 8; i++) T(1568 + Math.random() * 1000, t + .45 + i * .05, .1, 'sine', .07); return true;
    // ---- Adivina: máquina de escribir y timbre de recepción ----
    case 'wordright': for (let i = 0; i < 3; i++) N(t + i * .05, .03, .3, 'bandpass', 3000, 2500); T(2093, t + .18, .6, 'sine', .25); T(2637, t + .18, .45, 'sine', .1); seq([784, 1047, 1319], .06, 'triangle', .14, .25); return true;
    case 'wordstart': for (let i = 0; i < 6; i++) N(t + i * .055, .025, .26, 'bandpass', 2600 + i * 100, 2200); N(t + .36, .12, .3, 'highpass', 2000, 6000); T(1760, t + .4, .3, 'sine', .14); return true;
    case 'almost': T(523, t, .14, 'triangle', .25); T(622, t + .14, .14, 'triangle', .25); T(587, t + .3, .4, 'triangle', .22, 560); return true;
    case 'nope': T(330, t, .09, 'square', .14); T(247, t + .1, .2, 'square', .14, 200); return true;
    case 'wordtick': N(t, .02, .3, 'bandpass', 3500, 3000); return true;
    // ---- Trivia: show de concurso ----
    case 'quizchamp': seq([523, 659, 784, 1047, 784, 1047], .09, 'square', .1, .14); [523, 659, 784, 1047].forEach(f => T(f, t + .58, 1.1, 'triangle', .1)); N(t + .58, 1, .12, 'highpass', 5000, 9000); return true;
    case 'lockin': T(196, t, .06, 'square', .2); T(1175, t + .05, .25, 'sine', .22); T(1760, t + .05, .18, 'sine', .08); return true;
    case 'quiztick': T(2200, t, .025, 'sine', .14); T(1100, t + .005, .03, 'square', .05); return true;
    // ---- Votación: urna y sello ----
    case 'pollwin': N(t, .08, .5, 'lowpass', 900, 200); T(110, t, .12, 'sine', .4, 60); seq([587, 740, 880, 1175], .11, 'triangle', .2, .5); N(t + .3, .9, .14, 'bandpass', 1500, 2500); return true;
    case 'pollopen': T(330, t, .08, 'square', .1); N(t + .05, .25, .2, 'bandpass', 600, 1500); T(659, t + .25, .35, 'sine', .2); T(880, t + .32, .4, 'sine', .14); return true;
    case 'pollswing': N(t, .25, .22, 'bandpass', 400, 2400); T(440, t + .1, .18, 'triangle', .18, 660); return true;
    case 'votegift': T(1175, t, .06, 'triangle', .2); N(t + .05, .07, .35, 'lowpass', 700, 200); T(1568, t + .08, .2, 'sine', .14); return true;
    case 'pollclose': T(98, t, .12, 'sine', .5, 70); N(t, .1, .5, 'lowpass', 600, 150); T(587, t + .2, .5, 'triangle', .16); T(440, t + .2, .5, 'triangle', .1); return true;
    // ---- Piedra, papel o tijera ----
    case 'rpschamp': for (let i = 0; i < 3; i++) N(t + i * .12, .06, .4, 'bandpass', 1200, 4000); seq([659, 880, 1109, 1319], .1, 'sawtooth', .09, .3); T(1319, t + .45, .9, 'triangle', .2); T(1760, t + .45, .9, 'sine', .08); return true;
    case 'rpsstart': for (let i = 0; i < 3; i++) { T(150, t + i * .22, .1, 'sine', .4, 90); N(t + i * .22, .05, .3, 'lowpass', 1200, 300); } T(988, t + .66, .25, 'square', .12); return true;
    case 'rpstie': N(t, .08, .4, 'bandpass', 1400, 3000); T(587, t, .2, 'triangle', .18); T(587, t + .2, .25, 'triangle', .16, 500); return true;
    case 'rpspick': N(t, .04, .35, 'highpass', 2000, 5000); T(880, t, .06, 'sine', .14); return true;
    case 'rpstick': T(990, t, .03, 'triangle', .14); T(660, t + .06, .03, 'triangle', .1); return true;
    case 'rpslose': T(392, t, .18, 'sawtooth', .1, 330); T(311, t + .2, .4, 'sawtooth', .1, 260); return true;
    case 'rpswin': N(t, .06, .4, 'bandpass', 1500, 4500); T(784, t + .04, .12, 'square', .1); T(1175, t + .14, .3, 'square', .1); return true;
    // ---- Castillos ----
    case 'castlewin': [0, .18, .36].forEach((d, i) => T([392, 523, 659][i], t + d, .3, 'sawtooth', .12)); [392, 523, 659, 784].forEach(f => T(f, t + .55, 1.3, 'sawtooth', .07)); T(98, t + .55, 1.2, 'sine', .4); N(t + .55, .3, .3, 'lowpass', 800, 100); return true;
    // ---- PK: campana de ring ----
    case 'pkwin': for (let i = 0; i < 3; i++) { T(1320, t + i * .16, .5, 'sine', .25); T(2650, t + i * .16, .3, 'sine', .08); } seq([523, 784, 1047], .1, 'sawtooth', .1, .5); return true;
    case 'pkdraw': T(1320, t, .6, 'sine', .25); T(1320, t + .3, .7, 'sine', .2); T(880, t + .3, .7, 'triangle', .12); return true;
    case 'pkswing': N(t, .22, .3, 'bandpass', 2500, 300); T(220, t + .12, .18, 'sine', .3, 110); return true;
    case 'lastseconds': for (let i = 0; i < 8; i++) T(i % 2 ? 1046 : 1397, t + i * .09, .07, 'square', .12); return true;
    case 'pklose': T(220, t, .25, 'square', .1, 180); T(165, t + .25, .5, 'square', .1, 110); return true;
    case 'pkstart': T(1320, t, 1, 'sine', .3); T(2650, t, .6, 'sine', .1); N(t + .05, .5, .2, 'bandpass', 800, 1500); return true;
    // ---- Sorteo ----
    case 'rafflewin': N(t, .05, .6, 'lowpass', 1500, 200); T(80, t, .2, 'sine', .5, 50); for (let i = 0; i < 8; i++) T(1568 + i * 220, t + .12 + i * .05, .25, 'sine', .1); T(2093, t + .55, .8, 'triangle', .15); return true;
    case 'confirm': T(1047, t, .08, 'sine', .2); T(1568, t + .08, .25, 'sine', .2); return true;
    case 'raffleopen': N(t, .2, .3, 'highpass', 2500, 7000); seq([784, 988, 1175], .07, 'sine', .18, .3); return true;
    case 'raffleloss': T(196, t, .35, 'triangle', .3, 175); T(185, t + .35, .6, 'triangle', .26, 150); return true;
    // ---- Torre ----
    case 'towerwin': seq([262, 330, 392, 523, 659, 784, 1047, 1319], .06, 'square', .08, .12); T(1319, t + .5, .8, 'triangle', .2); N(t + .5, .6, .1, 'highpass', 5000, 9000); return true;
    case 'giantblock': T(70, t, .4, 'sine', .7, 35); N(t, .3, .5, 'lowpass', 500, 80); T(140, t + .05, .2, 'square', .12, 70); return true;
    case 'towerfall': for (let i = 0; i < 6; i++) N(t + i * .09, .2, .4 - i * .04, 'lowpass', 900 - i * 100, 150); T(300, t, .9, 'sawtooth', .1, 60); return true;
    // ---- Bomba ----
    case 'defused': N(t, .03, .5, 'highpass', 3000, 6000); T(1800, t, .05, 'square', .1); seq([392, 523, 659, 784], .09, 'triangle', .2, .5); return true;
    case 'toss': N(t, .18, .3, 'bandpass', 600, 3500); T(300, t, .18, 'sine', .15, 900); return true;
    case 'fusejoin': N(t, .3, .18, 'bandpass', 4000, 6000); T(660, t, .08, 'triangle', .16); return true;
    case 'bombtick': T(1600, t, .02, 'square', .18); T(800, t + .01, .04, 'sine', .1); return true;
    case 'bombshield': T(440, t, .35, 'sine', .2, 1320); T(660, t + .05, .35, 'sine', .14, 1980); N(t, .3, .1, 'highpass', 4000, 8000); return true;
    // ---- Pesca ----
    case 'legendfish': N(t, .3, .45, 'lowpass', 2000, 200); seq([294, 440, 587, 740, 880], .1, 'triangle', .18, .6); T(147, t + .5, 1, 'sine', .3); N(t + .5, 1, .1, 'highpass', 6000, 10000); return true;
    case 'epicfish': N(t, .22, .35, 'lowpass', 1800, 300); seq([440, 554, 659, 880], .08, 'triangle', .18, .4); return true;
    case 'fishschool': for (let i = 0; i < 6; i++) T(R(600, 1400), t + i * .06, .12, 'sine', .12, R(900, 1800)); return true;
    case 'trash': T(140, t, .2, 'square', .12, 100); N(t + .05, .15, .3, 'bandpass', 500, 300); T(110, t + .2, .3, 'square', .1, 80); return true;
    case 'escape': N(t, .25, .3, 'lowpass', 1500, 300); T(600, t, .3, 'sine', .2, 150); return true;
    // ---- Mascota ----
    case 'evolve': for (let i = 0; i < 12; i++) T(400 * Math.pow(1.12, i), t + i * .05, .2, 'sine', .1); T(1760, t + .6, .9, 'triangle', .18); T(2637, t + .6, .9, 'sine', .08); return true;
    case 'xp': T(1319, t, .05, 'sine', .14); T(1760, t + .04, .1, 'sine', .12); return true;
    // ---- Carrera ----
    case 'checkered': T(90, t, .6, 'sawtooth', .12, 300); seq([523, 659, 784, 1047], .1, 'square', .1, .3); T(1047, t + .7, .8, 'triangle', .2); N(t + .7, .8, .15, 'bandpass', 1200, 2500); return true;
    case 'overtake': T(180, t, .45, 'sawtooth', .1, 520); N(t, .3, .2, 'bandpass', 800, 2500); return true;
    case 'slip': T(900, t, .25, 'sine', .25, 200); N(t + .2, .12, .3, 'lowpass', 600, 120); return true;
    case 'nudge': T(220, t, .12, 'sine', .3, 360); T(360, t + .1, .1, 'sine', .14, 260); return true;
    case 'raceevent': for (let i = 0; i < 2; i++) { T(880, t + i * .3, .14, 'square', .1); T(660, t + i * .3 + .15, .14, 'square', .1); } return true;
    case 'raceshield': T(520, t, .4, 'triangle', .16, 1560); N(t + .1, .3, .12, 'highpass', 3000, 7000); return true;
    // ---- Muñequitos ----
    case 'growgiant': T(60, t, .5, 'sine', .7, 40); N(t, .25, .5, 'lowpass', 400, 60); T(100, t + .45, .5, 'sine', .6, 50); N(t + .45, .25, .45, 'lowpass', 400, 60); return true;
    case 'grow': T(300, t, .35, 'square', .1, 900); T(450, t + .05, .35, 'sine', .1, 1350); return true;
    case 'dance': seq([523, 659, 523, 784, 659, 880], .09, 'square', .1, .1); N(t, .04, .3, 'lowpass', 300, 80); N(t + .27, .04, .3, 'lowpass', 300, 80); return true;
    // ---- Frasco, corazón y ranking ----
    case 'jarfull': for (let i = 0; i < 10; i++) T(700 + i * 120, t + i * .045, .12, 'sine', .14); T(2093, t + .5, .9, 'sine', .14); T(3136, t + .5, .6, 'sine', .05); return true;
    case 'heartfull': T(70, t, .14, 'sine', .8, 45); T(60, t + .2, .18, 'sine', .6, 40); seq([659, 784, 988, 1319], .1, 'sine', .2, .6); return true;
    case 'newking': T(196, t, .25, 'sawtooth', .1); T(262, t + .25, .25, 'sawtooth', .1); T(392, t + .5, .8, 'sawtooth', .1); T(784, t + .5, .8, 'triangle', .14); return true;
    // ---- Batalla ----
    case 'victorydrums': for (let i = 0; i < 6; i++) { T(90, t + i * .1, .15, 'sine', .45, 55); N(t + i * .1, .06, .3, 'lowpass', 900, 200); } seq([392, 494, 587, 784], .08, 'sawtooth', .09, .6); return true;
    case 'double': T(523, t, .1, 'square', .12); T(523, t + .12, .1, 'square', .12); T(1047, t + .24, .35, 'square', .12); return true;
    case 'tugwar': N(t, .35, .25, 'bandpass', 300, 1800); T(160, t, .35, 'sawtooth', .08, 320); return true;
    // ---- Subathon ----
    case 'finalbuzz': T(98, t, 1.2, 'sawtooth', .16); T(147, t, 1.2, 'sawtooth', .1); N(t + 1, .8, .2, 'bandpass', 1000, 2000); return true;
    case 'timex2': T(1800, t, .03, 'square', .14); T(1350, t + .1, .03, 'square', .14); T(784, t + .2, .12, 'square', .12); T(1568, t + .32, .3, 'square', .12); return true;
    // ---- Bingo ----
    case 'bingonear': for (let i = 0; i < 4; i++) T(988 + i * 30, t + i * .14, .1, 'triangle', .2); return true;
    case 'bingoopen': N(t, .4, .25, 'bandpass', 1500, 2500); T(659, t + .3, .3, 'sine', .2); T(988, t + .38, .4, 'sine', .14); return true;
    case 'bingotick': N(t, .03, .25, 'bandpass', 2200, 1800); return true;
    case 'bingocard': N(t, .1, .3, 'highpass', 1500, 4000); T(1175, t + .08, .1, 'triangle', .16); return true;
    // ---- Tragamonedas ----
    case 'bigwin': for (let i = 0; i < 16; i++) T(1568 + (i % 4) * 200, t + i * .05, .08, 'square', .08); seq([523, 659, 784, 1047], .1, 'triangle', .2, .9); return true;
    case 'nearmiss': T(784, t, .1, 'square', .1); T(784, t + .12, .1, 'square', .1); T(740, t + .24, .4, 'square', .1, 600); return true;
    case 'smallwin': T(1319, t, .06, 'square', .12); T(1568, t + .07, .06, 'square', .12); T(2093, t + .14, .2, 'square', .1); return true;
    case 'slotlose': T(220, t, .15, 'triangle', .2); T(196, t + .15, .3, 'triangle', .18); return true;
    // ---- Penales ----
    case 'streak': N(t, .6, .25, 'bandpass', 800, 1600); seq([587, 784, 988, 1175], .08, 'square', .1, .3); return true;
    case 'wide': [220, 277, 330].forEach(f => T(f, t, .9, 'sawtooth', .05, f * .8)); N(t, .9, .12, 'bandpass', 700, 500); return true;
    case 'post': T(1250, t, .9, 'sine', .25); T(1873, t, .6, 'sine', .12); N(t, .05, .4, 'highpass', 2000, 6000); return true;
    case 'firekick': N(t, .7, .45, 'lowpass', 3000, 200); T(200, t, .5, 'sawtooth', .12, 60); T(60, t + .1, .5, 'sine', .4, 40); return true;
    // ---- Subasta ----
    case 'outbid': T(1047, t, .07, 'triangle', .2); T(1397, t + .07, .07, 'triangle', .2); N(t + .12, .08, .25, 'highpass', 3000, 7000); T(1760, t + .14, .25, 'triangle', .16); return true;
    case 'snipe': N(t, .12, .3, 'highpass', 2000, 8000); T(2500, t, .12, 'sine', .15, 600); N(t + .12, .05, .35, 'lowpass', 900, 200); return true;
    case 'auctiontick': T(1200, t, .03, 'sine', .14); N(t, .02, .2, 'bandpass', 2500, 2000); return true;
    // ---- Spin Royale, Ruleta y Lucky Roll ----
    case 'royaleentry': T(784, t, .07, 'sine', .2); T(1175, t + .07, .14, 'sine', .2); T(1568, t + .14, .2, 'sine', .1); return true;
    case 'royalespin': N(t, .03, .35, 'bandpass', 1800, 1500); T(600, t, .04, 'triangle', .14); return true;
    case 'duel': T(73, t, .9, 'sawtooth', .12); T(110, t, .9, 'sawtooth', .08); for (let i = 0; i < 3; i++) N(t + .2 + i * .2, .08, .3, 'lowpass', 600, 150); T(1760, t + .8, .5, 'sine', .1); return true;
    case 'wheelready': seq([659, 880], .1, 'triangle', .2, .3); N(t, .25, .2, 'bandpass', 1500, 4000); return true;
    case 'luckyprize': seq([988, 1319, 1760], .07, 'sine', .22, .25); N(t + .2, .3, .1, 'highpass', 5000, 9000); return true;
    // ---- Puntos ----
    case 'redeem': N(t, .06, .3, 'highpass', 2500, 5000); seq([1047, 1319, 1568, 2093], .05, 'triangle', .14, .2); return true;
    case 'denied': T(180, t, .12, 'square', .12); T(180, t + .16, .2, 'square', .12); return true;
    // ---- Jefe ----
    case 'bossspawn': T(55, t, 1.2, 'sawtooth', .18, 40); T(82, t + .1, 1, 'sawtooth', .1); N(t, 1.2, .25, 'lowpass', 400, 80); T(1100, t + .6, .6, 'sine', .06, 400); return true;
    case 'bossrage': T(120, t, .8, 'sawtooth', .2, 60); N(t, .8, .35, 'bandpass', 500, 200); T(180, t + .1, .6, 'square', .1, 90); return true;
    case 'bosshit': N(t, .06, .55, 'bandpass', 3000, 900); T(95, t, .2, 'sawtooth', .22, 50); T(1480, t, .35, 'sine', .1, 1380); T(2210, t, .25, 'sine', .05); return true;
  }
  return false;
}
Object.assign(SFX, SFX2_LABELS);
// Sonidos exclusivos de los cofres de Chispas (solo salen en la lista si ya los ganaste)
const SFX_EXCL = { x_monedas: '🎁 Lluvia de monedas', x_8bit: '🎁 Victoria 8-bit', x_glitch: '🎁 Glitch digital', x_trueno: '🎁 Trueno épico', x_coro: '🎁 Coro celestial', x_dragon: '🎁 Rugido legendario' };
Object.assign(SFX, SFX_EXCL);
// en el panel: un sonido exclusivo solo aparece en las listas si ya lo ganaste en un cofre
const sfxOk = (v, sel) => !SFX_EXCL[v] || v === sel || (window.CHISPAS?.owned?.snds || []).includes(v);
const skinOk = id => !DESIGN_SKINS[id]?.excl || (window.CHISPAS?.owned?.skins || []).includes(id);
let _ctx;
const ac = () => (_ctx = _ctx || new (window.AudioContext || window.webkitAudioContext)());
function _tone(f, t, d, type = 'triangle', g = .3, f2 = null) {
  const c = ac(), o = c.createOscillator(), gn = c.createGain();
  o.type = type; o.frequency.setValueAtTime(f, t); if (f2) o.frequency.exponentialRampToValueAtTime(f2, t + d);
  gn.gain.setValueAtTime(.0001, t); gn.gain.exponentialRampToValueAtTime(Math.max(.0002, g), t + .015); gn.gain.exponentialRampToValueAtTime(.0001, t + d);
  o.connect(gn).connect(_out); o.start(t); o.stop(t + d + .05);
}
function _noise(t, d, g = .3, type = 'lowpass', f1 = 1200, f2 = 200) {
  const c = ac(), b = c.createBuffer(1, c.sampleRate * d, c.sampleRate), data = b.getChannelData(0);
  for (let i = 0; i < data.length; i++) data[i] = Math.random() * 2 - 1;
  const s = c.createBufferSource(), fl = c.createBiquadFilter(), gn = c.createGain();
  s.buffer = b; fl.type = type; fl.frequency.setValueAtTime(f1, t); fl.frequency.exponentialRampToValueAtTime(f2, t + d);
  gn.gain.setValueAtTime(g, t); gn.gain.exponentialRampToValueAtTime(.0001, t + d);
  s.connect(fl).connect(gn).connect(_out); s.start(t);
}
let _out;
function synth(name, vol = .6) {
  if (previewMuted()) return;
  try {
    const c = ac(); if (c.state === 'suspended') c.resume();
    _out = c.createGain(); _out.gain.value = Math.max(0, Math.min(1, vol)); _out.connect(c.destination);
    const t = c.currentTime + .01;
    const seq = (notes, step, type, g, dur) => notes.forEach((f, i) => _tone(f, t + i * step, dur || step * 1.6, type, g));
    switch (name) {
      case 'tick': _tone(1400, t, .04, 'square', .12); break;
      case 'pop': _tone(500, t, .08, 'sine', .4, 1100); break;
      case 'coin': _tone(988, t, .08, 'square', .18); _tone(1319, t + .08, .3, 'square', .18); break;
      case 'gift': seq([660, 880, 1320], .09, 'triangle', .3, .3); break;
      case 'bell': _tone(880, t, 1.2, 'sine', .35); _tone(1760, t, .8, 'sine', .12); _tone(2640, t, .4, 'sine', .06); break;
      case 'win': seq([523, 659, 784, 1046], .1, 'triangle', .3, .35); break;
      case 'fanfare': seq([392, 523, 659], .12, 'sawtooth', .12, .2); [523, 659, 784].forEach(f => _tone(f, t + .38, .9, 'sawtooth', .1)); _tone(1046, t + .38, .9, 'triangle', .2); break;
      case 'levelup': seq([523, 659, 784, 1046, 1319, 1568, 2093], .05, 'square', .12, .12); break;
      case 'magic': for (let i = 0; i < 12; i++) _tone(1200 + Math.random() * 1800, t + i * .05, .4, 'sine', .12); break;
      case 'whoosh': _noise(t, .45, .5, 'bandpass', 300, 3000); break;
      case 'boom': _noise(t, .8, .8, 'lowpass', 900, 60); _tone(120, t, .6, 'sine', .6, 40); break;
      case 'oof': _tone(320, t, .35, 'sawtooth', .25, 110); _noise(t, .25, .2, 'lowpass', 600, 100); break;
      case 'airhorn': [0, .28, .56].forEach((d, i) => { _tone(466, t + d, i === 2 ? .7 : .22, 'sawtooth', .18); _tone(470, t + d, i === 2 ? .7 : .22, 'sawtooth', .18); }); break;
      case 'drum': for (let i = 0; i < 16; i++) _noise(t + i * .055, .07, .25 + i * .02, 'highpass', 900, 600); _noise(t + .9, .5, .7, 'lowpass', 600, 80); break;
      case 'laser': _tone(1800, t, .25, 'sawtooth', .2, 200); break;
      case 'boing': _tone(180, t, .5, 'sine', .45, 600); _tone(600, t + .25, .25, 'sine', .2, 300); break;
      // --- diseños de temporada ---
      case 'jingle': for (let i = 0; i < 6; i++) { const d = i * .13; _noise(t + d, .07, .22, 'highpass', 7000, 9000); _tone(2637, t + d, .12, 'sine', .1); _tone(3136, t + d, .1, 'sine', .07); } seq([1319, 1319, 1319, 1319, 1319, 1319, 1319, 1568, 1047, 1175, 1319], .13, 'triangle', .13, .2); break;
      case 'spooky': seq([622, 587, 554, 523, 494, 466], .11, 'sine', .2, .3); _tone(110, t, 1.2, 'triangle', .25, 70); [0, .12, .24, .36, .5].forEach((d, i) => _tone(520 - i * 45, t + .75 + d, .1, 'sawtooth', .12, 380 - i * 40)); _noise(t, 1.2, .08, 'bandpass', 400, 900); break;
      case 'kawaii': seq([1047, 1319, 1568, 2093, 2637, 3136], .06, 'sine', .16, .35); for (let i = 0; i < 8; i++) _tone(2400 + Math.random() * 2200, t + .3 + i * .05, .25, 'sine', .07); break;
      case 'firework': _tone(500, t, .45, 'sine', .14, 2400); _noise(t + .45, .5, .7, 'lowpass', 3000, 150); _tone(90, t + .45, .4, 'sine', .5, 40); for (let i = 0; i < 16; i++) _noise(t + .6 + i * .045 + Math.random() * .03, .04, .16, 'highpass', 4000, 6000); break;
      case 'kiss': seq([784, 988, 1175, 1568], .08, 'sine', .2, .45); _tone(1568, t + .32, .7, 'triangle', .12); _tone(2349, t + .4, .6, 'sine', .08); break;
      // --- batalla ---
      case 'cannon': _noise(t, .12, .9, 'lowpass', 2400, 300); _noise(t + .02, .5, .6, 'lowpass', 500, 50); _tone(150, t, .35, 'sine', .7, 38); break;
      case 'impact': _noise(t, .22, .7, 'lowpass', 1400, 120); _tone(95, t, .25, 'sine', .55, 45); for (let i = 0; i < 4; i++) _noise(t + .08 + i * .06, .05, .18, 'bandpass', 1800 + Math.random() * 1500, 900); break;
      case 'arrow': for (let i = 0; i < 3; i++) _noise(t + i * .07, .16, .28, 'bandpass', 2600, 900); for (let i = 0; i < 3; i++) _tone(210, t + .42 + i * .07, .06, 'square', .14, 120); break;
      case 'meteor': _noise(t, 1.3, .9, 'lowpass', 1600, 40); _tone(90, t, 1.1, 'sine', .8, 28); _tone(55, t + .05, .9, 'triangle', .5, 30); for (let i = 0; i < 8; i++) _noise(t + .25 + i * .09, .12, .22, 'bandpass', 900 + Math.random() * 1200, 300); break;
      case 'roar': _tone(140, t, 1.1, 'sawtooth', .28, 60); _tone(147, t, 1.1, 'sawtooth', .22, 52); _tone(70, t, 1.2, 'square', .16, 45); _noise(t, 1.1, .4, 'bandpass', 500, 180); _noise(t + .9, .9, .45, 'highpass', 1200, 2600); break;
      case 'shieldup': seq([523, 784, 1046, 1568], .06, 'sine', .22, .5); _tone(2093, t + .24, .9, 'sine', .12); _noise(t, .5, .12, 'highpass', 4000, 7000); break;
      case 'clang': [1200, 1810, 2630, 3420].forEach((f, i) => _tone(f, t, .5 - i * .08, 'square', .09 - i * .015)); _noise(t, .05, .4, 'highpass', 3000, 2000); break;
      case 'hammer': [0, .16, .32].forEach(d => { _tone(880, t + d, .09, 'square', .14, 500); _noise(t + d, .04, .35, 'highpass', 2500, 1500); }); seq([784, 988, 1175], .07, 'triangle', .18, .3); break;
      case 'crumble': _noise(t, 1.1, .7, 'lowpass', 900, 70); for (let i = 0; i < 12; i++) { _noise(t + i * .08 + Math.random() * .04, .07, .3, 'bandpass', 500 + Math.random() * 900, 250); _tone(70 + Math.random() * 50, t + i * .08, .1, 'sine', .25, 40); } break;
      case 'horn': _tone(147, t, 1.5, 'sawtooth', .2, 150); _tone(220, t + .08, 1.4, 'sawtooth', .16, 222); _tone(294, t + .5, 1.0, 'sawtooth', .1); _noise(t, 1.4, .08, 'bandpass', 600, 500); break;
      // --- propios de cada juego ---
      case 'bingoball': for (let i = 0; i < 7; i++) _noise(t + i * .045, .04, .22, 'bandpass', 1800 + i * 150, 900); _tone(520, t + .34, .08, 'sine', .3, 820); _tone(1240, t + .42, .25, 'sine', .22); _tone(1860, t + .42, .2, 'sine', .08); break;
      case 'bingo': seq([523, 659, 784, 1046], .09, 'square', .14, .18); [523, 659, 784, 1046, 1319].forEach(f => _tone(f, t + .42, 1.1, 'sawtooth', .07)); _tone(2093, t + .42, 1, 'triangle', .14); for (let i = 0; i < 6; i++) _noise(t + .5 + i * .12, .5, .12, 'bandpass', 500 + i * 220, 1800); break;
      case 'rpsshake': [0, .32, .64].forEach((d, i) => { _noise(t + d, .07, .5, 'lowpass', 900, 160); _tone(150, t + d, .1, 'sine', .55, 70); _tone(660 + i * 110, t + d + .02, .09, 'square', .1); }); break;
      case 'rpsclash': _noise(t, .12, .8, 'bandpass', 1400, 5000); _tone(220, t, .18, 'sawtooth', .3, 80); _tone(1760, t + .02, .35, 'triangle', .14, 1200); for (let i = 0; i < 5; i++) _tone(2400 + Math.random() * 1600, t + .05 + i * .03, .12, 'sine', .07); break;
      case 'bid': _noise(t, .05, .3, 'highpass', 5000, 7000); _tone(1568, t + .05, .09, 'square', .14); _tone(2093, t + .13, .35, 'square', .14); _tone(3136, t + .13, .3, 'sine', .08); break;
      case 'gavel': [0, .22].forEach(d => { _tone(190, t + d, .12, 'square', .3, 90); _noise(t + d, .05, .6, 'lowpass', 1800, 400); }); [523, 659, 784, 1046].forEach(f => _tone(f, t + .55, .8, 'sawtooth', .07)); _tone(1568, t + .55, .7, 'triangle', .12); break;
      case 'ratchet': _tone(900, t, .025, 'square', .14, 500); _noise(t, .02, .25, 'highpass', 3000, 2000); break;
      case 'sword': _noise(t, .22, .5, 'bandpass', 1200, 6000); _tone(2400, t + .16, .5, 'triangle', .1, 2000); _tone(3300, t + .16, .4, 'sine', .07); break;
      case 'crown': seq([392, 392, 523, 659], .13, 'sawtooth', .11, .18); [523, 659, 784, 1046].forEach(f => _tone(f, t + .55, 1.2, 'sawtooth', .08)); _tone(1568, t + .55, 1.1, 'triangle', .16); for (let i = 0; i < 8; i++) _tone(2000 + Math.random() * 2000, t + .7 + i * .07, .3, 'sine', .06); break;
      case 'dice': _tone(700 + Math.random() * 500, t, .025, 'square', .12, 300); _noise(t, .03, .3, 'bandpass', 2500, 1200); _tone(500 + Math.random() * 300, t + .045, .02, 'square', .08, 250); break;
      case 'treasure': for (let i = 0; i < 14; i++) { const f = 1200 + Math.random() * 1400; _tone(f, t + i * .05, .12, 'square', .07); _tone(f * 1.5, t + i * .05 + .02, .1, 'sine', .05); } [523, 659, 784, 1046].forEach(f => _tone(f, t + .55, 1.0, 'triangle', .14)); _tone(2093, t + .55, .9, 'sine', .1); break;
      case 'creak': _tone(110, t, .7, 'sawtooth', .14, 190); _tone(113, t + .03, .65, 'sawtooth', .1, 205); _noise(t, .7, .08, 'bandpass', 700, 1400); for (let i = 0; i < 8; i++) _tone(1500 + i * 220, t + .7 + i * .04, .3, 'sine', .08); break;
      case 'sadtrombone': [311, 294, 277].forEach((f, i) => _tone(f, t + i * .28, .26, 'sawtooth', .16)); _tone(262, t + .84, .8, 'sawtooth', .16, 233); break;
      case 'clink': _tone(2200 + Math.random() * 600, t, .18, 'sine', .2); _tone(3400 + Math.random() * 500, t + .01, .12, 'sine', .1); _noise(t, .02, .2, 'highpass', 6000, 5000); break;
      case 'gong': [110, 165, 223, 331, 440].forEach((f, i) => _tone(f, t, 2 - i * .25, 'sine', .3 - i * .05)); _noise(t, .3, .3, 'lowpass', 1500, 200); break;
      case 'punch': _noise(t, .09, .6, 'lowpass', 1000, 150); _tone(160, t, .12, 'sine', .5, 60); break;
      case 'startgun': _noise(t, .06, .9, 'highpass', 2000, 800); _noise(t, .35, .5, 'lowpass', 1800, 150); _tone(180, t, .15, 'square', .3, 50); break;
      case 'turbo': _tone(120, t, .9, 'sawtooth', .16, 900); _tone(124, t, .9, 'sawtooth', .12, 930); _noise(t, .9, .3, 'bandpass', 400, 4000); break;
      case 'slash': _noise(t, .15, .55, 'bandpass', 900, 7000); _noise(t + .1, .12, .4, 'highpass', 5000, 3000); _tone(1800, t + .1, .2, 'sawtooth', .08, 600); break;
      case 'bossdown': _tone(200, t, .9, 'sawtooth', .25, 40); _noise(t, .9, .5, 'lowpass', 800, 60); [523, 659, 784, 1046, 1319].forEach((f, i) => _tone(f, t + .9 + i * .09, .2, 'square', .1)); _tone(1568, t + 1.35, .8, 'triangle', .16); break;
      case 'quiz': seq([659, 784, 988], .1, 'triangle', .22, .25); _tone(1319, t + .3, .6, 'sine', .18); break;
      case 'correct': _tone(1047, t, .15, 'sine', .3); _tone(1319, t + .12, .15, 'sine', .3); _tone(1568, t + .24, .6, 'sine', .3); _tone(3136, t + .24, .5, 'sine', .08); break;
      case 'munch': [0, .14, .28].forEach(d => { _noise(t + d, .07, .45, 'bandpass', 900, 400); _tone(260, t + d, .06, 'square', .1, 150); }); break;
      case 'whine': _tone(700, t, .35, 'sine', .2, 420); _tone(620, t + .4, .5, 'sine', .2, 330); break;
      case 'ballot': _tone(880, t, .06, 'sine', .25, 1320); _tone(1320, t + .06, .1, 'sine', .18); break;
      case 'kick': _noise(t, .07, .7, 'lowpass', 1400, 200); _tone(130, t, .14, 'sine', .6, 55); _noise(t + .05, .25, .2, 'bandpass', 600, 2500); break;
      case 'crowd': for (let i = 0; i < 5; i++) _noise(t + i * .12, 1.5, .2, 'bandpass', 500 + i * 200, 1800); seq([523, 659, 784], .12, 'sawtooth', .08, .25); _tone(1046, t + .36, .8, 'sawtooth', .1); break;
      case 'glove': _noise(t, .1, .6, 'lowpass', 700, 150); _tone(110, t, .14, 'sine', .5, 60); _tone(300, t + .1, .3, 'sawtooth', .12, 140); break;
      case 'lever': _tone(300, t, .12, 'square', .12, 120); _noise(t, .08, .3, 'lowpass', 1500, 300); for (let i = 0; i < 8; i++) _tone(600 + i * 90, t + .15 + i * .05, .03, 'square', .09); break;
      case 'reelstop': _tone(220, t, .07, 'square', .2, 110); _noise(t, .04, .4, 'lowpass', 2200, 400); break;
      case 'payout': for (let i = 0; i < 26; i++) { _tone([988, 1319, 1568, 1976][i % 4] * (1 + Math.random() * .03), t + i * .045, .1, 'square', .07); _noise(t + i * .045, .02, .12, 'highpass', 6000, 5000); } [523, 659, 784].forEach(f => _tone(f, t + 1.2, .9, 'sawtooth', .09)); _tone(1046, t + 1.2, .9, 'triangle', .18); break;
      case 'fuse': _noise(t, 1.1, .3, 'highpass', 5000, 8000); for (let i = 0; i < 10; i++) _noise(t + Math.random(), .03, .3, 'bandpass', 3000, 6000); _tone(880, t + 1.0, .15, 'square', .15); break;
      case 'splash': _noise(t, .12, .6, 'lowpass', 2500, 500); _noise(t + .06, .5, .35, 'bandpass', 1800, 500); for (let i = 0; i < 4; i++) _tone(500 + Math.random() * 500, t + .2 + i * .07, .08, 'sine', .12, 900 + Math.random() * 400); break;
      case 'bubble': [0, .1, .19].forEach((d, i) => _tone(350 + i * 120, t + d, .08, 'sine', .3, 800 + i * 200)); break;
      case 'reelin': for (let i = 0; i < 10; i++) _tone(1100, t + i * .04, .02, 'square', .08); _tone(988, t + .45, .1, 'square', .15); _tone(1319, t + .53, .3, 'square', .15); break;
      case 'letter': _tone(700, t, .05, 'square', .1, 1000); _tone(1400, t + .05, .15, 'sine', .2); break;
      case 'buzzer': _tone(150, t, .7, 'sawtooth', .25); _tone(155, t, .7, 'square', .15); break;
      case 'brick': _noise(t, .05, .5, 'bandpass', 2400, 1600); _tone(520, t, .05, 'square', .1, 380); _tone(260, t + .03, .12, 'triangle', .3, 200); _noise(t + .09, .06, .15, 'bandpass', 1800, 1200); break;
      case 'creakwood': _tone(140, t, .5, 'sawtooth', .12, 230); _tone(232, t + .25, .45, 'sawtooth', .1, 150); _noise(t, .7, .1, 'bandpass', 900, 600); break;
      case 'ticket': _noise(t, .12, .35, 'highpass', 3500, 6000); _tone(1568, t + .1, .12, 'sine', .2); break;
      case 'squeak': _tone(900, t, .1, 'sine', .25, 1700); _tone(1700, t + .1, .14, 'sine', .2, 1100); break;
      case 'clock': _tone(1800, t, .03, 'square', .14); _tone(1350, t + .11, .03, 'square', .14); _tone(1568, t + .22, .25, 'sine', .2); break;
      case 'alarm': for (let i = 0; i < 6; i++) _tone(i % 2 ? 880 : 1175, t + i * .16, .14, 'square', .16); break;
      case 'heartbeat': _tone(70, t, .14, 'sine', .8, 45); _tone(60, t + .2, .18, 'sine', .6, 40); break;
      default: if (!sfx2(name, t, _tone, _noise, seq)) _tone(880, t, .2, 'triangle', .3);
    }
  } catch {}
}
// Las vistas previas del panel (los cuadritos con el overlay) van en silencio por defecto,
// así no se escucha doble con el overlay de OBS / TikTok LIVE Studio. Se activan con el botón 🔊 del panel.
var IN_PREVIEW = (() => { try { return window.self !== window.top && /panel\.html/.test(window.top.location.pathname); } catch { return false; } })();
function previewMuted() { return !!IN_PREVIEW && !window.CFG?.panelSound; }
// Reproduce un sonido configurado { on, preset, file }
function playSpec(spec, vol = .6) {
  if (!spec || spec.on === false || vol <= 0 || previewMuted()) return;
  if (spec.file) { try { const a = new Audio(spec.file); a.volume = Math.max(0, Math.min(1, vol)); let fb = false; const back = () => { if (!fb && spec.preset && spec.preset !== 'none') { fb = true; synth(spec.preset, vol); } }; a.onerror = back; a.play().catch(e => { if (e?.name !== 'NotAllowedError') back(); }); } catch {} } // si el archivo ya no existe, suena el de fábrica
  else if (spec.preset && spec.preset !== 'none') synth(spec.preset, vol);
}
const gameVol = () => VOLUME * ((gcfg().volume ?? 70) / 100);
// Sonido de un evento del juego. "coins" elige el nivel de sonido (regalos más grandes = sonido más grande)
function playSound(name, coins) {
  if (!fx('sound')) return;
  const s = gcfg().sounds?.[name]; if (!s || !s.on) return;
  if (s.tiers?.length && coins != null) {
    const t = [...s.tiers].filter(x => coins >= (+x.min || 0)).sort((a, b) => b.min - a.min)[0];
    if (!t) return; // con niveles, un regalo menor a todos no suena
    return playSpec({ on: true, preset: t.preset, file: t.file }, gameVol());
  }
  playSpec(s, gameVol());
}
// Compatibilidad: sonidos sueltos
function beep(kind = 'gift') { if (fx('sound')) synth(kind, gameVol()); }

// Confeti con los colores del tema
function confetti(count = 140) {
  if (BRAND.confetti === false || !fx('confetti')) return;
  const c = document.createElement('canvas');
  c.style.cssText = 'position:fixed;inset:0;pointer-events:none;z-index:999';
  c.width = innerWidth; c.height = innerHeight; document.body.appendChild(c);
  const x = c.getContext('2d');
  const colors = wheelPalette();
  const ps = Array.from({ length: count }, () => ({
    x: c.width / 2 + (Math.random() - .5) * 200, y: c.height / 2,
    vx: (Math.random() - .5) * 16, vy: -Math.random() * 16 - 4,
    s: 6 + Math.random() * 6, r: Math.random() * 6, c: colors[Math.random() * colors.length | 0]
  }));
  let f = 0;
  (function loop() {
    x.clearRect(0, 0, c.width, c.height);
    ps.forEach(p => { p.vy += .45; p.x += p.vx; p.y += p.vy; p.r += .2; x.save(); x.translate(p.x, p.y); x.rotate(p.r); x.fillStyle = p.c; x.fillRect(-p.s / 2, -p.s / 4, p.s, p.s / 2); x.restore(); });
    if (++f < 160) requestAnimationFrame(loop); else c.remove();
  })();
}
// Estallido de partículas (monedas, estrellas, pedazos) desde el centro de un elemento
function fxBurst(host, n = 12, kind = 'star', spread = 180, o = {}) {
  if (!host || BRAND.confetti === false || !fx('confetti')) return;
  if (getComputedStyle(host).position === 'static') host.style.position = 'relative';
  for (let i = 0; i < n; i++) {
    const p = document.createElement('i'), a = Math.random() * Math.PI * 2, d = spread * (.45 + Math.random() * .6);
    p.className = 'fxp ' + kind; if (o.x != null) { p.style.left = o.x + 'px'; p.style.top = o.y + 'px'; } if (o.color) p.style.setProperty('--c', o.color);
    p.style.setProperty('--x', Math.cos(a) * d + 'px'); p.style.setProperty('--y', (Math.sin(a) * d - (kind === 'coin' ? 40 : 0)) + 'px');
    p.style.setProperty('--d', (.7 + Math.random() * .6) + 's'); p.style.setProperty('--r', (Math.random() * 720 - 360) + 'deg');
    host.appendChild(p); setTimeout(() => p.remove(), 1500);
  }
}
// Efectos de pantalla: temblor, flash, zoom
function screenFx(kind, el) {
  if (!kind || kind === 'none') return;
  if (kind === 'shake' && fx('shake')) { const t = el || document.body; t.classList.remove('shake'); void t.offsetWidth; t.classList.add('shake'); }
  if (kind === 'flash') { const f = document.createElement('div'); f.className = 'fxflash'; document.body.appendChild(f); setTimeout(() => f.remove(), 700); }
  if (kind === 'zoom' && el) { el.classList.remove('fxzoom'); void el.offsetWidth; el.classList.add('fxzoom'); }
}

// =====================================================================
// EVOLUCIONES: banner que aparece al pasar un nivel de monedas
// =====================================================================
const _evoQ = []; let _evoBusy = false;
socket.on('evolve', e => {
  if (!window.GAME_KEY || e.key !== window.GAME_KEY || e.key !== 'jar') return;
  window.onEvolve && window.onEvolve(e);
  if (window.NO_EVO_BANNER) return;
  _evoQ.push(e); _evoNext();
});
function _evoNext() {
  if (_evoBusy || !_evoQ.length) return; _evoBusy = true;
  const e = _evoQ.shift(), t = e.tier || {};
  const el = document.createElement('div'); el.className = 'evo card enter pulse';
  el.innerHTML = `${t.image ? `<img class="evo-img" src="${esc(t.image)}">` : `<div class="evo-ico">🧬</div>`}
    <div class="evo-body"><div class="evo-tag">¡Evolución! · Nivel ${e.i + 1}</div>
    <div class="evo-name grad-text">${esc(t.name)}</div>
    <div class="evo-txt">${esc(fillText(t.text || (e.user?.name ? '{usuario} llegó a {monedas}' : ''), e))}</div></div>`;
  if (e.user && e.user.id !== 'meta' && e.user.id !== 'jar') el.querySelector('.evo-body').prepend(Object.assign(avatarEl(e.user, 30), { className: 'avatar evo-av' }));
  document.body.appendChild(el);
  playSpec({ on: true, preset: t.sound || 'levelup', file: t.soundFile || '' }, gameVol());
  if (t.confetti !== false) confetti(160);
  screenFx(t.effect, el);
  setTimeout(() => { el.classList.add('out'); setTimeout(() => { el.remove(); _evoBusy = false; _evoNext(); }, 400); }, 4200);
}
// Nivel actual para un valor (el más alto alcanzado)
function tierFor(value) {
  if (window.GAME_KEY !== 'jar') return null; // solo el frasco evoluciona
  const g = gcfg(); if (!g.evo?.on) return null;
  let best = null;
  (g.evo.tiers || []).forEach((t, i) => { if (t.coins > 0 && value >= t.coins && (!best || t.coins >= best.coins)) best = { ...t, i }; });
  return best;
}

// =====================================================================
// RULETA: porciones con peso (más monedas = porción más grande)
// =====================================================================
function _segAngles(n, weights) {
  const w = (weights && weights.length === n) ? weights.map(x => Math.max(0.0001, +x || 0)) : Array(n).fill(1);
  const tot = w.reduce((a, b) => a + b, 0); let a = 0;
  return w.map(x => { const a0 = a; a += x / tot * Math.PI * 2; return [a0, a]; });
}
function drawWheel(canvas, labels, rotation, opts) {
  const ctx = canvas.getContext('2d');
  const dpr = canvas.__dpr || 1, lux = !document.documentElement.classList.contains('clasico');
  const size = canvas.width / dpr, r = size / 2 - 10, n = labels.length;
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  const style = opts?.style || gcfg().variant || 'clasica';
  let palette = wheelPalette();
  if (style === 'pastel') palette = palette.map(c => { const [r, g, b] = hexToRgb(c); return `rgb(${(r + 255 * 1.4) / 2.4 | 0},${(g + 255 * 1.4) / 2.4 | 0},${(b + 255 * 1.4) / 2.4 | 0})`; });
  const font = BRAND.font || 'Bricolage Grotesque';
  const ang = _segAngles(n, opts?.weights);
  // color por "dueño" de la porción (para que las casillas de un mismo jugador se vean iguales)
  const keys = opts?.keys || labels.map((_, i) => i), uniq = [...new Set(keys)];
  ctx.clearRect(0, 0, size, size);
  ctx.save(); ctx.translate(size / 2, size / 2);
  ctx.beginPath(); ctx.arc(0, 0, r + 6, 0, Math.PI * 2); ctx.fillStyle = BRAND.colors?.accent || '#ffd23f'; ctx.fill();
  if (lux) { // aro metálico
    const mg = ctx.createLinearGradient(-r, -r, r, r);
    mg.addColorStop(0, 'rgba(255,255,255,.75)'); mg.addColorStop(.3, 'rgba(255,255,255,0)'); mg.addColorStop(.55, 'rgba(0,0,0,.35)'); mg.addColorStop(.8, 'rgba(255,255,255,.4)'); mg.addColorStop(1, 'rgba(0,0,0,.4)');
    ctx.fillStyle = mg; ctx.fill(); ctx.lineWidth = 1.5; ctx.strokeStyle = 'rgba(0,0,0,.55)'; ctx.stroke();
  }
  ctx.rotate(rotation);
  for (let i = 0; i < n; i++) {
    const [a0, a1] = ang[i], span = a1 - a0;
    ctx.beginPath(); ctx.moveTo(0, 0); ctx.arc(0, 0, r, a0, a1); ctx.closePath();
    const col = opts?.colors?.[i] || palette[uniq.indexOf(keys[i]) % palette.length];
    const light = col.startsWith('#') && (([r, g, b]) => (r * .299 + g * .587 + b * .114) / 255)(hexToRgb(col)) > .72;
    if (style === 'neon') {
      ctx.fillStyle = i % 2 ? '#0d0a16' : '#160f24'; ctx.fill();
      ctx.save(); ctx.shadowColor = col; ctx.shadowBlur = 16; ctx.strokeStyle = col; ctx.lineWidth = 3; ctx.stroke(); ctx.restore();
    } else {
      const grd = ctx.createRadialGradient(0, 0, r * 0.15, 0, 0, r);
      grd.addColorStop(0, col.startsWith('#') ? rgba(col, 0.75) : col); grd.addColorStop(1, col);
      ctx.fillStyle = grd; ctx.fill();
      ctx.strokeStyle = 'rgba(0,0,0,.35)'; ctx.lineWidth = n > 40 ? 1 : 3; ctx.stroke();
    }
    if (opts?.hl != null) { // porción ganadora: las demás se apagan
      if (i !== opts.hl) { ctx.fillStyle = 'rgba(6,4,12,.62)'; ctx.fill(); }
      else if (opts.hlOn !== false) { ctx.save(); ctx.fillStyle = 'rgba(255,255,255,.28)'; ctx.fill(); ctx.shadowColor = '#fff'; ctx.shadowBlur = 22; ctx.strokeStyle = '#fff'; ctx.lineWidth = 4; ctx.stroke(); ctx.restore(); }
    }
    if (span < 0.06) continue; // porción muy fina: sin texto
    ctx.save(); ctx.rotate((a0 + a1) / 2);
    // imagen de la porción (opcional), cerca del borde
    const im = opts?.images?.[i]; let pad = 18;
    if (im && im.complete && im.naturalWidth) {
      const isz = Math.min(span * r * 0.55, r * 0.2);
      ctx.save(); ctx.translate(r - 14 - isz / 2, 0); ctx.rotate(Math.PI / 2); ctx.drawImage(im, -isz / 2, -isz / 2, isz, isz); ctx.restore();
      pad = 22 + isz;
    }
    ctx.fillStyle = style === 'neon' ? col : (style === 'pastel' || light) ? '#2a1d3a' : '#fff'; ctx.textAlign = 'right'; ctx.textBaseline = 'middle';
    const fs = Math.max(10, Math.min(22, span * r * 0.55)) * (font === 'Press Start 2P' ? 0.6 : 1) * (opts?.fontScale || 1);
    ctx.font = `800 ${fs}px '${font}', Outfit, sans-serif`;
    ctx.shadowColor = style === 'neon' ? col : (style === 'pastel' || light) ? 'transparent' : 'rgba(0,0,0,.7)'; ctx.shadowBlur = style === 'neon' ? 10 : 5;
    let t = String(labels[i]); if (t.length > 18) t = t.slice(0, 17) + '…';
    ctx.fillText(t, r - pad, 0); ctx.restore();
  }
  ctx.rotate(-rotation);
  if (lux) { // brillo de vidrio y sombra interior
    ctx.save(); ctx.beginPath(); ctx.arc(0, 0, r, 0, Math.PI * 2); ctx.clip();
    const gl = ctx.createRadialGradient(-r * .45, -r * .55, r * .05, -r * .2, -r * .3, r * 1.1);
    gl.addColorStop(0, 'rgba(255,255,255,.22)'); gl.addColorStop(.45, 'rgba(255,255,255,.04)'); gl.addColorStop(1, 'rgba(0,0,0,.22)');
    ctx.fillStyle = gl; ctx.fillRect(-r, -r, r * 2, r * 2);
    ctx.lineWidth = 10; ctx.strokeStyle = 'rgba(0,0,0,.28)'; ctx.beginPath(); ctx.arc(0, 0, r, 0, Math.PI * 2); ctx.stroke(); ctx.restore();
  }
  const bulbs = 24, fast = opts?.chase ? 70 : 180;
  for (let i = 0; i < bulbs; i++) {
    const a = (i / bulbs) * Math.PI * 2, on = (i + Math.floor(performance.now() / fast)) % 2;
    ctx.save(); ctx.beginPath(); ctx.arc(Math.cos(a) * (r + 1), Math.sin(a) * (r + 1), lux ? 3.8 : 3.2, 0, Math.PI * 2);
    if (lux && on) { ctx.shadowColor = '#fff6c9'; ctx.shadowBlur = 9; }
    ctx.fillStyle = on ? '#fff' : 'rgba(255,255,255,.35)'; ctx.fill(); ctx.restore();
  }
  ctx.restore();
  const cr = opts?.centerSize ? Math.max(16, size * opts.centerSize / 2) : 34;
  ctx.save(); ctx.beginPath(); ctx.arc(size / 2, size / 2, cr, 0, Math.PI * 2);
  ctx.fillStyle = '#14101e'; ctx.fill();
  const center = opts && 'center' in opts ? opts.center : (_gameImg && _gameImg.complete && _gameImg.naturalWidth) ? _gameImg : (BRAND.logoInWheel !== false ? _logoImg : null);
  if (center && center.complete && center.naturalWidth) { ctx.clip(); ctx.drawImage(center, size / 2 - cr, size / 2 - cr, cr * 2, cr * 2); }
  ctx.restore();
  ctx.beginPath(); ctx.arc(size / 2, size / 2, cr, 0, Math.PI * 2);
  ctx.lineWidth = 5; ctx.strokeStyle = BRAND.colors?.accent || '#ffd23f'; ctx.stroke();
  if (lux) { ctx.beginPath(); ctx.arc(size / 2, size / 2, cr + 3.5, 0, Math.PI * 2); ctx.lineWidth = 2; ctx.strokeStyle = 'rgba(0,0,0,.5)'; ctx.stroke();
    ctx.beginPath(); ctx.arc(size / 2, size / 2, cr, Math.PI * 1.05, Math.PI * 1.6); ctx.lineWidth = 2.5; ctx.strokeStyle = 'rgba(255,255,255,.75)'; ctx.stroke(); }
}
function spinWheel(canvas, labels, index, duration = 6000, onTick, opts) {
  return new Promise(res => {
    const ang = _segAngles(labels.length, opts?.weights);
    const [a0, a1] = ang[index], span = a1 - a0;
    // El puntero está arriba (-90°): llevamos el centro de la porción ganadora allí (con un poco de azar)
    const target = -Math.PI / 2 - (a0 + span / 2) + (Math.random() - .5) * span * 0.6;
    const turns = opts?.turns || Math.max(3, Math.round(duration / 900));
    const total = target - Math.PI * 2 * turns;
    const start = performance.now(); let last = -1;
    (function frame(now) {
      const t = Math.min(1, (now - start) / duration);
      const rot = total * (1 - Math.pow(1 - t, 4));
      drawWheel(canvas, labels, rot, t < 1 ? { ...opts, chase: true } : opts); canvas.__rot = rot;
      const p = (((-Math.PI / 2 - rot) % (Math.PI * 2)) + Math.PI * 2) % (Math.PI * 2);
      const s = ang.findIndex(([x, y]) => p >= x && p < y);
      if (s !== last) { last = s; onTick && onTick(); }
      if (t < 1) requestAnimationFrame(frame); else res(rot);
    })(performance.now());
  });
}

// Regalos acumulándose hacia el mínimo (opción "Acumular regalos")
socket.on('stack', s => {
  if (!window.GAME_KEY || s.key !== window.GAME_KEY) return;
  let el = document.querySelector(`.stackpill[data-u="${CSS.escape(s.user.id)}"]`);
  if (!el) { el = document.createElement('div'); el.className = 'stackpill card'; el.dataset.u = s.user.id; document.body.appendChild(el); }
  el.innerHTML = `${esc(s.user.name)} <b>${s.acc}/${s.min} 🪙</b><i style="width:${Math.min(100, s.acc / s.min * 100)}%"></i>`;
  clearTimeout(el._t); el._t = setTimeout(() => el.remove(), 3500);
});

// =====================================================================
// FONDOS DE CASILLA (diseño propio de ChispaLive)
// =====================================================================
const TILES = {
  carbon:  { n: 'Carbón',   bg: 'linear-gradient(145deg,#2b2733,#121017)' },
  oceano:  { n: 'Océano',   bg: 'linear-gradient(145deg,#38bdf8,#1d4ed8)' },
  aurora:  { n: 'Aurora',   bg: 'linear-gradient(145deg,#5eead4,#0f766e)' },
  lima:    { n: 'Lima',     bg: 'linear-gradient(145deg,#d9f99d,#4d7c0f)' },
  fuego:   { n: 'Fuego',    bg: 'linear-gradient(145deg,#fdba74,#dc2626)' },
  chicle:  { n: 'Chicle',   bg: 'linear-gradient(145deg,#f9a8d4,#db2777)' },
  uva:     { n: 'Uva',      bg: 'linear-gradient(145deg,#c4b5fd,#6d28d9)' },
  rubi:    { n: 'Rubí',     bg: 'linear-gradient(145deg,#fb7185,#9f1239)' },
  oro:     { n: 'Oro',      bg: 'linear-gradient(145deg,#fde68a,#d97706)' },
  hielo:   { n: 'Hielo',    bg: 'linear-gradient(145deg,#f0f9ff,#7dd3fc)' },
  galaxia: { n: 'Galaxia',  bg: 'radial-gradient(circle at 30% 25%,#f0abfc 0,#7c3aed 35%,#1e1b4b 75%)' },
  radar:   { n: 'Radar',    bg: 'repeating-radial-gradient(circle at 50% 50%,#2563eb 0 10px,#1e3a8a 10px 20px)' },
  rayas:   { n: 'Rayas',    bg: 'repeating-linear-gradient(135deg,#f43f5e 0 12px,#be123c 12px 24px)' },
  menta:   { n: 'Menta',    bg: 'repeating-linear-gradient(45deg,#34d399 0 10px,#059669 10px 20px)' },
  puntos:  { n: 'Puntos',   bg: 'radial-gradient(#fff3 2px,transparent 3px) 0 0/14px 14px,linear-gradient(145deg,#a855f7,#581c87)' },
  noche:   { n: 'Noche',    bg: 'radial-gradient(#ffffff55 1px,transparent 2px) 0 0/18px 18px,linear-gradient(160deg,#1e293b,#020617)' },
};
const tileBg = id => (TILES[id] || TILES.carbon).bg;

// =====================================================================
// PERSONAJES: avatar generado a partir del nombre (para quien no tiene foto)
// =====================================================================
function _hash(s) { let h = 2166136261; for (const c of String(s || '?')) { h ^= c.charCodeAt(0); h = Math.imul(h, 16777619); } return h >>> 0; }
const FACE_BG = ['#ffd6a5', '#caffbf', '#9bf6ff', '#bdb2ff', '#ffc6ff', '#fdffb6', '#a0c4ff', '#ffadad', '#b9fbc0', '#f1c0e8'];
const FACE_SKIN = ['#8b5a2b', '#f2c49b', '#7cc36a', '#5fb7d4', '#e8e8f0', '#ff9ec7', '#ffcf5a', '#b58df0', '#ff8c5a', '#4b9e8f'];
const _faceCache = {};
function faceSvg(name) {
  if (_faceCache[name]) return _faceCache[name];
  const h = _hash(name), bg = FACE_BG[h % FACE_BG.length], sk = FACE_SKIN[(h >>> 4) % FACE_SKIN.length], type = (h >>> 8) % 6;
  const eyes = (h >>> 12) % 4, mouth = (h >>> 14) % 3, ink = '#1a1426';
  const E = [
    `<circle cx="24" cy="30" r="4" fill="${ink}"/><circle cx="40" cy="30" r="4" fill="${ink}"/><circle cx="25.5" cy="28.5" r="1.4" fill="#fff"/><circle cx="41.5" cy="28.5" r="1.4" fill="#fff"/>`,
    `<path d="M20 30q4-5 8 0M36 30q4-5 8 0" stroke="${ink}" stroke-width="3" fill="none" stroke-linecap="round"/>`,
    `<rect x="17" y="25" width="13" height="9" rx="3" fill="${ink}"/><rect x="34" y="25" width="13" height="9" rx="3" fill="${ink}"/><path d="M30 29h4" stroke="${ink}" stroke-width="2.5"/><rect x="19" y="26.5" width="4" height="2" fill="#fff" opacity=".7"/>`,
    `<path d="M20 27l7 5M27 27l-7 5M37 27l7 5M44 27l-7 5" stroke="${ink}" stroke-width="2.6" stroke-linecap="round"/>`,
  ][eyes];
  const M = [`<path d="M26 40q6 6 12 0" stroke="${ink}" stroke-width="3" fill="none" stroke-linecap="round"/>`,
    `<ellipse cx="32" cy="42" rx="4.5" ry="3.5" fill="${ink}"/><ellipse cx="32" cy="43.5" rx="2.6" ry="1.5" fill="#ff6b8b"/>`,
    `<path d="M25 40h14" stroke="${ink}" stroke-width="3" stroke-linecap="round"/>`][mouth];
  const blush = `<ellipse cx="18" cy="38" rx="4" ry="2.5" fill="#ff6b8b" opacity=".35"/><ellipse cx="46" cy="38" rx="4" ry="2.5" fill="#ff6b8b" opacity=".35"/>`;
  const body = [
    // oso
    `<circle cx="15" cy="17" r="8" fill="${sk}"/><circle cx="49" cy="17" r="8" fill="${sk}"/><circle cx="32" cy="35" r="22" fill="${sk}"/><ellipse cx="32" cy="41" rx="10" ry="7" fill="#fff" opacity=".55"/>`,
    // gato
    `<path d="M11 24L14 6l13 11zM53 24L50 6 37 17z" fill="${sk}"/><circle cx="32" cy="35" r="21" fill="${sk}"/><path d="M12 38h-8M12 42l-7 3M52 38h8M52 42l7 3" stroke="${ink}" stroke-width="1.5"/>`,
    // robot
    `<path d="M32 4v8" stroke="${ink}" stroke-width="3"/><circle cx="32" cy="4" r="3.5" fill="#ff2e7e"/><rect x="11" y="12" width="42" height="42" rx="11" fill="${sk}"/><rect x="5" y="28" width="6" height="12" rx="3" fill="${ink}"/><rect x="53" y="28" width="6" height="12" rx="3" fill="${ink}"/>`,
    // fantasma
    `<path d="M12 56V30a20 20 0 0 1 40 0v26l-6-5-7 5-7-5-7 5-7-5z" fill="${sk}"/>`,
    // slime
    `<path d="M8 54q0-30 24-38q24 8 24 38z" fill="${sk}"/><ellipse cx="22" cy="24" rx="5" ry="3" fill="#fff" opacity=".5"/>`,
    // alien
    `<path d="M32 10l-4-8M32 10l4-8" stroke="${sk}" stroke-width="3"/><ellipse cx="32" cy="34" rx="24" ry="21" fill="${sk}"/>`,
  ][type];
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64" fill="${bg}"/>${body}${blush}${E}${M}</svg>`;
  return (_faceCache[name] = 'data:image/svg+xml;utf8,' + encodeURIComponent(svg));
}
// Desde ahora, quien no tenga foto muestra su personaje
(function () {
  const orig = avatarEl;
  avatarEl = function (user, size = 44) {
    if (user?.avatar) return orig(user, size);
    const el = document.createElement('img'); el.className = 'avatar'; el.src = faceSvg(user?.name || user?.id || '?');
    el.style.width = el.style.height = size + 'px'; return el;
  };
})();

// Vista previa de animación: solo visual, no suma monedas ni regalos
socket.on('preview', d => {
  if (d?.key && d.key !== window.GAME_KEY) return;
  const vis = [...document.querySelectorAll('#stage > *, #wrap, .card')].filter(el => !el.classList.contains('hidden') && el.offsetParent !== null && el.offsetWidth > 20);
  if (vis.length) { const el = vis[0]; el.classList.remove('enter', 'out'); void el.offsetWidth; el.classList.add('enter'); return; }
  const c = document.createElement('div'); c.className = 'card enter';
  c.style.cssText = 'position:fixed;left:0;right:0;top:40%;margin:0 auto;width:fit-content;padding:16px 26px;font-size:24px;font-weight:800;z-index:99';
  c.innerHTML = '✨ <span class="grad-text">Vista previa</span>';
  document.body.appendChild(c);
  setTimeout(() => { c.classList.add('out'); setTimeout(() => c.remove(), 450); }, 1800);
});
// Si el programa se actualizó, los overlays (OBS / LIVE Studio) se recargan solos con lo nuevo
let __ver = null;
socket.on('hello', h => { if (!h?.version) return; if (__ver && __ver !== h.version && window.GAME_KEY !== 'panel') location.reload(); __ver = h.version; });

// ---------- Tienda de diseños: adornos y partículas ----------
let _skinFx = { id: null, raf: 0, cv: null, parts: [] };
function applySkinFx(sk) {
  const root = document.documentElement;
  [...root.classList].filter(c => c.startsWith('skin-')).forEach(c => root.classList.remove(c));
  if (sk && sk.opt.deco !== false) root.classList.add('skin-' + sk.id);
  const want = sk && sk.opt.particles !== false ? sk.fx + '|' + (sk.opt.amount || 'normal') : null;
  if (want === _skinFx.id) return;
  _skinFx.id = want; cancelAnimationFrame(_skinFx.raf); _skinFx.cv?.remove(); _skinFx.cv = null;
  if (!want) return;
  const cv = document.createElement('canvas'); cv.className = 'skin-fx';
  cv.style.cssText = 'position:fixed;inset:0;width:100vw;height:100vh;pointer-events:none;z-index:2147483000';
  document.documentElement.appendChild(cv); _skinFx.cv = cv;
  const x = cv.getContext('2d'), kind = sk.fx;
  const N = { poco: .5, normal: 1, mucho: 2 }[sk.opt.amount] || 1;
  let W = 0, H = 0;
  const size = () => { W = cv.width = innerWidth; H = cv.height = innerHeight; };
  size(); addEventListener('resize', size);
  const base = { snow: 70, bats: 6, sakura: 34, sparkle: 46, hearts: 16, bubbles: 26, embers: 50, stars: 90, gold: 30 }[kind] || 30;
  const R = (a, b) => a + Math.random() * (b - a);
  const mk = (first) => {
    const p = { x: R(0, W), y: first ? R(0, H) : -30, r: R(0, 1), t: R(0, 6.28), s: R(.5, 1.4) };
    if (kind === 'bats') { p.x = Math.random() < .5 ? -40 : W + 40; p.dir = p.x < 0 ? 1 : -1; p.y = R(H * .05, H * .6); if (first) p.x = R(0, W); }
    if (kind === 'hearts' || kind === 'bubbles' || kind === 'embers') { p.y = first ? R(0, H) : H + 30; }
    if (kind === 'stars') { p.y = R(0, H); p.shoot = !first && Math.random() < .04; if (p.shoot) { p.x = R(0, W * .7); p.y = R(0, H * .4); p.life = 0; } }
    return p;
  };
  _skinFx.parts = Array.from({ length: Math.round(base * N) }, () => mk(true));
  const C = sk.colors;
  let last = performance.now();
  const step = now => {
    const dt = Math.min(50, now - last) / 16.7; last = now;
    x.clearRect(0, 0, W, H);
    _skinFx.parts.forEach((p, i) => {
      p.t += .03 * dt;
      if (kind === 'snow') {
        p.y += (.6 + p.r * 1.4) * dt; p.x += Math.sin(p.t) * .5 * dt;
        x.globalAlpha = .55 + p.r * .4; x.fillStyle = '#fff'; x.beginPath(); x.arc(p.x, p.y, 1.5 + p.r * 2.8, 0, 7); x.fill();
      } else if (kind === 'sakura') {
        p.y += (.5 + p.r) * dt; p.x += (Math.sin(p.t) * .8 + .4) * dt;
        x.save(); x.translate(p.x, p.y); x.rotate(p.t * 1.5); x.scale(1, Math.abs(Math.cos(p.t * 2)) * .7 + .3);
        x.globalAlpha = .8; x.fillStyle = i % 3 ? '#ffb7d5' : '#ffd6e8'; x.beginPath(); x.ellipse(0, 0, 6 + p.r * 4, 3.5 + p.r * 2, 0, 0, 7); x.fill(); x.restore();
      } else if (kind === 'sparkle') {
        p.y += (.3 + p.r * .8) * dt; const a = .35 + .65 * Math.abs(Math.sin(p.t * 2));
        x.globalAlpha = a; x.fillStyle = i % 4 ? C.primary : '#fff'; const s = 2 + p.r * 4;
        x.beginPath(); x.moveTo(p.x, p.y - s * 2); x.lineTo(p.x + s * .5, p.y - s * .5); x.lineTo(p.x + s * 2, p.y); x.lineTo(p.x + s * .5, p.y + s * .5); x.lineTo(p.x, p.y + s * 2); x.lineTo(p.x - s * .5, p.y + s * .5); x.lineTo(p.x - s * 2, p.y); x.lineTo(p.x - s * .5, p.y - s * .5); x.fill();
      } else if (kind === 'hearts') {
        p.y -= (.5 + p.r) * dt; p.x += Math.sin(p.t) * .6 * dt;
        x.globalAlpha = .45 + p.r * .4; x.font = `${16 + p.r * 18}px serif`; x.fillText(i % 3 ? '💗' : '❤️', p.x, p.y);
      } else if (kind === 'bubbles') {
        p.y -= (.5 + p.r * 1.1) * dt; p.x += Math.sin(p.t * 1.5) * .7 * dt; const rr = 4 + p.r * 10;
        x.globalAlpha = .35 + p.r * .35; x.strokeStyle = '#bff6ff'; x.lineWidth = 1.5; x.beginPath(); x.arc(p.x, p.y, rr, 0, 7); x.stroke();
        x.globalAlpha *= .8; x.fillStyle = '#ffffff'; x.beginPath(); x.arc(p.x - rr * .35, p.y - rr * .35, rr * .22, 0, 7); x.fill();
      } else if (kind === 'embers') {
        p.y -= (.8 + p.r * 1.6) * dt; p.x += Math.sin(p.t * 2) * .9 * dt; const a = Math.max(0, Math.min(1, p.y / H)) * (.5 + .5 * Math.abs(Math.sin(p.t * 3)));
        x.globalAlpha = a; x.fillStyle = i % 3 ? '#ff7a1a' : '#ffd166'; x.beginPath(); x.arc(p.x, p.y, 1.2 + p.r * 2.4, 0, 7); x.fill();
        x.globalAlpha = a * .25; x.beginPath(); x.arc(p.x, p.y, 5 + p.r * 5, 0, 7); x.fill();
      } else if (kind === 'stars') {
        if (p.shoot) { p.life += dt; p.x += 9 * dt; p.y += 4 * dt; x.globalAlpha = Math.max(0, 1 - p.life / 40); x.strokeStyle = '#fff'; x.lineWidth = 2; x.beginPath(); x.moveTo(p.x, p.y); x.lineTo(p.x - 60, p.y - 27); x.stroke(); if (p.life > 40) p.y = H + 99; }
        else { x.globalAlpha = .25 + .75 * Math.abs(Math.sin(p.t * (1 + p.r))); x.fillStyle = i % 5 ? '#ffffff' : C.primary; x.beginPath(); x.arc(p.x, p.y, .6 + p.r * 1.6, 0, 7); x.fill(); if (Math.random() < .0015 * dt) p.y = H + 99; }
      } else if (kind === 'gold') {
        p.y += (1 + p.r * 1.8) * dt; p.x += Math.sin(p.t) * .4 * dt; const w = Math.abs(Math.cos(p.t * 2)) * (5 + p.r * 4) + 1;
        x.globalAlpha = .85; x.fillStyle = i % 4 ? '#ffcc33' : '#fff1b8'; x.beginPath(); x.ellipse(p.x, p.y, w, 5 + p.r * 4, 0, 0, 7); x.fill();
        x.globalAlpha = .9; x.fillStyle = '#b8860b'; x.beginPath(); x.ellipse(p.x, p.y, w * .55, (5 + p.r * 4) * .55, 0, 0, 7); x.fill();
      } else if (kind === 'bats') {
        p.x += p.dir * (1.2 + p.r * 1.3) * dt; p.y += Math.sin(p.t * 2) * 1.2 * dt;
        x.globalAlpha = .85; x.font = `${22 + p.r * 18}px serif`;
        x.save(); x.translate(p.x, p.y); x.scale(p.dir > 0 ? -1 : 1, .8 + Math.abs(Math.sin(p.t * 6)) * .3); x.fillText('🦇', 0, 0); x.restore();
      }
      const out = kind === 'bats' ? (p.x < -60 || p.x > W + 60) : (kind === 'hearts' || kind === 'bubbles' || kind === 'embers') ? p.y < -40 : p.y > H + 30;
      if (out) _skinFx.parts[i] = mk(false);
    });
    x.globalAlpha = 1;
    _skinFx.raf = requestAnimationFrame(step);
  };
  _skinFx.raf = requestAnimationFrame(step);
}

// ---------- Tienda de diseños: explosión con cada regalo, sonido del diseño y "momentos" ----------
let _skinNow = null, _skBurstAt = 0, _skSndAt = 0;
const SKIN_DEMO = IS_OVERLAY && new URLSearchParams(location.search).has('demo');
// Varios overlays abiertos a la vez (OBS): solo uno pone el sonido, para que no suene repetido
const _skId = Math.random(), _skPeers = new Map(); let _skBC = null;
// (las vistas previas del panel van en silencio, así que no participan)
try { if (!IN_PREVIEW && !SKIN_DEMO && window.self === window.top) { _skBC = new BroadcastChannel('chispalive-skin'); _skBC.onmessage = e => _skPeers.set(e.data, Date.now()); setInterval(() => _skBC.postMessage(_skId), 1000); } } catch {}
const _skLeader = () => { const n = Date.now(); for (const [id, t] of _skPeers) if (n - t < 2500 && id < _skId) return false; return true; };
function skinBurst(big, force) {
  const sk = _skinNow; if (!sk || !IS_OVERLAY) return; const now = Date.now();
  if (sk.opt.burst !== false && (force || now - _skBurstAt > 900)) {
    _skBurstAt = now;
    const host = document.querySelector('.card') || document.body, r = host.getBoundingClientRect();
    const cx = r.width ? r.left + r.width / 2 : innerWidth / 2, cy = r.height ? r.top + r.height / 2 : innerHeight / 2;
    const n = big ? 22 : 12;
    for (let k = 0; k < n; k++) {
      const e = document.createElement('span'); e.textContent = sk.burst[k % sk.burst.length];
      e.style.cssText = `position:fixed;left:${cx}px;top:${cy}px;font-size:${(big ? 26 : 20) + Math.random() * 16}px;pointer-events:none;z-index:2147483600;will-change:transform`;
      document.documentElement.appendChild(e);
      const a = Math.random() * Math.PI * 2, d = (big ? 190 : 120) + Math.random() * (big ? 200 : 120), rot = (Math.random() - .5) * 540;
      e.animate([{ transform: 'translate(-50%,-50%) scale(.2)', opacity: 0 }, { transform: `translate(calc(-50% + ${Math.cos(a) * d * .6}px), calc(-50% + ${Math.sin(a) * d * .6 - 30}px)) scale(1.15) rotate(${rot * .5}deg)`, opacity: 1, offset: .35 }, { transform: `translate(calc(-50% + ${Math.cos(a) * d}px), calc(-50% + ${Math.sin(a) * d + 70}px)) scale(.8) rotate(${rot}deg)`, opacity: 0 }], { duration: 1300 + Math.random() * 600, easing: 'cubic-bezier(.2,.7,.3,1)' }).onfinish = () => e.remove();
    }
  }
  if (sk.opt.sound !== false && fx('sound') && _skLeader() && (force || now - _skSndAt > 3500)) { _skSndAt = now; synth(sk.snd, VOLUME * .7); }
}
// Momento especial cada tanto: el trineo, el fantasma, la estrella fugaz, los fuegos, la flecha de Cupido
function skinMoment() {
  const sk = _skinNow; if (!sk || !IS_OVERLAY || sk.opt.moments === false || document.hidden) return;
  const mk = (txt, css) => { const e = document.createElement('span'); e.textContent = txt; e.style.cssText = 'position:fixed;pointer-events:none;z-index:2147483500;white-space:nowrap;filter:drop-shadow(0 4px 6px rgba(0,0,0,.45));' + css; document.documentElement.appendChild(e); return e; };
  const W = innerWidth, H = innerHeight, y = 20 + Math.random() * Math.min(120, H * .25);
  if (sk.id === 'navidad') { const e = mk('🎅🛷🦌🦌', `left:0;top:${y}px;font-size:34px`); e.animate([{ transform: `translate(${W + 60}px, 30px) rotate(-6deg)` }, { transform: `translate(${W / 2}px, -10px) rotate(4deg)` }, { transform: 'translate(-260px, 20px) rotate(-6deg)' }], { duration: 5200, easing: 'linear' }).onfinish = () => e.remove(); }
  else if (sk.id === 'halloween') { const e = mk('👻', `left:${10 + Math.random() * 80}%;top:${H * .7}px;font-size:54px`); e.animate([{ transform: 'translateY(40px) scale(.6)', opacity: 0 }, { transform: 'translate(20px, -60px) scale(1)', opacity: .95, offset: .3 }, { transform: 'translate(-20px, -150px) scale(1.05)', opacity: .9, offset: .7 }, { transform: 'translate(10px, -240px) scale(1.1)', opacity: 0 }], { duration: 4200, easing: 'ease-in-out' }).onfinish = () => e.remove(); }
  else if (sk.id === 'anime') { const e = mk('🌠', `left:0;top:0;font-size:40px`); e.animate([{ transform: `translate(${W * .9}px, -40px) rotate(-10deg)`, opacity: 0 }, { opacity: 1, offset: .15 }, { transform: `translate(${W * .1}px, ${Math.min(H * .5, 260)}px) rotate(-10deg)`, opacity: 0 }], { duration: 1500, easing: 'ease-in' }).onfinish = () => e.remove(); }
  else if (sk.id === 'anonuevo') { for (let b = 0; b < 3; b++) setTimeout(() => { const x = W * (.15 + Math.random() * .7), yy = 30 + Math.random() * Math.min(160, H * .3), col = ['#ffd23f', '#b388ff', '#ff6a9a', '#7ee8ff'][b % 4]; for (let k = 0; k < 18; k++) { const p = mk('', `left:${x}px;top:${yy}px;width:6px;height:6px;border-radius:50%;background:${col};box-shadow:0 0 10px ${col}`); const a = k / 18 * 6.283, d = 60 + Math.random() * 50; p.animate([{ transform: 'translate(0,0) scale(1)', opacity: 1 }, { transform: `translate(${Math.cos(a) * d}px, ${Math.sin(a) * d + 24}px) scale(.3)`, opacity: 0 }], { duration: 1100, easing: 'cubic-bezier(.1,.7,.3,1)' }).onfinish = () => p.remove(); } }, b * 380); }
  else if (sk.id === 'sanvalentin') { const e = mk('💘', `left:0;top:${y + 20}px;font-size:40px`); e.animate([{ transform: 'translate(-60px, 20px) rotate(20deg)' }, { transform: `translate(${W / 2}px, -20px) rotate(20deg)` }, { transform: `translate(${W + 60}px, 20px) rotate(20deg)` }], { duration: 2600, easing: 'ease-in-out' }).onfinish = () => e.remove(); }
}
if (IS_OVERLAY) {
  socket.on('event', e => { if (e?.type === 'gift') skinBurst((e.diamonds || 0) >= 99); });
  socket.on('skin:test', () => { skinBurst(true, true); setTimeout(skinMoment, 700); });
  (function loopM() { setTimeout(() => { skinMoment(); loopM(); }, SKIN_DEMO ? 5000 : 22000 + Math.random() * 16000); })();
  if (SKIN_DEMO) setInterval(() => { _skBurstAt = 0; const s = _skinNow; if (s) { const o = s.opt; _skinNow = { ...s, opt: { ...o, sound: false } }; skinBurst(false, true); _skinNow = s; } }, 3200);
}
