// ===== Chispas ✨ y cofres 🎁 — página del panel =====
(function () {
  let S = null, opening = false;
  const n = v => (+v || 0).toLocaleString('es');
  const RAR = { comun: ['Común', '#9aa7b8'], raro: ['Raro', '#3b82f6'], epico: ['Épico', '#a855f7'], legendario: ['Legendario', '#ffcc33'] };
  const TIER = { comun: { c1: '#5b6b80', c2: '#2b3543', glow: '#9fb3cc', ic: '📦' }, raro: { c1: '#7c3aed', c2: '#3b1d7a', glow: '#b794ff', ic: '💜' }, legendario: { c1: '#f5b300', c2: '#8a5a00', glow: '#ffe28a', ic: '👑' } };
  // Cofre dibujado (sin imágenes): tapa, cuerpo, refuerzos y cerradura con los colores de su rareza
  const chestSvg = (t, cls = '') => { const T = TIER[t]; return `<svg class="cp-chest ${cls}" viewBox="0 0 120 110" aria-hidden="true">
    <defs><linearGradient id="cb-${t}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${T.c1}"/><stop offset="1" stop-color="${T.c2}"/></linearGradient>
    <linearGradient id="cm-${t}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#fff6c8"/><stop offset=".5" stop-color="#ffcc33"/><stop offset="1" stop-color="#a86b00"/></linearGradient></defs>
    <ellipse cx="60" cy="104" rx="46" ry="5" fill="rgba(0,0,0,.35)"/>
    <g class="lid"><path d="M14 46 Q14 14 60 14 Q106 14 106 46 Z" fill="url(#cb-${t})" stroke="rgba(0,0,0,.35)" stroke-width="2"/>
      <path d="M20 44 Q22 20 60 20 Q98 20 100 44" fill="none" stroke="rgba(255,255,255,.25)" stroke-width="3"/>
      <rect x="52" y="14" width="16" height="32" fill="url(#cm-${t})"/><rect x="12" y="42" width="96" height="8" rx="2" fill="url(#cm-${t})"/></g>
    <rect x="14" y="50" width="92" height="48" rx="6" fill="url(#cb-${t})" stroke="rgba(0,0,0,.35)" stroke-width="2"/>
    <rect x="52" y="50" width="16" height="48" fill="url(#cm-${t})"/><rect x="14" y="88" width="92" height="7" fill="url(#cm-${t})"/>
    <rect x="50" y="54" width="20" height="18" rx="4" fill="#2a1a00"/><circle cx="60" cy="61" r="3.2" fill="#ffcc33"/><rect x="58.6" y="62" width="2.8" height="6" fill="#ffcc33"/>
  </svg>`; };

  const sec = document.createElement('section'); sec.className = 'sec'; sec.id = 's-chispas';
  sec.innerHTML = `
  <div class="vz-head panel">
    <div class="vz-mascot rbx-logo">✨</div>
    <div class="vz-ttl"><h1 class="display">Chispas y cofres</h1><p class="hint">Gana Chispas usando ChispaLive en tus lives y ayudando a que crezca. Ábrelas en cofres: días gratis, días de Pro, diseños y sonidos exclusivos que no se compran.</p></div>
  </div>
  <div class="cp-top panel"><div class="cp-bal"><small>Tus Chispas</small><b data-r="bal">0</b></div><div class="cp-how" data-r="how"></div></div>
  <div class="panel"><h2>🎁 Abre un cofre</h2><div class="cp-chests" data-r="chests"></div></div>
  <div class="cp-two">
    <div class="panel"><h2>🎯 Misiones</h2><div class="cp-mis" data-r="mis"></div></div>
    <div class="panel"><h2>🎟️ Gana más Chispas</h2>
      <div class="cp-earn">
        <div><span>🤝</span><div><b>Trae a un amigo</b><small>Cuando compre su plan y diga que vino por ti</small></div><em>+300 ✨</em></div>
        <div><span>🎬</span><div><b>Sube un TikTok usando ChispaLive</b><small>Que se vea en tu live, con #ChispaLive</small></div><em>+150 ✨</em></div>
        <div><span>💡</span><div><b>Manda una idea o un error</b><small>Si la usamos o lo arreglamos</small></div><em>+100 ✨</em></div>
      </div>
      <p class="hint" style="margin:12px 0 8px">Mándalo por un ticket en Discord con tu código de equipo <b class="cp-code" data-r="mc"></b>. Te respondemos con un código <b>CHISPAS-…</b> y lo pegas aquí:</p>
      <div class="cp-redeem"><input class="i" data-r="code" placeholder="CHISPAS-…" autocomplete="off" spellcheck="false"><button class="btn pri" data-r="redeem">🎟️ Canjear</button></div>
    </div>
  </div>
  <div class="cp-two">
    <div class="panel"><h2>🏆 Mi colección</h2><div data-r="owned"></div></div>
    <div class="panel"><h2>🧾 Historial</h2><div class="cp-hist" data-r="hist"></div></div>
  </div>
  <div class="panel cp-owner" data-r="owner" hidden><h2>👑 Regalar Chispas (solo tú)</h2>
    <div class="row" style="margin:0;align-items:end;gap:8px;flex-wrap:wrap">
      <label class="f" style="flex:1;min-width:200px">Código de equipo del cliente<input class="i" data-r="gmc" placeholder="ABCD-EFGH-JKLM-NPQR"></label>
      <label class="f">Motivo<select class="i" data-r="gwhy"><option value="Referido|300">🤝 Referido · 300</option><option value="Video con #ChispaLive|150">🎬 Video · 150</option><option value="Idea o error|100">💡 Idea o error · 100</option><option value="Regalo|50">🎁 Regalo · 50</option></select></label>
      <label class="f" style="width:110px">Cantidad<input class="i" type="number" min="1" max="100000" data-r="gn" value="300"></label>
      <button class="btn pri" data-r="gen">✨ Generar código</button>
    </div>
    <div data-r="gout"></div>
    <div class="row" style="margin:12px 0 0;gap:8px"><button class="btn sm" data-r="me">🧪 Darme 1.000 ✨ para probar</button><span class="hint">Solo en tu PC, para probar los cofres.</span></div>
  </div>
  <div class="cp-modal" data-r="modal" hidden></div>`;
  document.getElementById('studios').after(sec);
  const $ = q => sec.querySelector(q);

  function lootList(t) {
    const L = S.loot[t], tot = L.reduce((a, x) => a + x[1], 0);
    const name = ([k, , v]) => k === 'chispas' ? `✨ ${v[0]}–${v[1]} Chispas` : k === 'dias' ? `📅 +${v} días gratis` : k === 'pro' ? `💎 ${v} días de Pro` : k === 'skin' ? `🎨 Diseño ${String(v).split('|').map(r => RAR[r][0].toLowerCase()).join(' o ')}` : `🔊 Sonido ${String(v).split('|').map(r => RAR[r][0].toLowerCase()).join(' o ')}`;
    return L.map(x => `<li><span>${name(x)}</span><i>${Math.round(x[1] / tot * 100)}%</i></li>`).join('');
  }
  function paint() {
    if (!S) return;
    const balEl = $('[data-r=bal]'), old = +balEl.dataset.v || 0; balEl.dataset.v = S.bal;
    if (old !== S.bal && old) { balEl.classList.remove('bump'); void balEl.offsetWidth; balEl.classList.add('bump'); }
    balEl.textContent = n(S.bal) + ' ✨';
    const ready = S.missions.filter(m => m.ready).length;
    $('[data-r=how]').innerHTML = ready ? `<b>🎉 Tienes ${ready} ${ready > 1 ? 'misiones listas' : 'misión lista'} para reclamar</b><small>Abajo en Misiones</small>` : `<b>¿Cómo gano Chispas?</b><small>Haciendo lives con ChispaLive (misiones) y con códigos por traer amigos, videos o ideas.</small>`;
    $('[data-r=mc]').textContent = S.machine;
    $('[data-r=chests]').innerHTML = Object.entries(S.chests).map(([t, c]) => `
      <div class="cp-cc t-${t}">${chestSvg(t, 'idle')}
        <h3>${c.name}</h3><button class="btn ${S.bal >= c.price ? 'pri' : ''}" data-open="${t}" ${S.bal >= c.price ? '' : 'disabled'}>Abrir · ${n(c.price)} ✨</button>
        <details><summary class="hint">Qué puede salir</summary><ul class="cp-loot">${lootList(t)}</ul></details></div>`).join('');
    $('[data-r=mis]').innerHTML = S.missions.map(m => `
      <div class="cp-m ${m.done ? 'done' : m.ready ? 'ready' : ''}"><span class="cp-mi">${m.icon}</span>
        <div class="cp-mb"><b>${m.name}${m.weekly ? ' <small class="cp-wk">SEMANAL</small>' : ''}</b><div class="cp-bar"><i style="width:${Math.round(m.v / m.max * 100)}%"></i></div><small>${m.max > 1 ? `${n(m.v)} / ${n(m.max)}` : m.v ? 'Hecho' : 'Pendiente'}</small></div>
        ${m.done ? '<span class="cp-ok">✓</span>' : `<button class="btn sm ${m.ready ? 'pri' : ''}" data-claim="${m.id}" ${m.ready ? '' : 'disabled'}>+${n(m.n)} ✨</button>`}</div>`).join('');
    const sk = S.owned.skins || [], sd = S.owned.snds || [];
    $('[data-r=owned]').innerHTML = sk.length + sd.length ? `
      ${sk.length ? `<div class="cp-own">${sk.map(id => { const d = DESIGN_SKINS[id] || {}; return `<div class="cp-oi r-${d.excl}"><span>${d.icon || '🎨'}</span><div><b>${d.name || id}</b><small>Diseño ${RAR[d.excl]?.[0] || ''}</small></div><button class="btn sm" data-skin="${id}">Usar</button></div>`; }).join('')}</div>` : ''}
      ${sd.length ? `<div class="cp-own">${sd.map(id => `<div class="cp-oi r-${S.snds[id]}"><span>🔊</span><div><b>${(SFX_EXCL[id] || id).replace(/^🎁 /, '')}</b><small>Sonido ${RAR[S.snds[id]]?.[0] || ''} · ya está en tus listas de sonidos</small></div><button class="btn sm" data-play="${id}">▶</button></div>`).join('')}</div>` : ''}`
      : '<div class="hint">Todavía no tienes premios exclusivos. ¡Abre un cofre!</div>';
    $('[data-r=hist]').innerHTML = S.hist.length ? S.hist.map(h => `<div class="cp-h"><span>${h.icon}</span><b>${h.why}</b><em class="${h.n < 0 ? 'neg' : ''}">${h.n > 0 ? '+' : ''}${n(h.n)} ✨</em><small>${new Date(h.at).toLocaleDateString(document.documentElement.lang === 'en' ? 'en' : 'es')}</small></div>`).join('') : '<div class="hint">Aquí verás lo que ganas y gastas.</div>';
    $('[data-r=owner]').hidden = !S.owner;
    bind();
  }
  function bind() {
    sec.querySelectorAll('[data-open]').forEach(b => b.onclick = () => openChest(b.dataset.open));
    sec.querySelectorAll('[data-claim]').forEach(b => b.onclick = () => socket.emit('chispas:claim', b.dataset.claim, r => {
      if (!r?.ok) return toast(r?.error || 'No se pudo');
      toast(`✨ +${n(r.n)} Chispas`); try { synth('coin', .5); fxBurst?.(b, 14, 'coin'); } catch {}
    }));
    sec.querySelectorAll('[data-skin]').forEach(b => b.onclick = () => { socket.emit('saveConfig', { skin: { id: b.dataset.skin } }); toast('🎨 Diseño puesto en todos tus overlays'); });
    sec.querySelectorAll('[data-play]').forEach(b => b.onclick = () => synth(b.dataset.play, .6));
  }
  $('[data-r=redeem]').onclick = () => {
    const inp = $('[data-r=code]'), c = inp.value.trim(); if (!c) return inp.focus();
    socket.emit('chispas:redeem', c, r => { if (!r?.ok) return toast('❌ ' + (r?.error || 'Código no válido')); inp.value = ''; toast(`🎟️ ¡+${n(r.n)} Chispas! ${r.why ? '· ' + r.why : ''}`); try { synth('x_monedas', .5); confetti?.(120); } catch {} });
  };
  $('[data-r=gwhy]').onchange = e => { $('[data-r=gn]').value = e.target.value.split('|')[1]; };
  $('[data-r=gen]').onclick = () => {
    const d = { machine: $('[data-r=gmc]').value.trim(), amount: +$('[data-r=gn]').value, why: $('[data-r=gwhy]').value.split('|')[0] };
    socket.emit('chispas:gen', d, r => {
      $('[data-r=gout]').innerHTML = r?.ok ? `<div class="cp-gout"><code>${esc(r.code)}</code><button class="btn sm pri" data-cp2>📋 Copiar</button></div>` : `<p class="hint">❌ ${esc(r?.error || 'No se pudo')}</p>`;
      sec.querySelector('[data-cp2]')?.addEventListener('click', () => navigator.clipboard.writeText(r.code).then(() => toast('📋 Código copiado')));
    });
  };
  $('[data-r=me]').onclick = () => socket.emit('chispas:ownerAdd', 1000, r => r?.ok ? toast('🧪 +1.000 ✨') : toast('Solo en tu PC'));

  // ---- Abrir un cofre: tiembla, brilla, explota y aparece el premio ----
  function prizeHtml(r) {
    if (r.kind === 'skin') { const d = DESIGN_SKINS[r.id] || {}; return { ic: d.icon || '🎨', t: d.name || r.id, s: `Diseño exclusivo · ${d.desc || ''}`, btn: `<button class="btn" data-m="skin" data-id="${r.id}">🎨 Usarlo ya</button>` }; }
    if (r.kind === 'snd') return { ic: '🔊', t: (SFX_EXCL[r.id] || r.id).replace(/^🎁 /, ''), s: 'Sonido exclusivo: ya aparece en las listas de sonidos de tus juegos', btn: `<button class="btn" data-m="play" data-id="${r.id}">▶ Escuchar</button>` };
    return { ic: r.icon, t: r.title, s: r.sub || '', btn: '' };
  }
  function openChest(t) {
    if (opening) return; opening = true;
    socket.emit('chispas:open', t, r => {
      if (!r?.ok) { opening = false; return toast(r?.error || 'No se pudo abrir'); }
      const m = $('[data-r=modal]'), rar = r.r.rarity || 'comun', [rn, rc] = RAR[rar] || RAR.comun, P = prizeHtml(r.r);
      m.innerHTML = `<div class="cp-stage t-${t}" style="--rc:${rc}"><div class="cp-rays"></div>${chestSvg(t, 'shake')}<div class="cp-flash"></div>
        <div class="cp-prize"><div class="cp-rar">${rn}</div><div class="cp-pi">${P.ic}</div><h2>${P.t}</h2><p>${P.s}</p>
        <div class="cp-pbtn">${P.btn}<button class="btn pri" data-m="ok">¡Genial!</button></div></div></div>`;
      m.hidden = false;
      const vol = .55;
      try { [0, 380, 760].forEach((d, i) => setTimeout(() => synth('ratchet', vol), d + i * 40)); } catch {}
      setTimeout(() => {
        m.querySelector('.cp-stage').classList.add('open');
        try { synth(rar === 'legendario' ? 'x_coro' : rar === 'epico' ? 'treasure' : rar === 'raro' ? 'payout' : 'gift', vol); if (rar === 'legendario' || rar === 'epico') setTimeout(() => synth('fanfare', vol * .8), 300); } catch {}
        try { confetti?.(rar === 'legendario' ? 260 : rar === 'epico' ? 180 : 90); } catch {}
      }, 1350);
      m.querySelector('[data-m=ok]').onclick = () => { m.hidden = true; m.innerHTML = ''; opening = false; };
      m.querySelector('[data-m=skin]')?.addEventListener('click', e => { socket.emit('saveConfig', { skin: { id: e.target.dataset.id } }); toast('🎨 Diseño puesto en todos tus overlays'); });
      m.querySelector('[data-m=play]')?.addEventListener('click', e => synth(e.target.dataset.id, .6));
    });
  }

  socket.on('chispas', st => { S = st; window.CHISPAS = st; paint(); window.tiendaPaint?.(); });
  socket.emit('chispas:get'); socket.on('connect', () => socket.emit('chispas:get'));
  document.querySelector('button.nav[data-s="chispas"]')?.addEventListener('click', () => socket.emit('chispas:get'));
})();
