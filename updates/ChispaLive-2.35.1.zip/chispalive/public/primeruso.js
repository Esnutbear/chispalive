// ===== Primer uso guiado: en 2 minutos queda un juego funcionando en el live =====
// 1) Tu usuario de TikTok · 2) Elige un juego · 3) Ponlo en LIVE Studio u OBS · 4) Pruébalo · 5) ¡Listo!
(function () {
  const GAMES = [
    ['royale', '👑', 'Spin Royale', 'Los viewers entran con regalos y la ruleta los va eliminando hasta que queda uno', 'royale'],
    ['ruleta', '🎡', 'Ruleta de acciones', 'Un regalo gira la ruleta y sale un reto o un premio', 'ruleta'],
    ['lucky', '🎲', 'Lucky Roll', 'Cada regalo tira los dados y puede ganar premios', 'lucky'],
    ['jar', '🫙', 'Frasco de regalos', 'Los regalos caen y llenan un frasco en pantalla', 'frasco'],
    ['batalla', '⚔️', 'Batalla de equipos', 'Dos equipos, cada uno con su regalo: gana el que más suma', 'batalla'],
    ['carrera', '🏁', 'Carrera de animales', 'Los regalos empujan a cada animal hacia la meta', 'carrera'],
  ];
  const STEPS = 5;
  let i = 0, game = 'royale', where = 'studio', open = false;
  const L = x => (window.i18n && document.documentElement.lang === 'en' ? window.i18n.tr(x) : x);
  const url = () => `${location.origin}/overlay/${(GAMES.find(g => g[0] === game) || GAMES[0])[4]}.html`;

  const css = document.createElement('style');
  css.textContent = `
  .pu-shade[hidden] { display: none !important; }
  .pu-shade { position: fixed; inset: 0; z-index: 85; display: grid; place-items: center; background: rgba(5,3,12,.78); backdrop-filter: blur(3px); }
  .pu-card { position: relative; width: min(640px, calc(100vw - 24px)); max-height: calc(100vh - 30px); overflow: auto; padding: 26px 26px 20px; border-radius: 24px;
    background: radial-gradient(circle at 100% 0, rgba(255,46,126,.18), transparent 45%), linear-gradient(180deg, #1f1735, #110d1f); border: 1px solid rgba(255,255,255,.14); box-shadow: 0 30px 90px rgba(0,0,0,.6); animation: puIn .35s cubic-bezier(.2,1.3,.4,1); }
  @keyframes puIn { from { transform: translateY(14px) scale(.97); opacity: 0 } }
  .pu-top { display: flex; align-items: center; gap: 10px; margin-bottom: 16px; }
  .pu-bar { flex: 1; display: grid; grid-template-columns: repeat(${STEPS}, 1fr); gap: 6px; }
  .pu-bar i { height: 6px; border-radius: 9px; background: rgba(255,255,255,.12); transition: background .3s; }
  .pu-bar i.on { background: linear-gradient(90deg, var(--c1, #ff6a2b), var(--c2, #ff2e7e)); }
  .pu-n { font-size: 12px; font-weight: 800; opacity: .6; white-space: nowrap; }
  .pu-x { background: none; border: 0; color: rgba(255,255,255,.5); font-size: 13px; cursor: pointer; padding: 4px 6px; }
  .pu-x:hover { color: #fff; }
  .pu-ic { font-size: 44px; line-height: 1; }
  .pu-card h2 { margin: 8px 0 6px; font-size: 26px; font-family: var(--display, inherit); }
  .pu-card p.pu-sub { margin: 0 0 16px; color: rgba(255,255,255,.75); line-height: 1.5; }
  .pu-user { display: flex; align-items: center; gap: 0; border-radius: 16px; background: rgba(255,255,255,.06); border: 2px solid rgba(255,255,255,.14); padding: 4px 4px 4px 14px; }
  .pu-user:focus-within { border-color: var(--c1, #ff6a2b); }
  .pu-user span { font-size: 20px; font-weight: 800; opacity: .6; }
  .pu-user input { flex: 1; min-width: 0; background: none; border: 0; outline: 0; color: #fff; font: inherit; font-size: 20px; font-weight: 700; padding: 10px 6px; }
  .pu-games { display: grid; grid-template-columns: repeat(auto-fill, minmax(180px, 1fr)); gap: 10px; }
  .pu-g { text-align: left; padding: 14px; border-radius: 16px; background: rgba(255,255,255,.05); border: 2px solid rgba(255,255,255,.1); color: #fff; cursor: pointer; font: inherit; transition: transform .12s, border-color .12s, background .12s; }
  .pu-g:hover { transform: translateY(-2px); background: rgba(255,255,255,.08); }
  .pu-g.on { border-color: var(--c1, #ff6a2b); background: linear-gradient(135deg, rgba(255,106,43,.18), rgba(255,46,126,.12)); }
  .pu-g b { display: block; font-size: 15px; margin: 6px 0 4px; } .pu-g small { display: block; font-size: 12.5px; opacity: .7; line-height: 1.35; } .pu-g em { font-style: normal; font-size: 28px; }
  .pu-tabs { display: flex; gap: 8px; margin-bottom: 14px; }
  .pu-tabs button { flex: 1; padding: 12px; border-radius: 14px; border: 2px solid rgba(255,255,255,.12); background: rgba(255,255,255,.04); color: #fff; font: inherit; font-weight: 800; cursor: pointer; }
  .pu-tabs button.on { border-color: var(--c1, #ff6a2b); background: rgba(255,106,43,.14); }
  .pu-link { display: flex; gap: 8px; align-items: center; padding: 10px 10px 10px 14px; border-radius: 14px; background: rgba(0,0,0,.35); border: 1px dashed rgba(255,255,255,.25); margin-bottom: 14px; }
  .pu-link code { flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; font-size: 14px; color: #ffd23f; }
  .pu-steps { margin: 0; padding: 0; list-style: none; counter-reset: pu; display: flex; flex-direction: column; gap: 8px; }
  .pu-steps li { counter-increment: pu; display: flex; gap: 10px; align-items: flex-start; line-height: 1.45; font-size: 14.5px; }
  .pu-steps li::before { content: counter(pu); flex: none; width: 24px; height: 24px; border-radius: 50%; display: grid; place-items: center; font-size: 12px; font-weight: 900; background: linear-gradient(135deg, var(--c1, #ff6a2b), var(--c2, #ff2e7e)); }
  .pu-prev { position: relative; height: 260px; border-radius: 16px; overflow: hidden; background: repeating-conic-gradient(#1b1528 0 25%, #221a33 0 50%) 0 0 / 24px 24px; border: 1px solid rgba(255,255,255,.12); margin-bottom: 12px; }
  .pu-prev iframe { position: absolute; left: 0; top: 0; width: 1280px; height: 720px; border: 0; transform-origin: 0 0; pointer-events: none; }
  .pu-ok { padding: 10px 14px; border-radius: 12px; background: rgba(47,211,138,.12); border: 1px solid rgba(47,211,138,.35); font-size: 14px; margin-top: 10px; }
  .pu-foot { display: flex; align-items: center; gap: 8px; margin-top: 20px; }
  .pu-foot .sp { flex: 1; }
  .pu-done { display: grid; grid-template-columns: repeat(auto-fill, minmax(170px, 1fr)); gap: 8px; }
  .pu-done button { padding: 12px; border-radius: 14px; border: 1px solid rgba(255,255,255,.12); background: rgba(255,255,255,.05); color: #fff; font: inherit; font-weight: 700; cursor: pointer; text-align: left; }
  .pu-done button:hover { background: rgba(255,255,255,.1); }
  @media (max-width: 560px) { .pu-card { padding: 20px 16px 16px; } .pu-card h2 { font-size: 22px; } }`;
  document.head.appendChild(css);

  const shade = document.createElement('div'); shade.className = 'pu-shade'; shade.hidden = true;
  document.body.appendChild(shade);

  function copy(t) { navigator.clipboard?.writeText(t).then(() => toast('🔗 Link copiado')).catch(() => toast('Copia el link a mano')); }

  function body() {
    const g = GAMES.find(x => x[0] === game) || GAMES[0];
    if (i === 0) {
      const u = (window.cfg?.username || document.getElementById('user')?.value || '').replace(/^@/, '');
      return `<div class="pu-ic">👋</div><h2>¡Hola! Vamos a dejar tu primer juego listo</h2>
        <p class="pu-sub">Son 4 pasos y menos de 2 minutos. Primero, ¿cuál es tu usuario de TikTok?</p>
        <label class="pu-user"><span>@</span><input data-puu placeholder="tu_usuario" value="${esc(u)}" autocomplete="off" spellcheck="false"></label>
        <p class="hint" style="margin-top:10px">No tienes que estar en vivo ahora: ChispaLive se conecta solo apenas empieces tu live.</p>`;
    }
    if (i === 1) return `<div class="pu-ic">🎮</div><h2>Elige tu primer juego</h2>
      <p class="pu-sub">Después puedes prender todos los que quieras. Empieza con uno:</p>
      <div class="pu-games">${GAMES.map(([k, ic, n, d]) => `<button class="pu-g${k === game ? ' on' : ''}" data-pug="${k}"><em>${ic}</em><b>${n}</b><small>${d}</small></button>`).join('')}</div>`;
    if (i === 2) {
      const studio = where === 'studio';
      return `<div class="pu-ic">🖥️</div><h2>Ponlo en tu live</h2>
        <p class="pu-sub">Así tus viewers ven <b>${g[2]}</b> en pantalla. ¿Con qué transmites?</p>
        <div class="pu-tabs"><button data-puw="studio" class="${studio ? 'on' : ''}">📱 TikTok LIVE Studio</button><button data-puw="obs" class="${studio ? '' : 'on'}">🎬 OBS</button></div>
        <div class="pu-link"><code>${esc(url())}</code><button class="btn sm pri" data-pucopy>📋 Copiar link</button></div>
        <ol class="pu-steps">${studio
          ? `<li><span>Abre <b>TikTok LIVE Studio</b>.</span></li><li><span>En "Fuentes", toca <b>＋ Agregar</b> y elige <b>Enlace</b> (o "Link").</span></li><li><span>Pega el link que copiaste y dale <b>Agregar</b>.</span></li><li><span>Acomoda el cuadro donde quieras que se vea el juego.</span></li>`
          : `<li><span>En OBS, en "Fuentes", toca <b>＋</b> y elige <b>Navegador</b>.</span></li><li><span>Pega el link en <b>URL</b>. Ancho <b>1280</b> y alto <b>720</b>.</span></li><li><span>Dale <b>Aceptar</b> y acomoda el cuadro.</span></li><li><span>Listo: el fondo es transparente, solo se ve el juego.</span></li>`}</ol>
        <p class="hint" style="margin-top:12px">Todos los links de tus juegos están también en 🖥️ <b>Overlays</b>.</p>`;
    }
    if (i === 3) return `<div class="pu-ic">⚡</div><h2>Pruébalo sin estar en vivo</h2>
      <p class="pu-sub">Manda regalos de mentira y mira cómo reacciona <b>${g[2]}</b>. Si ya lo pusiste en LIVE Studio u OBS, también se mueve ahí.</p>
      <div class="pu-prev"><iframe src="${esc(url())}" title="Vista previa"></iframe></div>
      <button class="btn pri" data-putest>🎁 Mandar regalos de prueba</button><div data-puok></div>`;
    return `<div class="pu-ic">🚀</div><h2>¡Listo para tu primer live!</h2>
      <p class="pu-sub">${esc(g[2])} ya está prendido. Cuando empieces tu live en TikTok, ChispaLive se conecta solo y el juego funciona con los regalos de verdad.</p>
      <div class="pu-done">
        <button data-pud="game">⚙️ Ajustar ${esc(g[2])}<br><small class="hint">regalos, tiempos y sonidos</small></button>
        <button data-pud="games">🎮 Ver todos los juegos<br><small class="hint">hay 20 para elegir</small></button>
        <button data-pud="tour">🧭 Recorrido por el panel<br><small class="hint">qué hay en cada sección</small></button>
        <button data-pud="lic">💎 Mi plan<br><small class="hint">tu prueba gratis y los planes</small></button>
      </div>`;
  }

  function show() {
    shade.innerHTML = `<div class="pu-card" role="dialog" aria-modal="true">
      <div class="pu-top"><div class="pu-bar">${Array.from({ length: STEPS }, (_, k) => `<i class="${k <= i ? 'on' : ''}"></i>`).join('')}</div><span class="pu-n">${i + 1} / ${STEPS}</span><button class="pu-x" data-puskip>Omitir ✕</button></div>
      ${body()}
      <div class="pu-foot">${i > 0 && i < STEPS - 1 ? '<button class="btn" data-puprev>← Atrás</button>' : ''}<span class="sp"></span>
        ${i < STEPS - 1 ? `<button class="btn pri" data-punext>${i === 0 ? 'Guardar y seguir →' : i === 3 ? 'Ya lo probé →' : 'Siguiente →'}</button>` : '<button class="btn pri" data-puclose>🎉 Terminar</button>'}</div></div>`;
    shade.hidden = false;
    const $ = q => shade.querySelector(q);
    $('[data-puskip]').onclick = finish;
    $('[data-puprev]') && ($('[data-puprev]').onclick = () => { i--; show(); });
    $('[data-punext]') && ($('[data-punext]').onclick = next);
    $('[data-puclose]') && ($('[data-puclose]').onclick = finish);
    shade.querySelectorAll('[data-pug]').forEach(b => b.onclick = () => { game = b.dataset.pug; show(); });
    shade.querySelectorAll('[data-puw]').forEach(b => b.onclick = () => { where = b.dataset.puw; show(); });
    $('[data-pucopy]') && ($('[data-pucopy]').onclick = () => copy(url()));
    const inp = $('[data-puu]'); if (inp) { inp.focus(); inp.onkeydown = e => { if (e.key === 'Enter') next(); }; }
    fit();
    $('[data-putest]') && ($('[data-putest]').onclick = () => {
      socket.emit('game', { key: game, action: 'test' });
      if (game === 'batalla' || game === 'carrera') setTimeout(() => socket.emit('game', { key: game, action: 'start' }), 300);
      setTimeout(() => socket.emit('game', { key: game, action: 'test' }), 1500);
      $('[data-puok]').innerHTML = `<div class="pu-ok">✅ ¡Funciona! Así se va a ver con los regalos de tus viewers.</div>`;
    });
    shade.querySelectorAll('[data-pud]').forEach(b => b.onclick = () => {
      const d = b.dataset.pud; finish();
      if (d === 'game') go(game); else if (d === 'games') document.querySelector('#nav-Juegos')?.scrollIntoView({ block: 'center' }), go(game);
      else if (d === 'tour') window.ChispaGuia?.start(1); else if (d === 'lic') go('licencia');
    });
  }
  // La vista previa del juego, encogida para que entre en la tarjeta
  function fit() { const pv = shade.querySelector('.pu-prev'), f = pv?.querySelector('iframe'); if (f) { const s = pv.clientWidth / 1280; f.style.transform = `scale(${s})`; pv.style.height = Math.round(720 * s) + 'px'; } }
  addEventListener('resize', () => open && fit());

  function next() {
    if (i === 0) {
      const u = (shade.querySelector('[data-puu]')?.value || '').trim().replace(/^@/, '');
      if (!u) { shade.querySelector('[data-puu]')?.focus(); return toast('Escribe tu usuario de TikTok'); }
      const el = document.getElementById('user'); if (el) el.value = u;
      socket.emit('saveConfig', { autoConnect: true });
      socket.emit('connectLive', u);
    }
    if (i === 1) socket.emit('saveConfig', { games: { [game]: { enabled: true } } });
    i = Math.min(STEPS - 1, i + 1); show();
  }
  function start() { i = 0; open = true; if (typeof go === 'function') go('inicio'); show(); }
  function finish() {
    open = false; shade.hidden = true; shade.innerHTML = '';
    try { localStorage.setItem('chispa.guia', '1'); } catch {}
    if (typeof socket !== 'undefined' && !window.cfg?.guideDone) socket.emit('saveConfig', { guideDone: true });
  }
  addEventListener('keydown', e => { if (open && e.key === 'Escape') finish(); });
  window.ChispaPrimer = { start, finish };
})();
