// ===== Licencia y compra — página del panel =====
(function () {
  let LIC = null, T = {}, plan = 'anual', pay = 'tarjeta', tier = 'pro';
  // Planes: solo se muestran los que tienen precio en tienda.json ("De por vida" queda para claves especiales)
  // Los del Plan Básico empiezan con "b" (bmensual, banual, bvida)
  const PL_ALL = [
    ['semanal', 'Pro semanal', '/ semana', 'Para probar pagando poco', ''],
    ['mensual', 'Pro mensual', '/ mes', 'Para probar en serio', ''],
    ['anual', 'Pro anual', '/ año', '', 'MÁS POPULAR'],
    ['vida', 'Pro de por vida', 'un solo pago', 'Tuyo para siempre + todas las actualizaciones', 'MEJOR VALOR'],
    ['bsemanal', 'Básico semanal', '/ semana', 'Para probar pagando poco', ''],
    ['bmensual', 'Básico mensual', '/ mes', 'Para empezar', ''],
    ['banual', 'Básico anual', '/ año', '', 'MÁS POPULAR'],
    ['bvida', 'Básico de por vida', 'un solo pago', 'Tuyo para siempre', ''],
  ];
  const TIERS = {
    basico: { name: 'Básico', ic: '⭐', tag: '', feats: ['🎮 6 juegos: Spin Royale, Ruleta, Lucky Roll, Frasco, Batalla y Carrera', '🔔 Alertas, chat en pantalla, mensaje destacado, metas, meta de corazón, rankings y votación', '🗣️ Voz del chat, Acciones y filtro del chat', '🎬 Control de OBS y 🎥 efectos en la cámara', '🎨 Diseños de temporada y 📱 control desde el celular'] },
    pro: { name: 'Pro', ic: '💎', tag: 'TODO INCLUIDO', feats: ['✅ Todo lo del Básico', '🔨 Subasta y ⏰ Subathon, los que más regalos mueven', '🎮 12 juegos más: Bingo, Piedra papel o tijera, Castillos, Torre, Jefe, Trivia, Adivina, Bomba, Pesca, Penales, Tragamonedas y Mascota', '🎟️ Sorteos, 🥊 Marcador PK y 🧸 Muñequitos del chat', '⭐ Puntos y niveles para tus viewers', '🧱 Roblox conectado a tu live'] },
  };
  const isB = k => /^b/.test(k), per = k => k.replace(/^b/, '');
  const PLAN_LIST = () => PL_ALL.filter(p => isB(p[0]) === (tier === 'basico') && T.precios?.[p[0]]).map(p => {
    if (per(p[0]) !== 'anual') return p;
    const pre = tier === 'basico' ? 'b' : '', m = T.precios?.[pre + 'mensual']?.usd, a = T.precios?.[p[0]]?.usd, pct = m && a ? Math.round((1 - a / (m * 12)) * 100) : 0;
    return [p[0], p[1], p[2], pct > 0 ? `Ahorras ${pct}% (casi ${Math.max(1, Math.round(12 - a / m))} meses gratis)` : 'Un año completo', p[4]];
  });
  const fromPrice = t => { const l = PL_ALL.filter(p => isB(p[0]) === (t === 'basico') && T.precios?.[p[0]]?.pen && per(p[0]) === 'mensual')[0]; return l ? T.precios[l[0]].pen : null; };
  function setTier(t) { tier = t; const p = (tier === 'basico' ? 'b' : '') + per(plan); plan = T.precios?.[p] ? p : (PLAN_LIST()[0] || [])[0] || plan; }
  const planName = k => (PL_ALL.find(p => p[0] === k) || [])[1] || k;
  const PL = { find: f => PL_ALL.find(f) }; // compatibilidad
  const PAYS_ALL = [['tarjeta', '💳', 'Tarjeta / PayPal', 'Automático'], ['yape', '🟣', 'Yape', 'Perú'], ['bancos', '🏦', 'Plin y bancos', 'BCP, BBVA, Interbank, Plin…'], ['cripto', '🪙', 'USDT (cripto)', 'Desde cualquier país'], ['pagoefectivo', '🟡', 'PagoEfectivo', 'Banca, agentes y bodegas']];
  // "Plin y bancos" y PagoEfectivo solo salen si tienen sus datos en tienda.json
  const PAYS_ON = () => PAYS_ALL.filter(([k]) => k === 'bancos' ? T.bancos?.qr : k === 'cripto' ? (T.cripto?.redes?.length || T.cripto?.direccion) : k === 'pagoefectivo' ? T.pagoefectivo?.link : true);
  const PAYS = { find: f => PAYS_ALL.find(f) };
  const money = (v, c) => v == null ? '—' : c === 'pen' ? `S/ ${(+v).toLocaleString('es')}` : `$${(+v).toLocaleString('en')}`;
  const price = (p, c) => T.precios?.[p]?.[c];
  const fdate = ms => new Date(ms).toLocaleDateString('es', { day: 'numeric', month: 'long', year: 'numeric' });

  // ---------- navegación ----------
  const nb = document.createElement('button'); nb.className = 'nav'; nb.dataset.s = 'licencia';
  nb.innerHTML = '<span class="ic">💎</span>Licencia<span class="badge" data-licbadge></span>';
  document.querySelector('.nav[data-s="overlays"]').after(nb);
  nb.onclick = () => go('licencia');

  const sec = document.createElement('section'); sec.className = 'sec'; sec.id = 's-licencia';
  document.getElementById('s-overlays').after(sec);
  // aviso arriba durante la prueba
  const bar = document.createElement('div'); bar.className = 'lic-bar hidden';
  document.querySelector('main').prepend(bar);

  let payPicked = false;
  // Botón de la comunidad de Discord en el menú
  const dc = document.createElement('a'); dc.className = 'nav nav-dc hidden'; dc.target = '_blank';
  dc.innerHTML = '<span class="ic">💬</span>Comunidad Discord';
  document.querySelector('.nav[data-s="ajustes"]').after(dc);
  socket.on('lic:tienda', t => {
    T = t || {};
    dc.href = T.discord || '#'; dc.classList.toggle('hidden', !T.discord);
    // abre en el primer método que ya tenga datos
    if (!payPicked) { const has = { tarjeta: Object.values(T.lemon?.checkout || {}).some(Boolean), yape: T.yape?.numero || T.yape?.qr, pagoefectivo: T.pagoefectivo?.link }; pay = Object.keys(has).find(k => has[k]) || 'yape'; }
    if (!T.precios?.[plan]) plan = Object.keys(T.precios || {}).includes('anual') ? 'anual' : Object.keys(T.precios || {})[0] || 'mensual';
    tier = isB(plan) ? 'basico' : 'pro';
    paint();
  });
  socket.on('lic:pro', () => toast('💎 Eso es del Plan Pro. Mira la página 💎 Licencia para pasarte.'));
  socket.on('lic', s => { const was = LIC?.allowed; LIC = s; paint(); if (was !== false && !s.allowed) lockNow(); if (s.allowed) document.body.classList.remove('lic-locked'); });
  socket.on('lic:need', s => { LIC = s; paint(); lockNow(); toast('🔑 ' + (s.msg || 'Activa tu licencia para conectarte al live')); });
  // pide la licencia apenas este script está listo (si llegó antes de escuchar, se perdía)
  socket.emit('lic:get'); socket.on('connect', () => socket.emit('lic:get'));
  function lockNow() { document.body.classList.add('lic-locked'); go('licencia'); }
  // si está bloqueado, solo se puede abrir esta página
  document.addEventListener('click', e => { const n = e.target.closest('.nav, [data-go]'); if (n && document.body.classList.contains('lic-locked') && (n.dataset.s || n.dataset.go) !== 'licencia') { e.stopPropagation(); e.preventDefault(); toast('🔑 Activa tu licencia para usar ChispaLive'); } }, true);

  const buyMsg = () => `Hola! Compré ChispaLive plan ${planName(plan)} (${money(price(plan, 'pen'), 'pen')} / ${money(price(plan, 'usd'), 'usd')}) por ${(PAYS.find(p => p[0] === pay) || [])[2] || ''}. Adjunto mi comprobante.\nMi código de equipo: ${LIC?.machine || ''}`;
  function waLink() {
    const num = String(T.whatsapp || '').replace(/\D/g, '');
    return num ? `https://wa.me/${num}?text=${encodeURIComponent(buyMsg())}` : '';
  }
  // Comprobante: Discord (ticket privado) > WhatsApp > DM de TikTok
  function sendProof() {
    const copy = `<button class="btn" data-copymsg>📋 Copiar mi mensaje (con mi código de equipo)</button>`;
    if (T.discord) return `<div class="row" style="margin:0;gap:8px;flex-wrap:wrap"><a class="btn pri" href="${esc(T.discord)}" target="_blank">💬 Enviar comprobante en Discord</a>${copy}</div>
      <div class="hint" style="margin-top:6px">En el Discord ve a <b>#🎫・comprar-licencia</b> y abre un <b>ticket</b> (es privado: solo lo vemos tú y nosotros). Pega tu mensaje y la captura del pago.</div>`;
    const url = waLink();
    if (url) return `<a class="btn pri lic-wa" href="${url}" target="_blank">📲 Enviar comprobante por WhatsApp</a>`;
    return `${copy}<div class="hint" style="margin-top:6px">Envíalo por DM a <b>${esc(T.tiktok || '@esnutbear')}</b> en TikTok junto con la foto del comprobante.</div>`;
  }
  const row = (k, v, copy) => v ? `<div class="lic-kv"><span>${k}</span><b>${esc(v)}</b>${copy ? `<button class="ib" data-cp="${esc(v)}" title="Copiar">📋</button>` : ''}</div>` : '';
  const soon = '<div class="lic-soon">⏳ Este método estará disponible muy pronto. Mientras tanto usa otro.</div>';
  function payBox() {
    const pen = money(price(plan, 'pen'), 'pen'), usd = money(price(plan, 'usd'), 'usd');
    if (pay === 'tarjeta') {
      const link = T.lemon?.checkout?.[plan];
      return `<div class="lic-auto">⚡ <b>Activación automática:</b> pagas y al instante recibes tu clave (también llega a tu correo). La pegas abajo y ChispaLive se activa solo en esta computadora.</div>
        <ol class="lic-steps"><li>Paga <b>${usd}</b> con tarjeta de crédito, débito o PayPal.</li><li>Copia la clave que aparece al terminar (o en tu correo).</li><li>Pégala en <b>Activar mi clave</b> 👇</li></ol>
        ${link ? `<a class="btn pri big" href="${esc(link)}" target="_blank">💳 Pagar ${usd} con tarjeta o PayPal</a>` : soon}`;
    }
    const steps = (how, data) => `<ol class="lic-steps"><li>${how}</li><li>Envía la captura del comprobante con tu <b>código de equipo</b> (ya va en el mensaje).</li><li>Te respondemos con tu clave: pégala en <b>Activar mi clave</b> 👇</li></ol>${data}<div style="margin-top:12px">${sendProof()}</div>`;
    if (pay === 'yape') { const y = T.yape || {}; if (!y.numero && !y.qr) return soon;
      return steps(`Yapea <b>${pen}</b> a <b>${esc(T.marca || 'ChispaLive')}</b>.`, `<div class="lic-pay">${y.qr ? `<img class="lic-qr" src="${esc(y.qr)}" alt="QR Yape">` : ''}<div>${row('Pagar a', T.marca || 'ChispaLive')}${row('Número Yape', y.numero, true)}${row('Monto', pen)}${y.nombre ? `<div class="hint" style="margin-top:4px">En Yape aparecerá el titular: <b>${esc(y.nombre)}</b> ✅</div>` : ''}</div></div>`); }
    if (pay === 'cripto') { const c = T.cripto || {}, nets = c.redes?.length ? c.redes : (c.direccion ? [{ id: 'red', red: c.red, direccion: c.direccion, qr: c.qr }] : []);
      if (!nets.length) return soon;
      const n = nets.find(x => x.id === cnet) || nets[0], coin = esc(c.moneda || 'USDT');
      return steps(`Envía <b>${usd} en ${coin}</b> por la red <b>${esc(n.red)}</b> a la dirección de abajo (desde Binance, Lemon, Bybit o la billetera que uses).`,
        `${nets.length > 1 ? `<div class="lic-nets"><small>¿Por qué red vas a enviar?</small>${nets.map(x => `<button class="${x === n ? 'on' : ''}" data-cnet="${esc(x.id)}"><b>${esc(x.red)}</b>${x.nota ? `<small>${esc(x.nota)}</small>` : ''}</button>`).join('')}</div>` : ''}
        <div class="lic-pay">${n.qr ? `<img class="lic-qr" src="${esc(n.qr)}" alt="QR de la dirección">` : ''}<div>${row('Moneda', c.moneda || 'USDT')}${row('Red', n.red)}${row('Dirección', n.direccion, true)}${row('Monto', usd)}
        <div class="lic-warn">⚠️ Esta dirección es solo para <b>${coin}</b> por la red <b>${esc(n.red)}</b>. Si mandas otra moneda o usas otra red, el dinero se pierde y no se puede recuperar.</div></div></div>`); }
    if (pay === 'bancos') { const q = T.bancos || {}; if (!q.qr) return soon;
      return steps(`Paga <b>${pen}</b> escaneando el QR desde la app de tu banco o billetera (BCP, BBVA, Interbank, Scotiabank, Plin…): elige <b>Pagar con QR</b>.`, `<div class="lic-pay"><img class="lic-qr" src="${esc(q.qr)}" alt="QR para pagar desde tu banco"><div>${row('Pagar a', T.marca || 'ChispaLive')}${row('Monto', pen)}${q.nombre ? `<div class="hint" style="margin-top:4px">Al pagar aparecerá el titular: <b>${esc(q.nombre)}</b> ✅</div>` : ''}</div></div>`); }
    if (pay === 'pagoefectivo') { const l = T.pagoefectivo?.link; if (!l) return soon;
      return steps(`Paga <b>${pen}</b> con PagoEfectivo: desde tu banca por internet o app (BCP, BBVA, Interbank, Scotiabank…), o en efectivo en agentes y bodegas con tu código CIP.`, `<a class="btn big" href="${esc(l)}" target="_blank" style="margin-top:6px">🟡 Pagar con PagoEfectivo</a>`); }
    return '';
  }

  // ---------- Mi plan, lo que incluye, comparar y compras ----------
  let showBuy = false, cnet = '';
  const FEAT = {
    basico: ['🎡 Spin Royale', '🎯 Ruleta', '🎲 Lucky Roll', '🫙 Frasco de regalos', '⚔️ Batalla de equipos', '🏁 Carrera', '🔔 Alertas', '💬 Chat en pantalla', '📌 Mensaje destacado', '🎯 Metas', '💗 Meta de corazón', '🏆 Rankings', '🗳️ Votación', '🗣️ Voz del chat', '⚡ Acciones y eventos', '🛡️ Filtro del chat', '🎬 Control de OBS', '🛍️ Diseños de temporada', '📱 Control desde el celular'],
    pro: ['🔨 Subasta', '⏰ Subathon', '🎱 Bingo del chat', '✊ Piedra, papel o tijera', '🏰 Guerra de castillos', '🗼 Torre de regalos', '👹 Derrota al jefe', '❓ Trivia', '🔤 Adivina la palabra', '💣 Bomba caliente', '🎣 Pesca', '⚽ Penales', '🎰 Tragamonedas', '🐣 Mascota', '🎟️ Sorteos', '🥊 Marcador PK', '🧸 Muñequitos del chat', '⭐ Puntos y niveles', '🧱 Roblox'],
  };
  const CMP = [
    ['🎮 Juegos', [['6 juegos de regalos: Spin Royale, Ruleta, Lucky Roll, Frasco, Batalla y Carrera', 1, 1, 1], ['Subasta y Subathon', 1, 0, 1], ['Bingo y Piedra, papel o tijera', 1, 0, 1], ['Castillos, Torre, Jefe y Trivia', 1, 0, 1], ['Adivina, Bomba, Pesca, Penales, Tragamonedas y Mascota', 1, 0, 1]]],
    ['🔔 Widgets', [['Alertas, chat en pantalla y mensaje destacado', 1, 1, 1], ['Metas, meta de corazón, rankings y votación', 1, 1, 1], ['Sorteos y Marcador PK', 1, 0, 1], ['Muñequitos del chat', 1, 0, 1], ['Puntos y niveles', 1, 0, 1]]],
    ['🧰 Herramientas', [['Voz del chat', 1, 1, 1], ['Acciones y eventos', 1, 1, 1], ['Filtro del chat', 1, 1, 1], ['Control de OBS y efectos en la cámara', 1, 1, 1], ['Roblox', 1, 0, 1]]],
    ['✨ Extras', [['Diseños de temporada', 1, 1, 1], ['Control desde el celular', 1, 1, 1], ['Todas las actualizaciones', 1, 1, 1]]],
  ];
  function myPlan(s, owner, basicActive) {
    const now = Date.now(), K = owner ? 'owner' : s.state === 'active' ? (s.tier === 'basico' ? 'basico' : 'pro') : s.state === 'trial' ? 'trial' : 'off';
    const emb = { owner: '👑', pro: '💎', basico: '⭐', trial: '🎁', off: '🔒' }[K];
    const badge = owner ? 'DUEÑO' : s.state === 'active' ? (s.tier === 'basico' ? 'PLAN BÁSICO' : 'PLAN PRO') : s.state === 'trial' ? 'PRUEBA GRATIS' : s.state === 'expired' ? 'PLAN VENCIDO' : 'SIN PLAN';
    const pill = owner ? ['DUEÑO', 'ok'] : s.ownerTest ? ['PROBANDO', 'warn'] : s.state === 'active' ? ['ACTIVA', 'ok'] : s.state === 'trial' ? ['PRUEBA', 'warn'] : s.state === 'expired' ? ['VENCIDA', 'bad'] : ['SIN PLAN', 'bad'];
    const who = owner ? 'Todo desbloqueado en esta computadora' : [s.name, s.state === 'active' || s.state === 'expired' ? s.planName : s.state === 'trial' ? `${s.trialDays} días con todo desbloqueado` : ''].filter(Boolean).join(' · ') || 'Este equipo';
    const life = s.state === 'active' && !s.until;
    const pct = owner || life ? 1 : s.until && s.total ? Math.max(0, Math.min(1, (s.until - now) / s.total)) : 0;
    const N = 24, on = Math.round(pct * N), col = pct > .35 ? 'g' : pct > .15 ? 'o' : 'r';
    const when = owner ? 'Sin vencimiento' : life ? 'De por vida · no vence nunca' : s.state === 'active' ? `${s.via === 'lemon' ? 'Se renueva el' : 'Vence el'} ${fdate(s.until)}` : s.state === 'trial' ? `La prueba termina el ${fdate(s.until)}` : s.state === 'expired' && s.until ? `Venció el ${fdate(s.until)}` : (s.msg || 'Elige un plan para seguir');
    const left = owner || life ? '∞' : s.state === 'active' || s.state === 'trial' ? (s.daysLeft > 1 ? `${s.daysLeft} días` : s.hoursLeft ? `${s.hoursLeft} horas` : '1 día') : '0 días';
    const btns = [
      !owner && !life ? `<button class="btn pri" data-renew>${s.state === 'active' ? '🔁 Renovar' : '💎 Elegir un plan'}</button>` : '',
      basicActive ? `<button class="btn gold" data-up>💎 Pasar a Pro</button>` : '',
      s.state === 'active' && !owner ? `<button class="btn" data-ldeact>↪ Quitar de esta PC</button>` : '',
    ].join('');
    return `<div class="panel mp mp-${K}"><i class="mp-glow"></i>
      <div class="mp-top"><div class="mp-emb">${emb}</div><div class="mp-id"><span class="mp-badge">${badge}</span><b class="mp-who">${esc(who)}</b>${s.ownerTest ? `<small class="hint">Eres el dueño, pero tienes una licencia activada: ves la app igual que ese cliente. Quita la licencia para volver a tener todo.</small>` : ''}</div>
        <span class="mp-pill ${pill[1]}">${pill[0]}</span></div>
      <div class="mp-mid"><div class="mp-when">${esc(when)}</div>
        <div class="mp-barrow"><div class="mp-bar ${col}">${Array.from({ length: N }, (_, i) => `<i class="${i < on ? 'on' : ''}" style="--d:${i * 25}ms"></i>`).join('')}</div><b class="mp-left">${left}</b></div>
        <div class="mp-btns">${btns}<div class="lic-code"><small>Código de este equipo</small><b>${s.machine}</b><button class="btn sm" data-cp="${s.machine}">📋 Copiar</button></div></div></div></div>`;
  }
  function included(s, owner) {
    if (!(s.allowed || owner)) return '';
    const all = owner || s.state === 'trial' || s.tier !== 'basico';
    const items = [...FEAT.basico.map(x => [x, 1]), ...FEAT.pro.map(x => [x, all ? 1 : 0])];
    return `<div class="panel mp-inc"><div class="ptitle c2">✅ Lo que incluye tu plan</div>
      <div class="mp-grid">${items.map(([x, ok]) => `<span class="${ok ? 'ok' : 'no'}"><i>${ok ? '✓' : '🔒'}</i>${x}</span>`).join('')}</div>
      ${all ? '' : `<div class="mp-more"><span>🔒 Lo que tiene candado es del <b>Plan Pro</b>.</span><button class="btn sm gold" data-up>💎 Pasar a Pro</button></div>`}</div>`;
  }
  function compare(s, owner) {
    const cur = owner ? -1 : s.state === 'trial' ? 0 : s.state === 'active' ? (s.tier === 'basico' ? 1 : 2) : -1;
    const pm = t => { const v = fromPrice(t); return v ? `S/ ${v}<small> / mes</small>` : '—'; };
    const cell = (v, i) => `<td class="${i === cur ? 'cur' : ''}">${v === 1 ? '<i class="y">✓</i>' : v === 0 ? '<i class="n">—</i>' : v}</td>`;
    return `<details class="panel mp-cmp"><summary><span class="ptitle c4" style="margin:0">📊 Comparar planes</span><i class="mp-chev">⌄</i></summary>
      <div class="mp-tw"><table><thead><tr><th></th>${['🎁 Prueba gratis', '⭐ Básico', '💎 Pro'].map((h, i) => `<th class="${i === cur ? 'cur' : ''}">${h}${i === cur ? '<em>Tu plan</em>' : ''}</th>`).join('')}</tr></thead><tbody>
        <tr class="price"><td>Precio</td>${[`${s.trialDays || 3} días gratis`, pm('basico'), pm('pro')].map(cell).join('')}</tr>
        ${CMP.map(([g, rows]) => `<tr class="grp"><td colspan="4">${g}</td></tr>${rows.map(([n, ...v]) => `<tr><td>${n}</td>${v.map(cell).join('')}</tr>`).join('')}`).join('')}
      </tbody></table></div></details>`;
  }
  function compras(s) {
    const L = s.compras || [], now = Date.now();
    const st = (c, i) => i === 0 && s.state === 'active' ? ['ACTIVA', 'ok'] : c.until && c.until < now ? ['VENCIDA', 'bad'] : i === 0 && s.state === 'expired' ? ['VENCIDA', 'bad'] : ['REEMPLAZADA', 'mut'];
    return `<details class="panel mp-buys" ${L.length ? '' : ''}><summary><span class="ptitle c3" style="margin:0">🧾 Mis compras (${L.length})</span><i class="mp-chev">⌄</i></summary>
      ${L.length ? `<div class="mp-tw"><table><thead><tr><th>Fecha</th><th>Plan</th><th>Pago</th><th>Vence</th><th>Estado</th></tr></thead><tbody>
        ${L.map((c, i) => { const [t, k] = st(c, i); return `<tr><td>${new Date(c.at).toLocaleDateString('es')}</td><td><b>${esc(c.name)}</b>${c.carryDays ? `<small class="hint"> · +${c.carryDays} días que te quedaban</small>` : ''}</td><td>${c.via === 'lemon' ? '💳 Tarjeta / PayPal' : '🟣 Yape u otro'}</td><td>${c.until ? new Date(c.until).toLocaleDateString('es') : 'Nunca'}</td><td><span class="mp-pill sm ${k}">${t}</span></td></tr>`; }).join('')}
      </tbody></table></div>` : `<div class="hint" style="padding:6px 2px">Todavía no hay compras en esta computadora. Cuando actives una clave, aparece aquí.</div>`}</details>`;
  }
  function paint() {
    if (!LIC) return;
    const s = LIC, owner = s.owner && !s.ownerTest; // con una licencia activada, el dueño ve la app como la vería ese cliente
    // insignia del menú y barra de prueba
    const bd = nb.querySelector('[data-licbadge]');
    bd.textContent = s.state === 'trial' ? `PRUEBA ${s.daysLeft}D` : s.state === 'active' || owner ? 'ACTIVA' : 'ACTIVAR';
    bd.className = 'badge ' + (s.state === 'active' || owner ? 'ok' : '');
    bar.classList.toggle('hidden', s.state !== 'trial');
    if (s.state === 'trial') bar.innerHTML = `🎁 <b>Prueba gratis:</b> ${s.daysLeft > 1 ? `te quedan ${s.daysLeft} días` : `te quedan ${s.hoursLeft} horas`} con todo desbloqueado. <button class="btn sm pri" data-buy>💎 Comprar licencia</button>`;
    bar.querySelector('[data-buy]')?.addEventListener('click', () => go('licencia'));

    paintPro(s);
    const basicActive = s.state === 'active' && !owner && s.tier === 'basico';
    if (basicActive && tier !== 'pro' && !showBuy) setTier('pro');
    const head = owner ? ['👑', 'Eres el dueño', 'Esta computadora tiene el generador de licencias. Todo desbloqueado.', 'ok']
      : s.ownerTest ? ['🧪', `Probando como cliente · ${esc(s.planName)}`, 'Eres el dueño, pero tienes una licencia activada: ves la app igual que ese cliente. Quita la licencia para volver a tener todo.', 'ok']
      : s.state === 'active' ? ['✅', `Licencia activa · ${esc(s.planName)}`, s.until ? `Vence el ${fdate(s.until)} (${s.daysLeft} días)` : 'De por vida: no vence nunca', 'ok']
      : s.state === 'trial' ? ['🎁', 'Prueba gratis', `Te quedan ${s.daysLeft} día(s): termina el ${fdate(s.until)}`, 'trial']
      : ['🔒', s.state === 'expired' ? 'Tu plan venció' : 'Tu prueba gratis terminó', esc(s.msg || 'Elige un plan para seguir usando ChispaLive.'), 'bad'];
    const keep = sec.querySelector('[data-lkey]')?.value || '';
    sec.innerHTML = `
      <div class="vz-head panel"><div class="vz-mascot rbx-logo">💎</div><div class="vz-ttl"><h1 class="display">Licencia</h1><p class="hint">Juegos, widgets, voz y acciones para tu TikTok LIVE. Elige tu plan, paga como prefieras y activa en segundos.</p></div></div>
      ${myPlan(s, owner, basicActive)}
      ${s.state === 'active' && !owner && !basicActive && !showBuy ? '' : `<div id="lic-buy"></div>
      ${basicActive ? `<div class="panel lic-up"><b>💎 Pásate a Pro</b><span class="hint">Desbloquea Subasta, Subathon, 12 juegos más, Sorteos, Marcador PK, Muñequitos, Puntos y niveles, y Roblox. Compras el Pro, pegas la nueva clave y listo.</span></div>` : ''}
      <div class="lic-tiers">${['basico', 'pro'].filter(t => !basicActive || t === 'pro').map(t => { const X = TIERS[t], fp = fromPrice(t); return `<button class="lic-tier ${tier === t ? 'on' : ''} t-${t}" data-tier="${t}">${X.tag ? `<i>${X.tag}</i>` : ''}<div class="lt-h"><span>${X.ic}</span><b>Plan ${X.name}</b>${fp != null ? `<small>desde ${money(fp, 'pen')} / mes</small>` : ''}</div><ul>${X.feats.map(x => `<li>${x}</li>`).join('')}</ul></button>`; }).join('')}</div>
      <div class="lic-plans">${PLAN_LIST().map(([k, n, per, d, tag]) => `<button class="lic-plan ${plan === k ? 'on' : ''}" data-plan="${k}">${tag ? `<i>${tag}</i>` : ''}<b>${n}</b>
        <span class="lic-price">${money(price(k, 'pen'), 'pen')}</span><small class="lic-usd">${money(price(k, 'usd'), 'usd')} USD · ${per}</small><small>${d}</small></button>`).join('')}</div>
      <div class="panel"><div class="ptitle c3">💸 ¿Cómo quieres pagar?</div>
        <div class="lic-pays">${PAYS_ON().map(([k, ic, n, sub]) => `<button class="${pay === k ? 'on' : ''}" data-pay="${k}"><span>${ic}</span><b>${n}</b><small>${sub}</small></button>`).join('')}</div>
        <div class="lic-box">${payBox()}</div></div>`}
      <div class="panel"><div class="ptitle c2">🔑 Activar mi clave</div>
        <div class="lic-act"><input class="i" data-lkey placeholder="Pega aquí tu clave (CHISPA-… o la de tu correo)" value="${esc(keep)}"><button class="btn pri" data-lact>Activar</button></div>
        <div class="hint" data-lmsg style="margin-top:8px">La clave queda atada a esta computadora.</div>
</div>
      ${included(s, owner)}
      ${compare(s, owner)}
      ${compras(s)}
      ${owner ? `<div class="panel lic-gen"><div class="ptitle c4">👑 Generador de licencias (solo tú lo ves)</div>
        <div class="hint" style="margin-bottom:10px">Cuando te paguen por Yape, Plin, Mercado Pago o Binance: pega el <b>código de equipo</b> que te mandó el cliente, elige el plan y genera su clave.</div>
        <div class="lic-genf"><label class="f">Código de equipo del cliente<input class="i" data-gcode placeholder="ABCD-EFGH-JKLM-NPQR"></label>
          <label class="f">Plan<select class="i" data-gplan>${PL_ALL.map(([k, n]) => `<option value="${k}">${n}${T.precios?.[k] ? '' : ' (especial / regalo)'}</option>`).join('')}</select></label>
          <label class="f">Nombre / TikTok del cliente<input class="i" data-gname placeholder="@cliente"></label></div>
        <button class="btn pri" data-gen style="margin-top:10px">✨ Generar clave</button>
        <div data-gout></div>
        <div class="flab" style="margin-top:14px">ÚLTIMAS CLAVES EMITIDAS</div><div class="lic-hist" data-ghist><div class="hint">Cargando…</div></div></div>` : ''}`;
    bind();
  }
  function bind() {
    sec.querySelectorAll('[data-plan]').forEach(b => b.onclick = () => { plan = b.dataset.plan; paint(); });
    const toBuy = () => setTimeout(() => sec.querySelector('#lic-buy')?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 60);
    sec.querySelectorAll('[data-renew]').forEach(b => b.onclick = () => { showBuy = true; if (LIC.plan && T.precios?.[LIC.plan]) { plan = LIC.plan; tier = /^b/.test(plan) ? 'basico' : 'pro'; } paint(); toBuy(); });
    sec.querySelectorAll('[data-up]').forEach(b => b.onclick = () => { showBuy = true; setTier('pro'); paint(); toBuy(); });
    sec.querySelectorAll('[data-tier]').forEach(b => b.onclick = () => { setTier(b.dataset.tier); paint(); });
    sec.querySelectorAll('[data-cnet]').forEach(b => b.onclick = () => { cnet = b.dataset.cnet; paint(); });
    sec.querySelectorAll('[data-pay]').forEach(b => b.onclick = () => { pay = b.dataset.pay; payPicked = true; paint(); });
    sec.querySelectorAll('[data-cp]').forEach(b => b.onclick = () => { navigator.clipboard.writeText(b.dataset.cp).then(() => toast('Copiado ✓')).catch(() => toast(b.dataset.cp)); });
    sec.querySelector('[data-copymsg]')?.addEventListener('click', () => { navigator.clipboard.writeText(buyMsg()).then(() => toast('Mensaje copiado ✓')); });
    const msg = sec.querySelector('[data-lmsg]'), inp = sec.querySelector('[data-lkey]');
    const doAct = () => {
      const k = inp.value.trim(); if (!k) return toast('Pega tu clave');
      msg.innerHTML = '⏳ Verificando…';
      socket.emit('lic:activate', k, r => {
        if (r?.ok) { inp.value = ''; showBuy = false; toast(r.carryDays ? `✅ ¡Renovado! Se sumaron ${r.carryDays} días que te quedaban` : '✅ ¡ChispaLive activado!'); confettiPanel(); LIC = r.status; document.body.classList.remove('lic-locked'); paint(); const k2 = sec.querySelector('[data-lkey]'); if (k2) k2.value = ''; }
        else msg.innerHTML = `<span style="color:var(--bad)">❌ ${esc(r?.error || 'No se pudo activar')}</span>`;
      });
    };
    sec.querySelector('[data-lact]').onclick = doAct; inp.onkeydown = e => { if (e.key === 'Enter') doAct(); };
    sec.querySelector('[data-ldeact]')?.addEventListener('click', () => { if (confirm('¿Quitar la licencia de esta computadora? Podrás activarla en otra con la misma clave.')) socket.emit('lic:deactivate', null, () => toast('Licencia quitada de esta PC')); });
    if (LIC.owner) {
      const out = sec.querySelector('[data-gout]');
      sec.querySelector('[data-gen]').onclick = () => {
        const d = { machine: sec.querySelector('[data-gcode]').value.trim(), plan: sec.querySelector('[data-gplan]').value, name: sec.querySelector('[data-gname]').value.trim() };
        socket.emit('lic:gen', d, r => {
          if (!r?.ok) { out.innerHTML = `<div class="hint" style="color:var(--bad);margin-top:8px">❌ ${esc(r?.error || 'Error')}</div>`; return; }
          const note = `¡Gracias por tu compra! 💖\nTu clave de ChispaLive (${planName(d.plan)}):\n\n${r.key}\n\nAbre ChispaLive → 💎 Licencia → pégala en "Activar mi clave".`;
          out.innerHTML = `<div class="lic-key"><code>${esc(r.key)}</code><div class="row" style="margin:8px 0 0"><button class="btn sm pri" data-ck>📋 Copiar clave</button><button class="btn sm" data-cn>💬 Copiar mensaje para el cliente</button></div></div>`;
          out.querySelector('[data-ck]').onclick = () => navigator.clipboard.writeText(r.key).then(() => toast('Clave copiada ✓'));
          out.querySelector('[data-cn]').onclick = () => navigator.clipboard.writeText(note).then(() => toast('Mensaje copiado ✓'));
          loadHist();
        });
      };
      loadHist();
    }
  }
  function loadHist() {
    socket.emit('lic:emitted', null, h => {
      const box = sec.querySelector('[data-ghist]'); if (!box) return;
      box.innerHTML = (h || []).slice(0, 15).map(x => `<div class="lic-h"><span class="hint">${new Date(x.at).toLocaleDateString('es')}</span><b>${esc(x.name || '—')}</b><span>${esc(planName(x.plan))}</span><code>${esc(x.machine)}</code><button class="ib" data-cp="${esc(x.key)}" title="Copiar clave">📋</button></div>`).join('') || '<div class="hint">Todavía no generaste claves.</div>';
      box.querySelectorAll('[data-cp]').forEach(b => b.onclick = () => navigator.clipboard.writeText(b.dataset.cp).then(() => toast('Clave copiada ✓')));
    });
  }
  // Marca PRO en el menú y bloquea esas páginas si el plan es Básico
  function paintPro(s) {
    const keys = s.proKeys || [], locked = s.tier === 'basico' && !(s.owner && !s.ownerTest) && s.allowed;
    keys.forEach(k => {
      const n = document.querySelector(`.nav[data-s="${k}"]`);
      if (n) { const b = n.querySelector('.badge'); if (b && !b.dataset.pro) { b.dataset.pro = '1'; b.dataset.orig = b.textContent; } if (b) { b.textContent = locked ? '🔒 PRO' : 'PRO'; b.classList.add('pro'); } else if (!n.querySelector('.pro-tag')) n.insertAdjacentHTML('beforeend', '<span class="badge pro">PRO</span>'); else n.querySelector('.badge.pro').textContent = locked ? '🔒 PRO' : 'PRO'; }
      const sc = document.getElementById('s-' + k); if (!sc) return;
      sc.classList.toggle('pro-lock', locked);
      let ban = sc.querySelector(':scope > .pro-banner');
      if (locked && !ban) { ban = document.createElement('div'); ban.className = 'pro-banner'; ban.innerHTML = '<span>🔒</span><div><b>Esto es del Plan Pro</b><small>Tu plan Básico no lo incluye. Pásate a Pro para usarlo en tu live.</small></div><button class="btn pri">💎 Pásate a Pro</button>'; ban.querySelector('button').onclick = () => { setTier('pro'); go('licencia'); }; sc.prepend(ban); }
      if (!locked && ban) ban.remove();
    });
  }
  function confettiPanel() { try { if (typeof confetti === 'function') confetti(160); } catch {} }
})();
