// ===== Licencia y compra — página del panel =====
(function () {
  let LIC = null, T = {}, plan = 'anual', pay = 'tarjeta';
  // Planes: solo se muestran los que tienen precio en tienda.json ("De por vida" queda para claves especiales)
  const PL_ALL = [
    ['mensual', 'Mensual', '/ mes', 'Para probar en serio', ''],
    ['anual', 'Anual', '/ año', '', 'MÁS POPULAR'],
    ['vida', 'De por vida', 'un solo pago', 'Tuyo para siempre + todas las actualizaciones', 'MEJOR VALOR'],
  ];
  const PLAN_LIST = () => PL_ALL.filter(p => T.precios?.[p[0]]).map(p => {
    if (p[0] !== 'anual') return p;
    const m = T.precios?.mensual?.usd, a = T.precios?.anual?.usd, pct = m && a ? Math.round((1 - a / (m * 12)) * 100) : 0;
    return [p[0], p[1], p[2], pct > 0 ? `Ahorras ${pct}% (casi ${Math.max(1, Math.round(12 - a / m))} meses gratis)` : 'Un año completo', p[4]];
  });
  const planName = k => (PL_ALL.find(p => p[0] === k) || [])[1] || k;
  const PL = { find: f => PL_ALL.find(f) }; // compatibilidad
  const PAYS = [['tarjeta', '💳', 'Tarjeta / PayPal', 'Automático'], ['yape', '🟣', 'Yape', 'Perú'], ['pagoefectivo', '🟡', 'PagoEfectivo', 'Banca, agentes y bodegas']];
  const money = (v, c) => v == null ? '—' : c === 'pen' ? `S/ ${(+v).toLocaleString('es')}` : `$${(+v).toLocaleString('en')}`;
  const price = (p, c) => T.precios?.[p]?.[c];
  const fdate = ms => new Date(ms).toLocaleDateString('es', { day: 'numeric', month: 'long', year: 'numeric' });

  // ---------- navegación ----------
  const nb = document.createElement('button'); nb.className = 'nav'; nb.dataset.s = 'licencia';
  nb.innerHTML = '<span class="ic">💎</span>Licencia<span class="badge" data-licbadge></span>';
  document.querySelector('.nav[data-s="overlays"]').after(nb);
  nb.onclick = () => go('licencia');

  const sec = document.createElement('section'); sec.className = 'sec'; sec.id = 's-licencia';
  document.getElementById('s-overlays').after(sec);
  // aviso arriba durante la prueba
  const bar = document.createElement('div'); bar.className = 'lic-bar hidden';
  document.querySelector('main').prepend(bar);

  let payPicked = false;
  // Botón de la comunidad de Discord en el menú
  const dc = document.createElement('a'); dc.className = 'nav nav-dc hidden'; dc.target = '_blank';
  dc.innerHTML = '<span class="ic">💬</span>Comunidad Discord';
  document.querySelector('.nav[data-s="ajustes"]').after(dc);
  socket.on('lic:tienda', t => {
    T = t || {};
    dc.href = T.discord || '#'; dc.classList.toggle('hidden', !T.discord);
    // abre en el primer método que ya tenga datos
    if (!payPicked) { const has = { tarjeta: Object.values(T.lemon?.checkout || {}).some(Boolean), yape: T.yape?.numero || T.yape?.qr, pagoefectivo: T.pagoefectivo?.link }; pay = Object.keys(has).find(k => has[k]) || 'yape'; }
    if (!T.precios?.[plan]) plan = Object.keys(T.precios || {}).includes('anual') ? 'anual' : Object.keys(T.precios || {})[0] || 'mensual';
    paint();
  });
  socket.on('lic', s => { const was = LIC?.allowed; LIC = s; paint(); if (was !== false && !s.allowed) lockNow(); if (s.allowed) document.body.classList.remove('lic-locked'); });
  socket.on('lic:need', s => { LIC = s; paint(); lockNow(); toast('🔑 ' + (s.msg || 'Activa tu licencia para conectarte al live')); });
  function lockNow() { document.body.classList.add('lic-locked'); go('licencia'); }
  // si está bloqueado, solo se puede abrir esta página
  document.addEventListener('click', e => { const n = e.target.closest('.nav, [data-go]'); if (n && document.body.classList.contains('lic-locked') && (n.dataset.s || n.dataset.go) !== 'licencia') { e.stopPropagation(); e.preventDefault(); toast('🔑 Activa tu licencia para usar ChispaLive'); } }, true);

  const buyMsg = () => `Hola! Compré ChispaLive plan ${planName(plan)} (${money(price(plan, 'pen'), 'pen')} / ${money(price(plan, 'usd'), 'usd')}) por ${(PAYS.find(p => p[0] === pay) || [])[2] || ''}. Adjunto mi comprobante.\nMi código de equipo: ${LIC?.machine || ''}`;
  function waLink() {
    const num = String(T.whatsapp || '').replace(/\D/g, '');
    return num ? `https://wa.me/${num}?text=${encodeURIComponent(buyMsg())}` : '';
  }
  // Comprobante: Discord (ticket privado) > WhatsApp > DM de TikTok
  function sendProof() {
    const copy = `<button class="btn" data-copymsg>📋 Copiar mi mensaje (con mi código de equipo)</button>`;
    if (T.discord) return `<div class="row" style="margin:0;gap:8px;flex-wrap:wrap"><a class="btn pri" href="${esc(T.discord)}" target="_blank">💬 Enviar comprobante en Discord</a>${copy}</div>
      <div class="hint" style="margin-top:6px">En el Discord ve a <b>#🎫・comprar-licencia</b> y abre un <b>ticket</b> (es privado: solo lo vemos tú y nosotros). Pega tu mensaje y la captura del pago.</div>`;
    const url = waLink();
    if (url) return `<a class="btn pri lic-wa" href="${url}" target="_blank">📲 Enviar comprobante por WhatsApp</a>`;
    return `${copy}<div class="hint" style="margin-top:6px">Envíalo por DM a <b>${esc(T.tiktok || '@esnutbear')}</b> en TikTok junto con la foto del comprobante.</div>`;
  }
  const row = (k, v, copy) => v ? `<div class="lic-kv"><span>${k}</span><b>${esc(v)}</b>${copy ? `<button class="ib" data-cp="${esc(v)}" title="Copiar">📋</button>` : ''}</div>` : '';
  const soon = '<div class="lic-soon">⏳ Este método estará disponible muy pronto. Mientras tanto usa otro.</div>';
  function payBox() {
    const pen = money(price(plan, 'pen'), 'pen'), usd = money(price(plan, 'usd'), 'usd');
    if (pay === 'tarjeta') {
      const link = T.lemon?.checkout?.[plan];
      return `<div class="lic-auto">⚡ <b>Activación automática:</b> pagas y al instante recibes tu clave (también llega a tu correo). La pegas abajo y ChispaLive se activa solo en esta computadora.</div>
        <ol class="lic-steps"><li>Paga <b>${usd}</b> con tarjeta de crédito, débito o PayPal.</li><li>Copia la clave que aparece al terminar (o en tu correo).</li><li>Pégala en <b>Activar mi clave</b> 👇</li></ol>
        ${link ? `<a class="btn pri big" href="${esc(link)}" target="_blank">💳 Pagar ${usd} con tarjeta o PayPal</a>` : soon}`;
    }
    const steps = (how, data) => `<ol class="lic-steps"><li>${how}</li><li>Envía la captura del comprobante con tu <b>código de equipo</b> (ya va en el mensaje).</li><li>Te respondemos con tu clave: pégala en <b>Activar mi clave</b> 👇</li></ol>${data}<div style="margin-top:12px">${sendProof()}</div>`;
    if (pay === 'yape') { const y = T.yape || {}; if (!y.numero && !y.qr) return soon;
      return steps(`Yapea <b>${pen}</b> a <b>${esc(T.marca || 'ChispaLive')}</b>.`, `<div class="lic-pay">${y.qr ? `<img class="lic-qr" src="${esc(y.qr)}" alt="QR Yape">` : ''}<div>${row('Pagar a', T.marca || 'ChispaLive')}${row('Número Yape', y.numero, true)}${row('Monto', pen)}${y.nombre ? `<div class="hint" style="margin-top:4px">En Yape aparecerá el titular: <b>${esc(y.nombre)}</b> ✅</div>` : ''}</div></div>`); }
    if (pay === 'pagoefectivo') { const l = T.pagoefectivo?.link; if (!l) return soon;
      return steps(`Paga <b>${pen}</b> con PagoEfectivo: desde tu banca por internet o app (BCP, BBVA, Interbank, Scotiabank…), o en efectivo en agentes y bodegas con tu código CIP.`, `<a class="btn big" href="${esc(l)}" target="_blank" style="margin-top:6px">🟡 Pagar con PagoEfectivo</a>`); }
    return '';
  }

  function paint() {
    if (!LIC) return;
    const s = LIC, owner = s.owner;
    // insignia del menú y barra de prueba
    const bd = nb.querySelector('[data-licbadge]');
    bd.textContent = s.state === 'trial' ? `PRUEBA ${s.daysLeft}D` : s.state === 'active' || owner ? 'ACTIVA' : 'ACTIVAR';
    bd.className = 'badge ' + (s.state === 'active' || owner ? 'ok' : '');
    bar.classList.toggle('hidden', s.state !== 'trial');
    if (s.state === 'trial') bar.innerHTML = `🎁 <b>Prueba gratis:</b> ${s.daysLeft > 1 ? `te quedan ${s.daysLeft} días` : `te quedan ${s.hoursLeft} horas`} con todo desbloqueado. <button class="btn sm pri" data-buy>💎 Comprar licencia</button>`;
    bar.querySelector('[data-buy]')?.addEventListener('click', () => go('licencia'));

    const head = owner ? ['👑', 'Eres el dueño', 'Esta computadora tiene el generador de licencias. Todo desbloqueado.', 'ok']
      : s.state === 'active' ? ['✅', `Licencia activa · ${esc(s.planName)}`, s.until ? `Vence el ${fdate(s.until)} (${s.daysLeft} días)` : 'De por vida: no vence nunca', 'ok']
      : s.state === 'trial' ? ['🎁', 'Prueba gratis', `Te quedan ${s.daysLeft} día(s): termina el ${fdate(s.until)}`, 'trial']
      : ['🔒', s.state === 'expired' ? 'Tu plan venció' : 'Tu prueba gratis terminó', esc(s.msg || 'Elige un plan para seguir usando ChispaLive.'), 'bad'];
    const keep = sec.querySelector('[data-lkey]')?.value || '';
    sec.innerHTML = `
      <h1>💎 Licencia de ChispaLive</h1>
      <p class="lead">Juegos, widgets, voz y acciones para tu TikTok LIVE. Elige tu plan, paga como prefieras y activa en segundos.</p>
      <div class="panel lic-status ${head[3]}"><span class="lic-ic">${head[0]}</span><div style="flex:1"><b>${head[1]}</b><small>${head[2]}</small></div>
        <div class="lic-code"><small>Código de este equipo</small><b>${s.machine}</b><button class="btn sm" data-cp="${s.machine}">📋 Copiar</button></div></div>
      ${s.state === 'active' && !owner ? '' : `
      <div class="lic-plans">${PLAN_LIST().map(([k, n, per, d, tag]) => `<button class="lic-plan ${plan === k ? 'on' : ''}" data-plan="${k}">${tag ? `<i>${tag}</i>` : ''}<b>${n}</b>
        <span class="lic-price">${money(price(k, 'pen'), 'pen')}</span><small class="lic-usd">${money(price(k, 'usd'), 'usd')} USD · ${per}</small><small>${d}</small></button>`).join('')}</div>
      <div class="panel"><div class="ptitle c3">💸 ¿Cómo quieres pagar?</div>
        <div class="lic-pays">${PAYS.map(([k, ic, n, sub]) => `<button class="${pay === k ? 'on' : ''}" data-pay="${k}"><span>${ic}</span><b>${n}</b><small>${sub}</small></button>`).join('')}</div>
        <div class="lic-box">${payBox()}</div></div>`}
      <div class="panel"><div class="ptitle c2">🔑 Activar mi clave</div>
        <div class="lic-act"><input class="i" data-lkey placeholder="Pega aquí tu clave (CHISPA-… o la de tu correo)" value="${esc(keep)}"><button class="btn pri" data-lact>Activar</button></div>
        <div class="hint" data-lmsg style="margin-top:8px">La clave queda atada a esta computadora.</div>
        ${s.state === 'active' && !owner ? `<button class="btn sm" data-ldeact style="margin-top:10px">↪ Quitar la licencia de esta PC (para pasarla a otra)</button>` : ''}</div>
      ${owner ? `<div class="panel lic-gen"><div class="ptitle c4">👑 Generador de licencias (solo tú lo ves)</div>
        <div class="hint" style="margin-bottom:10px">Cuando te paguen por Yape, Plin, Mercado Pago o Binance: pega el <b>código de equipo</b> que te mandó el cliente, elige el plan y genera su clave.</div>
        <div class="lic-genf"><label class="f">Código de equipo del cliente<input class="i" data-gcode placeholder="ABCD-EFGH-JKLM-NPQR"></label>
          <label class="f">Plan<select class="i" data-gplan>${PL_ALL.map(([k, n]) => `<option value="${k}">${n}${T.precios?.[k] ? '' : ' (especial / regalo)'}</option>`).join('')}</select></label>
          <label class="f">Nombre / TikTok del cliente<input class="i" data-gname placeholder="@cliente"></label></div>
        <button class="btn pri" data-gen style="margin-top:10px">✨ Generar clave</button>
        <div data-gout></div>
        <div class="flab" style="margin-top:14px">ÚLTIMAS CLAVES EMITIDAS</div><div class="lic-hist" data-ghist><div class="hint">Cargando…</div></div></div>` : ''}`;
    bind();
  }
  function bind() {
    sec.querySelectorAll('[data-plan]').forEach(b => b.onclick = () => { plan = b.dataset.plan; paint(); });
    sec.querySelectorAll('[data-pay]').forEach(b => b.onclick = () => { pay = b.dataset.pay; payPicked = true; paint(); });
    sec.querySelectorAll('[data-cp]').forEach(b => b.onclick = () => { navigator.clipboard.writeText(b.dataset.cp).then(() => toast('Copiado ✓')).catch(() => toast(b.dataset.cp)); });
    sec.querySelector('[data-copymsg]')?.addEventListener('click', () => { navigator.clipboard.writeText(buyMsg()).then(() => toast('Mensaje copiado ✓')); });
    const msg = sec.querySelector('[data-lmsg]'), inp = sec.querySelector('[data-lkey]');
    const doAct = () => {
      const k = inp.value.trim(); if (!k) return toast('Pega tu clave');
      msg.innerHTML = '⏳ Verificando…';
      socket.emit('lic:activate', k, r => {
        if (r?.ok) { inp.value = ''; toast('✅ ¡ChispaLive activado!'); confettiPanel(); LIC = r.status; document.body.classList.remove('lic-locked'); paint(); }
        else msg.innerHTML = `<span style="color:var(--bad)">❌ ${esc(r?.error || 'No se pudo activar')}</span>`;
      });
    };
    sec.querySelector('[data-lact]').onclick = doAct; inp.onkeydown = e => { if (e.key === 'Enter') doAct(); };
    sec.querySelector('[data-ldeact]')?.addEventListener('click', () => { if (confirm('¿Quitar la licencia de esta computadora? Podrás activarla en otra con la misma clave.')) socket.emit('lic:deactivate', null, () => toast('Licencia quitada de esta PC')); });
    if (LIC.owner) {
      const out = sec.querySelector('[data-gout]');
      sec.querySelector('[data-gen]').onclick = () => {
        const d = { machine: sec.querySelector('[data-gcode]').value.trim(), plan: sec.querySelector('[data-gplan]').value, name: sec.querySelector('[data-gname]').value.trim() };
        socket.emit('lic:gen', d, r => {
          if (!r?.ok) { out.innerHTML = `<div class="hint" style="color:var(--bad);margin-top:8px">❌ ${esc(r?.error || 'Error')}</div>`; return; }
          const note = `¡Gracias por tu compra! 💖\nTu clave de ChispaLive (${planName(d.plan)}):\n\n${r.key}\n\nAbre ChispaLive → 💎 Licencia → pégala en "Activar mi clave".`;
          out.innerHTML = `<div class="lic-key"><code>${esc(r.key)}</code><div class="row" style="margin:8px 0 0"><button class="btn sm pri" data-ck>📋 Copiar clave</button><button class="btn sm" data-cn>💬 Copiar mensaje para el cliente</button></div></div>`;
          out.querySelector('[data-ck]').onclick = () => navigator.clipboard.writeText(r.key).then(() => toast('Clave copiada ✓'));
          out.querySelector('[data-cn]').onclick = () => navigator.clipboard.writeText(note).then(() => toast('Mensaje copiado ✓'));
          loadHist();
        });
      };
      loadHist();
    }
  }
  function loadHist() {
    socket.emit('lic:emitted', null, h => {
      const box = sec.querySelector('[data-ghist]'); if (!box) return;
      box.innerHTML = (h || []).slice(0, 15).map(x => `<div class="lic-h"><span class="hint">${new Date(x.at).toLocaleDateString('es')}</span><b>${esc(x.name || '—')}</b><span>${esc(planName(x.plan))}</span><code>${esc(x.machine)}</code><button class="ib" data-cp="${esc(x.key)}" title="Copiar clave">📋</button></div>`).join('') || '<div class="hint">Todavía no generaste claves.</div>';
      box.querySelectorAll('[data-cp]').forEach(b => b.onclick = () => navigator.clipboard.writeText(b.dataset.cp).then(() => toast('Clave copiada ✓')));
    });
  }
  function confettiPanel() { try { if (typeof confetti === 'function') confetti(160); } catch {} }
})();
