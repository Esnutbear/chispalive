// ===== Control de OBS — página del panel =====
(function () {
  const O = () => window.cfg?.obs || {};
  window.OBS = { status: 'off', scenes: [], items: {}, inputs: [], current: '' };

  let pend = {}, pt;
  function save(k, v) {
    window.cfg.obs = { ...(window.cfg.obs || {}), [k]: v }; pend[k] = v;
    clearTimeout(pt); pt = setTimeout(() => { socket.emit('saveConfig', { obs: pend }); pend = {}; flash(); }, 500);
    paint();
  }
  function flash() { const s = sec.querySelector('.saved'); if (s) { s.classList.add('on'); setTimeout(() => s.classList.remove('on'), 1200); } }

  const sec = document.createElement('section'); sec.className = 'sec'; sec.id = 's-obs';
  sec.innerHTML = `
  <div class="vz-head panel">
    <div class="vz-mascot rbx-logo">🎬</div>
    <div class="vz-ttl"><h1 class="display">OBS <span class="saved">✓ Guardado</span></h1><p class="hint">Los regalos controlan tu OBS: cambian de escena, muestran un video, guardan un clip…</p></div>
    <label class="vz-power"><input type="checkbox" data-k="on"><span class="vz-pw"><i></i></span><b data-r="pwlab">Apagado</b></label>
  </div>
  <div class="vz-offbar" data-r="offbar">🎬 <b>El control de OBS está apagado.</b> <button class="btn sm pri" data-r="turnon">Encender</button></div>
  <div class="rbx-status panel" data-r="status"></div>
  <div class="rbx-grid">
    <div class="panel">
      <h2>1️⃣ Activa el WebSocket en OBS</h2>
      <p class="hint">En <b>OBS Studio</b> ve a <b>Herramientas → Ajustes del servidor WebSocket</b>, marca <b>"Habilitar servidor WebSocket"</b> y toca <b>"Mostrar información de conexión"</b> para ver el puerto y la contraseña.</p>
      <label class="f">Puerto<input class="i" data-k="port" inputmode="numeric" placeholder="4455"></label>
      <label class="f">Contraseña<input class="i" type="password" data-k="password" placeholder="La del WebSocket de OBS" autocomplete="off"></label>
      <details class="hint" style="margin-top:8px"><summary>OBS está en otra PC</summary><label class="f">Dirección (IP)<input class="i" data-k="host" placeholder="127.0.0.1"></label></details>
      <div class="hint" style="margin-top:8px">Funciona con <b>OBS Studio 28 o más nuevo</b>. TikTok LIVE Studio y Streamlabs no tienen esta conexión.</div>
    </div>
    <div class="panel">
      <h2>🎞 Tus escenas</h2>
      <div class="obs-scenes" data-r="scenes"></div>
      <div class="row" style="margin:8px 0 0;gap:8px"><button class="btn sm" data-r="refresh">🔄 Actualizar</button></div>
      <div class="hint" style="margin-top:8px">Toca una escena para probar el cambio.</div>
    </div>
    <div class="panel">
      <h2>2️⃣ Crea tus acciones</h2>
      <p class="hint">Ve a <b>Acciones y eventos → Nueva acción</b>, elige qué la activa (por ejemplo, la Galaxy) y en "¿Qué pasa?" elige <b>🎬 Controlar OBS</b>. Puedes:</p>
      <ul class="hint obs-list"><li>🎞 Cambiar de escena (y volver sola después de unos segundos)</li><li>👁 Mostrar u ocultar una fuente (un GIF, una cámara, un texto)</li><li>▶️ Reproducir un video o sonido</li><li>✏️ Cambiar un texto, por ejemplo "Último regalo: {usuario}"</li><li>🎬 Guardar una repetición (clip) del momento</li></ul>
    </div>
  </div>`;
  document.getElementById('studios').after(sec);
  const $ = q => sec.querySelector(q);

  sec.querySelectorAll('[data-k]').forEach(i => i.addEventListener(i.type === 'checkbox' ? 'change' : 'input', () => {
    let v = i.type === 'checkbox' ? i.checked : i.value;
    if (i.dataset.k === 'port') { v = v.replace(/\D/g, '').slice(0, 5); i.value = v; v = +v || 4455; }
    save(i.dataset.k, v);
  }));
  $('[data-r=turnon]').onclick = () => { $('[data-k=on]').checked = true; save('on', true); };
  $('[data-r=refresh]').onclick = () => socket.emit('obs:refresh');

  function paintStatus() {
    const S = window.OBS, cls = S.status === 'connected' ? 'ok' : S.status === 'error' ? 'bad' : '';
    $('[data-r=status]').innerHTML = `<div><span class="rbx-dot ${cls}"></span><b>${esc(S.msg || 'Apagado')}</b>${S.version && S.status === 'connected' ? ` <span class="hint">· WebSocket ${esc(S.version)}</span>` : ''}</div>${S.current ? `<div>🎞 Escena actual: <b>${esc(S.current)}</b></div>` : ''}`;
    const box = $('[data-r=scenes]');
    box.innerHTML = S.scenes?.length ? S.scenes.map(n => `<button class="obs-sc ${n === S.current ? 'on' : ''}" data-sc="${esc(n)}">${n === S.current ? '🔴 ' : ''}${esc(n)}<small>${(S.items[n] || []).length} fuentes</small></button>`).join('')
      : `<div class="hint">${S.status === 'connected' ? 'No hay escenas.' : 'Conecta OBS para ver tus escenas.'}</div>`;
    box.querySelectorAll('[data-sc]').forEach(b => b.onclick = () => socket.emit('obs:test', { do: 'scene', scene: b.dataset.sc }, err => err && toast('🎬 ' + err)));
  }
  function paint() {
    const c = O();
    sec.querySelectorAll('[data-k]').forEach(i => { if (document.activeElement === i) return; const v = c[i.dataset.k]; if (i.type === 'checkbox') i.checked = !!v; else i.value = v ?? (i.dataset.k === 'port' ? 4455 : i.dataset.k === 'host' ? '127.0.0.1' : ''); });
    $('[data-r=pwlab]').textContent = c.on ? 'Encendido' : 'Apagado';
    $('[data-r=offbar]').hidden = !!c.on;
    paintStatus();
  }
  socket.on('config', () => setTimeout(paint, 0));
  socket.on('obs:status', s => { window.OBS = s || window.OBS; paintStatus(); document.dispatchEvent(new CustomEvent('obs:status')); });
  if (window.cfg?.obs) paint();
  socket.emit('obs:get'); socket.on('connect', () => socket.emit('obs:get'));
})();
