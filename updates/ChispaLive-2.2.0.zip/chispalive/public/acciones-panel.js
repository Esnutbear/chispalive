// ===== Acciones y eventos — página del panel =====
(function () {
  const A = () => window.cfg?.actions || { rules: [], screens: [] };
  let KEYS = [];
  socket.on('tts:meta', m => { KEYS = m.keys || []; });
  const EVENTS = [
    ['anygift', '🎁', 'Cualquier regalo', 'Llega cualquier regalo', 'Regalos'], ['gift', '🎯', 'Regalo específico', 'Un regalo que tú eliges', 'Regalos'],
    ['value', '💰', 'Valor del regalo', 'Vale N monedas o más', 'Regalos'], ['chest', '🧰', 'Cofre del tesoro', 'Alguien suelta un cofre', 'Regalos'],
    ['follow', '💗', 'Nuevo seguidor', 'Alguien te sigue', 'Comunidad'], ['share', '📣', 'Compartir', 'Comparten tu live', 'Comunidad'],
    ['join', '🚪', 'Entra al live', 'Un viewer se une', 'Comunidad'], ['first', '🌱', 'Primera vez', 'Primera acción de un viewer', 'Comunidad'],
    ['sub', '👑', 'Super fan', 'Nueva suscripción', 'Comunidad'], ['comment', '💬', 'Comentario', 'Alguien escribe en el chat', 'Chat'],
    ['keyword', '🔑', 'Palabra clave', 'Ej. !baile o "hola"', 'Chat'], ['likes', '👍', 'Likes', 'Cada N likes de un viewer', 'Chat'],
    ['coingoal', '🏁', 'Meta de monedas', 'El live junta N monedas', 'Metas'], ['likegoal', '❤️‍🔥', 'Meta de likes', 'El live llega a N likes', 'Metas'],
    ['viewers', '👀', 'Espectadores', 'Llegas a N viewers', 'Metas'], ['corazon', '💖', 'Corazón lleno', 'Se cumple la Meta de corazón', 'Metas'], ['battlewin', '⚔️', 'Gana una batalla', 'Un equipo gana la Batalla', 'Metas'], ['subathonend', '⏰', 'Termina el subathon', 'El reloj llega a cero', 'Metas'], ['carrerawin', '🏁', 'Gana la carrera', 'Un corredor cruza la meta', 'Metas'], ['jefedown', '👹', 'Derrotan al jefe', 'La vida del jefe llega a cero', 'Metas'], ['triviawin', '❓', 'Gana la trivia', 'Termina una partida de trivia', 'Metas'], ['mascotaevo', '🐣', 'La mascota evoluciona', 'La Mascota del live sube de etapa', 'Metas'], ['castillowin', '🏰', 'Gana la guerra de castillos', 'Un castillo derriba al otro', 'Metas'], ['adivinawin', '🔤', 'Gana Adivina la palabra', 'El que más palabras adivinó en la partida', 'Metas'], ['pescalegend', '🎣', 'Pesca algo legendario', 'Un tiburón, una ballena, un delfín dorado o un tesoro', 'Metas'], ['bombawin', '💣', 'Gana la bomba caliente', 'El último que queda sin explotar', 'Metas'], ['slotjackpot', '🎰', 'Sale el JACKPOT', 'Alguien saca 7️⃣7️⃣7️⃣ en el tragamonedas', 'Metas'], ['penalgol', '⚽', 'Gol de penal', 'Cada gol en el juego de Penales', 'Metas'], ['start', '🟢', 'Empieza el live', 'Te conectas en vivo', 'Live'],
    ['end', '🔴', 'Termina el live', 'Se cierra tu live', 'Live'], ['timer', '⏰', 'Cada X minutos', 'Se repite mientras estás en vivo', 'Live'],
    ['hotkey', '⌨️', 'Atajo de teclado', 'Presionas una tecla en el panel', 'Live'],
  ];
  const EV = Object.fromEntries(EVENTS.map(e => [e[0], e]));
  const CATS = ['Todos', 'Regalos', 'Comunidad', 'Chat', 'Metas', 'Live'];
  const REACT = [
    ['alert', '🖼️', 'Alerta en pantalla', 'GIF o imagen con texto'], ['sound', '🔊', 'Sonido', 'De la lista o tu MP3'], ['tts', '🗣️', 'Voz (TTS)', 'Lee un texto en voz alta'],
    ['confetti', '🎉', 'Confeti', 'Lluvia de confeti'], ['shake', '📳', 'Temblor', 'La pantalla tiembla'], ['flash', '⚡', 'Flash', 'Destello de luz'],
    ['key', '⌨️', 'Presionar tecla', 'Para juegos y apps (Windows)'], ['game', '🎮', 'Mover un juego', 'Gira la ruleta, suma al frasco…'], ['webhook', '🌐', 'Webhook', 'Avisa a otra app (Streamer.bot…)'],
    ['obs', '🎬', 'Controlar OBS', 'Escena, fuente, video, texto o clip'],
    ['roblox', '🧱', 'Poder en Roblox', 'Activa algo en tu juego de Roblox'],
  ];
  const RX = Object.fromEntries(REACT.map(r => [r[0], r]));
  const GAMES = [['ruleta', '🎡 Girar la ruleta'], ['lucky', '🎲 Lucky Roll / cofre'], ['jar', '🫙 Sumar al frasco'], ['subasta', '🔨 Sumar tiempo a la subasta'], ['royale', '👑 Meter en Spin Royale'], ['meta', '🎯 Sumar a la meta'], ['corazon', '💖 Sumar al corazón'], ['batalla', '⚔️ Sumar puntos en la Batalla'], ['subathon', '⏰ Sumar tiempo al subathon'], ['carrera', '🏁 Empujar en la Carrera'], ['jefe', '👹 Hacerle daño al jefe'], ['castillos', '🏰 Disparar en la Guerra de castillos']];
  const uid = () => 'r' + Math.random().toString(36).slice(2, 9);
  const OBS_DO = [['scene', '🎞 Cambiar de escena'], ['show', '👁 Mostrar una fuente'], ['hide', '🙈 Ocultar una fuente'], ['toggle', '🔁 Mostrar/ocultar (alternar)'], ['media', '▶️ Reproducir video o sonido'], ['text', '✏️ Cambiar un texto'], ['replay', '🎬 Guardar repetición (clip)'], ['record', '⏺ Grabar']];
  function obsFields(r) {
    const O = window.OBS || {}, scenes = O.scenes || [], opt = (list, sel) => list.map(n => `<option value="${esc(n)}" ${n === sel ? 'selected' : ''}>${esc(n)}</option>`).join('');
    const keep = (list, v) => v && !list.includes(v) ? [v, ...list] : list;
    const srcs = keep((O.items?.[r.scene] || []).map(i => i.name), r.source);
    const inputs = k => keep((O.inputs || []).filter(i => k(i.kind)).map(i => i.name), r.source);
    const sceneSel = `<label class="f">Escena<select class="i" data-f="scene"><option value="">— Elige —</option>${opt(keep(scenes, r.scene), r.scene)}</select></label>`;
    let extra = '';
    if (r.do === 'scene') extra = `${sceneSel}<label class="f">Volver a la escena anterior después de<input class="i" type="number" min="0" max="3600" data-f="seconds" value="${r.seconds ?? 10}"></label>`;
    else if (['show', 'hide', 'toggle'].includes(r.do)) extra = `${sceneSel}<label class="f">Fuente<select class="i" data-f="source"><option value="">— Elige —</option>${opt(srcs, r.source)}</select></label>${r.do !== 'toggle' ? `<label class="f">${r.do === 'show' ? 'Ocultar' : 'Mostrar'} otra vez después de (s)<input class="i" type="number" min="0" max="3600" data-f="seconds" value="${r.seconds ?? 10}"></label>` : ''}`;
    else if (r.do === 'media') extra = `<label class="f">Video o sonido<select class="i" data-f="source"><option value="">— Elige —</option>${opt(inputs(k => /ffmpeg|media|vlc/.test(k)), r.source)}</select></label>`;
    else if (r.do === 'text') extra = `<label class="f">Fuente de texto<select class="i" data-f="source"><option value="">— Elige —</option>${opt(inputs(k => /text/.test(k)), r.source)}</select></label><label class="f" style="flex-basis:100%">Texto<input class="i" data-f="text" value="${esc(r.text || '')}"></label>`;
    else if (r.do === 'record') extra = `<label class="f">¿Qué hacer?<select class="i" data-f="mode"><option value="start" ${r.mode !== 'stop' ? 'selected' : ''}>Empezar a grabar</option><option value="stop" ${r.mode === 'stop' ? 'selected' : ''}>Parar la grabación</option></select></label>`;
    const hint = r.do === 'replay' ? 'Guarda los últimos segundos del live como clip. Activa el <b>Búfer de repetición</b> en OBS (Ajustes → Salida).'
      : r.do === 'text' ? 'Puedes usar {usuario}, {regalo}, {cantidad}, {monedas}…' : (r.do === 'scene' || r.do === 'show' || r.do === 'hide') ? 'Pon 0 para que se quede así.' : '';
    const warn = O.status !== 'connected' ? '<div class="hint" style="color:#fde68a">⚠️ OBS no está conectado: configúralo en <b>🎬 OBS</b> (menú de la izquierda) para ver tus escenas.</div>' : '';
    return `<div class="row" style="margin:0;flex-wrap:wrap"><label class="f">Qué hacer<select class="i" data-f="do">${OBS_DO.map(([k, n]) => `<option value="${k}" ${r.do === k ? 'selected' : ''}>${n}</option>`).join('')}</select></label>${extra}</div>${hint ? `<div class="hint">${hint}</div>` : ''}${warn}`;
  }

  let pt;
  function saveA() { clearTimeout(pt); pt = setTimeout(() => { socket.emit('saveConfig', { actions: window.cfg.actions }); const s = document.querySelector('#s-acciones .saved'); if (s) { s.classList.add('on'); setTimeout(() => s.classList.remove('on'), 1200); } }, 250); }

  // ---------- estructura ----------
  const sec = document.createElement('section'); sec.className = 'sec'; sec.id = 's-acciones';
  sec.innerHTML = `
  <div class="ac-head panel">
    <img class="vz-mascot" src="/brand/oso-acciones.svg" alt="">
    <div class="vz-ttl"><h1 class="display">Acciones y eventos <span class="saved">✓ Guardado</span></h1><p class="hint">Automatiza tu live: <b>CUANDO</b> pasa algo → <b>HACER</b> algo. Alertas, sonidos, voz, teclas y juegos.</p></div>
    <div class="ac-hbtns">
      <label class="vz-power sm"><input type="checkbox" data-r="on"><span class="vz-pw"><i></i></span><b data-r="onlab"></b></label>
      <button class="btn" data-r="io">⇅ Importar / Exportar</button>
      <button class="btn pri" data-r="new">＋ Nueva acción</button>
    </div>
  </div>
  <div class="ac-strip">
    <div class="panel ac-screens"><div class="ptitle c3" style="justify-content:space-between"><span>🖥️ Tus pantallas <span class="hint" data-r="scount"></span></span><button class="btn sm" data-r="sadd">＋ Pantalla</button></div>
      <div class="ac-scr" data-r="scr"></div>
      <div class="ac-url"><div class="hint">Agrégala en OBS / LIVE Studio como fuente de navegador · solo las acciones de esta pantalla se ven aquí</div>
        <div class="url"><code data-r="surl"></code><span class="ac-conn" data-r="sconn"></span><button class="btn sm pri" data-r="scopy">Copiar</button></div></div></div>
    <div class="panel ac-opts">
      <div class="flab">🔊 ¿DÓNDE SUENAN LOS SONIDOS?</div>
      <div class="vz-where sm"><button data-snd="overlay"><b>📺 En el overlay</b><small>OBS / LIVE Studio</small></button><button data-snd="panel"><b>🖥️ En esta ventana</b><small>El panel</small></button></div>
      <label class="vz-ck" style="margin-top:10px"><input type="checkbox" data-r="top"><i></i><span>Ejecutar solo la regla de mayor prioridad (la primera que coincida)</span></label>
      <div class="ac-key"><span>⌨️ Teclas: ${navigator.userAgent.includes('Windows') ? '<b style="color:var(--ok)">Windows listo</b>' : '<b style="color:var(--gold)">solo en Windows</b>'} · algunos juegos no aceptan teclas simuladas</span><button class="btn sm" data-r="ktest">▶ Probar tecla</button></div>
    </div>
  </div>
  <div class="panel">
    <div class="ac-bar"><input class="i" data-r="q" placeholder="🔍 Buscar acciones, regalos, eventos…"><select class="i sel" data-r="sort"><option value="prio">Orden: prioridad</option><option value="name">Orden: nombre</option><option value="on">Activas primero</option></select>
      <span class="hint" data-r="count"></span><button class="btn sm danger" data-r="wipe">🗑 Borrar todo</button></div>
    <div class="ac-list" data-r="list"></div>
  </div>
  <div class="panel"><div class="ptitle c4">📜 Últimas ejecuciones</div><div class="ac-log" data-r="log"><div class="hint">Todavía no se ejecutó ninguna acción.</div></div></div>`;
  document.getElementById('s-voz').after(sec);
  const $ = q => sec.querySelector(q);
  let curScreen = 0, screensConn = {};

  // ---------- cabecera y opciones ----------
  $('[data-r=on]').onchange = e => { A().on = e.target.checked; saveA(); paint(); };
  $('[data-r=top]').onchange = e => { A().onlyTop = e.target.checked; saveA(); };
  sec.querySelectorAll('[data-snd]').forEach(b => b.onclick = () => { A().soundsIn = b.dataset.snd; saveA(); paint(); });
  $('[data-r=new]').onclick = () => openEditor(null);
  $('[data-r=sadd]').onclick = () => { if (A().screens.length >= 8) return toast('Máximo 8 pantallas'); A().screens.push(`Pantalla ${A().screens.length + 1}`); curScreen = A().screens.length - 1; saveA(); paint(); };
  $('[data-r=scopy]').onclick = () => { navigator.clipboard.writeText($('[data-r=surl]').textContent); toast('Link copiado ✓'); };
  $('[data-r=wipe]').onclick = () => { if (A().rules.length && confirm(`¿Borrar las ${A().rules.length} acciones?`)) { A().rules = []; saveA(); paint(); } };
  $('[data-r=q]').oninput = paint; $('[data-r=sort]').onchange = paint;
  $('[data-r=ktest]').onclick = () => {
    const m = modal('⌨️ Probar tecla', `<div class="hint" style="margin-bottom:10px">Abre el juego o la app, vuelve aquí y presiona Probar: ChispaLive enviará la tecla a la ventana que indiques.</div>${keyFields({ key: 'ESPACIO', window: '' })}`,
      [['Cerrar'], ['▶ Probar', 'pri', () => { socket.emit('act:key', readKey(m)); return false; }]]);
    bindKeyFields(m);
  };
  $('[data-r=io]').onclick = () => {
    const m = modal('⇅ Importar / Exportar', `<div class="hint" style="margin-bottom:8px">Copia este texto para guardar tus acciones, o pega uno para cargarlas.</div><textarea class="i" rows="12" data-x style="font-family:monospace;font-size:12px">${esc(JSON.stringify(A().rules, null, 2))}</textarea>`,
      [['Cerrar'], ['⬇ Descargar', '', () => { const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([JSON.stringify(A().rules, null, 2)], { type: 'application/json' })); a.download = 'chispalive-acciones.json'; a.click(); return false; }],
        ['⬆ Importar', 'pri', () => { try { const r = JSON.parse(m.querySelector('[data-x]').value); if (!Array.isArray(r)) throw 0; r.forEach(x => x.id = x.id || uid()); A().rules = r; saveA(); paint(); toast(`✓ ${r.length} acciones cargadas`); } catch { toast('Ese texto no es válido'); return false; } }]]);
  };
  socket.on('screens', s => { screensConn = s || {}; paintScreens(); });

  // ---------- pintar ----------
  function paintScreens() {
    const sc = A().screens || [];
    if (curScreen >= sc.length) curScreen = 0;
    $('[data-r=scount]').textContent = `· ${sc.length} / 8`;
    $('[data-r=scr]').innerHTML = sc.map((n, i) => `<button class="${i === curScreen ? 'on' : ''}" data-si="${i}"><i class="${screensConn[i + 1] > 0 ? 'ok' : ''}"></i>${esc(n)}</button>`).join('');
    $('[data-r=scr]').querySelectorAll('[data-si]').forEach(b => {
      b.onclick = () => { curScreen = +b.dataset.si; paintScreens(); };
      b.ondblclick = () => { const n = prompt('Nombre de la pantalla', sc[+b.dataset.si]); if (n) { sc[+b.dataset.si] = n.slice(0, 24); saveA(); paintScreens(); } };
    });
    $('[data-r=surl]').textContent = `${location.origin}/overlay/acciones.html?pantalla=${curScreen + 1}`;
    const c = screensConn[curScreen + 1] || 0;
    $('[data-r=sconn]').innerHTML = c ? `<b class="okc">● Conectada</b>` : `<b class="noc">○ Sin conectar</b>`;
  }
  function trigLabel(t) {
    const e = EV[t.type] || ['', '❔', 'Evento'];
    let extra = '';
    if (t.type === 'gift') extra = t.gift || ''; if (t.type === 'value') extra = `≥ ${t.min || 1} 🪙`; if (t.type === 'keyword') extra = `"${t.keyword || ''}"`;
    if (t.type === 'likes') extra = `cada ${t.every || 100}`; if (['coingoal', 'likegoal', 'viewers'].includes(t.type)) extra = `${(t.goal || 0).toLocaleString('es')}`;
    if (t.type === 'timer') extra = `${t.minutes || 10} min`; if (t.type === 'hotkey') extra = t.combo || '';
    const g = t.type === 'gift' ? giftCatalog().find(x => x.name.toLowerCase() === String(t.gift || '').toLowerCase()) : null;
    return `<span class="ac-when">${g ? giftImg(g, 22) : `<em>${e[1]}</em>`}<b>${e[2]}</b>${extra ? `<small>${esc(extra)}</small>` : ''}</span>`;
  }
  function rxLabel(r) { const x = RX[r.type] || ['', '❔', r.type]; return `<span class="ac-do ${r.on === false ? 'off' : ''}">${x[1]} ${x[2]}${r.type === 'game' ? ` · ${esc((GAMES.find(g => g[0] === r.game) || [])[1] || '')}` : r.type === 'key' ? ` · ${esc(r.key || '')}` : r.type === 'roblox' ? ` · ${esc(r.cmd || '')}` : r.type === 'obs' ? ` · ${esc((OBS_DO.find(x => x[0] === r.do) || [])[1] || '')}${r.scene && r.do === 'scene' ? ' ' + esc(r.scene) : r.source ? ' ' + esc(r.source) : ''}` : ''}</span>`; }
  function paint() {
    const a = A();
    $('[data-r=on]').checked = a.on !== false; $('[data-r=onlab]').textContent = a.on !== false ? 'Acciones activas' : 'Acciones apagadas';
    $('[data-r=top]').checked = !!a.onlyTop;
    sec.querySelectorAll('[data-snd]').forEach(b => b.classList.toggle('on', (a.soundsIn || 'overlay') === b.dataset.snd));
    paintScreens();
    const q = ($('[data-r=q]').value || '').toLowerCase(), sort = $('[data-r=sort]').value;
    let rows = a.rules.map((r, i) => ({ r, i })).filter(({ r }) => !q || JSON.stringify(r).toLowerCase().includes(q) || (EV[r.trigger?.type]?.[2] || '').toLowerCase().includes(q));
    if (sort === 'name') rows.sort((x, y) => x.r.name.localeCompare(y.r.name)); if (sort === 'on') rows.sort((x, y) => (y.r.on ? 1 : 0) - (x.r.on ? 1 : 0));
    $('[data-r=count]').textContent = `${a.rules.filter(r => r.on).length} activas de ${a.rules.length}`;
    $('[data-r=list]').innerHTML = rows.length ? rows.map(({ r, i }) => `
      <div class="ac-rule ${r.on ? '' : 'off'}" data-i="${i}">
        <div class="ac-prio"><button data-up title="Subir prioridad">▲</button><b>${i + 1}</b><button data-dn title="Bajar prioridad">▼</button></div>
        <label class="sw2"><input type="checkbox" data-on ${r.on ? 'checked' : ''}><i></i></label>
        <div class="ac-body"><div class="ac-name">${esc(r.name || 'Sin nombre')}${r.who?.mode === 'some' ? ' <span class="ac-tag">🎯 algunos</span>' : ''}${r.cooldown ? ` <span class="ac-tag">⏳ ${r.cooldown}s</span>` : ''}</div>
          <div class="ac-flow"><span class="ac-lbl">CUANDO</span>${trigLabel(r.trigger || {})}<span class="ac-arrow">➜</span><span class="ac-lbl">HACER</span>${(r.reactions || []).map(rxLabel).join('') || '<span class="hint">sin reacciones</span>'}</div></div>
        <select class="i sel ac-sel" data-scr title="Pantalla">${(a.screens || []).map((n, j) => `<option value="${j}" ${(r.screen || 0) === j ? 'selected' : ''}>${esc(n)}</option>`).join('')}</select>
        <div class="ac-btns"><button class="ib" data-test title="Probar">▶</button><button class="ib" data-edit title="Editar">✏️</button><button class="ib" data-dup title="Duplicar">⧉</button><button class="ib" data-del title="Borrar">🗑</button></div>
      </div>`).join('') : `<div class="ac-empty"><img src="/brand/oso-acciones.svg"><div><b>${q ? 'Nada coincide con tu búsqueda' : 'Todavía no tienes acciones'}</b><span>Crea la primera: por ejemplo, "cuando alguien manda una Rosa → sonido + alerta con tu GIF".</span><button class="btn pri" data-r2="new">＋ Nueva acción</button></div></div>`;
    $('[data-r2=new]')?.addEventListener('click', () => openEditor(null));
    $('[data-r=list]').querySelectorAll('.ac-rule').forEach(el => {
      const i = +el.dataset.i, r = a.rules[i];
      el.querySelector('[data-on]').onchange = e => { r.on = e.target.checked; saveA(); paint(); };
      el.querySelector('[data-scr]').onchange = e => { r.screen = +e.target.value; saveA(); };
      el.querySelector('[data-test]').onclick = () => {
        socket.emit('act:test', r.id);
        const visual = (r.reactions || []).some(x => x.on !== false && ['alert', 'confetti', 'shake', 'flash'].includes(x.type));
        toast(visual && !(screensConn[(r.screen || 0) + 1] > 0) ? `▶ Probando "${r.name}" · para ver la alerta abre el link de "${(a.screens || [])[r.screen || 0] || 'Pantalla 1'}" en OBS` : `▶ Probando "${r.name}"`);
      };
      el.querySelector('[data-edit]').onclick = () => openEditor(i);
      el.querySelector('[data-dup]').onclick = () => { const c = clone(r); c.id = uid(); c.name += ' (copia)'; a.rules.splice(i + 1, 0, c); saveA(); paint(); };
      el.querySelector('[data-del]').onclick = () => { if (confirm(`¿Borrar "${r.name}"?`)) { a.rules.splice(i, 1); saveA(); paint(); } };
      el.querySelector('[data-up]').onclick = () => { if (i > 0) { [a.rules[i - 1], a.rules[i]] = [a.rules[i], a.rules[i - 1]]; saveA(); paint(); } };
      el.querySelector('[data-dn]').onclick = () => { if (i < a.rules.length - 1) { [a.rules[i + 1], a.rules[i]] = [a.rules[i], a.rules[i + 1]]; saveA(); paint(); } };
    });
  }
  let fixed = false;
  socket.on('config', () => setTimeout(() => { if (window.cfg?.actions) { if (!fixed) { fixed = true; fixOldNames(); } paint(); } }, 0));
  socket.on('catalog', () => { if (window.cfg?.actions) paint(); });
  const LOG = [];
  socket.on('act:log', l => { LOG.unshift(l); if (LOG.length > 30) LOG.pop(); $('[data-r=log]').innerHTML = LOG.map(x => `<div class="ac-lg"><span class="hint">${new Date(x.t).toLocaleTimeString()}</span> <b>${esc(x.rule)}</b>${x.user ? ` · ${esc(x.user.name)}` : ''}${x.test ? ' <span class="ac-tag">prueba</span>' : ''}</div>`).join(''); });

  // ---------- ventana modal genérica ----------
  function modal(title, html, buttons, wide) {
    const m = document.createElement('div'); m.className = 'gpm';
    m.innerHTML = `<div class="gpm-box ac-modal ${wide ? 'wide' : ''}"><div class="gpm-hd"><h2 class="display" style="margin:0;flex:1">${title}</h2><button class="btn sm" data-x>✕</button></div><div class="ac-mbody">${html}</div>
      <div class="gpm-ft" style="justify-content:flex-end">${buttons.map(([l, c], i) => `<button class="btn ${c || ''}" data-b="${i}">${l}</button>`).join('')}</div></div>`;
    document.body.appendChild(m);
    const close = () => m.remove();
    m.querySelector('[data-x]').onclick = close; m.onclick = e => { if (e.target === m) close(); };
    m.querySelectorAll('[data-b]').forEach(b => b.onclick = () => { const fn = buttons[+b.dataset.b][2]; if (!fn || fn() !== false) close(); });
    return m;
  }
  // ---------- campos de tecla ----------
  function keyFields(r) {
    return `<div class="row" style="margin:0;align-items:end"><label class="f">Tecla<select class="i" data-k="key">${(KEYS.length ? KEYS : ['ESPACIO', 'ENTER', 'F1']).concat('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'.split('')).map(k => `<option ${r.key === k ? 'selected' : ''}>${k}</option>`).join('')}</select></label>
      <label class="vz-ck"><input type="checkbox" data-k="ctrl" ${r.ctrl ? 'checked' : ''}><i></i><span>Ctrl</span></label><label class="vz-ck"><input type="checkbox" data-k="shift" ${r.shift ? 'checked' : ''}><i></i><span>Shift</span></label><label class="vz-ck"><input type="checkbox" data-k="alt" ${r.alt ? 'checked' : ''}><i></i><span>Alt</span></label>
      <label class="f" style="max-width:110px">Veces<input class="i" type="number" min="1" max="20" data-k="times" value="${r.times || 1}"></label></div>
      <label class="f" style="margin-top:8px">Ventana (opcional): parte del título, ej. "Roblox"<input class="i" data-k="window" value="${esc(r.window || '')}"></label>`;
  }
  function readKey(m) { const o = {}; m.querySelectorAll('[data-k]').forEach(i => o[i.dataset.k] = i.type === 'checkbox' ? i.checked : i.type === 'number' ? +i.value : i.value); return o; }
  function bindKeyFields() {}

  // =====================================================================
  // EDITOR (asistente de 3 pasos)
  // =====================================================================
  function openEditor(idx) {
    const a = A();
    const d = idx == null ? { id: uid(), on: true, name: '', trigger: { type: '' }, who: { mode: 'all' }, cooldown: 0, userCooldown: 0, screen: curScreen, reactions: [] } : clone(a.rules[idx]);
    let step = idx == null ? 1 : 2, cat = 'Todos', q = '';
    const m = document.createElement('div'); m.className = 'gpm';
    m.innerHTML = `<div class="gpm-box ac-modal wide"><div class="ac-steps" data-r="steps"></div><div class="ac-mbody" data-r="body"></div>
      <div class="gpm-ft"><button class="btn" data-r="back">← Atrás</button><span style="flex:1"></span><button class="btn" data-r="cancel">Cancelar</button><button class="btn pri" data-r="next"></button></div></div>`;
    document.body.appendChild(m);
    const mb = s => m.querySelector(s);
    const close = () => { m.remove(); document.removeEventListener('keydown', escK); };
    const escK = e => { if (e.key === 'Escape') close(); };
    document.addEventListener('keydown', escK);
    mb('[data-r=cancel]').onclick = close;
    mb('[data-r=back]').onclick = () => { if (step > 1) { step--; draw(); } };
    mb('[data-r=next]').onclick = () => {
      if (step === 1) { if (!d.trigger.type) return toast('Elige qué lo activa'); step = 2; return draw(); }
      if (step === 2) { step = 3; return draw(); }
      if (!d.reactions.length) return toast('Agrega al menos una reacción');
      if (!d.name.trim()) d.name = autoName(d.trigger);
      if (idx == null) a.rules.push(d); else a.rules[idx] = d;
      saveA(); paint(); close(); toast('✓ Acción guardada');
    };
    function draw() {
      mb('[data-r=steps]').innerHTML = [['1', '¿Qué lo activa?'], ['2', 'Detalles y quién cuenta'], ['3', '¿Qué pasa?']].map(([n, l], i) => `<div class="${step === i + 1 ? 'on' : step > i + 1 ? 'done' : ''}" data-st="${i + 1}"><b>${step > i + 1 ? '✓' : n}</b>${l}</div>`).join('<i></i>');
      m.querySelectorAll('[data-st]').forEach(s => s.onclick = () => { const n = +s.dataset.st; if (n === 1 || d.trigger.type) { step = n; draw(); } });
      mb('[data-r=back]').style.visibility = step > 1 ? '' : 'hidden';
      mb('[data-r=next]').textContent = step === 3 ? '💾 Guardar acción' : 'Siguiente →';
      const body = mb('[data-r=body]');
      if (step === 1) {
        body.innerHTML = `<div class="ac-s1"><div><input class="i ac-q" placeholder="🔍 Busca un evento: regalo, seguir, chat, like…" value="${esc(q)}"><div class="seg sm" style="margin-top:10px">${CATS.map(c => `<button data-c="${c}" class="${c === cat ? 'on' : ''}">${c}</button>`).join('')}</div>
          <div class="ac-evgrid">${EVENTS.filter(e => (cat === 'Todos' || e[4] === cat) && (!q || (e[2] + ' ' + e[3]).toLowerCase().includes(q.toLowerCase()))).map(e => `<button class="ac-ev ${d.trigger.type === e[0] ? 'on' : ''}" data-ev="${e[0]}" data-cat="${e[4]}"><span>${e[1]}</span><b>${e[2]}</b><small>${e[3]}</small></button>`).join('')}</div></div>
          <div class="ac-side"><img src="/brand/oso-acciones.svg"><p>Elige lo que pasa en tu live. Después decides qué hace ChispaLive.</p><small>Tip: escribe para buscar y presiona Enter.</small></div></div>`;
        const qi = body.querySelector('.ac-q'); qi.focus(); qi.setSelectionRange(q.length, q.length);
        qi.oninput = e => { q = e.target.value; draw(); };
        qi.onkeydown = e => { if (e.key === 'Enter') { const f = body.querySelector('[data-ev]'); if (f) f.click(); } };
        body.querySelectorAll('[data-c]').forEach(b => b.onclick = () => { cat = b.dataset.c; draw(); });
        body.querySelectorAll('[data-ev]').forEach(b => b.onclick = () => { d.trigger = { type: b.dataset.ev, ...defaultsFor(b.dataset.ev) }; step = 2; draw(); });
      }
      if (step === 2) {
        const t = d.trigger, e = EV[t.type], W = d.who = d.who || { mode: 'all' };
        let det = '';
        if (t.type === 'gift') det = `<div class="flab">REGALO</div><button class="gpick" data-gp>${t.gift ? giftChip(t.gift) : '<span class="gchip"><b>Elegir regalo</b><i>▾</i></span>'}</button>
          <label class="vz-ck" style="margin-top:8px"><input type="checkbox" data-t="perUnit" ${t.perUnit ? 'checked' : ''}><i></i><span>Repetir por cada regalo de la racha (máx. 10)</span></label>`;
        if (t.type === 'value') det = num('min', 'Monedas mínimas del regalo', t.min, 1) + `<button class="btn sm" data-gv style="margin-top:6px">🎁 Usar el valor de un regalo</button>`;
        if (t.type === 'keyword') det = `<label class="f">Palabra o comando<input class="i" data-t="keyword" value="${esc(t.keyword || '')}" placeholder="!baile"></label><label class="vz-ck" style="margin-top:8px"><input type="checkbox" data-t="exact" ${t.exact ? 'checked' : ''}><i></i><span>El mensaje debe empezar con esa palabra (si no, basta con que la contenga)</span></label>`;
        if (t.type === 'likes') det = num('every', 'Cada cuántos likes de un mismo viewer', t.every, 1);
        if (t.type === 'coingoal') det = num('goal', 'Cuando el live junte (monedas)', t.goal, 1) + '<div class="hint">Se ejecuta una vez por live.</div>';
        if (t.type === 'likegoal') det = num('goal', 'Cuando el live llegue a (likes)', t.goal, 1) + '<div class="hint">Se ejecuta una vez por live.</div>';
        if (t.type === 'viewers') det = num('goal', 'Cuando haya (espectadores)', t.goal, 1) + '<div class="hint">Se ejecuta una vez por live.</div>';
        if (t.type === 'timer') det = num('minutes', 'Cada cuántos minutos', t.minutes, 1);
        if (t.type === 'hotkey') det = `<div class="flab">ATAJO</div><button class="btn" data-hk>${t.combo ? `⌨️ ${esc(t.combo)}` : '⌨️ Presiona para grabar el atajo'}</button><div class="hint" style="margin-top:6px">Funciona cuando la ventana del panel está activa (no mientras escribes en un campo).</div>`;
        body.innerHTML = `<div class="ac-s2">
          <div class="ac-chosen"><span>${e[1]}</span><div><b>${e[2]}</b><small>${e[3]}</small></div><button class="btn sm" data-chg>Cambiar</button></div>
          <label class="f">Nombre de la acción<input class="i" data-name value="${esc(d.name)}" placeholder="Ej. Rosa = sonido + GIF"></label>
          ${det ? `<div class="ac-det">${det}</div>` : ''}
          ${['start', 'end', 'timer', 'coingoal', 'likegoal', 'viewers', 'hotkey'].includes(t.type) ? '' : `
          <div class="flab" style="margin-top:6px">👥 ¿QUIÉN CUENTA?</div>
          <button class="ac-all ${W.mode !== 'some' ? 'on' : ''}" data-wall><span>🌍</span><div><b>Todos</b><small>Cuenta a cualquier viewer</small></div><i></i></button>
          <div class="ac-or">O SOLO DE — ELIGE LOS QUE QUIERAS</div>
          <div class="ac-who">${[['followers', '💗', 'Seguidores', 'Te siguen'], ['subs', '👑', 'Super fans', 'Suscriptores'], ['mods', '🛡️', 'Moderadores', 'Tus mods'],
            ['fan', '💖', 'Club de fans', 'Nivel', 'fanLevel'], ['gifter', '🎁', 'Nivel de donador', 'Nivel', 'gifterLevel'], ['top', '🏆', 'Top donador', 'Top', 'topRank']]
            .map(([k, ic, n, s, lv]) => `<label class="ac-wc ${W.mode === 'some' && W[k] ? 'on' : ''}"><input type="checkbox" data-w="${k}" ${W.mode === 'some' && W[k] ? 'checked' : ''}><span class="tc-ic">${ic}</span><div><b>${n}</b>${lv ? `<small>${s} ≥ <input type="number" min="1" max="50" data-wl="${lv}" value="${W[lv] || (k === 'top' ? 3 : 1)}"></small>` : `<small>${s}</small>`}</div><i></i></label>`).join('')}</div>`}
          <div class="vz-two" style="margin-top:8px">${num('cooldown', '⏳ Espera general (segundos)', d.cooldown, 0, true)}${['start', 'end', 'timer', 'coingoal', 'likegoal', 'viewers', 'hotkey'].includes(t.type) ? '' : num('userCooldown', '👤 Espera por viewer (segundos)', d.userCooldown, 0, true)}</div>
          <label class="f" style="margin-top:8px">🖥️ Pantalla donde se ve<select class="i" data-scr>${(a.screens || []).map((n, j) => `<option value="${j}" ${(d.screen || 0) === j ? 'selected' : ''}>${esc(n)}</option>`).join('')}</select></label>
        </div>`;
        body.querySelector('[data-chg]').onclick = () => { step = 1; draw(); };
        body.querySelector('[data-name]').oninput = e => d.name = e.target.value;
        body.querySelectorAll('[data-t]').forEach(i => i.addEventListener(i.type === 'checkbox' ? 'change' : 'input', () => t[i.dataset.t] = i.type === 'checkbox' ? i.checked : i.type === 'number' ? +i.value : i.value));
        body.querySelectorAll('[data-d]').forEach(i => i.oninput = () => d[i.dataset.d] = Math.max(0, +i.value || 0));
        body.querySelector('[data-gp]')?.addEventListener('click', () => openGiftPicker({ title: 'Regalo que activa la acción', onPick: g => { t.gift = g.name; draw(); } }));
        body.querySelector('[data-gv]')?.addEventListener('click', () => openGiftPicker({ title: 'Monedas mínimas = valor del regalo', onPick: g => { t.min = +g.coins || 1; draw(); } }));
        body.querySelector('[data-hk]')?.addEventListener('click', ev => {
          const b = ev.currentTarget; b.textContent = '⌨️ Presiona tu atajo ahora…'; b.classList.add('pri');
          const h = k => { k.preventDefault(); if (['Control', 'Shift', 'Alt', 'Meta'].includes(k.key)) return; t.combo = comboOf(k); document.removeEventListener('keydown', h, true); draw(); };
          document.addEventListener('keydown', h, true);
        });
        body.querySelector('[data-wall]')?.addEventListener('click', () => { W.mode = 'all'; draw(); });
        body.querySelectorAll('[data-w]').forEach(c => c.onchange = () => { W.mode = 'some'; W[c.dataset.w] = c.checked; if (!['followers', 'subs', 'mods', 'fan', 'gifter', 'top'].some(k => W[k])) W.mode = 'all'; draw(); });
        body.querySelectorAll('[data-wl]').forEach(i => { i.onclick = e => e.stopPropagation(); i.oninput = () => W[i.dataset.wl] = Math.max(1, +i.value || 1); });
        body.querySelector('[data-scr]').onchange = e => d.screen = +e.target.value;
      }
      if (step === 3) {
        body.innerHTML = `<div class="ac-s3"><div class="ac-flow big"><span class="ac-lbl">CUANDO</span>${trigLabel(d.trigger)}<span class="ac-arrow">➜</span><span class="ac-lbl">HACER</span></div>
          <div class="ac-rxlist" data-rl></div>
          <div class="flab" style="margin-top:6px">＋ AGREGAR REACCIÓN</div>
          <div class="ac-rxadd">${REACT.map(r => `<button data-add="${r[0]}"><span>${r[1]}</span><b>${r[2]}</b><small>${r[3]}</small></button>`).join('')}</div></div>`;
        body.querySelectorAll('[data-add]').forEach(b => b.onclick = () => { d.reactions.push(newReaction(b.dataset.add, d.trigger)); drawRx(); body.querySelector('.ac-rxlist').lastElementChild?.scrollIntoView({ block: 'nearest', behavior: 'smooth' }); });
        drawRx();
      }
    }
    function drawRx() {
      const box = m.querySelector('[data-rl]'); if (!box) return;
      box.innerHTML = d.reactions.length ? d.reactions.map((r, i) => `<div class="ac-rx" data-ri="${i}"><div class="ac-rxh"><span class="tc-ic">${RX[r.type][1]}</span><b>${RX[r.type][2]}</b><span style="flex:1"></span>
        <label class="sw2" title="Activa"><input type="checkbox" data-ron ${r.on !== false ? 'checked' : ''}><i></i></label><button class="ib" data-rp title="Probar">▶</button><button class="ib" data-rd title="Quitar">✕</button></div>
        <div class="ac-rxb">${rxFields(r)}</div></div>`).join('') : '<div class="ac-empty sm">Agrega una o varias reacciones de abajo 👇</div>';
      box.querySelectorAll('.ac-rx').forEach(el => {
        const r = d.reactions[+el.dataset.ri];
        el.querySelector('[data-ron]').onchange = e => r.on = e.target.checked;
        el.querySelector('[data-rd]').onclick = () => { d.reactions.splice(+el.dataset.ri, 1); drawRx(); };
        el.querySelector('[data-rp]').onclick = () => previewRx(r);
        el.querySelectorAll('[data-f]').forEach(i => i.addEventListener(i.type === 'checkbox' ? 'change' : 'input', () => { r[i.dataset.f] = i.type === 'checkbox' ? i.checked : i.type === 'number' ? +i.value : i.value; if (i.tagName === 'SELECT' && ['preset', 'game', 'do', 'scene'].includes(i.dataset.f)) { if (i.dataset.f === 'preset') { r.file = ''; playSpec({ on: true, preset: r.preset }, .6); } drawRx(); } }));
        el.querySelectorAll('[data-k]').forEach(i => i.addEventListener(i.type === 'checkbox' ? 'change' : 'input', () => r[i.dataset.k] = i.type === 'checkbox' ? i.checked : i.type === 'number' ? +i.value : i.value));
        el.querySelector('[data-up-img]')?.addEventListener('click', () => pickUp('image/*', true, url => { r.image = url; drawRx(); }));
        el.querySelector('[data-rm-img]')?.addEventListener('click', () => { r.image = ''; drawRx(); });
        el.querySelector('[data-up-snd]')?.addEventListener('click', () => pickUp('audio/*', false, url => { r.file = url; drawRx(); }));
        el.querySelector('[data-rm-snd]')?.addEventListener('click', () => { r.file = ''; drawRx(); });
      });
    }
    draw();
  }
  function num(k, label, v, min, isRule) { return `<label class="f">${label}<input class="i" type="number" min="${min}" ${isRule ? `data-d="${k}"` : `data-t="${k}"`} value="${v ?? min}"></label>`; }
  // Solo los datos que usa cada evento (antes todos guardaban "Rose" y el nombre salía "Palabra clave · Rose")
  function defaultsFor(t) {
    return ({ gift: { gift: 'Rose' }, value: { min: 100 }, likes: { every: 100 }, coingoal: { goal: 1000 }, likegoal: { goal: 10000 }, viewers: { goal: 100 },
      timer: { minutes: 10 }, keyword: { keyword: '!baile', exact: true } })[t] || {};
  }
  function autoName(t) {
    const base = EV[t.type]?.[2] || 'Acción';
    if (t.type === 'gift' && t.gift) return `${base} · ${t.gift}`;
    if (t.type === 'keyword' && t.keyword) return `${base} · ${t.keyword}`;
    if (t.type === 'value') return `${base} · ${t.min || 1}+ 🪙`;
    return base;
  }
  // Arregla nombres viejos que salían con "· Rose" sin ser de regalo
  function fixOldNames() {
    let ch = false;
    for (const r of A().rules || []) {
      const t = r.trigger || {};
      if (t.type !== 'gift' && t.gift && r.name === `${EV[t.type]?.[2]} · ${t.gift}`) { r.name = autoName(t); ch = true; }
      if (t.type !== 'gift' && t.gift) { delete t.gift; ch = true; }
    }
    if (ch) saveA();
  }
  // Texto de alerta / voz según lo que activa la acción
  function textFor(t, tts) {
    const k = t?.type;
    if (['gift', 'anygift', 'value'].includes(k)) return tts ? 'Gracias {usuario} por {regalo}' : '¡{usuario} envió {regalo}!';
    if (k === 'follow') return tts ? 'Gracias por seguir, {usuario}' : '¡Gracias por seguir, {usuario}! 💖';
    if (k === 'share') return tts ? 'Gracias por compartir, {usuario}' : '¡{usuario} compartió el live! 📣';
    if (k === 'join' || k === 'first') return tts ? 'Bienvenido {usuario}' : '¡Bienvenido, {usuario}! 👋';
    if (k === 'keyword' || k === 'comment') return tts ? '{usuario} dice {mensaje}' : '{usuario}: {mensaje}';
    if (k === 'likes' || k === 'likegoal') return tts ? 'Gracias por los likes, {usuario}' : '❤️ ¡Gracias por los likes, {usuario}!';
    if (k === 'sub') return tts ? 'Gracias por ser super fan, {usuario}' : '👑 ¡{usuario} es super fan!';
    if (k === 'corazon') return tts ? '¡Llenamos el corazón!' : '💖 ¡Llenamos el corazón!';
    if (k === 'carrerawin') return tts ? '¡Ganó el {equipo}!' : '🏁 ¡Ganó el {equipo}! MVP: {usuario}';
    if (k === 'jefedown') return tts ? '¡Derrotaron al jefe!' : '👹 ¡{usuario} derrotó al jefe nivel {nivel}!';
    if (k === 'mascotaevo') return tts ? '¡Nuestra mascota evolucionó!' : '🐣 ¡La mascota evolucionó gracias a {usuario}!';
    if (k === 'castillowin') return tts ? '¡Ganó el {equipo}!' : '🏰 ¡Ganó el {equipo}! MVP: {usuario}';
    if (k === 'adivinawin') return tts ? '¡{usuario} ganó adivina la palabra!' : '🔤 ¡{usuario} ganó Adivina la palabra con {puntos} puntos!';
    if (k === 'pescalegend') return tts ? '¡{usuario} pescó algo legendario!' : '🎣 ¡{usuario} pescó un {pez}!';
    if (k === 'bombawin') return tts ? '¡{usuario} sobrevivió a la bomba!' : '💣 ¡{usuario} sobrevivió a la bomba caliente!';
    if (k === 'slotjackpot') return tts ? '¡Jackpot para {usuario}!' : '🎰 ¡JACKPOT! {usuario} se llevó {puntos} puntos';
    if (k === 'penalgol') return tts ? '¡Gol de {usuario}!' : '⚽ ¡GOOOL de {usuario}!';
    if (k === 'triviawin') return tts ? '¡{usuario} ganó la trivia!' : '❓ ¡{usuario} ganó la trivia con {puntos} puntos!';
    if (k === 'subathonend') return tts ? '¡Se acabó el subathon! Gracias a todos' : '⏰ ¡Se acabó el subathon! Gracias a todos 💖';
    if (k === 'battlewin') return tts ? '¡Ganó el {equipo}!' : '⚔️ ¡Ganó el {equipo}! MVP: {usuario}';
    if (k === 'coingoal') return '🏁 ¡Llegamos a la meta de monedas!';
    if (k === 'viewers') return '👀 ¡Somos {espectadores} en el live!';
    return tts ? '¡Gracias {usuario}!' : '¡Gracias, {usuario}! ✨';
  }
  function newReaction(t, trig) {
    if (t === 'alert') return { type: t, image: '', text: textFor(trig), anim: 'pop', duration: 5, size: 100 };
    if (t === 'sound') return { type: t, preset: 'fanfare', file: '', volume: 80 };
    if (t === 'tts') return { type: t, text: textFor(trig, true) };
    if (t === 'key') return { type: t, key: 'ESPACIO', ctrl: false, shift: false, alt: false, times: 1, window: '' };
    if (t === 'game') return { type: t, game: 'ruleta', wheel: 1, amount: 100 };
    if (t === 'webhook') return { type: t, url: '', method: 'POST' };
    if (t === 'roblox') return { type: t, cmd: 'turbo', value: '' };
    if (t === 'obs') return { type: t, do: 'scene', scene: window.OBS?.scenes?.[0] || '', source: '', seconds: 10, text: 'Último regalo: {usuario}' };
    return { type: t };
  }
  function rxFields(r) {
    const vars = '<div class="hint">Puedes usar {usuario}, {regalo}, {cantidad}, {monedas}, {mensaje}, {likes}, {espectadores}, {equipo}.</div>';
    if (r.type === 'alert') return `<div class="ac-media"><div class="ph">${r.image ? `<img src="${esc(r.image)}">` : '🖼️'}</div><div style="flex:1;display:flex;gap:6px;flex-wrap:wrap"><button class="btn sm" data-up-img>⬆ Subir GIF / imagen</button>${r.image ? '<button class="btn sm danger" data-rm-img>Quitar</button>' : ''}</div></div>
      <label class="f">Texto<input class="i" data-f="text" value="${esc(r.text || '')}"></label>${vars}
      <div class="row" style="margin:0"><label class="f">Animación<select class="i" data-f="anim">${Object.entries(ANIMS).map(([k, n]) => `<option value="${k}" ${r.anim === k ? 'selected' : ''}>${n}</option>`).join('')}</select></label>
      <label class="f">Duración (s)<input class="i" type="number" min="1" max="60" data-f="duration" value="${r.duration || 5}"></label><label class="f">Tamaño (%)<input class="i" type="number" min="30" max="300" data-f="size" value="${r.size || 100}"></label></div>`;
    if (r.type === 'sound') return `<div class="row" style="margin:0;align-items:end"><label class="f">Sonido<select class="i" data-f="preset">${PRESETS.filter(([v]) => v !== 'none').map(([v, l]) => `<option value="${v}" ${r.preset === v && !r.file ? 'selected' : ''}>${l}</option>`).join('')}</select></label>
      <button class="btn sm" data-up-snd>📁 ${r.file ? 'Cambiar mi sonido' : 'Subir MP3 / WAV'}</button>${r.file ? '<button class="btn sm danger" data-rm-snd>Quitar mi sonido</button>' : ''}</div>
      ${r.file ? '<div class="hint">🎵 Se usa tu sonido subido.</div>' : ''}<label class="f">Volumen (%)<input class="i" type="number" min="0" max="100" data-f="volume" value="${r.volume ?? 80}"></label>`;
    if (r.type === 'tts') return `<label class="f">Texto que se lee<input class="i" data-f="text" value="${esc(r.text || '')}"></label>${vars}<div class="hint">Usa la voz configurada en "Voz del chat".</div>`;
    if (r.type === 'key') return keyFields(r) + '<div class="hint">Solo en Windows. Si pones el título de la ventana, ChispaLive la activa antes de presionar.</div>';
    if (r.type === 'game') return `<div class="row" style="margin:0"><label class="f">Juego<select class="i" data-f="game">${GAMES.map(([k, n]) => `<option value="${k}" ${r.game === k ? 'selected' : ''}>${n}</option>`).join('')}</select></label>
      ${r.game === 'ruleta' ? `<label class="f">Rueda Nº<input class="i" type="number" min="1" data-f="wheel" value="${r.wheel || 1}"></label>` : ['jar', 'subasta', 'royale', 'meta', 'corazon', 'batalla', 'subathon', 'carrera', 'jefe', 'castillos'].includes(r.game) ? `<label class="f">${r.game === 'subasta' || r.game === 'subathon' ? 'Segundos' : r.game === 'batalla' ? 'Puntos' : r.game === 'carrera' ? 'Metros' : r.game === 'jefe' || r.game === 'castillos' ? 'Daño' : 'Cantidad'}<input class="i" type="number" min="1" data-f="amount" value="${r.amount || 100}"></label>` : ''}${r.game === 'batalla' || r.game === 'carrera' || r.game === 'castillos' ? `<label class="f">${r.game === 'carrera' ? 'Corredor' : r.game === 'castillos' ? 'Castillo que dispara' : 'Equipo'}<select class="i" data-f="team"><option value="mine" ${!r.team || r.team === 'mine' ? 'selected' : ''}>${r.game === 'carrera' ? 'El corredor del viewer' : r.game === 'castillos' ? 'El castillo del viewer' : 'El equipo del viewer'}</option>${(r.game === 'castillos' ? [1, 2] : [1, 2, 3, 4]).map(n => `<option value="${n}" ${String(r.team) === String(n) ? 'selected' : ''}>Equipo ${n}</option>`).join('')}</select></label>` : ''}</div>`;
    if (r.type === 'webhook') return `<div class="row" style="margin:0"><label class="f" style="flex:3">URL<input class="i" data-f="url" value="${esc(r.url || '')}" placeholder="http://127.0.0.1:7474/…"></label><label class="f">Método<select class="i" data-f="method"><option ${r.method === 'POST' ? 'selected' : ''}>POST</option><option ${r.method === 'GET' ? 'selected' : ''}>GET</option></select></label></div><div class="hint">Envía los datos del evento en JSON (usuario, regalo, monedas…).</div>`;
    if (r.type === 'obs') return obsFields(r);
    if (r.type === 'roblox') return `<div class="row" style="margin:0"><label class="f" style="flex:2">Poder (comando)<input class="i" data-f="cmd" value="${esc(r.cmd || '')}" placeholder="turbo, salto, meteorito…" maxlength="40"></label><label class="f">Valor extra (opcional)<input class="i" data-f="value" value="${esc(r.value || '')}" placeholder="ej. 5" maxlength="60"></label></div><div class="hint">Tu juego recibe <b>data.cmd</b> con este nombre, además del usuario, el regalo y la cantidad. La conexión se configura en <b>🧱 Roblox</b> (menú de la izquierda).</div>`;
    return '<div class="hint">Sin opciones: se ve en la pantalla elegida.</div>';
  }
  function previewRx(r) {
    if (r.type === 'sound') return r.file ? new Audio(r.file).play().catch(() => {}) : playSpec({ on: true, preset: r.preset }, (r.volume ?? 80) / 100);
    if (r.type === 'tts') return window.vozSpeak ? window.vozSpeak(String(r.text || '').replace(/\{usuario\}/g, 'Tu canal').replace(/\{regalo\}/g, 'Rosa')) : null;
    if (r.type === 'key') return socket.emit('act:key', r);
    if (r.type === 'obs') return socket.emit('obs:test', r, err => toast(err ? `🎬 ${err}` : '🎬 Listo, revisa tu OBS'));
    if (r.type === 'roblox') return socket.emit('rbx:send', r, err => toast(err ? `🧱 ${err}` : `🧱 Poder "${r.cmd}" enviado a Roblox`));
    if (r.type === 'game' || r.type === 'webhook') return toast('Se prueba con ▶ en la lista, después de guardar');
    socket.emit('act:preview', { screen: curScreen, r });
  }
  function pickUp(accept, isImg, cb) {
    const f = Object.assign(document.createElement('input'), { type: 'file', accept });
    f.onchange = () => { const file = f.files[0]; if (!file) return; (isImg ? readImage : readAudio)(file, data => socket.emit('uploadMedia', data, res => res?.url ? cb(res.url) : toast(res?.error || 'No se pudo subir'))); };
    f.click();
  }
  // ---------- atajos de teclado globales del panel ----------
  function comboOf(k) { return [k.ctrlKey && 'Ctrl', k.altKey && 'Alt', k.shiftKey && 'Shift', k.key.length === 1 ? k.key.toUpperCase() : k.key].filter(Boolean).join('+'); }
  document.addEventListener('keydown', k => {
    if (['INPUT', 'TEXTAREA', 'SELECT'].includes(document.activeElement?.tagName) || document.querySelector('.gpm')) return;
    if (['Control', 'Shift', 'Alt', 'Meta'].includes(k.key)) return;
    const c = comboOf(k);
    if ((A().rules || []).some(r => r.on && r.trigger?.type === 'hotkey' && (r.trigger.combo || '').toLowerCase() === c.toLowerCase())) { k.preventDefault(); socket.emit('hotkey', c); toast(`⌨️ ${c}`); }
  });
  // Sonidos de acciones cuando se eligen "en esta ventana"
  // (también suenan aquí si la pantalla de esa acción no está abierta en OBS, para que nunca quede en silencio)
  socket.on('act:run', x => { if ((x.soundsIn === 'panel' || !(screensConn[(x.screen || 0) + 1] > 0)) && x.r.type === 'sound') x.r.file ? (() => { const au = new Audio(x.r.file); au.volume = (x.r.volume ?? 80) / 100; au.play().catch(() => {}); })() : playSpec({ on: true, preset: x.r.preset }, (x.r.volume ?? 80) / 100); });
})();

