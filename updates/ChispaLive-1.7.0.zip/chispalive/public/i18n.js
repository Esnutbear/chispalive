// ChispaLive — idioma (Español / English)
// La app se escribe en español; este archivo traduce lo que se ve en pantalla al inglés
// cuando config.lang === 'en'. Funciona en el panel y en todos los overlays.
// Traduce textos, placeholders y títulos (tooltips), y también los cuadros confirm/prompt.
(function () {
  // '#' = cualquier número (se rellena solo)
  const D = {
    // ── Textos que faltaban (batalla, subathon, OBS, Roblox, resumen, celular, ajustes…)
    'Perú': 'Peru', 'Pega aquí tu clave (CHISPA-… o la de tu correo)': 'Paste your key here (CHISPA-… or the one from your email)', 'Cómo te fue en cada live: monedas, regalos, seguidores, tus mejores donadores y el momento con más gente.': 'How each live went: coins, gifts, followers, your top gifters and the moment with the most viewers.', 'No hay un live contándose. Empieza solo cuando te conectas a tu live.': 'No live is being tracked. It starts by itself when you connect to your live.', 'Todavía no hay lives guardados. Cuando termines tu próximo live, aparece aquí.': 'No saved lives yet. When you finish your next live, it shows up here.', 'Elige un live de la lista para ver su resumen.': 'Pick a live from the list to see its summary.', 'Maneja tu live desde el celular: juegos, subathon, batalla, escenas de OBS y acciones, sin tocar la PC.': 'Run your live from your phone: games, subathon, battle, OBS scenes and actions, without touching the PC.', 'puede abrir tu panel. Nadie más en tu WiFi puede entrar ni ver tus claves.': 'can open your panel. Nobody else on your WiFi can get in or see your keys.', 'arriba para manejar tu live desde el teléfono: te sale un código QR que solo funciona con tu código secreto.': 'above to run your live from your phone: you get a QR code that only works with your secret code.', 'Cualquier regalo cuenta. Toca uno y': 'Any gift counts. Tap one and', 'será la puja mínima: entra todo regalo que valga eso o más, y sus monedas se suman.': 'becomes the minimum bid: any gift worth that or more gets in, and its coins add up.', 'Espera después de cada eliminación antes del siguiente giro': 'Wait after each elimination before the next spin', 'Ganó la partida': 'Won the game', 'Solo un regalo': 'Only one gift', 'Valor mínimo': 'Minimum value', 'Cualquier regalo cuenta. Toca uno para que': 'Any gift counts. Tap one so that', 'solo ese regalo': 'only that gift', '¡Frasco lleno!': 'Jar full!', 'Duración de la batalla': 'Battle length', 'Los que más aportan': 'Top contributors', 'Cada equipo tiene': 'Each team has', 'su regalo': 'its gift', 'del chat para unirse. Puedes tener de 2 a 4 equipos.': 'chat command to join. You can have 2 to 4 teams.', '¿Qué suma puntos?': 'What scores points?', 'el valor del regalo': 'the gift\'s value', 'Cualquier regalo cuenta': 'Any gift counts', 'Si alguien se unió con el comando del chat, todos sus regalos suman a su equipo': 'If someone joined with the chat command, all their gifts count for their team', 'Los likes también suman': 'Likes count too', 'Solo de los que ya están en un equipo': 'Only from people already on a team', 'En los últimos segundos todo vale el doble: ¡remontadas!': 'In the last seconds everything counts double: comebacks!', 'Últimos': 'Last', 'Mostrar top de cada equipo': 'Show each team\'s top', 'Los 3 que más aportan debajo de cada equipo': 'The top 3 contributors under each team', 'Regalo del equipo': 'Team gift', 'Cada vez que un equipo suma': 'Every time a team scores', 'Cuando un equipo pasa adelante': 'When a team takes the lead', 'Al empezar el tiempo doble': 'When double time starts', 'barra que se empuja': 'tug-of-war bar', 'Cada corredor tiene': 'Each runner has', 'para unirse. De 2 a 6 corredores.': 'to join. 2 to 6 runners.', '0 = sin límite. Si se acaba, gana el que va adelante.': '0 = no limit. If time runs out, whoever is ahead wins.', 'Cada': 'Every', '0 = la empiezas tú': '0 = you start it', '0 = sin límite. Si se acaba, ¡escapa!': '0 = no limit. If time runs out, it escapes!', '0 = lo haces aparecer tú': '0 = you spawn it', 'Tiempo x2': 'Double time', 'Tiempo del reloj': 'Clock time', 'Corriendo: los botones suman o quitan tiempo en vivo': 'Running: the buttons add or remove time live', 'Los que más tiempo sumaron': 'Who added the most time', 'Qué suma tiempo': 'What adds time', 'Ejemplo: con': 'Example: with', 'cada 1 moneda = 5 segundos': 'every 1 coin = 5 seconds', ', una Rosa suma 5 s y una Galaxy (1000 monedas) suma 1 h 23 min.': ', a Rose adds 5 s and a Galaxy (1000 coins) adds 1 h 23 min.', 'Según las monedas del regalo': 'Based on the gift\'s coins', 'Cada follow nuevo': 'Each new follow', 'Cada suscripción nueva': 'Each new subscription', 'Cada vez que comparten el live': 'Every time someone shares the live', 'Duración máxima': 'Maximum length', '0 = sin límite. Cuando el subathon llega a este total, ya no se suma más tiempo.': '0 = no limit. When the subathon reaches this total, no more time is added.', 'Mostrar "+tiempo"': 'Show "+time"', 'Sale "+30 s" cada vez que alguien suma': 'Shows "+30 s" every time someone adds time', 'Último que sumó': 'Last to add', 'Nombre de la última persona que sumó tiempo': 'Name of the last person who added time', 'Tiempo total sumado': 'Total time added', 'Cuánto tiempo extra se ha ganado': 'How much extra time has been earned', '¡Se acabó el subathon!': 'The subathon is over!', 'Suma tiempo': 'Time added', 'Cada vez que alguien suma': 'Every time someone adds', 'Último minuto': 'Last minute', 'Cuando queda 1 minuto': 'When 1 minute is left', 'Al activar el tiempo doble': 'When double time turns on', 'Se acabó': 'Time\'s up', 'Cuando el reloj llega a cero': 'When the clock hits zero', 'números grandes': 'big numbers', 'píldora pequeña': 'small pill', 'Toca una meta para editarla (doble clic en el nombre para renombrar). El regalo, la meta y el diseño cambian solo para esa meta. 🔗 copia su link para OBS.': 'Tap a goal to edit it (double-click the name to rename it). The gift, target and design change only for that goal. 🔗 copies its OBS link.', 'Ningún otro regalo lo llena. Toca otro regalo para cambiarlo.': 'No other gift fills it. Tap another gift to change it.', 'se ejecutan cada vez que esta meta se llena (también en cada nivel si la meta sube sola).': 'run every time this goal fills up (also at each level if the goal rises by itself).', 'Nada elegido: al cumplirse no se ejecuta ninguna acción extra.': 'Nothing picked: no extra action runs when it is reached.', 'se vacía y empieza otra vez ·': 'empties and starts over ·', 'se vacía y empieza otra vez': 'empties and starts over', 'sigue llenándose hacia una meta más alta (nivel 2, 3…) ·': 'keeps filling toward a higher goal (level 2, 3…) ·', 'sigue llenándose hacia una meta más alta (nivel 2, 3…)': 'keeps filling toward a higher goal (level 2, 3…)', 'desaparece y vuelve a salir vacío con el próximo regalo': 'disappears and comes back empty with the next gift', 'Doble clic para renombrar': 'Double-click to rename', 'Copiar su link para OBS': 'Copy its OBS link', 'Período': 'Period', '¿De cuándo es el ranking?': 'What time range is the ranking?', 'se reinicia en cada live': 'resets every live', 'La semana empieza el': 'The week starts on', 'El ranking semanal, mensual y de siempre': 'The weekly, monthly and all-time ranking', 'solo cuenta tus lives reales': 'only counts your real lives', '(las pruebas del Simulador no se guardan ahí).': '(Simulator tests are not saved there).', '¿Quieres dos rankings a la vez en OBS? Usa el link del overlay y agrégale': 'Want two rankings at once in OBS? Use the overlay link and add', 'Todavía no hay una semana anterior.': 'There is no previous week yet.', 'Los regalos controlan tu OBS: cambian de escena, muestran un video, guardan un clip…': 'Gifts control your OBS: switch scenes, show a video, save a clip…', 'El control de OBS está apagado.': 'OBS control is off.', '"Mostrar información de conexión"': '"Show Connect Info"', 'para ver el puerto y la contraseña.': 'to see the port and password.', 'OBS está en otra PC': 'OBS is on another PC', 'Dirección (IP)': 'Address (IP)', 'Funciona con': 'Works with', 'OBS Studio 28 o más nuevo': 'OBS Studio 28 or newer', 'TikTok LIVE Studio y Streamlabs no tienen esta conexión.': 'TikTok LIVE Studio and Streamlabs don\'t have this connection.', 'Conecta OBS para ver tus escenas.': 'Connect OBS to see your scenes.', 'Toca una escena para probar el cambio.': 'Tap a scene to test the switch.', 'Acciones y eventos → Nueva acción': 'Actions & events → New action', ', elige qué la activa (por ejemplo, la Galaxy) y en "¿Qué pasa?" elige': ', pick what triggers it (for example, the Galaxy) and under "What happens?" choose', 'Cambiar de escena (y volver sola después de unos segundos)': 'Switch scene (and switch back by itself after a few seconds)', 'Mostrar u ocultar una fuente (un GIF, una cámara, un texto)': 'Show or hide a source (a GIF, a camera, a text)', 'Reproducir un video o sonido': 'Play a video or sound', 'Cambiar un texto, por ejemplo "Último regalo: {user}"': 'Change a text, for example "Last gift: {user}"', 'Guardar una repetición (clip) del momento': 'Save a replay (clip) of the moment', 'Tu live controla tu juego de Roblox: los regalos, likes y comentarios activan poderes dentro del juego.': 'Your live controls your Roblox game: gifts, likes and comments trigger powers inside the game.', 'La conexión con Roblox está apagada:': 'The Roblox connection is off:', 'no se manda nada al juego.': 'nothing is sent to the game.', 'Juego publicado: falta Universe ID y API key': 'Published game: Universe ID and API key missing', 'Descarga el script y ponlo en': 'Download the script and put it in', 'de tu juego en Roblox Studio. Ahí mismo puedes cambiar lo que hace cada poder (vienen de ejemplo': 'of your game in Roblox Studio. Right there you can change what each power does (examples included:', 'Para probar en Roblox Studio:': 'To test in Roblox Studio:', ', deja ChispaLive abierto y dale Play. No necesitas nada más.': ', keep ChispaLive open and hit Play. You don\'t need anything else.', 'En el juego publicado los eventos viajan por la nube de Roblox. Crea una API key en el': 'In the published game, events travel through Roblox\'s cloud. Create an API key in the', 'con el permiso': 'with the permission', 'para tu juego.': 'for your game.', 'El canal tiene que ser el mismo en el script. Si lo cambias, descarga el script otra vez.': 'The channel has to match the one in the script. If you change it, download the script again.', 'Con esto tu juego recibe cada evento (data.cmd = "gift", "like", "chat"…) y tú decides qué hacer en el script.': 'With this your game receives every event (data.cmd = "gift", "like", "chat"…) and you decide what to do in the script.', 'Para poderes por regalo': 'For powers per gift', 'Todavía no se mandó nada. Usa el Simulador o el botón ▶ Probar conexión.': 'Nothing sent yet. Use the Simulator or the ▶ Test connection button.', 'Pega aquí tu API key': 'Paste your API key here', 'Cuando haya una versión nueva te sale un aviso arriba: presionas': 'When there is a new version you get a notice at the top: press', 'y listo. Si te paso el archivo': 'and that\'s it. If I send you the file', ', déjalo en Descargas o en el Escritorio y el aviso aparece solo (o súbelo aquí).': ', leave it in Downloads or on the Desktop and the notice shows up by itself (or upload it here).', 'ChispaLive sigue funcionando aunque cierres esta ventana (así tus overlays de OBS no se apagan). Para apagarlo del todo usa este botón.': 'ChispaLive keeps running even if you close this window (so your OBS overlays don\'t go dark). To shut it down completely, use this button.', 'cuando actualices ChispaLive no pierdes nada. Además se guarda un respaldo automático cada vez que abres el programa (los últimos 10).': 'when you update ChispaLive you don\'t lose anything. A backup is also saved automatically every time you open the program (the last 10).', 'Al abrir ChispaLive espera tu live y se conecta solo. Si TikTok corta la conexión, se reconecta solo y te avisa en rojo. Así no se pierden donaciones.': 'When you open ChispaLive it waits for your live and connects by itself. If TikTok drops the connection, it reconnects by itself and warns you in red. That way no gifts get lost.', 'La conexión al LIVE usa un servidor de firmas (Euler Stream).': 'The LIVE connection uses a signing server (Euler Stream).', 'Sin clave tiene límites': 'Without a key it has limits', 'si te conectas varias veces seguidas TikTok te bloquea unos minutos y en ese tiempo las donaciones no se cuentan.': 'if you connect several times in a row, TikTok blocks you for a few minutes and gifts aren\'t counted during that time.', 'crea una clave gratis en': 'create a free key at', '(botón "Sign up"), copia tu API Key y pégala aquí.': '("Sign up" button), copy your API Key and paste it here.',
    // ── Mensajes, licencia, voz, acciones…
    '% (casi': '% (almost', '% de ganar este premio (si no, sale "': '% chance to win this prize (if not, "', '% usado': '% used', '%: los últimos premios no podrán salir completos. Baja algunos %.': '%: the last prizes won\'t be able to come out fully. Lower some %.', '(ej. Rosa → turbo) ve a': '(e.g. Rose → turbo) go to', '(es privado: solo lo vemos tú y nosotros). Pega tu mensaje y la captura del pago.': '(it\'s private: only you and we can see it). Paste your message and the payment screenshot.', '(especial / regalo)': '(special / gift)', '(menú de la izquierda).': '(left menu).', '(por ejemplo "sonido + GIF") y luego elígelas aquí.': '(for example "sound + GIF") and then pick them here.', '(ya va en el mensaje).': '(it\'s already in the message).', ') por': ') by', ', marca': ', check', ', permite Node.js en': ', allow Node.js on', ', pero ese overlay no está abierto en OBS / TikTok LIVE Studio. Mientras tanto la voz suena': ', but that overlay isn\'t open in OBS / TikTok LIVE Studio. Meanwhile the voice plays', '. Adjunto mi comprobante.': '. My receipt is attached.', '. Cuenta cualquier regalo de ese valor o más.': '. Any gift worth that or more counts.', '. Elige otra en la pestaña Voz.': '. Pick another one in the Voice tab.', '. Para usar el overlay agrega su link como fuente de navegador.': '. To use the overlay, add its link as a browser source.', '. Puedes:': '. You can:', '. Si alguien más lo vio, cámbialo y los celulares que tenían el anterior se desconectan.': '. If someone else saw it, change it and phones that had the old one get disconnected.', '. Toca para agregar o quitar.': '. Tap to add or remove.', '/ año': '/ year', '/ mes': '/ month', ': cuenta desde': ': counting since', 'Empezar a grabar': 'Start recording', 'Parar la grabación': 'Stop recording', '? No se puede deshacer.': '? This can\'t be undone.', 'Abre ChispaLive → 💎 Licencia → pégala en "Activar mi clave".': 'Open ChispaLive → 💎 License → paste it in "Activate my key".', 'Abre la cámara del celular y apunta al código. Tu celular tiene que estar en el': 'Open your phone\'s camera and point it at the code. Your phone has to be on the', 'Acciones apagadas': 'Actions off', 'Acción': 'Action', 'Activa tu licencia para conectarte al live': 'Activate your license to connect to the live', 'Activación automática:': 'Automatic activation:', 'Activador global apagado: cada premio solo se gana con su propio regalo.': 'Global trigger off: each prize can only be won with its own gift.', 'Actualización v': 'Update v', 'Agrega premios con su imagen y su %.': 'Add prizes with their image and %.', 'Agrega un nivel: elige las monedas, sube tu GIF y su sonido.': 'Add a level: pick the coins, upload your GIF and its sound.', 'Ahora mismo': 'Right now', 'Al azar (6-8)': 'Random (6-8)', 'Al iniciar la batalla': 'When the battle starts', 'Al terminar': 'When it ends', 'Banca, agentes y bodegas': 'Online banking, agents and stores', 'Cambiar mi sonido': 'Change my sound', 'Clave copiada ✓': 'Key copied ✓', 'Con el activador global, cada tirada usa estas probabilidades. Lo que sobra (': 'With the global trigger, each roll uses these odds. The rest (', 'Con niveles, un regalo menor a todos no suena.': 'With levels, a gift smaller than all of them makes no sound.', 'Contando este live': 'Tracking this live', 'Copia la clave que aparece al terminar (o en tu correo).': 'Copy the key that shows up at the end (or in your email).', 'Copiado ✓': 'Copied ✓', 'Crea la primera: por ejemplo, "cuando alguien manda una Rosa → sonido + alerta con tu GIF".': 'Create the first one: for example, "when someone sends a Rose → sound + alert with your GIF".', 'Crea una con "＋ Nueva rueda".': 'Create one with "＋ New wheel".', 'Créditos para el final de tu live:': 'Credits for the end of your live:', 'Cuando te paguen por Yape, Plin, Mercado Pago o Binance: pega el': 'When they pay you by Yape, Plin, Mercado Pago or Binance: paste the', 'Código de equipo del cliente': 'Customer\'s computer code', 'De por vida: no vence nunca': 'Lifetime: never expires', 'El corredor del viewer': 'The viewer\'s runner', 'El código QR es secreto:': 'The QR code is secret:', 'El equipo del viewer': 'The viewer\'s team', 'Elegir regalo': 'Pick gift', 'Elige acciones de': 'Pick actions from', 'Elige un plan para seguir usando ChispaLive.': 'Pick a plan to keep using ChispaLive.', 'En Yape aparecerá el titular:': 'In Yape the account holder shows as:', 'En curso': 'In progress', 'En el Discord ve a': 'On Discord go to', 'Envía la captura del comprobante con tu': 'Send the payment screenshot with your', 'Envíalo por DM a': 'Send it by DM to', 'Ese regalo ya es de': 'That gift already belongs to', 'Esperando jugadores': 'Waiting for players', 'Esta computadora tiene el generador de licencias. Todo desbloqueado.': 'This computer has the license generator. Everything unlocked.', 'Fuente de texto': 'Text source', 'Hola! Compré ChispaLive plan': 'Hi! I bought ChispaLive plan', 'Hola, así sueno en tu live': 'Hi, this is how I sound on your live', 'Inscripción en pausa': 'Sign-ups paused', 'Juego publicado: conectado': 'Published game: connected', 'Juego publicado:': 'Published game:', 'Licencia activa ·': 'License active ·', 'Licencia activa': 'License active', 'Licencia quitada de esta PC': 'License removed from this PC', 'Mensaje al terminar': 'End message', 'Mensaje copiado ✓': 'Message copied ✓', 'Mi código de equipo:': 'My computer code:', 'Mi sonido': 'My sound', 'Monedas por minuto': 'Coins per minute', 'Mostrar al ganador': 'Show the winner', 'Máximo 4 equipos': 'Max 4 teams', 'Nada coincide con tu búsqueda': 'Nothing matches your search', 'Niveles de alerta': 'Alert levels', 'No encontré preguntas con ese formato': 'I couldn\'t find questions in that format', 'No hay escenas.': 'No scenes.', 'No se pudo activar': 'Couldn\'t activate', 'No se pudo actualizar:': 'Couldn\'t update:', 'No se pudo subir': 'Couldn\'t upload', 'Nombre / TikTok del cliente': 'Customer name / TikTok', 'Número Yape': 'Yape number', 'Pagar a': 'Pay to', 'Pega tu clave': 'Paste your key', 'Pon 0 para que se quede así.': 'Set 0 to keep it like that.', 'Premio 1': 'Prize 1', 'Premio 2': 'Prize 2', 'Premio 3': 'Prize 3', 'Prueba con otra red de la lista (si sale más de una).': 'Try another network from the list (if there\'s more than one).', 'Puntos x2 al final': 'Double points at the end', 'Puntos x2': 'Double points', 'Pégala en': 'Paste it in', 'REGALO MÁS GRANDE': 'BIGGEST GIFT', 'Regalo de': 'Gift from', 'Regalo que activa la acción': 'Gift that triggers the action', 'Resumen del live': 'Live summary', 'Revisa que el celular esté en el': 'Make sure your phone is on the', 'Si Windows preguntó por el': 'If Windows asked about the', 'Si alguien envía este regalo, tiene': 'If someone sends this gift, it has', 'Sigue intentando': 'Keeps trying', 'Sin límite (empiezas tú)': 'No limit (you start it)', 'Sin límite': 'No limit', 'Sin niveles': 'No levels', 'Sin nombre': 'No name', 'Sin premios': 'No prizes', 'Sin ruedas': 'No wheels', 'Solo cuenta:': 'Only counts:', 'Solo cuentan:': 'Only count:', 'Te quedan': 'You have', 'Te respondemos con tu clave: pégala en': 'We reply with your key: paste it in', 'Tienes la v': 'You have v', 'Todavía no tienes acciones': 'You don\'t have actions yet', 'Todavía no tienes acciones. Créalas en': 'You don\'t have actions yet. Create them in', 'Tu configuración, regalos e imágenes se quedan como están. El programa se reinicia solo (tarda unos segundos).': 'Your settings, gifts and images stay as they are. The program restarts by itself (takes a few seconds).', 'Tu juego recibe': 'Your game receives', 'Un año completo': 'A full year', 'Vence el': 'Expires on', 'Video o sonido': 'Video or sound', 'a las': 'at', 'a los valores por defecto?': 'to the default values?', 'acciones cargadas': 'actions loaded', 'acción(es).': 'action(s).', 'activas de': 'active out of', 'ajustes de': 'settings of', 'aquí en el panel': 'here in the panel', 'celular conectado': 'phone connected', 'celulares conectados': 'phones connected', 'cola llena': 'queue full', 'con PagoEfectivo: desde tu banca por internet o app (BCP, BBVA, Interbank, Scotiabank…), o en efectivo en agentes y bodegas con tu código CIP.': 'with PagoEfectivo: from your online banking or app (BCP, BBVA, Interbank, Scotiabank…), or in cash at agents and stores with your CIP code.', 'con este nombre, además del usuario, el regalo y la cantidad. La conexión se configura en': 'with this name, plus the user, the gift and the amount. The connection is set up in', 'con tarjeta de crédito, débito o PayPal.': 'with credit card, debit card or PayPal.', 'con tarjeta o PayPal': 'with card or PayPal', 'con todo desbloqueado.': 'with everything unlocked.', 'código de equipo': 'computer code', 'de esta semana': 'this week', 'de este live': 'this live', 'de este mes': 'this month', 'de siempre': 'all time', 'desde las': 'since', 'día(s): termina el': 'day(s): ends on', 'días)': 'days)', 'en Game Settings → Security activa': 'in Game Settings → Security turn on', 'en TikTok junto con la foto del comprobante.': 'on TikTok along with the payment screenshot.', 'en cola': 'queued', 'en fila': 'in line', 'en total': 'in total', 'en un overlay': 'in an overlay', 'enviados ·': 'sent ·', 'envió': 'sent', 'este equipo': 'this computer', 'la del sistema': 'the system one', 'mejoras y arreglos': 'improvements and fixes', 'meses gratis)': 'months free)', 'mismo WiFi': 'same WiFi', 'nada (ningún nivel llega)': 'nothing (no level reached)', 'no está en este navegador. Se usa': 'isn\'t in this browser. Using', 'no lo muestres en tu live': 'don\'t show it on your live', 'nunca se borra': 'never resets', 'pagas y al instante recibes tu clave (también llega a tu correo). La pegas abajo y ChispaLive se activa solo en esta computadora.': 'you pay and get your key instantly (it also reaches your email). Paste it below and ChispaLive activates on this computer only.', 'pico de viewers': 'peak viewers', 'preguntas agregadas': 'questions added', 'que esta PC.': 'as this PC.', 'que la PC (no con datos móviles).': 'as the PC (not on mobile data).', 'que te mandó el cliente, elige el plan y genera su clave.': 'the customer sent you, pick the plan and generate their key.', 'redes privadas': 'private networks', 'regalos de TikTok': 'TikTok gifts', 'regalos oficiales de TikTok con su imagen': 'official TikTok gifts with their image', 'respaldos guardados': 'backups saved', 's de espera': 's wait', 'se reinicia solo': 'resets by itself', 'seguidores nuevos · ❤️': 'new followers · ❤️', 'solo esta PC': 'this PC only', 'tarjetas frente a frente': 'head-to-head cards', 'te quedan': 'you have', 'todo el chat': 'the whole chat', 'y abre un': 'and open a', 'y elige': 'and pick', 'y toca': 'and tap', '¡En batalla!': 'Battle on!', '¡Gracias a todos por acompañarme!': 'Thanks everyone for being here!', '¡Gracias por tu compra! 💖': 'Thanks for your purchase! 💖', '¡Llenamos el corazón!': 'We filled the heart!', '¡Lleno!': 'Full!', '¡Nueva actualización v': 'New update v', '¡Puntos x2!': 'Double points!', '· Regalo de tu comunidad': '· Gift from your community', '· en línea': '· online', '· regalo propio:': '· own gift:', '· reintento en': '· retrying in', '· solo': '· only', '· ¡Gracias por el apoyo! 💖': '· Thanks for the support! 💖', '· ⚠️ pon al menos un peso mayor a 0': '· ⚠️ set at least one weight above 0', '¿Borrar el resumen de este live?': 'Delete this live\'s summary?', '¿Borrar esta pregunta?': 'Delete this question?', '¿Cambiar el código secreto? Los celulares conectados se desconectan y tendrás que escanear el QR otra vez.': 'Change the secret code? Connected phones get disconnected and you\'ll have to scan the QR again.', '¿Cerrar ChispaLive? Los overlays de OBS dejarán de funcionar hasta que lo abras otra vez.': 'Close ChispaLive? OBS overlays will stop working until you open it again.', '¿No abre? Prueba con otra red de esta PC': 'Not opening? Try another network on this PC', '¿Quitar la licencia de esta computadora? Podrás activarla en otra con la misma clave.': 'Remove the license from this computer? You can activate it on another one with the same key.', '¿Qué hacer?': 'What to do?', '¿Reiniciar el subathon? Se borra el reloj y todo el tiempo sumado.': 'Reset the subathon? The clock and all added time get cleared.', '¿Reiniciar la batalla? Se borran los puntos de todos los equipos.': 'Reset the battle? All teams\' points get cleared.', '¿Terminar el subathon ahora? El reloj se detiene y sale la pantalla final.': 'End the subathon now? The clock stops and the final screen shows.', '¿Terminar y guardar el resumen de este live? Si sigues en vivo, se empieza uno nuevo cuando te vuelvas a conectar.': 'End and save this live\'s summary? If you\'re still live, a new one starts when you reconnect.', 'ÚLTIMAS CLAVES EMITIDAS': 'LATEST KEYS ISSUED', '— Elige —': '— Pick —', 'Quitar la licencia de esta PC (para pasarla a otra)': 'Remove the license from this PC (to move it to another)', 'Mayor precio': 'Highest price', 'Presiona tu atajo ahora…': 'Press your shortcut now…', 'Sumar tiempo al subathon': 'Add time to the subathon', 'Esta semana se reinicia en': 'This week resets in', 'Verificando…': 'Checking…', 'Terminar y guardar': 'End and save', 'Grabar': 'Record', 'Empezar a contar ahora': 'Start tracking now', 'Iniciar batalla': 'Start battle', 'Iniciar reloj': 'Start clock', 'Reproducir video o sonido': 'Play video or sound', 'CONECTANDO CON TIKTOK…': 'CONNECTING TO TIKTOK…', 'Conectada': 'Connected', 'Conectado al live': 'Connected to the live', 'EN VIVO': 'LIVE', 'NO SE PUDO CONECTAR': 'COULDN\'T CONNECT', 'Equipos': 'Teams', 'Sumar puntos en la Batalla': 'Add points in the Battle', 'Elegiste que la voz suene': 'You chose for the voice to play', 'La suma es': 'The total is', 'La voz': 'The voice', 'Al cumplirse se ejecutan': 'When reached, these run', 'Quitar x2': 'Remove x2', 'Cambiar un texto': 'Change a text', 'Ya tienes la última versión (v': 'You already have the latest version (v', 'Generar clave': 'Generate key', 'Mejor momento: minuto': 'Best moment: minute', 'Elegir regalo': 'Pick gift', 'Solo cuenta:': 'Only counts:', '¡Actualizado a la v': 'Updated to v', 'Cambiar de escena': 'Switch scene', 'Escena actual:': 'Current scene:', 'Créditos en OBS': 'Credits in OBS', 'Créditos enviados al overlay de OBS': 'Credits sent to the OBS overlay', 'Guardar repetición (clip)': 'Save replay (clip)', 'Listo, revisa tu OBS': 'Done, check your OBS', 'Mostrar créditos': 'Show credits', '¡Llegamos a la meta de monedas!': 'We hit the coin goal!', 'Mis mejores donadores:': 'My top gifters:', 'Mostrar una fuente': 'Show a source', 'Generador de licencias (solo tú lo ves)': 'License generator (only you see it)', '¡Gracias por el live de hoy!': 'Thanks for today\'s live!', 'Copiar mensaje para el cliente': 'Copy message for the customer', 'Los más activos en el chat': 'Most active in chat', 'Resumen del live guardado:': 'Live summary saved:', 'Cómo fue tu live': 'How your live went', 'Agradecimiento copiado': 'Thank-you copied', 'Copiar clave': 'Copy key', 'Copiar link': 'Copy link', 'Copiar mi mensaje (con mi código de equipo)': 'Copy my message (with my computer code)', 'Link copiado (no lo compartas)': 'Link copied (don\'t share it)', 'cola máx.': 'max queue', 'Mostrar/ocultar (alternar)': 'Show/hide (toggle)', 'Nueva batalla': 'New battle', 'Un regalo de 10 monedas suena:': 'A 10-coin gift plays:', 'Activa tu licencia para usar ChispaLive': 'Activate your license to use ChispaLive', 'En vivo ahora': 'Live now', 'Live en curso': 'Live in progress', 'Imagen descargada': 'Image downloaded', 'Borrar ranking': 'Delete ranking', 'Ocultar una fuente': 'Hide a source', 'No se leería:': 'Wouldn\'t be read:', 'Primero enciende la conexión con Roblox': 'Turn on the Roblox connection first', 'Prueba enviada: en Roblox debe salir "✅ ChispaLive conectado" en la consola': 'Test sent: Roblox should show "✅ ChispaLive conectado" in the console', 'Cuenta ese regalo y cualquier otro que valga': 'Counts that gift and any other worth',
    // ── Overlays
    'Subasta terminada sin pujas': 'Auction ended with no bids', 'Un giro, un ganador': 'One spin, one winner', 'Para entrar:': 'To join:', 'activó la ruleta': 'spun the wheel', 'envía': 'send', 'gana con': 'wins with', 'ganó': 'won', 'pujadores ·': 'bidders ·', 'pujadores': 'bidders', 'tira el dado': 'rolls the dice', 'toma la delantera!': 'takes the lead!', '¡Batalla!': 'Battle!', '¡Evolución! · Nivel': 'Evolution! · Level', 'esperando': 'waiting', 'te toca': 'your turn', 'Duró': 'Lasted', 'Gana al instante con': 'Win instantly with', 'Donadores': 'Gifters', 'Regalo más grande': 'Biggest gift', 'Los más activos del chat': 'Most active in chat', '¡PUNTOS x2! Últimos': 'DOUBLE POINTS! Last', '¡Derrotaron a': 'They defeated', '¡Apareció': 'It appeared:', 'MVP:': 'MVP:', 'quedan · giro en': 'left · spin in', 'giro en': 'spin in', '¡Ganó': 'Winner:',
    // ── Carrera: poderes y sorpresas
    'Sorpresa': 'Surprise',
    'Apágalo para una carrera normal': 'Turn it off for a normal race', 'Cuando alguien activa el turbo': 'When someone activates turbo', 'Cuando se activa o bloquea': 'When it activates or blocks', 'Cuando un animal resbala': 'When an animal slips', 'Cáscara de plátano': 'Banana peel', 'Cáscara': 'Banana peel', 'El que va primero resbala y retrocede': 'Whoever is first slips and goes back', 'Empuja al que va último': 'Pushes whoever is last', 'Evento sorpresa': 'Surprise event', 'Eventos sorpresa': 'Surprise events', 'Más o menos: varía un poco para que no se adivine': 'Roughly: it varies a bit so nobody can guess it', 'Pasan solos mientras corre la carrera': 'They happen by themselves during the race', 'Poderes activados': 'Powers on', 'Protege a tu animal de una cáscara': 'Protects your animal from a banana peel', 'Regalo de la cáscara': 'Banana peel gift', 'Regalo del escudo': 'Shield gift', 'Regalo del turbo': 'Turbo gift', 'Todos corren a la mitad de velocidad': 'Everyone runs at half speed', 'Tu animal corre más rápido por unos segundos': 'Your animal runs faster for a few seconds', 'Un animal al azar da un salto': 'A random animal jumps ahead', 'Viento a favor': 'Tailwind', 'Viento, lluvia o estrella': 'Wind, rain or star', 'Poderes': 'Powers', 'Lanzar estrella': 'Launch star', 'Lanzar lluvia': 'Launch rain', 'Lanzar viento': 'Launch wind', 'Probar cáscara': 'Test banana peel', 'Probar turbo': 'Test turbo', 'Probar escudo': 'Test shield', '¡Bloqueado!': 'Blocked!', 'Sorpresas': 'Surprises', 'Turbo': 'Turbo', 'Escudo': 'Shield', 'Lluvia': 'Rain', 'Estrella': 'Star', 'Dura': 'Lasts', 'Retrocede': 'Goes back', 'Avanza': 'Moves ahead', 'Salta': 'Jumps', 'Regalos especiales que cambian la carrera. El': 'Special gifts that change the race. The', 'y el': 'and the', 'son para el animal de quien los manda (tiene que haberse unido antes). La': 'are for the sender\'s animal (they must have joined first). The', 'le cae al que va primero.': 'hits whoever is first.', 'Cada cierto tiempo pasa algo solo en la pista. También puedes lanzar uno cuando quieras con el botón': 'Every so often something happens on the track by itself. You can also launch one whenever you want with the button', 'turbo': 'turbo', 'escudo': 'shield', 'cáscara': 'banana peel',
    // ── Monstruos del jefe
    'Dragón de Fuego': 'Fire Dragon', 'Rey Calavera': 'Skull King', 'Slime Gigante': 'Giant Slime', 'Mecha X-9': 'Mecha X-9', 'Fantasmón': 'Big Ghost', 'Kraken': 'Kraken', 'Monstruo': 'Monster', 'Uno distinto en cada nivel': 'A different one every level', 'Si subes tu propia imagen abajo, se usa esa en vez del monstruo.': 'If you upload your own image below, it\'s used instead of the monster.', 'Vacío = el nombre del monstruo': 'Empty = the monster\'s name', 'Déjalo vacío y se llama como el monstruo que sale (por ejemplo Dragón de Fuego).': 'Leave it empty and it takes the name of the monster that shows up (for example Fire Dragon).', 'Siguiente:': 'Next:',
    // ── Carrera / Jefe / Trivia
    "Dos castillos frente a frente. El regalo de cada equipo dispara un cañonazo al castillo enemigo (1 moneda = 1 de daño). Gana el que lo derriba primero o el que tiene más vida al final.": "Two castles face off. Each team's gift fires a cannon shot at the enemy castle (1 coin = 1 damage). The first to knock it down wins, or the one with more HP at the end.",
    "Cada castillo tiene": "Each castle has",
    "para unirse. Si te uniste, tus likes lanzan flechas y puedes usar los poderes.": "to join. Once you join, your likes shoot arrows and you can use the powers.",
    "1 moneda = 1 de daño": "1 coin = 1 damage",
    "0 = sin límite: sigue hasta que caiga un castillo. Si se acaba el tiempo gana el que tiene más vida.": "0 = no limit: it goes on until a castle falls. If time runs out, the one with more HP wins.",
    "sale sola con regalos grandes.": "comes out on its own with big gifts.",
    "son para el castillo de quien los manda (tiene que haberse unido antes).": "are for the sender's castle (they have to join first).",
    "La": "The", "y": "and",
    "¿Terminar la guerra ahora?": "End the war now?",
    "En guerra": "At war",
    "% de la vida": "% of HP",
    "Al activar el escudo": "When the shield turns on",
    "Al empezar el daño doble": "When double damage starts",
    "Al iniciar la guerra": "When the war starts",
    "Asalto final": "Final assault",
    "Bola de fuego": "Fireball",
    "Cada cierto tiempo llega un dragón y quema al castillo que va ganando. Así la pelea nunca está decidida.": "Every so often a dragon shows up and burns the castle that's winning, so the fight is never decided.",
    "Cada disparo": "Every shot",
    "Campo de batalla": "Battlefield",
    "Castillo Azul": "Blue Castle",
    "Castillo Rojo": "Red Castle",
    "Castillo que dispara": "Castle that shoots",
    "Cañonazo": "Cannon shot",
    "Con regalos grandes": "With big gifts",
    "Cualquier regalo dispara": "Any gift shoots",
    "Cuando llega el dragón": "When the dragon arrives",
    "Cuando un castillo pierde una parte": "When a castle loses a piece",
    "Cuando un castillo se repara": "When a castle gets repaired",
    "Dale a ¡A la guerra! y los regalos de cada equipo disparan al castillo enemigo.": "Hit To war! and each team's gifts shoot at the enemy castle.",
    "Dragón": "Dragon",
    "El MVP de cada castillo al terminar": "Each castle's MVP at the end",
    "El castillo de quien te sigue recupera vida": "The new follower's castle gets HP back",
    "El castillo del viewer": "The viewer's castle",
    "En los últimos segundos todo el daño vale doble": "In the last seconds all damage counts double",
    "Gana la guerra de castillos": "Wins the castle war",
    "Guerra de castillos": "Castle War",
    "La Mascota del live sube de etapa": "The Live pet reaches a new stage",
    "La mascota evoluciona": "The pet evolves",
    "Los follows reparan": "Follows repair",
    "Los likes lanzan flechas": "Likes shoot arrows",
    "Los regalos grandes hacen daño extra": "Big gifts deal extra damage",
    "Mostrar a los mejores": "Show the best",
    "Más o menos: varía un poco": "Roughly: it varies a bit",
    "Nadie ha disparado todavía": "Nobody has fired yet",
    "Nueva guerra sola después de": "New war automatically after",
    "Regalo para reparar": "Repair gift",
    "Se rompe": "Breaks",
    "Si te uniste con el comando, todos tus regalos disparan desde tu castillo": "If you joined with the command, all your gifts shoot from your castle",
    "Solo de los que ya están en un castillo": "Only from people already in a castle",
    "Tiempo de la guerra": "War time",
    "Tu castillo no recibe daño por unos segundos": "Your castle takes no damage for a few seconds",
    "Tu castillo recupera vida": "Your castle gets HP back",
    "Un castillo derriba al otro": "One castle knocks down the other",
    "Vida de cada castillo": "Each castle's HP",
    "los dos castillos con cañonazos": "both castles with cannon shots",
    "solo las barras de vida, compacto": "just the HP bars, compact",
    "x las monedas": "x the coins",
    "En guerra!": "At war!",
    "¡En guerra!": "At war!",
    "¿Reiniciar la guerra? Los dos castillos vuelven con la vida llena.": "Restart the war? Both castles go back to full HP.",
    "Se acabó el tiempo": "Time's up",
    "Probar bola de fuego": "Test fireball",
    "¡BOLA DE FUEGO!": "FIREBALL!",
    "¡A la guerra!": "To war!",
    "¡Empieza la guerra!": "The war begins!",
    "Castillos": "Castles",
    "Disparar en la Guerra de castillos": "Shoot in the Castle War",
    "Probar flechas": "Test arrows",
    "Llamar al dragón": "Call the dragon",
    "¡El dragón ataca al que va ganando!": "The dragon attacks whoever's winning!",
    "Los que más disparan": "Top shooters",
    "Castillo derribado": "Castle destroyed",
    "¡ASALTO FINAL! x2": "FINAL ASSAULT! x2",
    "¡ASALTO FINAL!": "FINAL ASSAULT!",
    "¡Asalto final!": "Final assault!",
    "Todo el daño vale x2": "All damage counts x2",
    "Probar reparar": "Test repair",
    "¡BLOQUEADO!": "BLOCKED!",
    "Reparar": "Repair",
    "Repara": "Repairs",
    "Quema": "Burns",
    "Empieza": "Starts",
    "% por minuto": "% per minute",
    "Comida por cada regalo": "Food per gift",
    "Comida: cada": "Food: every",
    "Huevo": "Egg",
    "Cría": "Baby",
    "Joven": "Young",
    "Adulta": "Adult",
    "Legendaria": "Legendary",
    "Cuando come": "When it eats",
    "Cuando le da hambre": "When it gets hungry",
    "Cuando recibe un regalo": "When it gets a gift",
    "Cuando sube de etapa": "When it levels up",
    "Cuando te den regalos y likes, aquí salen sus cuidadores de siempre.": "Once you get gifts and likes, its regular caretakers show up here.",
    "Cuánta comida le dan": "How much food they give",
    "De la misma persona": "From the same person",
    "Ej: Chispita": "E.g. Sparky",
    "Evolución": "Evolution",
    "Experiencia total que necesita para llegar a cada etapa. Se guarda entre lives: tus viewers vuelven para verla crecer.": "Total XP it needs to reach each stage. It is saved between lives: your viewers come back to watch it grow.",
    "Le da hambre": "Gets hungry",
    "Los 3 que más la han cuidado": "The top 3 caretakers",
    "Mascota del live": "Live pet",
    "Mientras estás en vivo la comida baja poco a poco. Con hambre se pone triste.": "While you're live, food slowly goes down. When hungry it gets sad.",
    "Mostrar cuidadores": "Show caretakers",
    "Nadie la ha cuidado todavía": "Nobody has cared for it yet",
    "Nombre de la mascota": "Pet name",
    "Tengo hambre… ¡denme likes!": "I'm hungry… send likes!",
    "Tengo hambre… ¡dale likes!": "I'm hungry… send likes!",
    "Un regalo de 30 monedas da 30 XP": "A 30-coin gift gives 30 XP",
    "Una mascota que vive en tu stream y se guarda entre lives. Los regalos le dan experiencia y la hacen evolucionar (huevo → cría → joven → adulta → legendaria). Los likes la alimentan.": "A pet that lives on your stream and is saved between lives. Gifts give it XP and make it evolve (egg → baby → young → adult → legendary). Likes feed it.",
    "XP por compartir": "XP per share",
    "XP por follow": "XP per follow",
    "XP por moneda": "XP per coin",
    "mascota con barras e info": "pet with bars and info",
    "solo la mascota, para una esquina": "just the pet, for a corner",
    "¡Estoy llenito!": "I'm stuffed!",
    "Bosque": "Forest",
    "Comida": "Food",
    "Cuidados": "Care",
    "Darle de comer": "Feed it",
    "Mascota": "Pet",
    "Sus mejores cuidadores": "Top caretakers",
    "Feliz": "Happy",
    "Normal": "Normal",
    "Con hambre": "Hungry",
    "Volver a huevo": "Back to egg",
    "¿Volver la mascota a huevo? Se borra toda su experiencia y sus cuidadores.": "Turn the pet back into an egg? All its XP and caretakers will be erased.",
    "Fuego": "Fire",
    "Hielo": "Ice",
    "Galaxia": "Galaxy",
    "Tarjeta": "Card",
    "Flotante": "Floating",
    "Baja": "Drops",
    "💰 Comida": "💰 Food",
    'Nadie acertó': 'Nobody got it right',
    '10 juegos': '10 games', '11 juegos': '11 games', '12 juegos': '12 games',
    'No se puede deshacer.': "This can't be undone.",
    'Pega una pregunta por línea, así:\nPregunta | opción A | opción B | opción C | opción D | letra correcta\n\nEjemplo:\n¿Capital de Francia? | Roma | París | Madrid | Lisboa | B': 'Paste one question per line, like this:\nQuestion | option A | option B | option C | option D | correct letter\n\nExample:\nCapital of France? | Rome | Paris | Madrid | Lisbon | B', 'Herramientas → Ajustes del servidor WebSocket': 'Tools → WebSocket Server Settings', '"Habilitar servidor WebSocket"': '"Enable WebSocket server"',
    'Nadie ha sumado todavía': 'Nobody has scored yet', 'Inicia la batalla: los regalos de cada equipo suman solos.': 'Start the battle: each team\'s gifts add up by themselves.', 'No tienes preguntas propias. Agrega las tuyas o usa las de ejemplo. Marca el círculo de la opción correcta.': 'You don\'t have your own questions. Add yours or use the sample ones. Mark the circle of the correct option.', 'Nadie ha sumado tiempo todavía': 'Nobody has added time yet', 'Inicia el reloj: los regalos y follows suman solos.': 'Start the clock: gifts and follows add time by themselves.',
    'El live se divide en equipos. Cada equipo tiene su regalo y su comando del chat: quien más puntos junte antes de que acabe el tiempo, ¡gana!': 'The live splits into teams. Each team has its own gift and chat command: whoever scores the most before time runs out wins!', 'Un reloj que va bajando: cada regalo, follow o super fan le suma tiempo. Si llega a cero, ¡se acaba el live! El reloj se guarda solo aunque cierres ChispaLive.': 'A clock that counts down: every gift, follow or super fan adds time. If it hits zero, the live is over! The clock saves itself even if you close ChispaLive.', 'Cada animal tiene su regalo y su comando. Los regalos lo empujan hacia la meta (1 moneda = 1 metro). ¡Gana el primero que llega!': 'Each animal has its own gift and command. Gifts push it toward the finish line (1 coin = 1 meter). First one there wins!',
    'Guía rápida': 'Quick guide',
    '# preguntas': '# questions', 'preguntas': 'questions',
    'Gana la carrera': 'Wins the race', 'Un corredor cruza la meta': 'A runner crosses the finish line', 'Derrotan al jefe': 'The boss is defeated', 'La vida del jefe llega a cero': 'The boss health hits zero', 'Gana la trivia': 'Wins the trivia', 'Termina una partida de trivia': 'A trivia game ends', '¡Ganó el {equipo}!': '{equipo} wins!', '¡Derrotaron al jefe!': 'The boss was defeated!', '¡{usuario} ganó la trivia!': '{usuario} won the trivia!',
    'Carrera de animales': 'Animal race', '¡Corriendo!': 'Racing!', 'Reanudar': 'Resume', '¡Largada!': 'Go!', 'Largada': 'Go', '¿Reiniciar la carrera? Todos vuelven a la salida.': 'Reset the race? Everyone goes back to the start.', 'Los que más empujan': 'Top pushers', 'Nadie ha empujado todavía': 'Nobody has pushed yet', 'Dale a ¡Largada! y los regalos de cada animal lo hacen avanzar.': 'Hit Go! and each animal\'s gifts move it forward.', 'Corredores': 'Runners', 'Distancia de la meta': 'Finish line distance', 'Tiempo límite': 'Time limit', 'Cualquier regalo empuja': 'Any gift pushes', 'Si te uniste con el comando, todos tus regalos empujan a tu corredor': 'If you joined with the command, all your gifts push your runner', 'Los likes también empujan': 'Likes push too', 'Solo de los que ya están con un corredor': 'Only from people already on a runner', 'Nueva carrera sola después de': 'New race by itself after', 'Al empezar': 'On start', 'Empujón': 'Push', 'Cada vez que alguien empuja': 'Every time someone pushes', 'Cambio de líder': 'Lead change', 'Cuando alguien pasa adelante': 'When someone takes the lead', 'Recta final': 'Final stretch', 'Cuando un corredor llega al 80%': 'When a runner reaches 80%', 'Al cruzar la meta': 'On crossing the finish line', 'carriles de colores': 'colored lanes', 'hipódromo': 'racetrack', 'pasa adelante!': 'takes the lead!', '¡Recta final!': 'Final stretch!', '¡Carrera!': 'Race!', 'Carrera terminada': 'Race over', '¡Carrera de animales!': 'Animal race!', 'Caballo': 'Horse', 'Conejo': 'Rabbit', 'Tortuga': 'Turtle', 'Pato': 'Duck', 'Empujar en la Carrera': 'Push in the Race', 'Metros': 'Meters', 'Corriendo': 'Racing', 'Terminada': 'Over', 'Derrota al jefe': 'Defeat the boss', 'Un jefe con barra de vida: los regalos, likes y follows le hacen daño. Se enoja al 50% y al 25%. Si lo derrotan, aparece uno más fuerte.': 'A boss with a health bar: gifts, likes and follows damage it. It gets angry at 50% and 25%. If they defeat it, a stronger one appears.', '¡Derrotado!': 'Defeated!', 'Escapó': 'Escaped', '¡Que aparezca!': 'Spawn it!', 'Que aparezca': 'Spawn it', 'Siguiente nivel': 'Next level', '¿Reiniciar al jefe? Vuelve al nivel 1.': 'Reset the boss? It goes back to level 1.', '¿Reiniciar el jefe al nivel 1?': 'Reset the boss to level 1?', 'Los que más daño hacen': 'Top damage dealers', 'Nadie lo ha golpeado': 'Nobody has hit it', 'Haz que aparezca: cada moneda es 1 de daño.': 'Spawn it: each coin is 1 damage.', 'El jefe': 'The boss', 'Nombre del jefe': 'Boss name', 'Ej: Rey Gólem': 'E.g.: Golem King', 'Rey Gólem': 'Golem King', 'Imagen del jefe (PNG o GIF)': 'Boss image (PNG or GIF)', 'Si no subes nada, sale un monstruo de ChispaLive.': 'If you don\'t upload anything, a ChispaLive monster shows up.', 'Vida del nivel 1': 'Level 1 health', 'de vida': 'health', 'Cada nivel tiene': 'Each level has', 'Igual vida': 'Same health', 'El doble': 'Double', 'Se cura solo': 'Heals by itself', 'de vida por segundo': 'health per second', 'Tiempo para derrotarlo': 'Time to defeat it', 'Siguiente jefe aparece en': 'Next boss appears in', 'Daño': 'Damage', 'Cada moneda hace': 'Each coin does', '½ de daño': '½ damage', '1 de daño': '1 damage', '2 de daño': '2 damage', '5 de daño': '5 damage', 'Cada N likes hacen daño': 'Every N likes do damage', 'de daño': 'damage', 'Cada follow hace daño': 'Each follow does damage', 'Cada vez que comparten': 'Every time someone shares', 'Golpes críticos': 'Critical hits', 'A veces el golpe hace el doble de daño': 'Sometimes a hit does double damage', 'Cada golpe': 'Each hit', 'Crítico': 'Critical', 'Golpe x2': 'Hit x2', 'Se enoja': 'Gets angry', 'Al 50% y 25% de vida': 'At 50% and 25% health', 'Cuando lo vencen': 'When defeated', 'Cuando aparece un jefe': 'When a boss appears', 'grande al centro': 'big in the center', 'solo la vida, compacta': 'health only, compact', '¡El jefe está FURIOSO!': 'The boss is FURIOUS!', '¡El jefe se enojó!': 'The boss got angry!', '¡CRÍTICO!': 'CRITICAL!', 'Siguiente jefe en': 'Next boss in', '¡Ahí viene!': 'Here it comes!', '¡El jefe escapó!': 'The boss escaped!', 'Le quedaba': 'It had left', 'Golpe final:': 'Final blow:', 'Sin jefe': 'No boss', 'Se escapó': 'Escaped', 'Curar +500': 'Heal +500', 'Hacerle daño al jefe': 'Damage the boss', 'Trivia con el chat': 'Chat trivia', 'Sale una pregunta con 4 opciones y tus viewers responden escribiendo A, B, C o D en el chat. ¡El más rápido en acertar gana más puntos!': 'A question with 4 options shows up and your viewers answer by typing A, B, C or D in chat. The fastest correct answer gets more points!', 'Empezar trivia': 'Start trivia', 'Empezar de nuevo': 'Start over', 'De nuevo': 'Again', 'Empezar': 'Start', '¿Empezar de nuevo? Se borran los puntos.': 'Start over? Points are cleared.', 'Mostrar respuesta': 'Show answer', 'Siguiente pregunta': 'Next question', 'Terminar': 'End', '¿Reiniciar la trivia? Se borran los puntos.': 'Reset the trivia? Points are cleared.', '¿Terminar la trivia ahora?': 'End the trivia now?', '¿Terminar la carrera ahora?': 'End the race now?', 'Tabla de puntos': 'Scoreboard', 'Nadie ha acertado todavía': 'Nobody has got it right yet', 'Empieza la trivia: responden en el chat con A, B, C o D.': 'Start the trivia: they answer in chat with A, B, C or D.', 'Preguntas por partida': 'Questions per game', 'Tiempo para responder': 'Time to answer', 'Mostrar la respuesta durante': 'Show the answer for', 'Puntos por acertar': 'Points for a correct answer', 'Bonus por rapidez': 'Speed bonus', 'El que responde más rápido gana hasta el doble': 'The fastest answer gets up to double', 'Pasar sola a la siguiente': 'Go to the next one by itself', 'Si lo apagas, tú pasas cada pregunta': 'If you turn it off, you move each question', 'Preguntas en desorden': 'Shuffle questions', 'Cada partida sale un orden distinto': 'Each game has a different order', 'Preguntas': 'Questions', 'Usar las preguntas de ejemplo': 'Use the sample questions', '38 preguntas de cultura general, Perú, ciencia y gaming': '38 questions on general knowledge, Peru, science and gaming', 'Pregunta nueva': 'New question', 'Al salir cada pregunta': 'When each question shows', 'Alguien responde': 'Someone answers', 'Cada respuesta del chat': 'Each chat answer', 'Al mostrar la respuesta': 'When showing the answer', 'Al terminar la partida': 'When the game ends', 'pregunta y 4 opciones': 'question and 4 options', 'estilo programa de TV': 'TV show style', '¡Nadie acertó!': 'Nobody got it!', '¡Nadie acertó esta vez!': 'Nobody got it this time!', 'Responde en el chat:': 'Answer in chat:', 'respondieron': 'answered', 'acertaron': 'got it right', 'Sin empezar': 'Not started', 'Respuesta': 'Answer', 'Terminó': 'Over', 'Sin pregunta': 'No question', 'TUS PREGUNTAS': 'YOUR QUESTIONS', 'Agregar pregunta': 'Add question', 'Pegar varias': 'Paste many', 'Escribe la pregunta': 'Type the question', 'Respuesta correcta': 'Correct answer', 'Máximo 300 preguntas': 'Max 300 questions', 'Pregunta #/#': 'Question #/#', 'Nivel #': 'Level #', 'Opción A': 'Option A', 'Opción B': 'Option B', 'Opción C': 'Option C', 'Opción D': 'Option D',
    // ── Celular
    'Celular': 'Phone', 'Escanea con tu celular': 'Scan with your phone', 'Celulares conectados': 'Connected phones', '🔄 Cambiar código secreto': '🔄 Change secret code', '¿No abre en el celular?': 'Not opening on the phone?', 'Tu ChispaLive está protegido': 'Your ChispaLive is protected',
    // ── Ranking
    'Esta semana': 'This week', 'Este mes': 'This month', 'De siempre': 'All time', 'Este live': 'This live', 'Ganadores de la semana pasada': 'Last week winners', 'Lunes': 'Monday', 'Domingo': 'Sunday',
    // ── Resúmenes
    'Resúmenes': 'Summaries', 'Tus lives': 'Your lives', 'Top donadores': 'Top gifters', 'Regalos más enviados': 'Most sent gifts', 'Seguidores nuevos': 'New followers', 'Pico de espectadores': 'Peak viewers', 'Duración': 'Duration', 'Monedas': 'Coins', 'Comentarios': 'Comments', 'Compartidos': 'Shares', '📋 Copiar agradecimiento': '📋 Copy thank-you', '🖼 Descargar imagen': '🖼 Download image', '¡Gracias por este live!': 'Thanks for this live!', '¡Nos vemos en el próximo live! 🔥': 'See you next live! 🔥',
    // ── OBS
    'Controlar OBS': 'Control OBS', 'Escena, fuente, video, texto o clip': 'Scene, source, video, text or clip', 'Tus escenas': 'Your scenes', 'Activa el WebSocket en OBS': 'Turn on the WebSocket in OBS', 'Crea tus acciones': 'Create your actions', 'Qué hacer': 'What to do', 'Escena': 'Scene', 'Fuente': 'Source', 'Contraseña': 'Password', 'Puerto': 'Port', '🔄 Actualizar': '🔄 Refresh',
    // ── Subathon
    'Subathon': 'Subathon', 'Termina el subathon': 'Subathon ends', 'El reloj llega a cero': 'The clock hits zero', '⏸ En pausa': '⏸ Paused', 'sumados': 'added', '¡Se acabó el subathon! Gracias a todos 💖': 'The subathon is over! Thanks everyone 💖',
    // ── Batalla
    'Batalla de equipos': 'Team battle', '¡Empate!': 'Tie!', 'Batalla terminada': 'Battle over', ' o ': ' or ', 'Equipo Rojo': 'Red Team', 'Equipo Azul': 'Blue Team', 'Gana una batalla': 'A team wins the battle', 'Un equipo gana la Batalla': 'A team wins the Battle',
    // ── Roblox
    'Poder en Roblox': 'Roblox power', 'Activa algo en tu juego de Roblox': 'Triggers something in your Roblox game', 'Poder (comando)': 'Power (command)', 'Valor extra (opcional)': 'Extra value (optional)',
    'Pon el script en tu juego': 'Put the script in your game', 'Para tu juego publicado': 'For your published game', '¿Qué se manda al juego?': 'What is sent to the game?', 'Últimos envíos': 'Latest sends',
    '⬇ Descargar script para Roblox': '⬇ Download Roblox script', '▶ Probar conexión': '▶ Test connection', 'Universe ID del juego': 'Game Universe ID', 'API key de Open Cloud': 'Open Cloud API key', 'Canal (topic)': 'Channel (topic)',
    'Mandar todos los eventos del live': 'Send all live events', 'Encendido': 'On', 'Apagado': 'Off', 'Encender': 'Turn on', 'Roblox Studio conectado': 'Roblox Studio connected', 'Roblox Studio: sin conectar': 'Roblox Studio: not connected',
    '🎁 Regalos': '🎁 Gifts', '👍 Likes': '👍 Likes', '💗 Seguidores': '💗 Followers', '📣 Compartidos': '📣 Shares', '💬 Comentarios': '💬 Comments', '🚪 Entradas al live': '🚪 Live joins', '👑 Super fans': '👑 Super fans',
    // ── Licencia
    'Licencia': 'License', 'Licencia de ChispaLive': 'ChispaLive license', 'Juegos, widgets, voz y acciones para tu TikTok LIVE. Elige tu plan, paga como prefieras y activa en segundos.': 'Games, widgets, voice and actions for your TikTok LIVE. Pick a plan, pay your way and activate in seconds.',
    'Prueba gratis': 'Free trial', 'Código de este equipo': 'This computer code', 'Mensual': 'Monthly', 'Anual': 'Yearly', 'De por vida': 'Lifetime', 'MÁS POPULAR': 'MOST POPULAR', 'MEJOR VALOR': 'BEST VALUE',
    'Para probar en serio': 'To really try it', 'Ahorras más de la mitad': 'Save more than half', 'Tuyo para siempre + todas las actualizaciones': 'Yours forever + all updates', 'un solo pago': 'one-time',
    '¿Cómo quieres pagar?': 'How do you want to pay?', 'Tarjeta / PayPal': 'Card / PayPal', 'Automático': 'Automatic', 'Activar mi clave': 'Activate my key', 'Activar': 'Activate',
    'La clave queda atada a esta computadora.': 'The key is tied to this computer.', '💎 Comprar licencia': '💎 Buy license', 'Eres el dueño': 'You are the owner', 'Tu plan venció': 'Your plan expired', 'Tu prueba gratis terminó': 'Your free trial ended',
    '📲 Enviar comprobante por WhatsApp': '📲 Send receipt via WhatsApp', '⏳ Este método estará disponible muy pronto. Mientras tanto usa otro.': '⏳ This method is coming very soon. Please use another one for now.',
    'Clave no válida': 'Invalid key', 'Esta clave es de otra computadora': 'This key belongs to another computer', 'Esa clave no tiene el formato de ChispaLive': 'That is not a ChispaLive key', '✅ ¡ChispaLive activado!': '✅ ChispaLive activated!',
    // ── Meta de corazón
    '💖 Se queda lleno (100%)': '💖 Keep visible (stay at 100%)', '📈 Sube la meta': '📈 Increase the target', '🎉 Celebra y se oculta': '🎉 Celebrate + hide', '¿Cómo sube la meta?': 'How does the goal go up?',
    'Tus metas': 'Your goals', 'cada una con su regalo, su meta, su diseño y su link': 'each with its own gift, target, design and link', 'Nueva meta…': 'New goal…', 'Meta principal': 'Main goal', 'principal': 'main',
    'Acción al cumplir la meta': 'Goal action', 'apagada en la lista': 'off in the list', '⚡ Ir a Acciones y eventos': '⚡ Go to Actions & events',
    'Necesitas al menos una meta': 'You need at least one goal', 'Máximo 10 metas': 'Max 10 goals', '💖 Meta creada: ya tiene su propio link para OBS': '💖 Goal created: it has its own OBS link',
    'Meta de corazón': 'Heart goal', 'Un corazón con carita que se llena con el regalo que elijas (por ejemplo Heart Me). Al llenarse celebra, se pone su corona y la meta puede subir sola.': 'A cute heart that fills with the gift you choose (e.g. Heart Me). When full it celebrates, puts on its crown and the goal can go up by itself.',
    'Llenándose': 'Filling', '¡Meta cumplida!': 'Goal reached!', '¡META CUMPLIDA!': 'GOAL REACHED!', '▶ Probar regalo': '▶ Test gift', '↺ Poner en 0': '↺ Set to 0',
    '💖 Regalo que llena el corazón': '💖 Gift that fills the heart', 'Cuántos regalos (o monedas) llenan el corazón': 'How many gifts (or coins) fill the heart',
    'Cuando se llena': 'When it fills', '💖 Se queda lleno': '💖 Stays full', '🔄 Vuelve a 0': '🔄 Back to 0', '🙈 Se oculta': '🙈 Hides',
    'Esperar antes de volver a 0': 'Wait before going back to 0', 'Después de la celebración': 'After the celebration',
    'Subir la meta sola': 'Auto-raise the goal', 'Al llenarse, la meta sube y el corazón sigue llenándose': 'When full, the goal goes up and the heart keeps filling',
    '¿Cómo sube?': 'How does it go up?', '➕ Sumar (100 → 200 → 300)': '➕ Add (100 → 200 → 300)', '✖️ Multiplicar': '✖️ Multiply', 'Multiplicar por': 'Multiply by', 'Ej. 1.5: 100 → 150 → 225': 'E.g. 1.5: 100 → 150 → 225',
    'Al cumplirla': 'When reached', 'Duración de la celebración': 'Celebration length', 'Corona, estrellas y confeti': 'Crown, stars and confetti',
    'Ocultar el cartel "¡Meta cumplida!"': 'Hide the "Goal reached!" banner', 'Solo celebra, sin el texto': 'Just celebrates, no text',
    'Ocultar el corazón después de': 'Hide the heart after', 'Solo cuando se queda lleno': 'Only when it stays full', 'Nunca': 'Never',
    'Título arriba del corazón': 'Title above the heart', 'Usa el texto de "Título en pantalla" (pestaña Diseño)': 'Uses the "On-screen title" text (Design tab)',
    'Contador debajo': 'Counter below', 'La pastilla con 37 / 100': 'The pill with 37 / 100', 'Si lo apagas, muestra el %': 'If off, shows the %',
    'Mostrar a quien regala': 'Show who gifts', 'El nombre aparece un momento en el contador': 'Their name flashes on the counter', 'Cuánto tiempo': 'How long', 'Texto antes del nombre': 'Text before the name', '¡Gracias!': 'Thanks!',
    'Entre lives': 'Between lives', 'Reiniciar en cada live nuevo': 'Reset on each new live', 'Si lo apagas, el progreso sigue de un live a otro (se guarda aunque cierres el programa)': 'If off, progress carries over between lives (saved even if you close the app)',
    'Ocultar el corazón': 'Hide the heart', 'Lo esconde del stream sin borrar el progreso': 'Hides it from the stream without losing progress',
    'Cada regalo': 'Each gift', 'Cuando suma al corazón': 'When it adds to the heart', 'Al llenarse': 'When full', 'Corazón lleno': 'Heart full', 'Se cumple la Meta de corazón': 'The heart goal is reached', '💖 Sumar al corazón': '💖 Add to the heart',
    '❤️ Clásico': '❤️ Classic', '🔥 Fuego': '🔥 Fire', '👑 Dorado': '👑 Golden', '🌊 Océano': '🌊 Ocean', '🧊 Hielo': '🧊 Ice', '💚 Esmeralda': '💚 Emerald', '💜 Neón': '💜 Neon', '🌌 Galaxia': '🌌 Galaxy', '🖤 Oscuro': '🖤 Dark', '⚫ Negro': '⚫ Black',
    // ── General / navegación
    'Dashboard': 'Dashboard', 'Juegos': 'Games', 'Widgets': 'Widgets', 'Automatización': 'Automation', 'Ajustes': 'Settings',
    'Simulador': 'Simulator', 'Tu marca': 'Your brand', 'Mi estilo': 'My style', 'Inicio': 'Home', 'Live': 'Live', 'Juego': 'Game',
    'Tus juegos y widgets': 'Your games & widgets', 'Panel del streamer': 'Streamer panel', 'Estadísticas': 'Stats', 'Estadísticas en vivo': 'Live stats',
    'Eventos en vivo': 'Live events', 'Chat en vivo': 'Live chat', 'Interacciones': 'Interactions', 'Pruebas': 'Tests', 'Historial': 'History',
    'Guardar': 'Save', 'Guardado': 'Saved', 'Cancelar': 'Cancel', 'Cerrar': 'Close', 'Editar': 'Edit', 'Borrar': 'Delete', 'Eliminar': 'Remove',
    'Quitar': 'Remove', 'Agregar': 'Add', 'Duplicar': 'Duplicate', 'Copiar': 'Copy', 'Descargar': 'Download', 'Importar': 'Import',
    'Importar / Exportar': 'Import / Export', 'Cambiar': 'Change', 'Ver': 'View', 'Mostrar': 'Show', 'Limpiar': 'Clear', 'Reiniciar': 'Reset',
    'Restablecer todo': 'Reset everything', 'Borrar todo': 'Delete all', 'Siguiente': 'Next', 'Atrás': 'Back', 'Enviar': 'Send', 'Probar': 'Test',
    'Iniciar': 'Start', '¡Empezar!': 'Start!', 'Pausar': 'Pause', 'Escuchar': 'Listen', 'Personalizar': 'Customize', 'Vista previa': 'Preview',
    'Detalles': 'Details', 'Avanzado': 'Advanced', 'Principal': 'Main', 'Secundario': 'Secondary', 'Todos': 'All', 'todos': 'all', 'Ninguno': 'None',
    'Cualquiera': 'Anyone', 'Especial': 'Special', 'Especiales': 'Special', 'Activa': 'On', 'Activo': 'Active', 'Apagada': 'Off', 'Apagado': 'Off',
    'Encendido': 'On', 'SÍ': 'YES', 'NO': 'NO', 'NUEVO': 'NEW', 'MÁS': 'MORE', 'ahora': 'now', 'y': 'and', 'o': 'or', 'cada': 'every', 'vale': 'is worth',
    'o más': 'or more', 'monedas o más': 'coins or more', 'Desde': 'From', 'Mínimo': 'Minimum', 'Igual': 'Equal', 'Al azar': 'Random', 'Aleatorio': 'Random',
    'Nombre': 'Name', 'Texto': 'Text', 'Imagen': 'Image', 'Color': 'Color', 'Tamaño': 'Size', 'Tamaño (%)': 'Size (%)', 'Formato': 'Format',
    'Duración': 'Duration', 'Duración (s)': 'Duration (s)', 'Velocidad': 'Speed', 'Volumen': 'Volume', 'Volumen (%)': 'Volume (%)', 'Tono': 'Pitch',
    'Modo': 'Mode', 'Modos': 'Modes', 'Tipos': 'Types', 'Diseño': 'Design', 'Efecto': 'Effect', 'Animación': 'Animation', 'Letras': 'Fonts',
    'Lista': 'List', 'Barra': 'Bar', 'Barras': 'Bars', 'Tarjeta': 'Card', 'tarjetas': 'cards', 'Banner': 'Banner', 'Zoom': 'Zoom', 'Deslizar': 'Slide',
    'Rebote': 'Bounce', 'Caída': 'Drop', 'Giro': 'Spin', 'Pop': 'Pop', 'Glitch': 'Glitch', 'Flash': 'Flash', 'Temblor': 'Shake', 'Explosión': 'Explosion',
    'Cantidad': 'Amount', 'Cantidad (racha)': 'Amount (streak)', 'Veces': 'Times', 'Segundos': 'Seconds', 'segundos': 'seconds', 'seg': 'sec', 's': 's', 'm': 'm', 'h': 'h',
    'Posición y tamaño': 'Position & size', 'Mover horizontal': 'Move horizontally', 'Mover vertical': 'Move vertically', 'Zona segura': 'Safe zone',
    'Aún no hay datos': 'No data yet', 'Sin resultados todavía': 'No results yet', 'Sin historial todavía': 'No history yet', 'Esperando': 'Waiting',
    'En progreso': 'In progress', 'Resultado': 'Result', 'Ganador': 'Winner', 'Victoria': 'Victory', 'Premio': 'Prize', 'Puntos': 'Points', 'Peso': 'Weight',
    'Probabilidad': 'Chance', 'Porcentajes': 'Percentages', 'Nivel': 'Level', 'NIVEL #': 'LEVEL #', 'Meta': 'Goal', 'Metas': 'Goals',
    'Moneda': 'Coin', 'Monedas': 'Coins', 'monedas': 'coins', 'Likes': 'Likes', 'Seguidores': 'Followers', 'Seguidor': 'Follower', 'Compartidos': 'Shares',
    'Compartido': 'Share', 'Compartir': 'Share', 'Espectadores': 'Viewers', 'Regalo': 'Gift', 'Regalos': 'Gifts', 'Chat': 'Chat', 'Comentario': 'Comment',
    'Mensaje': 'Message', 'mensaje': 'message', 'Jugadores': 'Players', 'jugadores': 'players', 'Pantalla': 'Screen', 'Pantalla #': 'Screen #',
    'Tecla': 'Key', 'Teclas': 'Keys', 'Comando': 'Command', 'Prefijo': 'Prefix', 'Enlace': 'Link', 'URL': 'URL', 'Método': 'Method', 'Idioma': 'Language',
    'Ruleta': 'Wheel', 'Rueda': 'Wheel', 'Ruedas': 'Wheels', 'Rueda Nº': 'Wheel #', 'Porción': 'Slice', 'Porciones': 'Slices', 'Frasco': 'Jar', 'Cofre': 'Chest',
    'Dado': 'Dice', 'Puja': 'Bid', 'Pujas': 'Bids', 'Top': 'Top', 'Podio': 'Podium', 'Pirámide': 'Pyramid', 'Hexágono': 'Hexagon', 'Cuadrícula': 'Grid',
    'Cuadros': 'Tiles', 'Radial': 'Radial', 'Corazón': 'Heart', 'Ruleta de acciones': 'Action wheel', 'Ruleta de retos': 'Dare wheel',
    'Frasco de regalos': 'Gift jar', 'Meta de likes': 'Like goal', 'Meta de monedas': 'Coin goal', 'Top del live': 'Live top', 'Subasta en vivo': 'Live auction',
    'Subasta': 'Auction', 'Alertas': 'Alerts', 'Alerta': 'Alert', 'Chat en pantalla': 'On-screen chat', 'Rankings': 'Rankings', 'Spin Royale': 'Spin Royale',
    'Lucky Roll': 'Lucky Roll', 'Lucky Roll / cofre': 'Lucky Roll / chest', 'Cofre de premios': 'Prize chest', 'Cofre del tesoro': 'Treasure chest',
    'Acciones': 'Actions', 'Voz': 'Voice', 'VOZ': 'VOICE', 'Voz (TTS)': 'Voice (TTS)', 'Voz del chat': 'Chat voice', 'Acciones y eventos': 'Actions & events',
    'Conectar': 'Connect', 'Desconectado': 'Disconnected', 'Sin conectar': 'Not connected', 'OFFLINE': 'OFFLINE', 'Copiar link para OBS': 'Copy OBS link',
    'Abrir overlay': 'Open overlay', 'Links para OBS': 'OBS links', 'Links para OBS / TikTok LIVE Studio': 'Links for OBS / TikTok LIVE Studio',
    'Fuente de navegador': 'Browser source', 'OBS / LIVE Studio': 'OBS / LIVE Studio', '(OBS) o': '(OBS) or', 'Tu canal': 'Your channel',
    'Ej. # / #': 'E.g. # / #', 'Ej: Esnupi el Oso': 'E.g. Esnupi the Bear', 'Ej: Subasta de Esnupi': 'E.g. Esnupi\'s auction', 'Ej: Elegir mi próximo skin': 'E.g. Pick my next skin',
    'Ej. Rosa = sonido + GIF': 'E.g. Rose = sound + GIF', 'Ej. !baile o "hola"': 'E.g. !dance or "hello"', 'tu_usuario_de_tiktok': 'your_tiktok_username',

    // ── Conexión (dashboard)
    'Conecta tu live': 'Connect your live', 'SIN CONECTAR · LISTO CUANDO TÚ LO ESTÉS': 'NOT CONNECTED · READY WHEN YOU ARE',
    '¡Hola! ¿Listo para tu live?': 'Hi! Ready for your live?', '¡Conecta y que empiece la fiesta!': 'Connect and let the party start!',
    '¡Vamos por esos regalos!': 'Let\'s go get those gifts!', 'Abre tu LIVE en TikTok o LIVE Studio': 'Open your LIVE on TikTok or LIVE Studio',
    'Escribe tu @ y dale a Conectar': 'Type your @ and hit Connect', 'Escribe tu @ aquí arriba': 'Type your @ up here',
    'Tu centro de mando se enciende en cuanto te conectas: juegos, alertas, voz y acciones reaccionan a tus viewers.': 'Your command center lights up as soon as you connect: games, alerts, voice and actions react to your viewers.',
    'Nunca publicamos nada en tu nombre.': 'We never post anything on your behalf.', 'Prueba el Simulador.': 'Try the Simulator.',
    'Conecta tu cuenta cuando estés en vivo. Si no, prueba todo en el Simulador.': 'Connect your account when you are live. If not, try everything in the Simulator.',
    'Sin conectar · conéctate en el Dashboard': 'Not connected · connect from the Dashboard', 'Probar sin estar en vivo': 'Test without being live',
    'Ajustes de conexión': 'Connection settings', 'Conexión avanzada': 'Advanced connection', 'Clave de Euler Stream (opcional)': 'Euler Stream key (optional)',
    'La conexión al LIVE usa un servidor de firmas (Euler Stream). Sin clave funciona con límites; si se cae seguido, crea una clave gratis en eulerstream.com y pégala aquí.': 'The LIVE connection uses a signing server (Euler Stream). Without a key it works with limits; if it drops often, create a free key at eulerstream.com and paste it here.',
    'Aquí verás regalos, comentarios y follows en tiempo real': 'Gifts, comments and follows show up here in real time', 'Regalaron hoy': 'Gifted today',
    'Top donadores ahora': 'Top gifters now', 'Top donadores': 'Top gifters', 'Top donador': 'Top gifter', 'Top likes': 'Top likes', 'Top compartidos': 'Top shares',
    'Reiniciar estadísticas': 'Reset stats', 'Todavía no hay regalos.': 'No gifts yet.', 'Aparecen cuando lleguen regalos.': 'They show up when gifts arrive.',
    'Nombre del canal': 'Channel name', 'Usuario (@handle)': 'Username (@handle)',

    // ── Marca / estilo
    'El estilo general de todos tus overlays: logo, colores, letras y animaciones. Cada juego puede cambiar su propio diseño, imagen y animación en su estudio.': 'The general style of all your overlays: logo, colors, fonts and animations. Each game can change its own design, image and animation in its studio.',
    'Mi logo': 'My logo', 'Sube tu logo o foto': 'Upload your logo or photo', 'Haz clic o arrastra una imagen (PNG, JPG, GIF). Aparece en los overlays y en el centro de las ruletas.': 'Click or drag an image (PNG, JPG, GIF). It shows in the overlays and in the center of the wheels.',
    'Haz clic o arrastra una imagen.': 'Click or drag an image.', 'Mostrar logo y nombre en los overlays': 'Show logo and name in overlays', 'Logo en el centro de las ruletas': 'Logo in the center of the wheels',
    'Tema de colores': 'Color theme', 'O elige tus propios colores': 'Or pick your own colors', 'Colores propios': 'Custom colors', 'Brillo (glow)': 'Glow',
    'Brillo y efectos': 'Glow & effects', 'Brillo y pulso': 'Glow & pulse', 'Opacidad del fondo': 'Background opacity', 'Esquinas redondeadas': 'Rounded corners',
    'Tamaño de overlays': 'Overlay size', 'Tamaño del texto': 'Text size', 'Tamaño de letra': 'Font size', 'Animación de entrada': 'Entry animation',
    'Confeti en momentos épicos': 'Confetti on epic moments', 'Volumen de efectos': 'Effects volume', 'Estilo del overlay': 'Overlay style',
    'Chispa Neón': 'Neon Spark', 'Cyber Azul': 'Cyber Blue', 'Oro Real': 'Royal Gold', 'Rosa Kawaii': 'Kawaii Pink', 'Galaxia': 'Galaxy', 'Tóxico': 'Toxic',
    'Océano': 'Ocean', 'Oro': 'Gold', 'Chicle': 'Bubblegum', 'Uva': 'Grape', 'Aurora': 'Aurora', 'Carbón': 'Coal', 'Lima': 'Lime', 'Menta': 'Mint', 'Rubí': 'Ruby',
    'Hielo': 'Ice', 'Fuego': 'Fire', 'Noche': 'Night', 'Pastel': 'Pastel', 'Madera': 'Wood', 'Rayas': 'Stripes', 'Burbujas': 'Bubbles', 'Láser': 'Laser',
    'Magia': 'Magic', 'Misterio': 'Mystery', 'Terror': 'Horror', 'Neón': 'Neon', 'Cristal': 'Crystal', 'Vidrio': 'Glass', 'Caldero': 'Cauldron', 'Pecera': 'Fishbowl',
    'Claro': 'Light', 'Oscuro': 'Dark', 'Limpia': 'Clean', 'Moderna': 'Modern', 'Clásica': 'Classic', 'clásica': 'classic', 'Compacta': 'Compact', 'Deportiva': 'Sporty',
    'Cómic': 'Comic', 'Cartoon': 'Cartoon', 'Gamer': 'Gamer', 'Minimal': 'Minimal', 'Pixel': 'Pixel', 'Radar': 'Radar', 'Redondita': 'Round', 'Arena': 'Arena',
    'Brainrot': 'Brainrot', 'Vitrina': 'Showcase', 'Cinta': 'Reel', 'Tragamonedas': 'Slot machine',

    // ── Idioma
    'Cambia el idioma del panel y de los textos que ven tus viewers en los overlays.': 'Changes the language of the panel and the texts your viewers see in the overlays.',
    'Panel y overlays en español': 'Panel and overlays in Spanish', 'Panel and overlays in English': 'Panel and overlays in English',

    // ── Estudio de juegos (común)
    'Imagen del juego': 'Game image', 'Título en pantalla': 'On-screen title', 'Tipo de juego': 'Game type', 'Modo de vista': 'View mode', 'Tipo de partida': 'Match type',
    'Sonidos': 'Sounds', 'Sonido': 'Sound', 'EFECTOS DE SONIDO': 'SOUND EFFECTS', 'Sonidos activados': 'Sounds on', 'Volumen de este juego': 'This game\'s volume',
    'Apaga todos los sonidos de este juego de una vez': 'Turn off all of this game\'s sounds at once', 'Niveles de sonido: regalos más grandes, sonido más grande.': 'Sound tiers: bigger gifts, bigger sound.',
    'Subir MP# / WAV': 'Upload MP# / WAV', 'Subir mi sonido…': 'Upload my sound…', 'Elige qué lo activa': 'Choose what triggers it', 'De la lista o tu MP#': 'From the list or your MP#',
    'Confeti': 'Confetti', 'Lluvia de confeti': 'Confetti rain', 'La pantalla tiembla': 'The screen shakes', 'La pantalla tiembla en eliminaciones y evoluciones': 'The screen shakes on eliminations and evolutions',
    'Bordes de luz y latido en momentos épicos': 'Light borders and pulse on epic moments', 'Destello de luz': 'Light flash', 'Confeti y rayos desde': 'Confetti and rays from',
    'Si lo apagas, este juego ignora los regalos y comandos del live': 'If you turn it off, this game ignores the live\'s gifts and commands',
    'Los regalos cuentan en este juego': 'Gifts count in this game', 'Usa colores distintos a "Mi estilo" solo en este juego': 'Use colors different from "My style" only in this game',
    'el de "Mi estilo"': 'the one from "My style"', 'Se muestra en el overlay. Sube un PNG o GIF para que se vea único.': 'Shown in the overlay. Upload a PNG or GIF to make it unique.',
    'Subir PNG o GIF': 'Upload PNG or GIF', 'Subir GIF / imagen': 'Upload GIF / image', 'GIF o imagen': 'GIF or image', 'Imagen o GIF propio': 'Your own image or GIF',
    'Se puede usar como ícono del centro.': 'Can be used as the center icon.', 'Restablecido ✓': 'Reset ✓', 'Ya está todo por defecto': 'Everything is already default',
    'PRESETS': 'PRESETS', 'Nuevo preset': 'New preset', 'Guarda configuraciones para cambiar rápido entre ellas.': 'Save setups to switch between them quickly.',
    'Aquí aparecen los ganadores y premios de este juego.': 'This game\'s winners and prizes show up here.', 'RESULTADOS RECIENTES': 'RECENT RESULTS',
    'Buscar ajuste…': 'Search setting…', 'Ningún ajuste coincide': 'No setting matches', 'Tip: escribe para buscar y presiona Enter.': 'Tip: type to search and press Enter.',
    'Buscar acciones, regalos, eventos…': 'Search actions, gifts, events…', 'Buscar regalo…': 'Search gift…', 'Buscar usuarios…': 'Search users…',
    'Toca un regalo para elegirlo': 'Tap a gift to choose it', 'Elegir regalo mínimo': 'Choose minimum gift', 'regalo mínimo': 'minimum gift', 'Cualquier regalo': 'Any gift',
    'Regalo específico': 'Specific gift', 'Un regalo que tú eliges': 'A gift you choose', 'Valor del regalo': 'Gift value', 'Usar el valor de un regalo': 'Use a gift\'s value',
    'Monedas mínimas del regalo': 'Minimum gift coins', 'Desde (monedas)': 'From (coins)', 'Desde X monedas': 'From X coins', 'Traer regalos de TikTok': 'Fetch TikTok gifts',
    'Usando íconos de respaldo. Trae las imágenes oficiales': 'Using backup icons. Fetch the official images', 'Buscando regalos de TikTok…': 'Looking for TikTok gifts…',
    'Cualquier regalo cuenta. Toca uno para fijarlo como': 'Any gift counts. Tap one to set it as', 'Cuentan los de borde verde.': 'The ones with a green border count.',
    'elegidos. Toca para agregar o quitar.': 'selected. Tap to add or remove.', 'Regalos que cuentan': 'Gifts that count', 'Configura cuáles en "Regalos que cuentan"': 'Set which ones in "Gifts that count"',
    'Acumular regalos': 'Stack gifts', 'Los regalos pequeños se suman hasta llegar al mínimo': 'Small gifts add up until they reach the minimum',
    'Repetir por cada regalo de la racha (máx. #)': 'Repeat for each gift in the streak (max. #)', 'se suman': 'add up',
    '¿Cómo entra la gente? Combina regalo, comando, likes, follow o compartir. Los regalos además suman monedas al jugador.': 'How do people join? Combine gift, command, likes, follow or share. Gifts also add coins to the player.',
    'Escriben un comando para entrar': 'They type a command to join', 'Comando del chat': 'Chat command', 'Comando en el chat': 'Chat command', 'Con comando': 'With command',
    'Dar likes cuenta para entrar': 'Giving likes counts to join', 'Los nuevos seguidores entran solos': 'New followers join automatically', 'Quien comparte entra': 'Whoever shares joins',
    'Cada N likes de un viewer': 'Every N likes from a viewer', 'Cada cuántos likes de un mismo viewer': 'How many likes from the same viewer', 'likes = # giro': 'likes = # spin',
    'likes = puntos': 'likes = points', 'Espera por viewer (segundos)': 'Cooldown per viewer (seconds)', 'Espera entre comandos del mismo viewer': 'Wait between commands from the same viewer',
    's por viewer': 's per viewer', 'Para gente que participa fuera de TikTok (o por otra cosa que no sea regalo).': 'For people who join outside TikTok (or for something other than a gift).',
    'Útil para donaciones por fuera (Yape, PayPal…).': 'Useful for outside donations (Yape, PayPal…).', 'Agregar a mano': 'Add manually', 'Ajustar a mano': 'Adjust manually',
    'suma o resta al progreso': 'adds to or subtracts from progress', 'Evoluciones': 'Evolutions', 'Subir de nivel': 'Level up', 'Agregar nivel': 'Add level', 'Quitar nivel': 'Remove level',
    'Nombre del nivel': 'Level name', 'Imagen o GIF del nivel': 'Level image or GIF', 'Sale en el banner de evolución': 'Shows in the evolution banner',
    'El frasco evoluciona: al llegar a X monedas cambia de diseño (por ejemplo, de vidrio a cofre) con banner, sonido y efecto.': 'The jar evolves: when it reaches X coins it changes design (for example, from glass to chest) with a banner, sound and effect.',
    'El frasco se convierte en': 'The jar turns into', '¡{usuario} evolucionó!': '{usuario} evolved!', 'Mover un juego': 'Move a game', 'Mostrar números': 'Show numbers',
    'Tamaño de la imagen': 'Image size', 'Tamaño del ícono': 'Icon size', 'Fotos de perfil': 'Profile pictures', 'Foto del viewer': 'Viewer photo', 'Ícono del centro': 'Center icon',
    'Fondo de la casilla': 'Tile background', 'Mostrar regalos': 'Show gifts', 'Mensajes visibles': 'Visible messages', 'Ocultar comandos': 'Hide commands',

    // ── Subasta
    'Inicia la subasta. Los viewers pujan con regalos o puedes agregarlos a mano.': 'Start the auction. Viewers bid with gifts, or you can add them manually.',
    'Los viewers pujan con regalos (o como tú elijas). Gana quien más acumule antes de que acabe el tiempo.': 'Viewers bid with gifts (or however you choose). Whoever stacks the most before time runs out wins.',
    '¿Qué se subasta?': 'What is being auctioned?', '¿Con qué se puja? Activa varias formas: regalos, comando en el chat, likes, follows o shares.': 'What do people bid with? Turn on several ways: gifts, chat command, likes, follows or shares.',
    'Agregar puja a mano': 'Add bid manually', 'Todavía no hay pujas': 'No bids yet', 'Puja mínima': 'Minimum bid', 'Insignia de puja mínima': 'Minimum bid badge',
    'Muestra la puja mínima en el overlay': 'Shows the minimum bid in the overlay', 'Muestra el comando para pujar': 'Shows the bid command', 'Pujadores en pantalla': 'Bidders on screen',
    'Pujadores y monedas totales': 'Bidders and total coins', 'El % de cada pujador': 'Each bidder\'s %', 'Suena con cada puja': 'Plays with each bid', 'Sumar tiempo a la subasta': 'Add time to the auction',
    'Cuando se suma tiempo': 'When time is added', 'Al terminar la subasta': 'When the auction ends', 'Nuevo líder': 'New leader', 'Anti-sniper': 'Anti-sniper',
    'Anti-sniper: si quedan menos de': 'Anti-sniper: if less than', 'Evita que alguien gane en el último segundo.': 'Stops someone from winning in the last second.',
    'Victoria instantánea': 'Instant win', 'Un solo regalo de este valor gana al momento': 'A single gift of this value wins instantly', 'Si alguien llega a esta cantidad gana al momento.': 'If someone reaches this amount they win instantly.',
    'Ganador directo': 'Instant winner', 'Terminar ya': 'End now', 'Cuenta regresiva': 'Countdown', 'Tiempos': 'Timing', 'Live Auction': 'Live Auction', 'Premio sorpresa': 'Mystery prize',
    'Puestos': 'Places', 'Puestos en pantalla': 'Places on screen', 'el que más regala arriba': 'top gifter on top', 'top # con corona': 'top # with crown', 'top # en escalones': 'top # on steps',
    'ranking con %': 'ranking with %', 'una sola línea': 'single line', 'barra arriba': 'bar on top', 'Menor precio': 'Lowest price',

    // ── Spin Royale
    'Los viewers entran por regalo, chat, likes o follow. La ruleta elimina por rondas (o elige al ganador de un giro).': 'Viewers join by gift, chat, likes or follow. The wheel eliminates by rounds (or picks the winner in one spin).',
    'Abre las inscripciones. Entran con un regalo o con el comando del chat.': 'Open sign-ups. They join with a gift or with the chat command.', 'Abrir inscripciones': 'Open sign-ups',
    'Agregar jugador a mano': 'Add player manually', 'Aún no hay jugadores': 'No players yet', 'Lista de jugadores': 'Player list', 'Meter en Spin Royale': 'Add to Spin Royale',
    'Tiempo para unirse': 'Time to join', 'El tiempo de inscripción arranca cuando se juntan N jugadores': 'The sign-up timer starts when N players have joined',
    'Mínimo de participantes': 'Minimum players', 'Máximo de jugadores': 'Maximum players', 'Al llenarse, aparece LLENO y los nuevos no entran': 'When full, FULL appears and new people can\'t join',
    'Inscripción bloqueada': 'Sign-ups locked', 'Congela la lista al empezar: nadie nuevo entra durante el juego': 'Freezes the list on start: nobody new joins during the game',
    'Empieza solo cuando se acaba el tiempo de inscripción': 'Starts on its own when sign-up time runs out', 'Eliminación': 'Elimination', 'uno sale por ronda': 'one out per round',
    'un giro y listo': 'one spin and done', 'Eliminaciones masivas': 'Mass eliminations', 'Saca a varios por ronda hasta que queden pocos': 'Removes several per round until few are left',
    'Hasta que queden': 'Until there are', 'Cada cuánto gira la ruleta en eliminación': 'How often the wheel spins in elimination', 'Tiempo entre giros': 'Time between spins',
    'Pausa entre giros': 'Pause between spins', 'Duración del giro': 'Spin duration', 'Velocidad del giro': 'Spin speed', 'Ventaja por monedas': 'Coin advantage',
    'Más monedas = porción más grande para ganar (o más chica para salir eliminado)': 'More coins = bigger slice to win (or smaller to get eliminated)',
    'Entradas múltiples': 'Multiple entries', 'Más monedas = más casillas. Cada "puja mínima" de monedas es una casilla': 'More coins = more tiles. Each "minimum bid" of coins is one tile',
    'Máx. casillas por jugador': 'Max. tiles per player', 'Duelo': 'Duel', 'Banner de duelo # vs #': 'Duel banner # vs #', 'Un cara a cara cuando quedan dos': 'A face-off when two are left',
    'Cuando quedan dos': 'When two are left', 'Al coronar al ganador': 'When the winner is crowned', 'Oof (eliminado)': 'Oof (eliminated)', 'Monedas del ganador': 'Winner\'s coins',
    'Muestra sus monedas en la pantalla final': 'Shows their coins on the final screen', 'Fichas de jugadores debajo de la ruleta': 'Player chips under the wheel',
    'Jugadores, vivos y monedas': 'Players, alive and coins', 'personajes + temporizador': 'characters + timer', 'Cuando alguien entra o suma monedas': 'When someone joins or adds coins',
    'Cuando alguien sale': 'When someone is out', 'Tic mientras gira': 'Tick while spinning', 'Tic de la ruleta': 'Wheel tick', 'Tic': 'Tick', 'unirme': 'join', 'ronda': 'round',

    // ── Ruleta de acciones
    'Crea varias ruedas. Cada una se activa con su propio regalo o comando y cada porción puede lanzar una acción: sonido, voz o mensaje.': 'Create several wheels. Each one is triggered by its own gift or command, and each slice can fire an action: sound, voice or message.',
    'Nueva rueda': 'New wheel', 'Activar o apagar esta rueda': 'Turn this wheel on or off', '¿Qué la activa?': 'What triggers it?', 'Cuando alguien activa la rueda': 'When someone triggers the wheel',
    'Cualquier regalo gira esta rueda.': 'Any gift spins this wheel.', 'Cada nuevo seguidor gira esta rueda.': 'Each new follower spins this wheel.', 'Cada vez que compartan el live gira esta rueda.': 'Every time the live is shared this wheel spins.',
    'Girar ahora': 'Spin now', 'Girar ya': 'Spin now', 'Girar la ruleta': 'Spin the wheel', 'Girar rueda #': 'Spin wheel #', 'Auto-girar': 'Auto-spin',
    'Texto de la porción': 'Slice text', 'Imagen de la porción': 'Slice image', 'Igualar %': 'Even out %', 'Mínimo 2 porciones': 'Minimum 2 slices', 'Mínimo 2 opciones': 'Minimum 2 options',
    'Sin acción': 'No action', 'Cuando sale la porción (si no tiene sonido propio)': 'When the slice lands (if it has no sound of its own)', 'Anuncio': 'Announcement',
    'Anuncio antes de girar': 'Announcement before spinning', 'Cuántas vueltas da antes de parar': 'How many turns before it stops', 'Vueltas': 'Turns', 'Tamaño de la ruleta': 'Wheel size',
    'Mostrar base': 'Show base', 'La ruleta aparece sobre un pedestal': 'The wheel sits on a pedestal', 'Ocultar hasta que gire': 'Hide until it spins', 'Solo aparece cuando alguien la activa': 'Only appears when someone triggers it',
    'Resultado en pantalla': 'Result on screen', 'Pantalla de espera': 'Idle screen', 'Ocultar el premio después de': 'Hide the prize after', 'Mensaje en pantalla': 'On-screen message',
    'Gira la ruleta, suma al frasco…': 'Spin the wheel, add to the jar…', 'Cantar una canción': 'Sing a song', 'Hablar con acento': 'Talk with an accent', 'Cambiar de skin': 'Change skin',
    'Leer un comentario random': 'Read a random comment', 'Gritar "¡VAMOS!"': 'Shout "LET\'S GO!"', 'Nada 😎': 'Nothing 😎', '# sentadillas': '# squats', 'Bailar # seg': 'Dance # sec',
    'baile': 'dance',

    // ── Lucky Roll
    'Dos modos: 🎲 Dado de la suerte o 🎁 Cofre de premios (se abre el cofre, gira una cinta y sale un premio según su %).': 'Two modes: 🎲 Lucky dice or 🎁 Prize chest (the chest opens, a reel spins and a prize comes out based on its %).',
    'Caras del dado': 'Dice faces', 'Caras del dado y probabilidades': 'Dice faces and chances', 'PROBABILIDADES': 'CHANCES', 'Premios del cofre': 'Chest prizes', 'Agregar premio': 'Add prize',
    'Nombre del premio': 'Prize name', 'Imagen del premio (PNG o GIF)': 'Prize image (PNG or GIF)', 'Regalo propio (opcional)': 'Own gift (optional)', 'Sin regalo propio': 'No own gift',
    'Si no subes nada, se usa la imagen del regalo.': 'If you upload nothing, the gift image is used.', 'Si no subes una, se usa la del regalo propio.': 'If you don\'t upload one, the own gift\'s image is used.',
    'Probabilidad de ganar': 'Chance to win', 'Activador global': 'Global trigger', 'Activador global (gira todos los premios)': 'Global trigger (spins all prizes)', 'todos los premios': 'all prizes',
    'Encendido: el regalo de "Activador global" gira todos los premios con su %. Apagado: cada premio solo se gana con su propio regalo.': 'On: the "Global trigger" gift spins all prizes with their %. Off: each prize can only be won with its own gift.',
    'Mostrar % al público': 'Show % to the public', 'Apagado: solo tú ves las probabilidades aquí en el panel. Encendido: salen en las casillas del overlay.': 'Off: only you see the chances here in the panel. On: they show on the overlay tiles.',
    'Fondo de "Nada"': '"Nothing" background', 'Texto de "Nada"': '"Nothing" text', 'Nada': 'Nothing', 'Nada 😢': 'Nothing 😢', 'Cuando no sale premio': 'When no prize comes out',
    'Estilo del cofre': 'Chest style', 'Animación de abrir': 'Opening animation', 'Velocidad de apertura': 'Opening speed', 'El cofre tiembla y se abre antes de girar': 'The chest shakes and opens before spinning',
    'Al temblar el cofre': 'When the chest shakes', 'Tiempo rodando': 'Rolling time', 'Rodando / cinta': 'Rolling / reel', 'Premio ganado': 'Prize won', 'Premio en pantalla': 'Prize on screen',
    'Premio normal del dado': 'Normal dice prize', 'Jackpot del dado o premio del cofre': 'Dice jackpot or chest prize', 'Al ganar este premio': 'When this prize is won',
    'Mostrar nombre del ganador': 'Show winner\'s name', 'Mensaje: usa {usuario} y {premio}': 'Message: use {usuario} and {premio}', '{usuario} ganó {premio}': '{usuario} won {premio}',
    'Abrir cofre': 'Open chest', 'Abrir cofre ahora': 'Open chest now', 'Tirar ahora': 'Roll now', 'Cofre listo': 'Chest ready', 'Dado listo': 'Dice ready', 'Premio (dado)': 'Prize (dice)',
    '¿Qué activa el juego? En modo cofre, esto es el activador global; además cada premio puede tener su propio regalo.': 'What triggers the game? In chest mode this is the global trigger; each prize can also have its own gift.',
    'Con el activador global, cada tirada usa estas probabilidades. Lo que sobra (#%) es "Nada 😢".': 'With the global trigger, each roll uses these chances. What\'s left over (#%) is "Nothing 😢".',
    'Si alguien envía este regalo, tiene #% de ganar este premio (si no, sale "Nada 😢").': 'If someone sends this gift, they have a #% chance to win this prize (otherwise "Nothing 😢").',
    'cinta con % por premio': 'reel with % per prize', 'cofre + premios pasando': 'chest + prizes passing by', 'cofre flotando': 'floating chest', 'tesoro pirata': 'pirate treasure',
    'de bruja': 'witch\'s', 'número brillante': 'glowing number', 'número con premio': 'number with prize', 'solo texto': 'text only', 'Premio o reto': 'Prize or dare',
    '¡PREMIO MAYOR!': 'JACKPOT!', 'Saludo en el live': 'Shout-out on the live', 'Elige la música': 'Pick the music', 'Un reto para mí': 'A dare for me', 'Mención especial': 'Special mention',
    'Mala suerte 😢': 'Bad luck 😢', 'Elige un reto': 'Pick a dare', '¡JACKPOT! Premio mayor 🎉': 'JACKPOT! Grand prize 🎉', 'Misterio ': 'Mystery',

    // ── Frasco / meta / top
    'Cada regalo cae dentro del frasco con física real. El frasco evoluciona por niveles y al llegar a la meta: ¡celebración!': 'Each gift falls into the jar with real physics. The jar evolves by levels, and when it reaches the goal: party time!',
    '¿Qué cae al frasco? Los regalos caen con su imagen; likes, follows y shares caen como ❤️ ⭐ 📣.': 'What falls into the jar? Gifts fall with their image; likes, follows and shares fall as ❤️ ⭐ 📣.',
    'Meta del frasco': 'Jar goal', 'Vaciar al llenarse': 'Empty when full', 'Vaciar frasco': 'Empty jar', 'Frasco lleno': 'Jar full', 'Llenándose': 'Filling', 'Contador y %': 'Counter and %',
    'Barra de progreso debajo del frasco': 'Progress bar under the jar', 'Muestra "nombre +#" al caer algo': 'Shows "name +#" when something falls', 'Cuando cae algo': 'When something falls',
    'Ranking del frasco': 'Jar ranking', 'Los que más llenaron el frasco': 'Who filled the jar the most', 'Sumar al frasco': 'Add to jar', 'Suma monedas al frasco': 'Adds coins to the jar',
    'frasco clásico': 'classic jar', 'con agua': 'with water', 'se llena latiendo': 'fills while pulsing', 'Nivel # · Cofre del tesoro': 'Level # · Treasure chest', 'Nivel # · Caldero mágico': 'Level # · Magic cauldron',
    'Barra, círculo o corazón que se llena con likes, monedas, seguidores o compartidos.': 'Bar, circle or heart that fills with likes, coins, followers or shares.', '¿Qué cuenta?': 'What counts?',
    'Al cumplirla, subir la meta en': 'When reached, raise the goal by', 'La meta sube sola cada vez que se cumple': 'The goal rises automatically each time it\'s reached', 'Empieza de nuevo cuando llega a la meta': 'Starts over when it reaches the goal',
    'Al llegar a la meta': 'When the goal is reached', 'Al llegar al #%': 'When reaching #%', 'Meta cumplida': 'Goal reached', 'Hoy se rompe la meta': 'Today we smash the goal', 'Sumar a la meta': 'Add to goal',
    'Reiniciar progreso': 'Reset progress', 'círculo con %': 'circle with %', 'Top donadores, top likes y top compartidos. Puede rotar entre ellos solo.': 'Top gifters, top likes and top shares. It can rotate between them on its own.',
    'Tablas que rotan': 'Rotating boards', 'Cambiar de tabla cada': 'Switch board every', 'Los que más regalan en tu live': 'Your live\'s biggest gifters', 'Mandaron al menos un regalo en este live': 'Sent at least one gift in this live',

    // ── Alertas / chat
    'Animación cuando alguien regala, te sigue o comparte. Regalos más grandes = alerta más grande.': 'Animation when someone gifts, follows you or shares. Bigger gifts = bigger alert.',
    '¿Qué regalos muestran alerta?': 'Which gifts show an alert?', 'Regalo normal': 'Normal gift', 'Regalo grande': 'Big gift', 'Nuevo seguidor': 'New follower', 'Nuevos seguidores': 'New followers',
    'En victorias, premios y regalos grandes': 'On wins, prizes and big gifts', 'Duración en pantalla': 'Time on screen', 'GIF gigante': 'Giant GIF', 'Texto que se lee': 'Text that is read',
    'Muestra los comentarios y regalos del live en tu stream.': 'Shows the live\'s comments and gifts on your stream.', 'Los regalos aparecen en el chat con su imagen': 'Gifts show up in the chat with their image',
    'blanco clásico': 'classic white', 'colores llenos': 'solid colors', 'colores suaves': 'soft colors', 'contorno de luz': 'light outline', 'líneas de luz': 'light lines', 'de colores': 'colorful',
    'centrada': 'centered', 'horizontal': 'horizontal', 'envió {cantidad}x {regalo}': 'sent {cantidad}x {regalo}', '¡Gracias por seguir! 💖': 'Thanks for following! 💖', 'compartió el live 🚀': 'shared the live 🚀',
    'compartió': 'shared', 'te siguió': 'followed you', '¡Hola!': 'Hi!', '¡Hola! Bienvenidos a mi live': 'Hi! Welcome to my live', 'Mensaje de prueba': 'Test message',

    // ── Simulador
    'Prueba todo sin estar en vivo. Lo que hagas aquí llega a los juegos y overlays como si fuera un viewer real.': 'Test everything without being live. What you do here reaches the games and overlays as if it were a real viewer.',
    'Escribir en el chat como viewer (prueba comandos como !unirme)': 'Write in the chat as a viewer (try commands like !unirme)', 'Probar regalo': 'Test gift', 'Probar regalo grande': 'Test big gift',
    'Probar seguidor': 'Test follower', 'Probar compartido': 'Test share', 'Soltar regalo de prueba': 'Drop test gift', 'Probar animación': 'Test animation', 'Probar con datos': 'Test with data',

    // ── Voz del chat
    'Tus viewers hablan en tu live: sus mensajes se leen en voz alta.': 'Your viewers talk on your live: their messages are read out loud.', 'Voz del sistema': 'System voice',
    'Buscar voz (ej. Spanish, Sabina, Pablo)…': 'Search voice (e.g. English, Zira, David)…', 'No se encontraron voces. En Windows: Configuración → Hora e idioma → Voz, para instalar voces en español.': 'No voices found. On Windows: Settings → Time & language → Speech, to install more voices.',
    'Probar voz': 'Test voice', '¿DÓNDE SUENA?': 'WHERE DOES IT PLAY?', 'El panel': 'The panel', 'En esta ventana': 'In this window', 'En un overlay': 'In an overlay', 'En el overlay': 'In the overlay',
    'Captura el audio del escritorio en OBS / LIVE Studio': 'Capture desktop audio in OBS / LIVE Studio', 'Agrega el link como fuente de navegador': 'Add the link as a browser source',
    'Controlar audio vía OBS': 'Control audio via OBS', '"Controlar audio vía OBS"': '"Control audio via OBS"', 'Activadores': 'Triggers', '¿CÓMO ACTIVAN LA VOZ LOS VIEWERS?': 'HOW DO VIEWERS TRIGGER THE VOICE?',
    'Todo el chat': 'All chat', 'Se lee cada mensaje': 'Every message is read', 'se leen todos': 'all are read', 'Con prefijo': 'With prefix', 'Mensajes que empiezan con': 'Messages that start with',
    'comando !say': '!say command', 'say': 'say', 'sin comandos': 'no commands', 'Leer los regalos': 'Read gifts', 'Anuncia en voz alta quién envió un regalo': 'Announces out loud who sent a gift',
    'Aviso de quién regaló': 'Who-gifted notice', 'Leer los nuevos seguidores': 'Read new followers', 'Da las gracias en voz alta': 'Says thanks out loud', 'Usa {usuario}, {regalo}, {cantidad}, {monedas}.': 'Use {usuario}, {regalo}, {cantidad}, {monedas}.',
    'Usa {usuario} y {mensaje}.': 'Use {usuario} and {mensaje}.', 'Quién puede': 'Who can', 'Cualquier viewer': 'Any viewer', 'Solo algunos': 'Only some', 'Elige los grupos de abajo': 'Pick the groups below',
    'O SOLO DE — ELIGE LOS QUE QUIERAS': 'OR ONLY FROM — PICK THE ONES YOU WANT', 'Personas que te siguen': 'People who follow you', 'Suscriptores': 'Subscribers', 'Suscriptores de pago': 'Paid subscribers',
    'Club de fans': 'Fan club', 'Miembros de tu club': 'Your club members', 'Moderadores': 'Moderators', 'Tus moderadores del live': 'Your live moderators', 'Tus mods': 'Your mods',
    'Donadores con nivel de TikTok': 'Gifters with TikTok level', 'Nivel de donador': 'Gifter level', 'Super fan': 'Super fan', 'Super fans': 'Super fans', 'Usuarios especiales': 'Special users',
    'Sin usuarios especiales ni bloqueados.': 'No special or blocked users.', 'Leer todo lo suyo': 'Read everything they say', 'Bloquear': 'Block', 'Filtros': 'Filters', 'FILTROS DE CONTENIDO': 'CONTENT FILTERS',
    'Largo máximo': 'Max length', 'letras por mensaje': 'letters per message', 'Espera general (segundos)': 'General cooldown (seconds)', 'Quitar spam (aaaaaaa → aaa)': 'Remove spam (aaaaaaa → aaa)',
    'Cambiar links por "link"': 'Replace links with "link"', 'Quitar emojis': 'Remove emojis', 'Saltar mensajes que empiezan con': 'Skip messages that start with', 'Saltar comandos (!) cuando se lee todo': 'Skip commands (!) when reading everything',
    'Esconde mensajes que empiezan con !': 'Hides messages that start with !', 'IDIOMAS QUE SE LEEN': 'LANGUAGES THAT ARE READ', 'Latino (español, inglés…)': 'Latin (Spanish, English…)', 'Árabe': 'Arabic',
    'Hebreo': 'Hebrew', 'Chino': 'Chinese', 'Japonés': 'Japanese', 'Coreano': 'Korean', 'Hindi': 'Hindi', 'Tailandés': 'Thai', 'Cirílico (ruso…)': 'Cyrillic (Russian…)', 'Griego': 'Greek',
    'PALABRAS PROHIBIDAS': 'BANNED WORDS', 'Usar lista incluida (#)': 'Use built-in list (#)', 'Incluida': 'Built-in', 'Agregar palabra…': 'Add word…', 'No leer el mensaje': 'Don\'t read the message',
    'Cambiar por "piii"': 'Replace with "beep"', 'Decir el nombre': 'Say the name', 'Lee quién escribió antes del mensaje': 'Reads who wrote it before the message', 'Cola máxima': 'Max queue',
    'mensajes esperando': 'messages waiting', 'Pausa entre mensajes': 'Pause between messages', 'segundos entre mensajes': 'seconds between messages', 'Burbuja en el overlay': 'Bubble in the overlay',
    'Muestra el mensaje que se está leyendo (overlay de voz)': 'Shows the message being read (voice overlay)', 'Cola': 'Queue', 'Cola vacía': 'Queue empty', 'cola máx. #': 'max. queue #',
    'LEYENDO': 'READING', 'REPRODUCCIÓN': 'PLAYBACK', 'Recientes': 'Recent', 'Leídos': 'Read', 'No leídos': 'Not read', 'espera': 'wait', 'Este navegador no tiene voz (usa Chrome o Edge)': 'This browser has no voice (use Chrome or Edge)',
    '{usuario} dice: {mensaje}': '{usuario} says: {mensaje}', 'Gracias por seguir, {usuario}': 'Thanks for following, {usuario}', '{usuario} envió {cantidad} {regalo}': '{usuario} sent {cantidad} {regalo}',
    'Usa la voz configurada en "Voz del chat".': 'Uses the voice set up in "Chat voice".', 'Lee un texto en voz alta': 'Reads a text out loud',
    // motivos para no leer
    'bloqueado': 'blocked', 'no está en los grupos permitidos': 'not in the allowed groups', 'vacío': 'empty', 'empieza con @': 'starts with @', 'es un comando': 'is a command',
    'idioma filtrado': 'filtered language', 'palabra prohibida': 'banned word', 'espera (cooldown)': 'cooldown',

    // ── Acciones y eventos
    'Automatiza tu live': 'Automate your live', 'algo. Alertas, sonidos, voz, teclas y juegos.': 'something. Alerts, sounds, voice, keys and games.', 'pasa algo': 'something happens',
    'Nueva acción': 'New action', 'Acciones activas': 'Active actions', 'Tus pantallas': 'Your screens', 'Agrega cada link como': 'Add each link as',
    'Agrégala en OBS / LIVE Studio como fuente de navegador · solo las acciones de esta pantalla se ven aquí': 'Add it in OBS / LIVE Studio as a browser source · only this screen\'s actions show here',
    '(LIVE Studio), tamaño # × # para vertical. El fondo es transparente y usan tu estilo automáticamente.': '(LIVE Studio), size # × # for vertical. The background is transparent and they use your style automatically.',
    'Máximo 8 pantallas': 'Maximum 8 screens', 'Nombre de la pantalla': 'Screen name', '¿DÓNDE SUENAN LOS SONIDOS?': 'WHERE DO THE SOUNDS PLAY?',
    'Los sonidos suenan dentro del overlay (OBS / LIVE Studio). En OBS marca': 'Sounds play inside the overlay (OBS / LIVE Studio). In OBS check', 'en la fuente si no los escuchas.': 'on the source if you don\'t hear them.',
    'Ejecutar solo la regla de mayor prioridad (la primera que coincida)': 'Run only the highest-priority rule (the first one that matches)', 'Para juegos y apps (Windows)': 'For games and apps (Windows)',
    'Abre el juego o la app, vuelve aquí y presiona Probar: ChispaLive enviará la tecla a la ventana que indiques.': 'Open the game or app, come back here and press Test: ChispaLive will send the key to the window you set.',
    'Probar tecla': 'Test key', 'Orden: prioridad': 'Sort: priority', 'Orden: nombre': 'Sort: name', 'Activas primero': 'Active first', 'Subir prioridad': 'Raise priority', 'Bajar prioridad': 'Lower priority',
    'CUANDO': 'WHEN', 'HACER': 'DO', 'Últimas ejecuciones': 'Latest runs', 'Todavía no se ejecutó ninguna acción.': 'No action has run yet.', 'Pantalla donde se ve': 'Screen where it shows',
    'Sin opciones: se ve en la pantalla elegida.': 'No options: it shows on the chosen screen.', 'Copia este texto para guardar tus acciones, o pega uno para cargarlas.': 'Copy this text to save your actions, or paste one to load them.',
    'Elige lo que pasa en tu live. Después decides qué hace ChispaLive.': 'Pick what happens on your live. Then you decide what ChispaLive does.', 'Busca un evento: regalo, seguir, chat, like…': 'Search an event: gift, follow, chat, like…',
    'Comunidad': 'Community', 'Llega cualquier regalo': 'Any gift arrives', 'Vale N monedas o más': 'Worth N coins or more', 'El live junta N monedas': 'The live collects N coins', 'Alguien te sigue': 'Someone follows you',
    'Comparten tu live': 'Someone shares your live', 'Entra al live': 'Joins the live', 'Un viewer se une': 'A viewer joins', 'Primera acción de un viewer': 'A viewer\'s first action', 'Primera vez': 'First time',
    'Alguien escribe en el chat': 'Someone writes in the chat', 'Palabra clave': 'Keyword', 'Palabra o comando': 'Word or command', 'Escriben': 'They write', 'Con cada comentario': 'With every comment', 'Con cada regalo': 'With every gift',
    'El mensaje debe empezar con esa palabra (si no, basta con que la contenga)': 'The message must start with that word (otherwise it just has to contain it)', 'El live llega a N likes': 'The live reaches N likes',
    'Llegas a N viewers': 'You reach N viewers', 'Nueva suscripción': 'New subscription', 'Alguien suelta un cofre': 'Someone drops a chest', 'Empieza el live': 'Live starts', 'Te conectas en vivo': 'You go live',
    'Termina el live': 'Live ends', 'Se cierra tu live': 'Your live closes', 'Atajo de teclado': 'Keyboard shortcut', 'ATAJO': 'SHORTCUT', 'Presionas una tecla en el panel': 'You press a key in the panel',
    'Presiona para grabar el atajo': 'Press to record the shortcut', 'Funciona cuando la ventana del panel está activa (no mientras escribes en un campo).': 'Works when the panel window is active (not while typing in a field).',
    'Cada X minutos': 'Every X minutes', 'Cada cuántos minutos': 'How many minutes', 'Se repite mientras estás en vivo': 'Repeats while you are live', 'Se ejecuta una vez por live.': 'Runs once per live.',
    'Cuando el live junte (monedas)': 'When the live collects (coins)', 'Cuando el live llegue a (likes)': 'When the live reaches (likes)', 'Cuando haya (espectadores)': 'When there are (viewers)',
    'Cuando cambia el ##': 'When the ## changes', 'Detalles y quién cuenta': 'Details and who counts', '¿QUIÉN CUENTA?': 'WHO COUNTS?', 'Cuenta a cualquier viewer': 'Counts any viewer', 'Solo estos': 'Only these',
    'Te siguen': 'They follow you', 'Espera por usuario': 'Cooldown per user', 'Nombre de la acción': 'Action name', 'AGREGAR REACCIÓN': 'ADD REACTION', 'Agrega al menos una reacción': 'Add at least one reaction',
    'Guardar acción': 'Save action', '✓ Acción guardada': '✓ Action saved', 'Alerta en pantalla': 'On-screen alert', 'GIF o imagen con texto': 'GIF or image with text', 'Sonido ': 'Sound',
    'Presionar tecla': 'Press key', 'solo en Windows': 'Windows only', 'algunos juegos no aceptan teclas simuladas': 'some games don\'t accept simulated keys',
    'Solo en Windows. Si pones el título de la ventana, ChispaLive la activa antes de presionar.': 'Windows only. If you enter the window title, ChispaLive focuses it before pressing.',
    'Ventana (opcional): parte del título, ej. "Roblox"': 'Window (optional): part of the title, e.g. "Roblox"', 'Avisa a otra app (Streamer.bot…)': 'Notifies another app (Streamer.bot…)',
    'Envía los datos del evento en JSON (usuario, regalo, monedas…).': 'Sends the event data as JSON (user, gift, coins…).', 'Webhook': 'Webhook', 'Mover un juego ': 'Move a game',
    'Puedes usar {usuario}, {regalo}, {cantidad}, {monedas}, {mensaje}, {likes}, {espectadores}.': 'You can use {usuario}, {regalo}, {cantidad}, {monedas}, {mensaje}, {likes}, {espectadores}.',
    'En los textos puedes usar': 'In texts you can use', 'Textos: usa': 'Texts: use', 'Se prueba con ▶ en la lista, después de guardar': 'Test it with ▶ in the list, after saving',
    'Gracias por seguir': 'Thanks for following', '¡Gracias por seguir, {usuario}! 💖': 'Thanks for following, {usuario}! 💖', '🔥 {usuario} mandó {regalo} ({monedas} monedas)': '🔥 {usuario} sent {regalo} ({monedas} coins)',
    'Aa ¡Gracias!': 'Aa Thanks!', 'Bocina': 'Air horn', 'Campana': 'Bell', 'Fanfarria': 'Fanfare', 'Redoble': 'Drum roll', 'Boing': 'Boing', 'Whoosh': 'Whoosh', 'GG': 'GG',
    'Probar ': 'Test', 'Los regalos': 'Gifts', 'Seguir la cuenta': 'Follow the account', 'Compartir el live': 'Share the live', 'Saludo en el live #%': 'Shout-out on the live #%',
    'Elige la música #%': 'Pick the music #%', 'Mención especial #%': 'Special mention #%', 'Un reto para mí #%': 'A dare for me #%', '¡PREMIO MAYOR! #%': 'JACKPOT! #%', 'Nada 😢 #%': 'Nothing 😢 #%',
    'Clave guardada ✓': 'Key saved ✓', 'Link copiado ✓': 'Link copied ✓', 'Link copiado ✓ Pégalo como Fuente de navegador': 'Link copied ✓ Paste it as a Browser source',
    'El GIF pesa demasiado (máx. # MB)': 'The GIF is too big (max. # MB)', 'El sonido pesa demasiado (máx. # MB)': 'The sound is too big (max. # MB)', 'Eso no es un sonido (usa MP#, WAV u OGG)': 'That\'s not a sound (use MP#, WAV or OGG)',
    'Eso no es una imagen': 'That\'s not an image', 'Ese texto no es válido': 'That text is not valid', 'Escribe tu @ de TikTok': 'Type your TikTok @',
    '¿Quitar la imagen de esta porción? (Cancelar = cambiarla)': 'Remove this slice\'s image? (Cancel = change it)', '¿Reiniciar monedas, likes y rankings?': 'Reset coins, likes and rankings?',
    'Nombre del preset (guarda toda la configuración actual de este juego):': 'Preset name (saves this game\'s whole current setup):',
    '¿Qué pasa?': 'What happens?', '¿Qué lo activa?': 'What triggers it?', 'Útil': 'Useful',

    // ── Sueltos (unidades, etiquetas cortas, overlays)
    '# activas de #': '# active of #', '# espectadores': '# viewers', '# juegos': '# games', '# likes': '# likes', '# monedas': '# coins', '# palabras': '# words', '# punto por regalo': '# point per gift',
    '# regalos': '# gifts', '# ruedas': '# wheels', '#s de espera': '#s cooldown', '(# activas)': '(# active)', '#% usado': '#% used', 'Últimos # segundos': 'Last # seconds',
    'Sus monedas (Galaxy = #)': 'Their coins (Galaxy = #)', 'Cada regalo cuenta como': 'Each gift counts as', 'Toca un regalo': 'Tap a gift', 'Puja mín.': 'Min. bid', 'Vivos': 'Alive',
    'Gana al instante': 'Instant win', 'LLENO': 'FULL', 'Esperando jugadores…': 'Waiting for players…', '⏸ PAUSA': '⏸ PAUSED', 'PAUSA': 'PAUSED', 'DUELO FINAL': 'FINAL DUEL', '¡GANADOR!': 'WINNER!',
    '¡META CUMPLIDA!': 'GOAL REACHED!', '¡Envía regalos para pujar!': 'Send gifts to bid!', '¡Puja ya!': 'Bid now!', 'En pausa': 'Paused', '¡entró!': 'joined!', 'inscripción abierta': 'sign-ups open',
    'envía cualquier regalo': 'send any gift', 'envía un regalo': 'send a gift', 'sígueme': 'follow me', 'comparte': 'share', 'el streamer te agrega': 'the streamer adds you', 'Modo eliminación': 'Elimination mode',
    'para unirse': 'to join', 'quedan en pie': 'still standing', 'ganador': 'winner', 'victoria instantánea': 'instant win', '¡VICTORIA INSTANTÁNEA!': 'INSTANT WIN!', 'Inscripciones': 'Sign-ups',
    'puja mín.': 'min. bid', 'comando': 'command', 'vivos': 'alive', 'Rose · # monedas': 'Rose · # coins', 'Top fan': 'Top fan', 'Mecenas del live': 'Live patron',
    '¡Pujador fuerte!': 'Big bidder!', 'Rey de la subasta': 'Auction king', 'Guerrero': 'Warrior', 'Leyenda': 'Legend', 'Súper fan': 'Super fan', 'Suertudo': 'Lucky one', 'MEGA REGALO!': 'MEGA GIFT!',
    '¡MEGA REGALO!': 'MEGA GIFT!', '¡25% de la meta!': '25% of the goal!', '¡Vamos por la mitad!': 'Halfway there!', '¡El frasco evolucionó!': 'The jar evolved!', '¡Ya casi llegamos a la meta!': 'We\'re almost at the goal!',
    'Juegos, alertas y más': 'Games, alerts and more', 'Datos': 'Data', 'ÚLTIMO': 'LAST', 'Probando': 'Testing', 'ejecutada': 'ran', 'Ejecutada': 'Ran', 'prueba': 'test', 'PRUEBA': 'TEST',
    'REGALO': 'GIFT', 'Aa #': 'Aa #', 'ABAJO': 'DOWN', 'ARRIBA': 'UP', 'IZQUIERDA': 'LEFT', 'DERECHA': 'RIGHT', 'ESPACIO': 'SPACE', 'BORRAR': 'BACKSPACE', 'ENTER': 'ENTER', 'ESC': 'ESC', 'TAB': 'TAB',
    'Shift': 'Shift', 'Ctrl': 'Ctrl', 'Alt': 'Alt', 'GET': 'GET', 'POST': 'POST', 'English': 'English', 'Español': 'Español', 'ES': 'ES', 'EN': 'EN', 'TikTok': 'TikTok', 'ChispaLive': 'ChispaLive',
    'Así empezará. Ajusta antes de iniciar.': 'This is how it will start. Adjust before starting.', 'Entrada': 'Entry', 'Grande': 'Big', 'Vaciar fila': 'Clear queue',
    'Cuentan los de borde verde.': 'The ones with a green border count.', 'Saltar mensajes que empiezan con': 'Skip messages that start with', '¡Hola! Bienvenidos a mi live': 'Hi! Welcome to my live',
    'Inscripciones abiertas': 'Sign-ups open', 'Tenemos ganador': 'We have a winner', 'Envía un regalo para entrar': 'Send a gift to join', 'Subasta en vivo ': 'Live auction',
    '¡Gracias por seguir!': 'Thanks for following!', 'compartió el live': 'shared the live', '¡JACKPOT! Premio mayor': 'JACKPOT! Grand prize', 'Mala suerte': 'Bad luck', 'eliminado': 'out', 'ELIMINADO': 'OUT',
    'más': 'more', 'abierto': 'open', 'esperando #': 'waiting #', 'Sin ganador': 'No winner', 'pierde una casilla': 'loses a tile', '¡gana!': 'wins!', 'Partidas grandes': 'Big matches',
    'Con más de 20 vivos saca a varios por ronda (si no, 100 personas tardarían 20 minutos)': 'With more than 20 alive it removes several per round (otherwise 100 people would take 20 minutes)',
    'Tiradas por regalo': 'Rolls per gift', 'Según sus monedas': 'By its coins', 'Doughnut = # tiradas': 'Doughnut = # rolls', 'Una por regalo': 'One per gift', 'racha x# = # tiradas': 'streak x# = # rolls',
    'Cada cuántas monedas = # tirada': 'Every how many coins = # roll', 'Máximo de tiradas por regalo': 'Max rolls per gift', 'tiradas': 'rolls', 'Tiradas seguidas rápidas': 'Fast consecutive rolls',
    'Desde la 2ª tirada de la misma persona, gira más rápido para no hacer esperar': 'From the 2nd roll of the same person, it spins faster so nobody waits too long',
    'Vista previa': 'Preview',
    'La voz está apagada:': 'The voice is off:', 'los mensajes del chat no se leen.': 'chat messages are not read.', 'Encender voz': 'Turn on voice', 'Voz encendida': 'Voice on',
    'Se prueba con tus filtros: así sonará en el live.': 'Tested with your filters: this is how it will sound on the live.', '¡Hola! Bienvenidos a mi live': 'Hi! Welcome to my live',
    'Tus datos': 'Your data', 'Descargar respaldo': 'Download backup', 'Cargar respaldo': 'Load backup', 'Carpeta:': 'Folder:',
    'Se trajo tu configuración de la versión anterior ✓': 'Your settings were brought over from the previous version ✓', 'Respaldo cargado ✓': 'Backup loaded ✓',
    'Ese archivo no es un respaldo de ChispaLive': 'That file is not a ChispaLive backup',
    '¿Cargar este respaldo? Se reemplaza tu configuración actual (antes se guarda una copia).': 'Load this backup? Your current settings will be replaced (a copy is saved first).',
    'Actualizaciones': 'Updates', 'Buscar actualizaciones': 'Check for updates', 'Instalar desde archivo .zip': 'Install from .zip file', 'Ver novedades': 'What\'s new', 'Actualizar': 'Update',
    'Actualizar ahora': 'Update now', 'Después': 'Later', 'Reiniciando ChispaLive…': 'Restarting ChispaLive…', 'Esta página se recarga sola cuando esté lista.': 'This page reloads by itself when ready.',
    'Esto es lo nuevo:': 'Here is what\'s new:', '¡Genial!': 'Great!', 'Buscando actualizaciones…': 'Checking for updates…', 'Revisando el archivo…': 'Checking the file…',
    'Conexión automática': 'Auto connect', 'Conectarme solo cuando empiece mi live': 'Connect me automatically when my live starts',
    'No estás conectado a tu LIVE': 'You are not connected to your LIVE', 'Mientras esté así, las donaciones no cuentan en los juegos.': 'While this lasts, gifts don\'t count in the games.',
    'ESPERANDO TU LIVE · SE CONECTA SOLO': 'WAITING FOR YOUR LIVE · CONNECTS BY ITSELF', 'Detener': 'Stop',
    'Se cortó la conexión con TikTok. Reconectando…': 'The connection with TikTok dropped. Reconnecting…',
    'Cyber': 'Cyber', 'Follow': 'Follow', 'Confetti': 'Confetti', 'Galaxy': 'Galaxy', 'Panel': 'Panel', 'Estado': 'Status', 'Escribe': 'Type', 'Escribe ': 'Type',
  };
  // Frases con partes que cambian (nombres, regalos…). g = traduce también ese pedazo.
  const g = s => tr(s);
  const R = [
    [/^Conectando a (@\S+?)\.\.\.$/, (_, u) => `Connecting to ${u}...`],
    [/^En vivo como (@\S+) \(sala (\S+)\)$/, (_, u, r) => `Live as ${u} (room ${r})`],
    [/^(@\S+) no está en vivo ahora mismo$/, (_, u) => `${u} is not live right now`],
    [/^No se pudo conectar: (.*)$/s, (_, m) => `Couldn't connect: ${m}`],
    [/^Escribe tu usuario de TikTok$/, () => 'Type your TikTok username'],
    [/^El live terminó$/, () => 'The live ended'],
    [/^(\d+) regalos de TikTok cargados(?: \((\d+) nuevos\))?$/, (_, n, k) => `${n} TikTok gifts loaded${k ? ` (${k} new)` : ''}`],
    [/^No se pudieron traer los regalos ahora\. Se cargan solos la próxima vez que te conectes en vivo\.$/, () => 'Couldn\'t fetch the gifts right now. They will load on their own the next time you go live.'],
    [/^¡(\d+) jugadores! Empieza la cuenta regresiva$/, (_, n) => `${n} players! The countdown begins`],
    [/^Spin Royale: faltan jugadores \(mínimo 2\)$/, () => 'Spin Royale: not enough players (minimum 2)'],
    [/^Inscripciones cerradas\. ¡Dale a Empezar!$/, () => 'Sign-ups closed. Hit Start!'],
    [/^Primero abre las inscripciones$/, () => 'Open sign-ups first'],
    [/^Spin Royale necesita al menos 2 jugadores$/, () => 'Spin Royale needs at least 2 players'],
    [/^La rueda "(.*)" necesita al menos 2 porciones activas$/, (_, w) => `The wheel "${w}" needs at least 2 active slices`],
    [/^Inicia la subasta para agregar pujas$/, () => 'Start the auction to add bids'],
    [/^Abre las inscripciones para agregar jugadores$/, () => 'Open sign-ups to add players'],
    [/^Preset "(.*)" guardado$/, (_, n) => `Preset "${n}" saved`], [/^Preset "(.*)" aplicado$/, (_, n) => `Preset "${n}" applied`],
    [/^TikTok no dejó bajar la lista de regalos ahora\. No pasa nada: cada regalo que te envíen agrega su imagen oficial solo\.$/, () => 'TikTok didn\'t let us download the gift list right now. No problem: every gift you receive adds its official image automatically.'],
    [/^No se leería: (.+)$/, (_, r) => `Would not be read: ${tr(r)}`],
    [/^(\d+) respaldos guardados$/, (_, n) => `${n} backups saved`],
    [/^¡Nueva actualización v(.+)!$/, (_, v) => `New update v${v}!`], [/^Actualización v(.+)$/, (_, v) => `Update v${v}`], [/^¡Actualizado a la v(.+)!$/, (_, v) => `Updated to v${v}!`],
    [/^Ya tienes la última versión \(v(.+)\)$/, (_, v) => `You have the latest version (v${v})`],
    [/^Esperando a que (@\S+) empiece su live… \(se conecta solo\)$/, (_, u) => `Waiting for ${u} to start the live… (connects by itself)`],
    [/^Buscando el live de (@\S+)…$/, (_, u) => `Looking for ${u}'s live…`],
    [/^Reconectando a (@\S+)…$/, (_, u) => `Reconnecting to ${u}…`],
    [/^Tecla enviada$/, () => 'Key sent'], [/^Tecla no válida$/, () => 'Invalid key'], [/^Destino no válido$/, () => 'Invalid target'],
    [/^Formato no válido\. Imágenes: PNG, JPG, GIF, WEBP\. Sonidos: MP3, WAV, OGG$/, () => 'Invalid format. Images: PNG, JPG, GIF, WEBP. Sounds: MP3, WAV, OGG'],
    [/^Aquí va una imagen o GIF$/, () => 'An image or GIF goes here'], [/^Aquí va un sonido \(MP3, WAV u OGG\)$/, () => 'A sound goes here (MP3, WAV or OGG)'],
    [/^Imagen actualizada ✓$/, () => 'Image updated ✓'], [/^Sonido actualizado ✓$/, () => 'Sound updated ✓'], [/^El webhook no respondió$/, () => 'The webhook didn\'t respond'],
    [/^Probando "(.*)"$/, (_, n) => `Testing "${n}"`], [/^(\d+) acciones cargadas$/, (_, n) => `${n} actions loaded`],
    [/^¿Borrar "(.*)"\?$/s, (_, n) => `Delete "${n}"?`], [/^¿Borrar el preset "(.*)"\?$/, (_, n) => `Delete the preset "${n}"?`], [/^¿Borrar la rueda "(.*)"\?$/, (_, n) => `Delete the wheel "${n}"?`],
    [/^¿Borrar las (\d+) acciones\?$/, (_, n) => `Delete all ${n} actions?`],
    [/^¿Restablecer (\d+) ajustes de (.*) a los valores por defecto\?$/, (_, n, s) => `Reset ${n} ${g(s)} settings to their defaults?`],
    // carrera / jefe / trivia
    [/^¡(.+) está en llamas!$/, (_, n) => `${g(n)} is on fire!`],
    [/^MVP · (.+) · ([\d.,]+)/, (_, n, v) => `MVP · ${n} · ${v}`],
    [/^(.+) ✋$/, (_, n) => `${n} ✋`],
    [/^Etapa (\d+) · (.+)$/, (_, n, x) => `Stage ${n} · ${g(x)}`],
    [/^¡Ñam ñam! Gracias ?(.*)$/, (_, u) => `Yum yum! Thanks ${u}`],
    [/^¡Gracias (.+)! 💖$/, (_, u) => `Thanks ${u}! 💖`],
    [/^¡Bienvenido (.+)! 💖$/, (_, u) => `Welcome ${u}! 💖`],
    [/^(\S+) ¡(.+) evolucionó a (.+)!$/, (_, i, n, x) => `${i} ${n} evolved into ${g(x)}!`],
    [/^🐣 (.+) evolucionó a (.+)$/, (_, n, x) => `🐣 ${n} evolved into ${g(x)}`],
    [/^(\S+) Etapa (\d+) · (.+)$/, (_, i, n, x) => `${i} Stage ${n} · ${g(x)}`],
    [/^([\d.,]+) · MÁX$/, (_, n) => `${n} · MAX`],
    [/^(.+) · nivel (\d+) derrotado$/, (_, n, l) => `${g(n)} · level ${l} defeated`],
    [/^(.+) activó TURBO para (.+)$/, (_, u, x) => `${u} activated TURBO for ${g(x)}`],
    [/^(.+) protegió a (.+)$/, (_, u, x) => `${u} shielded ${g(x)}`],
    [/^(.+) le tiró una cáscara a (.+)$/, (_, u, x) => `${u} threw a banana peel at ${g(x)}`],
    [/^¡El escudo de (.+) paró la cáscara!$/, (_, x) => `${g(x)}'s shield stopped the banana peel!`],
    [/^(.+): únete primero con el comando de un animal$/, (_, u) => `${u}: join an animal with its command first`],
    [/^¡Viento a favor para (.+)! \+(\d+) m$/, (_, x, m) => `Tailwind for ${g(x)}! +${m} m`],
    [/^¡Lluvia! Todos corren más lento por (\d+) s$/, (_, n) => `Rain! Everyone runs slower for ${n} s`],
    [/^¡Estrella para (.+)! \+(\d+) m$/, (_, x, m) => `Star for ${g(x)}! +${m} m`],
    [/^Sorpresa en (\d+)s$/, (_, n) => `Surprise in ${n}s`],
    [/^(.+) pasa adelante!$/, (_, x) => `${g(x)} takes the lead!`],
    [/^¡Recta final! (.+)$/, (_, x) => `Final stretch! ${g(x)}`],
    [/^Link de "(.+)" copiado$/, (_, x) => `"${g(x)}" link copied`],
    [/^"(.+)" copiado$/, (_, x) => `"${g(x)}" copied`],
    [/^"(.+)" aplicado$/, (_, x) => `"${x}" applied`],
    [/^"(.+)" enviado a Roblox$/, (_, x) => `"${x}" sent to Roblox`],
    [/^¿Borrar (el preset |la meta |la rueda )?"(.+)"\?(.*)$/s, (_, w, x, r) => `Delete "${g(x)}"?${r ? ' ' + g(r.trim()) : ''}`],
    [/^¿Borrar el ranking (.+)\? No se puede deshacer\.$/, (_, x) => `Delete the ranking (${g(x)})? This can't be undone.`],
    [/^¿Quitar (.+)\?(.*)$/s, (_, x, r) => `Remove ${g(x)}?${r ? ' ' + g(r.trim()) : ''}`],
    [/^¿Restablecer (.+) a los valores por defecto\?$/, (_, x) => `Reset ${g(x)} to the default values?`],
    [/^Probando "(.+)"$/, (_, x) => `Testing "${g(x)}"`],
    [/^Regalo que activa "(.+)"$/, (_, x) => `Gift that triggers "${g(x)}"`],
    [/^Regalo propio de "(.+)"$/, (_, x) => `"${g(x)}" own gift`],
    [/^Poder "(.+)"(.*)$/, (_, x, r) => `Power "${x}"${g(r)}`],
    [/^Guardar en "(.+)"$/, (_, x) => `Save to "${x}"`],
    [/^Su link de OBS dejará de funcionar\.$/, () => 'Its OBS link will stop working.'],
    [/^(\d\uFE0F?\u20E3) (.+)$/u, (_, n, x) => `${n} ${g(x)}`],
    [/^Cambiar un texto, por ejemplo "Último regalo: \{usuario\}"$/, () => 'Change a text, for example "Last gift: {usuario}"'],
    [/^Te quedan (\d+) día\(s\): termina el (\d+) de (\w+) de (\d+)$/, (_, n, d, m, y) => `${n} day(s) left: ends ${({ enero: 'January', febrero: 'February', marzo: 'March', abril: 'April', mayo: 'May', junio: 'June', julio: 'July', agosto: 'August', septiembre: 'September', octubre: 'October', noviembre: 'November', diciembre: 'December' })[m] || m} ${d}, ${y}`],
    [/^(.+) · \/ (año|mes)$/, (_, p, u) => `${p} · / ${u === 'año' ? 'year' : 'month'}`],
    [/^([\d.,]+) monedas · lo completó (.+)$/, (_, n, u) => `${n} coins · completed by ${u}`],
    [/^Ganó:? (.+)$/, (_, x) => `Winner: ${g(x)}`],
    [/^te quedan (\d+) (días|horas) con todo desbloqueado\.$/, (_, n, u) => `${n} ${u === 'días' ? 'days' : 'hours'} left with everything unlocked.`],
    [/^¡Ganó (.+)!$/, (_, u) => `${g(u)} wins!`], [/^Meta: (.+) m$/, (_, n) => `Finish: ${n} m`], [/^¡Derrotaron a (.+)!$/, (_, n) => `${g(n)} was defeated!`], [/^Nivel (\d+) vencido$/, (_, n) => `Level ${n} cleared`],
    [/^¡Apareció (.+)! Nivel (\d+)$/, (_, n, l) => `${g(n)} appeared! Level ${l}`], [/^(\d+) de (\d+) acertaron$/, (_, a, b) => `${a} of ${b} got it right`], [/^(\d+) respondieron$/, (_, n) => `${n} answered`],
    [/^MVP: (.+)$/, (_, u) => `MVP: ${u}`], [/^Golpe final: (.+)$/, (_, u) => `Final blow: ${u}`], [/^Pregunta (\d+)\/(\d+)$/, (_, a, b) => `Question ${a}/${b}`],
    [/^(.+) o (!\S+)$/, (_, a, b) => `${a} or ${b}`], [/^(.+) o$/, (_, a) => `${a} or`], [/^(.+) o$/, (_, a) => `${a} or`],
    // overlays
    [/^(.+) tira el dado$/, (_, u) => `${u} rolls the dice`], [/^abre el cofre con (.+)$/, (_, x) => `opens the chest with ${x}`], [/^abre el cofre$/, () => 'opens the chest'],
    [/^(.+) ganó$/, (_, u) => `${u} won`], [/^(.+) ganó (.+)$/, (_, u, p) => `${u} won ${g(p)}`], [/^gana con (.+)$/, (_, x) => `wins with ${x}`],
    [/^(.+) activó la ruleta$/, (_, u) => `${u} spun the wheel`], [/^(.+) · te toca$/, (_, u) => `${u} · your turn`],
    [/^envía (.+) o (.+)$/, (_, a, b) => `send ${a} or ${b}`], [/^envía (.+)$/, (_, a) => `send ${a}`], [/^escribe (.+)$/, (_, c) => `type ${c}`],
    [/^regala (.+)$/, (_, x) => `gift ${x}`], [/^da (\d+) likes$/, (_, n) => `give ${n} likes`], [/^esperando (\d+) jugadores$/, (_, n) => `waiting for ${n} players`],
    [/^Escribe (\S+) o envía un regalo para entrar$/, (_, c) => `Type ${c} or send a gift to join`],
    [/^quedan · giro en (\d+)s$/, (_, n) => `left · spin in ${n}s`], [/^giro en (\d+)s$/, (_, n) => `spin in ${n}s`],
    [/^Quedan (\d+) de (\d+)$/, (_, a, b) => `${a} of ${b} left`], [/^Mínimo (.+)$/, (_, x) => `Minimum ${x}`], [/^(\d+) vivos$/, (_, n) => `${n} alive`],
    [/^(\d+) eliminados: (.*)$/, (_, n, l) => `${n} eliminated: ${l}`], [/^y (\d+) más$/, (_, n) => `and ${n} more`], [/^\+(\d+) más$/, (_, n) => `+${n} more`], [/^Puja mín\. (\d+)$/, (_, n) => `Min. bid ${n}`], [/^se lleva la corona/, s => s.replace('se lleva la corona', 'takes the crown')],
    [/^Puja mínima (.+)$/, (_, x) => `Minimum bid ${x}`], [/^Gana al instante con (.+)$/, (_, x) => `Instant win with ${x}`], [/^Regalo · (.+)$/, (_, x) => `Gift · ${x}`],
    [/^envió (\d+)x (.+)$/, (_, n, x) => `sent ${n}x ${x}`], [/^envió (.+)$/, (_, x) => `sent ${x}`], [/^(.+) envió (\d+) (.+)$/, (_, u, n, x) => `${u} sent ${n} ${x}`],
    [/^(.+) dice: (.*)$/s, (_, u, m) => `${u} says: ${m}`], [/^Gracias por seguir, (.+)$/, (_, u) => `Thanks for following, ${u}`], [/^¡Gracias por seguir, (.+)!$/, (_, u) => `Thanks for following, ${u}!`],
    [/^(.+) mandó (.+) \((\d+) monedas\)$/, (_, u, x, n) => `${u} sent ${x} (${n} coins)`], [/^(.+) ya lleva (\S+) monedas$/, (_, u, n) => `${u} already has ${n} coins`],
    [/^¡(.+) desbloqueó un nuevo personaje!$/, (_, u) => `${u} unlocked a new character!`], [/^¡(.+) evolucionó a (.+)!$/, (_, u, x) => `${u} evolved to ${g(x)}!`], [/^¡(.+) evolucionó!$/, (_, u) => `${u} evolved!`],
    [/^(.+) lleva (\S+) monedas en la ruleta$/, (_, u, n) => `${u} has ${n} coins on the wheel`], [/^(.+) desbloqueó el nivel (.+)$/, (_, u, x) => `${u} unlocked the ${g(x)} level`],
    [/^(.+) ya regaló (\S+) monedas$/, (_, u, n) => `${u} already gifted ${n} coins`], [/^(.+) · ([\d.,]+) monedas$/, (_, x, n) => `${x} · ${n} coins`],
    [/^([\d.,]+) monedas$/, (_, n) => `${n} coins`], [/^Nivel (\d+) · (.+)$/, (_, n, x) => `Level ${n} · ${g(x)}`], [/^(\d+)\/(\d+) activas$/, (_, a, b) => `${a}/${b} active`],
    [/^hace (\d+) ?(s|min|h)$/, (_, n, u) => `${n}${u} ago`],
  ];

  // Bordes que no se traducen (emojis, flechas, signos)
  const EDGE = '\\s\\p{Extended_Pictographic}\\p{Emoji_Modifier}\\p{So}\\p{Sm}\\u{1F1E6}-\\u{1F1FF}\\uFE0F\\u200D\\u20E3·•|*';
  const SPLIT = new RegExp(`^([${EDGE}.:…/@]*)([\\s\\S]*?)([${EDGE}@]*)$`, 'u');
  const VARS = { usuario: 'user', regalo: 'gift', cantidad: 'amount', monedas: 'coins', diamantes: 'diamonds', nivel: 'level', mensaje: 'message', premio: 'prize', espectadores: 'viewers' };
  const NUM = /\d+(?:[.,]\d+)*/g;
  const cache = new Map();
  // Las claves que empiezan o terminan con emoji también se guardan por su núcleo,
  // porque el traductor busca el texto sin emojis ni signos en los bordes.
  for (const k of Object.keys(D)) {
    const mk = k.match(SPLIT), mv = String(D[k]).match(SPLIT);
    if (mk && mk[2] && mk[2] !== k && !(mk[2] in D)) D[mk[2]] = mv ? mv[2] : D[k];
  }
  let lang = 'es';
  const q = new URLSearchParams(location.search).get('lang');

  function look(core) {
    if (core in D) return D[core];
    const nums = []; const k = core.replace(NUM, x => (nums.push(x), '#'));
    if (nums.length && k in D) { let i = 0; return D[k].replace(/#/g, () => nums[i++] ?? '#'); }
    const tail = core.match(/^(.*?)([:.…]+)$/s);
    if (tail && tail[1] && tail[1] in D) return D[tail[1]] + tail[2];
    if (core === core.toUpperCase() && /\p{Lu}/u.test(core)) { const c = core[0] + core.slice(1).toLowerCase(); if (c in D) return D[c].toUpperCase(); }
    for (const [re, f] of R) if (re.test(core)) return core.replace(re, f);
    return null;
  }
  function tr(s) {
    if (lang === 'es' || s == null) return s;
    s = String(s);
    if (!/\p{L}/u.test(s)) return s;
    if (cache.has(s)) return cache.get(s);
    const m = s.match(SPLIT); let out = s;
    if (m && m[2]) { const t = look(m[2]); if (t != null) out = m[1] + t + m[3]; }
    out = out.replace(/\{(usuario|regalo|cantidad|monedas|diamantes|nivel|mensaje|premio|espectadores)\}/g, (x, k) => '{' + VARS[k] + '}');
    if (cache.size > 5000) cache.clear();
    cache.set(s, out);
    return out;
  }

  // ── Aplicar al DOM
  const SKIP = new Set(['SCRIPT', 'STYLE', 'TEXTAREA', 'CODE', 'PRE', 'NOSCRIPT']);
  const ATTRS = ['placeholder', 'title', 'aria-label', 'data-tip'];
  function skipEl(el) { return !el || SKIP.has(el.tagName) || el.isContentEditable || el.closest?.('[data-noi18n]'); }
  function doText(n) {
    const v = n.nodeValue; if (!v || !v.trim()) return;
    if (n.__tr !== undefined && v === n.__tr) { if (lang === 'es') { n.__tr = undefined; n.nodeValue = n.__src; } return; }
    if (skipEl(n.parentElement)) return;
    n.__src = v; n.__tr = undefined;
    const t = tr(v); if (t !== v) { n.__tr = t; n.nodeValue = t; }
  }
  function doAttrs(el) {
    if (skipEl(el)) return;
    for (const a of ATTRS) {
      if (!el.hasAttribute(a)) continue;
      const v = el.getAttribute(a); el.__a = el.__a || {};
      const st = el.__a[a];
      if (st && v === st.tr) { if (lang === 'es') { delete el.__a[a]; el.setAttribute(a, st.src); } continue; }
      const t = tr(v); if (t !== v) { el.__a[a] = { src: v, tr: t }; el.setAttribute(a, t); } else delete el.__a[a];
    }
    if (el.tagName === 'INPUT' && /^(button|submit)$/i.test(el.type)) {
      const v = el.value, st = el.__v;
      if (st && v === st.tr) { if (lang === 'es') { el.__v = null; el.value = st.src; } }
      else { const t = tr(v); if (t !== v) { el.__v = { src: v, tr: t }; el.value = t; } }
    }
  }
  function walk(root) {
    if (!root) return;
    if (root.nodeType === 3) return doText(root);
    if (root.nodeType !== 1 && root.nodeType !== 9 && root.nodeType !== 11) return;
    if (root.nodeType === 1) { if (SKIP.has(root.tagName)) return; doAttrs(root); }
    const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT | NodeFilter.SHOW_ELEMENT, {
      acceptNode: n => n.nodeType === 1 && SKIP.has(n.tagName) ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT,
    });
    let n; while ((n = w.nextNode())) n.nodeType === 3 ? doText(n) : doAttrs(n);
  }
  const mo = new MutationObserver(list => {
    for (const m of list) {
      if (m.type === 'characterData') doText(m.target);
      else if (m.type === 'attributes') doAttrs(m.target);
      else m.addedNodes.forEach(walk);
    }
  });
  let docTitle = null;
  function setLang(l) {
    l = l === 'en' ? 'en' : 'es';
    if (l === lang) return;
    lang = l; cache.clear();
    document.documentElement.lang = l;
    if (docTitle == null) docTitle = document.title;
    document.title = tr(docTitle);
    walk(document.body);
    window.dispatchEvent(new CustomEvent('chispa:lang', { detail: l }));
  }
  function start() {
    mo.observe(document.body, { childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: [...ATTRS, 'value'] });
    if (!q && window.CFG?.lang) setLang(window.CFG.lang);
  }
  if (document.body) start(); else document.addEventListener('DOMContentLoaded', start);
  // Cuadros del navegador
  const _c = window.confirm.bind(window), _p = window.prompt.bind(window), _a = window.alert.bind(window);
  window.confirm = m => _c(tr(m)); window.prompt = (m, d) => _p(tr(m), d); window.alert = m => _a(tr(m));
  // El idioma viene de la configuración
  // (?lang=en en el link de un overlay fuerza el idioma)
  try { if (typeof socket !== 'undefined') socket.on('config', c => { if (!q) setLang(c?.lang); }); } catch (e) {}
  if (q) setTimeout(() => setLang(q), 0);
  window.i18n = { tr, setLang, get lang() { return lang; }, D };
})();
