// ===== Estudios de cada juego: definición + editor genérico =====
// Cada juego describe sus controles, temporizador, lista y pestañas de ajustes.
// El editor guarda solo (auto-guardado) en config.games[clave].

const ANIM_OPTS = [['', 'Mi estilo', 'el de "Mi estilo"'], ...Object.entries(ANIMS).map(([k, n]) => [k, n])];
const nowSrv = () => nowMs();
const clone = o => JSON.parse(JSON.stringify(o));
const PRESETS = [['none', '🔇 Ninguno'], ...Object.entries(SFX)];
const EFFECTS = [['none', 'Ninguno'], ['shake', '📳 Temblor'], ['flash', '⚡ Flash'], ['zoom', '🔍 Zoom']];

// ---------- Constructores de campos ----------
const F = {
  text: (path, label, ph = '', desc = '') => ({ t: 'text', path, label, ph, desc }),
  area: (path, label, ph = '', desc = '', rows = 8) => ({ t: 'area', path, label, ph, desc, rows }),
  num: (path, label, min = 0, max = 999999, desc = '') => ({ t: 'step', path, label, min, max, step: 1, unit: '', desc }),
  step: (path, label, min, max, step = 1, unit = '', desc = '', o = {}) => ({ t: 'step', path, label, min, max, step, unit, desc, ...o }),
  range: (path, label, min, max, step = 1, unit = 's', desc = '') => ({ t: 'range', path, label, min, max, step, unit, desc }),
  toggle: (path, label, desc = '', o = {}) => ({ t: 'toggle', path, label, desc, ...o }),
  chips: (path, label, opts, desc = '') => ({ t: 'chips', path, label, opts, desc }),
  image: (path, label, desc = '') => ({ t: 'image', path, label, desc }),
  colors: () => ({ t: 'colors' }),
  entry: () => ({ t: 'entry' }),
  sounds: list => ({ t: 'sounds', list }),
  evo: o => ({ t: 'evo', ...o }),
  note: html => ({ t: 'note', html }),
  tiles: (path, label) => ({ t: 'tiles', path, label }),
  history: () => ({ t: 'history' }),
  group: (label, fields) => ({ t: 'group', label, fields }),
  teams: (o = {}) => ({ t: 'teams', ...o }),
  questions: () => ({ t: 'questions' }),
  gift: (path, label, desc = '', o = {}) => ({ t: 'gift', path, label, desc, ...o }),
  buttons: list => ({ t: 'buttons', list }),
};
const design = (variants, o = {}) => ({
  id: 'diseno', label: '🎨 Diseño', fields: [
    ...(o.title === false ? [] : [F.text('title', 'Título en pantalla', 'Ej: Subasta de Esnupi')]),
    ...(o.image === false ? [] : [F.image('image', 'Imagen o GIF propio', o.imgDesc || 'Se muestra en el overlay. Sube un PNG o GIF para que se vea único.')]),
    ...(variants ? [F.chips('variant', 'Estilo del overlay', variants)] : []),
    F.chips('anim', 'Animación de entrada', ANIM_OPTS),
    F.group('📐 Posición y tamaño', [
      F.range('scale', 'Tamaño', 50, 200, 5, '%'),
      F.range('x', '↔ Mover horizontal', -600, 600, 10, ' px'),
      F.range('y', '↕ Mover vertical', -600, 600, 10, ' px'),
    ]),
    F.toggle('colors.custom', 'Colores propios', 'Usa colores distintos a "Mi estilo" solo en este juego', { icon: '🎨', color: 'vio', sub: [F.colors()] }),
    F.toggle('effects.confetti', 'Confeti', 'En victorias, premios y regalos grandes', { icon: '🎉', color: 'gold' }),
    F.toggle('effects.glow', 'Brillo y pulso', 'Bordes de luz y latido en momentos épicos', { icon: '✨', color: 'pink' }),
    F.toggle('effects.shake', 'Temblor', 'La pantalla tiembla en eliminaciones y evoluciones', { icon: '📳', color: 'red' }),
  ],
});
const soundsTab = list => ({ id: 'sonidos', label: '🔊 Sonidos', fields: [F.sounds(list)] });
const evoTab = o => ({ id: 'evo', label: '🧬 Evoluciones', fields: [F.evo(o)] });
const histTab = () => ({ id: 'hist', label: '📜 Historial', fields: [F.history()] });
const entryTab = (desc, extra = []) => ({ id: 'entrada', label: '🙋 Entrada', fields: [F.note(desc), F.entry(), ...extra] });

// ---------- Definición de cada juego ----------
const STUDIOS = {
  subasta: {
    icon: '🔨', name: 'Live Auction', overlay: 'subasta', group: 'Juegos',
    desc: 'Los viewers pujan con regalos (o como tú elijas). Gana quien más acumule antes de que acabe el tiempo.',
    status: s => ({ idle: ['Esperando', ''], running: ['En curso', 'live'], paused: ['En pausa', 'warn'], ended: ['Terminada', 'done'] })[s.subasta.status],
    stats: s => [['👥', s.subasta.bids.length], ['🪙', s.subasta.total.toLocaleString('es')]],
    controls: s => [
      ['start', s.subasta.status === 'paused' ? '▶ Reanudar' : '▶ Iniciar', 'go'],
      ['pause', '⏸ Pausar', 'warn', s.subasta.status !== 'running'],
      ['end', '⏹ Terminar ya', 'vio', !['running', 'paused'].includes(s.subasta.status)],
      ['reset', '↺ Reiniciar', 'danger'],
    ],
    timer: { path: 'duration', label: 'Duración', ms: s => s.subasta.status === 'running' ? s.subasta.endsAt - nowSrv() : s.subasta.status === 'paused' ? s.subasta.left : null },
    gifts: 'entry.gift', giftTap: 'min',
    list: {
      title: '🏅 Pujas', add: 'Agregar puja a mano', amount: '🪙', remove: true,
      empty: ['Todavía no hay pujas', 'Inicia la subasta. Los viewers pujan con regalos o puedes agregarlos a mano.'],
      rows: s => { const t = s.subasta.total || 1; return s.subasta.bids.map(b => ({ id: b.user.id, user: b.user, value: `${b.diamonds} 🪙`, pct: Math.round(b.diamonds / t * 100) })); },
    },
    tabs: [
      { id: 'modo', label: '⚙️ Modo', fields: [
        F.text('item', '¿Qué se subasta?', 'Ej: Elegir mi próximo skin'),
        F.step('instantWin', 'Victoria instantánea', 0, 1e7, 50, 'monedas', 'Si alguien llega a esta cantidad gana al momento.', { icon: '⚡', zero: 'Off' }),
        F.range('snipeSeconds', '🛡️ Anti-sniper: si quedan menos de', 0, 30, 1, 's', 'Evita que alguien gane en el último segundo.'),
        F.range('snipeAdd', '…se suman', 5, 60, 5, 's'),
        F.range('showTop', 'Pujadores en pantalla', 3, 10, 1, ''),
      ] },
      entryTab('¿Con qué se puja? Activa varias formas: regalos, comando en el chat, likes, follows o shares.'),
      { id: 'pantalla', label: '👁 Pantalla', fields: [
        F.toggle('display.pct', 'Porcentajes', 'El % de cada pujador', { icon: '📊', color: 'green' }),
        F.toggle('display.minBid', 'Insignia de puja mínima', 'Muestra la puja mínima en el overlay', { icon: '🪙', color: 'gold' }),
        F.toggle('display.stats', 'Estadísticas', 'Pujadores y monedas totales', { icon: '📈', color: 'vio' }),
        F.toggle('display.chat', 'Comando del chat', 'Muestra el comando para pujar', { icon: '💬', color: 'blue' }),
      ] },
      soundsTab([['entry', 'Puja', 'Suena con cada puja', '🪙', true], ['snipe', 'Anti-sniper', 'Cuando se suma tiempo', '🛡️'], ['tick', 'Últimos 10 segundos', 'Cuenta regresiva', '⏱'], ['winner', 'Ganador', 'Al terminar la subasta', '🏆']]),
      histTab(),
      design([['tarjeta', 'Tarjeta', 'ranking con %'], ['podio', 'Podio', 'top 3 en escalones'], ['compacta', 'Compacta', 'una sola línea']]),
    ],
  },

  royale: {
    icon: '👑', name: 'Spin Royale', overlay: 'royale', group: 'Juegos',
    desc: 'Los viewers entran por regalo, chat, likes o follow. La ruleta elimina por rondas (o elige al ganador de un giro).',
    status: s => ({ idle: ['Esperando', ''], joining: [s.royale.waiting ? 'Esperando jugadores' : s.royale.paused ? 'Inscripción en pausa' : 'Inscripciones abiertas', s.royale.paused || s.royale.waiting ? 'warn' : 'live'], playing: [s.royale.paused ? 'En pausa' : 'Jugando', s.royale.paused ? 'warn' : 'live'], finished: ['Terminado', 'done'] })[s.royale.phase],
    stats: s => [['👥', s.royale.players.length], ['🪙', s.royale.players.reduce((a, p) => a + p.coins, 0).toLocaleString('es')]],
    controls: s => {
      const R = s.royale;
      return [
        ['open', '📋 Abrir inscripciones', 'pri', R.phase === 'joining' || R.phase === 'playing'],
        ['start', '▶ ¡Empezar!', 'go', R.phase !== 'joining'],
        ['pause', R.paused ? '▶ Reanudar' : '⏸ Pausar', 'warn', !(R.phase === 'playing' || (R.phase === 'joining' && (R.joinEndsAt || R.paused)))],
        ['spin', '🎡 Girar ya', 'vio', !(R.phase === 'playing' || R.phase === 'joining') || R.spinning],
        ['reset', '↺ Reiniciar', 'danger'],
      ];
    },
    timer: { path: 'joinSeconds', label: 'Tiempo para unirse', zero: 'Sin límite (empiezas tú)', ms: s => s.royale.phase === 'joining' ? (s.royale.joinEndsAt ? s.royale.joinEndsAt - nowSrv() : s.royale.paused ? s.royale.joinLeft : null) : null },
    gifts: 'entry.gift', giftTap: 'min',
    list: {
      title: '👥 Jugadores', add: 'Agregar jugador a mano', amount: '🪙', remove: true,
      empty: ['Aún no hay jugadores', 'Abre las inscripciones. Entran con un regalo o con el comando del chat.'],
      rows: s => s.royale.players.map(p => ({ id: p.id, user: p, value: `${p.coins} 🪙${p.slots > 1 ? ` ×${p.left}` : ''}`, out: s.royale.eliminated.includes(p.id), win: s.royale.winner?.id === p.id })),
    },
    tabs: [
      { id: 'modo', label: '⚡ Modos', fields: [
        F.chips('variant', 'Modo de vista', [['arena', '🏟️ Arena', 'personajes + temporizador'], ['ruleta', '🎡 Ruleta'], ['cuadricula', '▦ Cuadrícula'], ['piramide', '🔺 Pirámide', 'el que más regala arriba'], ['hex', '⬢ Hexágono']]),
        F.chips('mode', 'Tipo de partida', [['eliminacion', '💥 Eliminación', 'uno sale por ronda'], ['ganador', '🏆 Ganador directo', 'un giro y listo']]),
        F.step('interval', 'Tiempo entre giros', 2, 120, 1, 'seg', 'Espera después de cada eliminación antes del siguiente giro', { icon: '⏱' }),
        F.toggle('locked', 'Inscripción bloqueada', 'Congela la lista al empezar: nadie nuevo entra durante el juego', { icon: '🔒', color: 'gold' }),
        F.toggle('mass.on', 'Eliminaciones masivas', 'Saca a varios por ronda hasta que queden pocos', { icon: '✂️', color: 'red', sub: [
          F.step('mass.cut', 'Eliminar', 2, 50, 1, '/ ronda'), F.step('mass.until', 'Hasta que queden', 2, 50, 1, 'jugadores'),
        ] }),
        F.toggle('crowd', 'Partidas grandes', 'Con más de 20 vivos saca a varios por ronda (si no, 100 personas tardarían 20 minutos)', { icon: '🚀', color: 'vio' }),
        F.step('minPlayers', 'Mínimo de participantes', 0, 200, 1, '', 'El tiempo de inscripción arranca cuando se juntan N jugadores', { icon: '👥', zero: 'Off' }),
        F.toggle('weighted', 'Ventaja por monedas', 'Más monedas = porción más grande para ganar (o más chica para salir eliminado)', { icon: '🎯', color: 'vio' }),
        F.toggle('multi', 'Entradas múltiples', 'Más monedas = más casillas. Cada "puja mínima" de monedas es una casilla', { icon: '📚', color: 'gold', sub: [
          F.step('maxEntries', 'Máx. casillas por jugador', 0, 100, 1, '', '', { zero: 'Sin límite' }),
        ] }),
        F.step('instantWin', 'Victoria instantánea', 0, 1e7, 10, 'monedas', 'Un solo regalo de este valor gana al momento', { icon: '⚡', zero: 'Off' }),
        F.toggle('autoStart', 'Auto-girar', 'Empieza solo cuando se acaba el tiempo de inscripción', { icon: '🔁', color: 'gold' }),
        F.range('spinSeconds', 'Velocidad del giro', 2, 12),
      ] },
      entryTab('¿Cómo entra la gente? Combina regalo, comando, likes, follow o compartir. Los regalos además suman monedas al jugador.', [
        F.step('maxPlayers', 'Máximo de jugadores', 0, 500, 1, '', 'Al llenarse, aparece LLENO y los nuevos no entran', { icon: '👥', zero: 'Sin límite' }),
      ]),
      { id: 'pantalla', label: '👁 Pantalla', fields: [
        F.toggle('display.minBid', 'Insignia de puja mínima', 'Muestra la puja mínima en el overlay', { icon: '👁', color: 'green' }),
        F.toggle('display.winnerCoins', 'Monedas del ganador', 'Muestra sus monedas en la pantalla final', { icon: '🏆', color: 'green' }),
        F.toggle('display.players', 'Lista de jugadores', 'Fichas de jugadores debajo de la ruleta', { icon: '👥', color: 'green' }),
        F.toggle('display.duel', 'Banner de duelo 1 vs 1', 'Un cara a cara cuando quedan dos', { icon: '⚔️', color: 'red' }),
        F.toggle('display.stats', 'Estadísticas', 'Jugadores, vivos y monedas', { icon: '📈', color: 'vio' }),
      ] },
      soundsTab([['spin', 'Giro', 'Tic de la ruleta', '🎡'], ['entry', 'Entrada', 'Cuando alguien entra o suma monedas', '🙋', true], ['elimination', 'Eliminación', 'Cuando alguien sale', '💥'], ['duel', 'Duelo', 'Cuando quedan dos', '⚔️'], ['winner', 'Ganador', 'Al coronar al ganador', '🏆']]),
      histTab(),
      design(null),
    ],
  },

  ruleta: {
    icon: '🎡', name: 'Ruleta de acciones', overlay: 'ruleta', group: 'Juegos', onoff: true,
    desc: 'Crea varias ruedas. Cada una se activa con su propio regalo o comando y cada porción puede lanzar una acción: sonido, voz o mensaje.',
    status: s => s.ruleta.queue ? [`${s.ruleta.queue} en fila`, 'live'] : ['Lista', ''],
    stats: s => [['🎡', `${(cfgG('ruleta').wheels || []).filter(w => w.on).length} ruedas`], ['⏳', s.ruleta.queue]],
    controls: () => [['test', '🎡 Girar rueda 1', 'go', false, { wi: 0 }], ['clear', '🧹 Vaciar fila', 'danger']],
    wheels: true,
    tabs: [
      { id: 'modo', label: '🎡 Rueda', fields: [
        F.group('⏱ Tiempos', [
          F.range('announceSeconds', 'Anuncio antes de girar', 0, 10), F.range('spinSeconds', 'Duración del giro', 2, 30),
          F.range('resultSeconds', 'Resultado en pantalla', 2, 15), F.range('waitSeconds', 'Pausa entre giros', 0, 10),
        ]),
        F.step('turns', 'Vueltas', 0, 30, 1, '', 'Cuántas vueltas da antes de parar', { icon: '🌀', zero: 'Al azar (6-8)' }),
        F.toggle('showBase', 'Mostrar base', 'La ruleta aparece sobre un pedestal', { icon: '🏛️', color: 'vio' }),
        F.toggle('hideIdle', 'Ocultar hasta que gire', 'Solo aparece cuando alguien la activa', { icon: '🙈', color: 'blue' }),
        F.range('size', 'Tamaño de la ruleta', 50, 160, 5, '%'),
        F.range('fontSize', 'Tamaño de letra', 50, 160, 5, '%'),
        F.chips('center', 'Ícono del centro', [['avatar', '👤 Foto del viewer'], ['logo', '⚡ Mi logo'], ['image', '🖼️ Imagen del juego'], ['none', '✖ Ninguno']]),
        F.range('iconSize', 'Tamaño del ícono', 8, 40, 1, '%'),
      ] },
      soundsTab([['announce', 'Anuncio', 'Cuando alguien activa la rueda', '📢'], ['spin', 'Giro', 'Tic mientras gira', '🎡'], ['result', 'Resultado', 'Cuando sale la porción (si no tiene sonido propio)', '🎯']]),
      histTab(),
      design([['clasica', 'Clásica', 'colores llenos'], ['neon', 'Neón', 'líneas de luz'], ['pastel', 'Pastel', 'colores suaves']], { imgDesc: 'Se puede usar como ícono del centro.' }),
    ],
  },

  lucky: {
    icon: '🎲', name: 'Lucky Roll', overlay: 'lucky', group: 'Juegos', onoff: true,
    desc: 'Dos modos: 🎲 Dado de la suerte o 🎁 Cofre de premios (se abre el cofre, gira una cinta y sale un premio según su %).',
    status: s => [cfgG('lucky').mode === 'cofre' ? 'Cofre listo' : 'Dado listo', ''],
    stats: s => [['🏆', (s.history?.lucky || []).length]],
    controls: () => [['roll', cfgG('lucky').mode === 'cofre' ? '🎁 Abrir cofre ahora' : '🎲 Tirar ahora', 'go'], ['test', '▶ Probar', 'vio']],
    gifts: 'entry.gift', giftsTitleFn: g => g.mode === 'cofre' ? '🎁 Activador global (gira todos los premios)' : '🎁 Regalos que cuentan',
    odds: { path: 'faces', title: '🎲 Caras del dado y probabilidades', label: 'Premio', ph: 'Premio o reto', numbered: true, when: g => g.mode !== 'cofre' },
    prizes: true,
    tabs: [
      { id: 'modo', label: '⚙️ Modo', fields: [
        F.chips('mode', 'Tipo de juego', [['dado', '🎲 Dado', 'número con premio'], ['cofre', '🎁 Cofre de premios', 'cinta con % por premio']]),
        { ...F.chips('sides', 'Caras del dado', [4, 6, 8, 10, 12, 20].map(n => [n, `D${n}`])), when: g => g.mode !== 'cofre' },
        { ...F.range('rollSeconds', 'Tiempo rodando', 1, 8, 0.5), when: g => g.mode !== 'cofre' },
        { ...F.range('showSeconds', 'Premio en pantalla', 2, 12), when: g => g.mode !== 'cofre' },
        { ...F.toggle('global', 'Activador global', 'Encendido: el regalo de "Activador global" gira todos los premios con su %. Apagado: cada premio solo se gana con su propio regalo.', { icon: '🌍', color: 'green' }), when: g => g.mode === 'cofre' },
        { ...F.chips('idle', 'Pantalla de espera', [['vitrina', '🏺 Vitrina', 'cofre flotando'], ['cinta', '🎞️ Cinta', 'cofre + premios pasando'], ['cuadricula', '▦ Cuadrícula', 'todos los premios']]), when: g => g.mode === 'cofre' },
        { ...F.chips('chest', 'Estilo del cofre', [['cofre', '🪵 Madera'], ['regalo', '🎀 Regalo'], ['misterio', '❓ Misterio'], ['tragamonedas', '🎰 Tragamonedas'], ['cristal', '💎 Cristal'], ['neon', '✨ Neón']]), when: g => g.mode === 'cofre' },
        { ...F.toggle('openAnim', 'Animación de abrir', 'El cofre tiembla y se abre antes de girar', { icon: '📦', color: 'gold', sub: [F.range('openSeconds', 'Velocidad de apertura', 0.5, 5, 0.1)] }), when: g => g.mode === 'cofre' },
        { ...F.range('spinSeconds', 'Duración del giro', 2, 12, 0.5), when: g => g.mode === 'cofre' },
        { ...F.range('textSize', 'Tamaño del texto', 60, 160, 5, '%'), when: g => g.mode === 'cofre' },
        { ...F.range('imgSize', 'Tamaño de la imagen', 50, 160, 5, '%'), when: g => g.mode === 'cofre' },
        { ...F.text('nothing.label', 'Texto de "Nada"', 'Nada 😢'), when: g => g.mode === 'cofre' },
        { ...F.tiles('nothing.tile', 'Fondo de "Nada"'), when: g => g.mode === 'cofre' },
        { ...F.toggle('showWinner', 'Mostrar nombre del ganador', '', { icon: '🏆', color: 'green' }), when: g => g.mode === 'cofre' },
        { ...F.toggle('publicOdds', 'Mostrar % al público', 'Apagado: solo tú ves las probabilidades aquí en el panel. Encendido: salen en las casillas del overlay.', { icon: '👁️', color: 'red' }), when: g => g.mode === 'cofre' },
        { ...F.range('hideSeconds', 'Ocultar el premio después de', 2, 15), when: g => g.mode === 'cofre' },
        F.chips('rolls.mode', 'Tiradas por regalo', [['coins', '🪙 Según sus monedas', 'Doughnut = 30 tiradas'], ['gift', '🎁 Una por regalo', 'racha x5 = 5 tiradas']]),
        { ...F.step('rolls.every', 'Cada cuántas monedas = 1 tirada', 1, 1000, 1, 'monedas'), when: g => g.rolls?.mode !== 'gift' },
        F.step('rolls.max', 'Máximo de tiradas por regalo', 1, 200, 1, 'tiradas'),
        F.toggle('rolls.fast', 'Tiradas seguidas rápidas', 'Desde la 2ª tirada de la misma persona, gira más rápido para no hacer esperar', { icon: '⚡', color: 'gold' }),
      ] },
      entryTab('¿Qué activa el juego? En modo cofre, esto es el activador global; además cada premio puede tener su propio regalo.'),
      soundsTab([['roll', 'Rodando / cinta', 'Tic mientras gira', '🎲'], ['result', 'Premio (dado)', 'Premio normal del dado', '🎁'], ['jackpot', 'Premio ganado', 'Jackpot del dado o premio del cofre', '💰'], ['open', 'Abrir cofre', 'Al temblar el cofre', '📦'], ['nothing', 'Nada', 'Cuando no sale premio', '💨']]),
      histTab(),
      design([['dado', 'Dado', 'blanco clásico'], ['neon', 'Neón', 'número brillante']]),
    ],
  },

  jar: {
    icon: '🫙', name: 'Frasco de regalos', overlay: 'frasco', group: 'Juegos', isNew: true, portrait: true, onoff: true,
    desc: 'Cada regalo cae dentro del frasco con física real. El frasco evoluciona por niveles y al llegar a la meta: ¡celebración!',
    status: s => [s.jar.total >= (cfgG('jar').goal || Infinity) ? '¡Lleno!' : 'Llenándose', s.jar.total ? 'live' : ''],
    stats: s => [['🫙', s.jar.count], ['🪙', `${s.jar.total.toLocaleString('es')} / ${(cfgG('jar').goal || 0).toLocaleString('es')}`]],
    controls: () => [['test', '🎁 Soltar regalo de prueba', 'go'], ['empty', '🫙 Vaciar frasco', 'danger']],
    gifts: 'entry.gift',
    list: { title: '🪙 Agregar a mano', add: 'Nombre', amount: '🪙', rows: s => s.jar.top.map(r => ({ id: r.user.id, user: r.user, value: `${r.value.toLocaleString('es')} 🪙` })), empty: ['Suma monedas al frasco', 'Útil para donaciones por fuera (Yape, PayPal…).'] },
    tabs: [
      { id: 'modo', label: '🎯 Meta', fields: [
        F.step('goal', 'Meta del frasco', 1, 1e8, 100, 'monedas', '', { icon: '🎯' }),
        F.toggle('emptyOnGoal', 'Vaciar al llenarse', 'Empieza de nuevo cuando llega a la meta', { icon: '♻️', color: 'gold' }),
        F.toggle('showCount', 'Contador y %', 'Barra de progreso debajo del frasco', { icon: '📊', color: 'green' }),
        F.toggle('dropAlert', 'Aviso de quién regaló', 'Muestra "nombre +100" al caer algo', { icon: '🔔', color: 'pink' }),
        F.toggle('showTop', 'Ranking del frasco', 'Los que más llenaron el frasco', { icon: '🏆', color: 'vio', sub: [F.step('topCount', 'Puestos', 1, 10, 1, '')] }),
      ] },
      entryTab('¿Qué cae al frasco? Los regalos caen con su imagen; likes, follows y shares caen como ❤️ ⭐ 📣.'),
      soundsTab([['drop', 'Caída', 'Cuando cae algo', '🪙', true], ['full', 'Frasco lleno', 'Al llegar a la meta', '🎉']]),
      evoTab({ unit: 'monedas', variants: true, desc: 'El frasco evoluciona: al llegar a X monedas cambia de diseño (por ejemplo, de vidrio a cofre) con banner, sonido y efecto.' }),
      histTab(),
      design([['vidrio', 'Vidrio', 'frasco clásico'], ['neon', 'Neón', 'contorno de luz'], ['cofre', 'Cofre', 'tesoro pirata'], ['caldero', 'Caldero', 'de bruja'], ['pecera', 'Pecera', 'con agua']]),
    ],
  },

  batalla: {
    icon: '⚔️', name: 'Batalla de equipos', overlay: 'batalla', group: 'Juegos', isNew: true, onoff: true,
    desc: 'El live se divide en equipos. Cada equipo tiene su regalo y su comando del chat: quien más puntos junte antes de que acabe el tiempo, ¡gana!',
    status: s => ({ idle: ['Esperando', ''], running: [s.batalla.double ? '¡Puntos x2!' : '¡En batalla!', 'live'], paused: ['En pausa', 'warn'], ended: ['Terminada', 'done'] })[s.batalla.status],
    stats: s => s.batalla.teams.map(t => [t.emoji || '⚔️', t.score.toLocaleString('es')]),
    controls: s => [
      ['start', s.batalla.status === 'paused' ? '▶ Reanudar' : s.batalla.status === 'running' ? '🔁 Nueva batalla' : '▶ Iniciar batalla', 'go', s.batalla.status === 'running'],
      ['pause', '⏸ Pausar', 'warn', s.batalla.status !== 'running'],
      ['end', '⏹ Terminar ya', 'vio', s.batalla.status !== 'running' && s.batalla.status !== 'paused'],
      ['reset', '↺ Reiniciar', 'danger', false, { confirm: '¿Reiniciar la batalla? Se borran los puntos de todos los equipos.' }],
    ],
    timer: { path: 'duration', label: 'Duración de la batalla', ms: s => s.batalla.status === 'running' ? s.batalla.endsAt - nowSrv() : s.batalla.status === 'paused' ? s.batalla.left : null },
    list: { title: '🏆 Los que más aportan', rows: s => s.batalla.teams.flatMap(t => t.top.map(r => ({ id: r.user.id, user: r.user, value: `${t.emoji || ''} ${r.value.toLocaleString('es')}` }))).sort((a, b) => parseInt(b.value.replace(/\D/g, '')) - parseInt(a.value.replace(/\D/g, ''))).slice(0, 10),
      empty: ['Nadie ha sumado todavía', 'Inicia la batalla: los regalos de cada equipo suman solos.'] },
    tabs: [
      { id: 'equipos', label: '⚔️ Equipos', fields: [
        F.note('Cada equipo tiene <b>su regalo</b> (siempre le suma) y <b>su comando</b> del chat para unirse. Puedes tener de 2 a 4 equipos.'),
        F.teams(),
        F.chips('points', '¿Qué suma puntos?', [['coins', '🪙 Monedas', 'el valor del regalo'], ['count', '🎁 Regalos', '1 punto por regalo']]),
        F.toggle('anyGift', 'Cualquier regalo cuenta', 'Si alguien se unió con el comando del chat, todos sus regalos suman a su equipo', { icon: '🎁', color: 'gold' }),
        F.toggle('likes.on', 'Los likes también suman', 'Solo de los que ya están en un equipo', { icon: '👍', color: 'pink', sub: [F.step('likes.every', 'Cada', 10, 100000, 10, 'likes'), F.step('likes.value', 'Valen', 1, 100000, 1, 'puntos')] }),
        F.toggle('double.on', 'Puntos x2 al final', 'En los últimos segundos todo vale el doble: ¡remontadas!', { icon: '🔥', color: 'red', sub: [F.step('double.seconds', 'Últimos', 5, 600, 5, 'segundos')] }),
        F.toggle('showTop', 'Mostrar top de cada equipo', 'Los 3 que más aportan debajo de cada equipo', { icon: '🏆', color: 'vio' }),
        F.step('winnerSeconds', 'Mostrar al ganador', 3, 120, 1, 'segundos', '', { icon: '👑' }),
      ] },
      soundsTab([['start', 'Empieza', 'Al iniciar la batalla', '🔔'], ['point', 'Punto', 'Cada vez que un equipo suma', '🪙'], ['lead', 'Cambio de líder', 'Cuando un equipo pasa adelante', '💨'], ['double', 'Puntos x2', 'Al empezar el tiempo doble', '🔥'], ['win', 'Ganador', 'Al terminar', '🏆']]),
      histTab(),
      design([['tira', 'Tira', 'barra que se empuja'], ['versus', 'Versus', 'tarjetas frente a frente']]),
    ],
  },

  subathon: {
    icon: '⏰', name: 'Subathon', overlay: 'subathon', group: 'Widgets', isNew: true, onoff: true,
    desc: 'Un reloj que va bajando: cada regalo, follow o super fan le suma tiempo. Si llega a cero, ¡se acaba el live! El reloj se guarda solo aunque cierres ChispaLive.',
    status: s => ({ idle: ['Sin empezar', ''], running: [s.subathon.mult === 2 ? '🔥 Tiempo x2' : 'Corriendo', 'live'], paused: ['En pausa', 'warn'], ended: ['Terminado', 'done'] })[s.subathon.status],
    stats: s => [['➕', subFmt(s.subathon.added)], ['🙌', s.subathon.top.length]],
    controls: s => [
      ['start', s.subathon.status === 'paused' ? '▶ Reanudar' : '▶ Iniciar reloj', 'go', s.subathon.status === 'running'],
      ['pause', '⏸ Pausar', 'warn', s.subathon.status !== 'running'],
      ['x2', s.subathon.mult === 2 ? '✋ Quitar x2' : '🔥 Tiempo x2', 'vio', !['running', 'paused'].includes(s.subathon.status)],
      ['end', '⏹ Terminar', 'danger', !['running', 'paused'].includes(s.subathon.status), { confirm: '¿Terminar el subathon ahora? El reloj se detiene y sale la pantalla final.' }],
      ['reset', '↺ Reiniciar', 'danger', false, { confirm: '¿Reiniciar el subathon? Se borra el reloj y todo el tiempo sumado.' }],
    ],
    timer: { path: 'start', label: 'Tiempo del reloj', ms: s => s.subathon.status === 'running' ? s.subathon.endsAt - nowSrv() : s.subathon.status === 'paused' ? s.subathon.left : null },
    list: { title: '🙌 Los que más tiempo sumaron', rows: s => s.subathon.top.map(r => ({ id: r.user.id, user: r.user, value: `+${subFmt(r.value)}` })), empty: ['Nadie ha sumado tiempo todavía', 'Inicia el reloj: los regalos y follows suman solos.'] },
    tabs: [
      { id: 'tiempo', label: '⏱ Qué suma tiempo', fields: [
        F.note('Ejemplo: con <b>cada 1 moneda = 5 segundos</b>, una Rosa suma 5 s y una Galaxy (1000 monedas) suma 1 h 23 min.'),
        F.toggle('coins.on', 'Regalos', 'Según las monedas del regalo', { icon: '🎁', color: 'gold', sub: [F.step('coins.every', 'Cada', 1, 100000, 1, 'monedas'), F.step('coins.seconds', 'Suman', 1, 36000, 1, 'segundos')] }),
        F.toggle('follow.on', 'Seguidores', 'Cada follow nuevo', { icon: '💗', color: 'pink', sub: [F.step('follow.seconds', 'Suman', 1, 36000, 5, 'segundos')] }),
        F.toggle('sub.on', 'Super fans', 'Cada suscripción nueva', { icon: '👑', color: 'vio', sub: [F.step('sub.seconds', 'Suman', 1, 36000, 30, 'segundos')] }),
        F.toggle('share.on', 'Compartidos', 'Cada vez que comparten el live', { icon: '📣', color: 'blue', sub: [F.step('share.seconds', 'Suman', 1, 36000, 5, 'segundos')] }),
        F.toggle('likes.on', 'Likes', 'Cada N likes de un viewer', { icon: '👍', color: 'green', sub: [F.step('likes.every', 'Cada', 10, 1000000, 10, 'likes'), F.step('likes.seconds', 'Suman', 1, 36000, 5, 'segundos')] }),
        F.step('maxHours', 'Duración máxima', 0, 720, 1, 'horas', '0 = sin límite. Cuando el subathon llega a este total, ya no se suma más tiempo.', { icon: '🛑' }),
      ] },
      { id: 'pantalla', label: '🖥️ Pantalla', fields: [
        F.toggle('showAdded', 'Mostrar "+tiempo"', 'Sale "+30 s" cada vez que alguien suma', { icon: '➕', color: 'green' }),
        F.toggle('showLast', 'Último que sumó', 'Nombre de la última persona que sumó tiempo', { icon: '🙋', color: 'pink' }),
        F.toggle('showTotal', 'Tiempo total sumado', 'Cuánto tiempo extra se ha ganado', { icon: '📈', color: 'gold' }),
        F.text('endText', 'Mensaje al terminar', '¡Se acabó el subathon!'),
      ] },
      soundsTab([['add', 'Suma tiempo', 'Cada vez que alguien suma', '➕'], ['warn', 'Último minuto', 'Cuando queda 1 minuto', '⚠️'], ['x2', 'Tiempo x2', 'Al activar el tiempo doble', '🔥'], ['end', 'Se acabó', 'Cuando el reloj llega a cero', '⏰']]),
      histTab(),
      design([['reloj', 'Reloj', 'números grandes'], ['compacto', 'Compacto', 'píldora pequeña']]),
    ],
  },

  carrera: {
    icon: '🏁', name: 'Carrera de animales', overlay: 'carrera', group: 'Juegos', isNew: true, onoff: true,
    desc: 'Cada animal tiene su regalo y su comando. Los regalos lo empujan hacia la meta (1 moneda = 1 metro). ¡Gana el primero que llega!',
    status: s => ({ idle: ['Esperando', ''], running: ['¡Corriendo!', 'live'], paused: ['En pausa', 'warn'], ended: ['Terminada', 'done'] })[s.carrera.status],
    stats: s => s.carrera.lanes.map(l => [l.emoji || '🏁', `${l.dist}/${s.carrera.goal}`]),
    controls: s => [
      ['start', s.carrera.status === 'paused' ? '▶ Reanudar' : '▶ ¡Largada!', 'go', s.carrera.status === 'running'],
      ['pause', '⏸ Pausar', 'warn', s.carrera.status !== 'running'],
      ['end', '🏁 Terminar ya', 'vio', !['running', 'paused'].includes(s.carrera.status)],
      ['event', '🎲 Evento sorpresa', 'pri', s.carrera.status !== 'running'],
      ['reset', '↺ Reiniciar', 'danger', false, { confirm: '¿Reiniciar la carrera? Todos vuelven a la salida.' }],
    ],
    list: { title: '🏆 Los que más empujan', rows: s => s.carrera.lanes.flatMap(l => l.top.map(r => ({ id: r.user.id + l.name, user: r.user, value: `${l.emoji || ''} ${r.value.toLocaleString('es')} m`, n: r.value }))).sort((a, b) => b.n - a.n).slice(0, 10),
      empty: ['Nadie ha empujado todavía', 'Dale a ¡Largada! y los regalos de cada animal lo hacen avanzar.'] },
    tabs: [
      { id: 'corredores', label: '🐎 Corredores', fields: [
        F.note('Cada corredor tiene <b>su regalo</b> (siempre lo empuja) y <b>su comando</b> para unirse. De 2 a 6 corredores.'),
        F.teams(),
        F.step('goal', 'Distancia de la meta', 50, 1000000, 50, 'metros', '1 moneda = 1 metro', { icon: '🏁' }),
        F.step('timeLimit', 'Tiempo límite', 0, 36000, 30, 'segundos', '0 = sin límite. Si se acaba, gana el que va adelante.', { icon: '⏱' }),
        F.toggle('anyGift', 'Cualquier regalo empuja', 'Si te uniste con el comando, todos tus regalos empujan a tu corredor', { icon: '🎁', color: 'gold' }),
        F.toggle('likes.on', 'Los likes también empujan', 'Solo de los que ya están con un corredor', { icon: '👍', color: 'pink', sub: [F.step('likes.every', 'Cada', 5, 100000, 5, 'likes'), F.step('likes.value', 'Avanza', 1, 10000, 1, 'metros')] }),
        F.step('autoRestart', 'Nueva carrera sola después de', 0, 600, 5, 'segundos', '0 = la empiezas tú', { icon: '🔁' }),
      ] },
      { id: 'poderes', label: '⚡ Poderes', fields: [
        F.note('Regalos especiales que cambian la carrera. El <b>turbo</b> y el <b>escudo</b> son para el animal de quien los manda (tiene que haberse unido antes). La <b>cáscara</b> le cae al que va primero.'),
        F.toggle('powers.on', 'Poderes activados', 'Apágalo para una carrera normal', { icon: '⚡', color: 'gold' }),
        F.toggle('powers.turbo.on', 'Turbo', 'Tu animal corre más rápido por unos segundos', { icon: '🚀', color: 'vio', sub: [
          F.gift('powers.turbo.gift', 'Regalo del turbo'), F.step('powers.turbo.seconds', 'Dura', 3, 120, 1, 'segundos'), F.step('powers.turbo.mult', 'Velocidad', 2, 5, 1, 'x')] }),
        F.toggle('powers.banana.on', 'Cáscara de plátano', 'El que va primero resbala y retrocede', { icon: '🍌', color: 'gold', sub: [
          F.gift('powers.banana.gift', 'Regalo de la cáscara'), F.step('powers.banana.back', 'Retrocede', 5, 100000, 5, 'metros')] }),
        F.toggle('powers.shield.on', 'Escudo', 'Protege a tu animal de una cáscara', { icon: '🛡️', color: 'pink', sub: [
          F.gift('powers.shield.gift', 'Regalo del escudo'), F.step('powers.shield.seconds', 'Dura', 5, 300, 5, 'segundos')] }),
        F.buttons([['power', '🚀 Probar turbo', 'vio', { type: 'turbo' }], ['power', '🍌 Probar cáscara', 'warn', { type: 'banana' }], ['power', '🛡️ Probar escudo', 'pri', { type: 'shield' }]]),
      ] },
      { id: 'sorpresas', label: '🎲 Sorpresas', fields: [
        F.note('Cada cierto tiempo pasa algo solo en la pista. También puedes lanzar uno cuando quieras con el botón <b>🎲 Evento sorpresa</b>.'),
        F.toggle('surprise.on', 'Eventos sorpresa', 'Pasan solos mientras corre la carrera', { icon: '🎲', color: 'vio', sub: [F.step('surprise.every', 'Cada', 10, 600, 5, 'segundos', 'Más o menos: varía un poco para que no se adivine')] }),
        F.toggle('surprise.wind', 'Viento a favor', 'Empuja al que va último', { icon: '🌪️', color: 'gold', sub: [F.step('surprise.windMeters', 'Avanza', 5, 100000, 5, 'metros')] }),
        F.toggle('surprise.rain', 'Lluvia', 'Todos corren a la mitad de velocidad', { icon: '🌧️', color: 'vio', sub: [F.step('surprise.rainSeconds', 'Dura', 3, 60, 1, 'segundos')] }),
        F.toggle('surprise.star', 'Estrella', 'Un animal al azar da un salto', { icon: '⭐', color: 'pink', sub: [F.step('surprise.starMeters', 'Salta', 5, 100000, 5, 'metros')] }),
        F.buttons([['event', '🌪️ Lanzar viento', 'warn', { kind: 'wind' }], ['event', '🌧️ Lanzar lluvia', 'vio', { kind: 'rain' }], ['event', '⭐ Lanzar estrella', 'pri', { kind: 'star' }]]),
      ] },
      soundsTab([['start', 'Largada', 'Al empezar', '🔔'], ['push', 'Empujón', 'Cada vez que alguien empuja', '🪙'], ['lead', 'Cambio de líder', 'Cuando alguien pasa adelante', '💨'], ['final', 'Recta final', 'Cuando un corredor llega al 80%', '🔥'], ['win', 'Ganador', 'Al cruzar la meta', '🏆'],
        ['turbo', 'Turbo', 'Cuando alguien activa el turbo', '🚀'], ['banana', 'Cáscara', 'Cuando un animal resbala', '🍌'], ['shield', 'Escudo', 'Cuando se activa o bloquea', '🛡️'], ['event', 'Evento sorpresa', 'Viento, lluvia o estrella', '🎲']]),
      histTab(),
      design([['pista', 'Pista', 'carriles de colores'], ['tierra', 'Tierra', 'hipódromo']]),
    ],
  },

  jefe: {
    icon: '👹', name: 'Derrota al jefe', overlay: 'jefe', group: 'Juegos', isNew: true, onoff: true,
    desc: 'Un jefe con barra de vida: los regalos, likes y follows le hacen daño. Se enoja al 50% y al 25%. Si lo derrotan, aparece uno más fuerte.',
    status: s => ({ idle: ['Esperando', ''], fighting: [`Nivel ${s.jefe.level}`, 'live'], paused: ['En pausa', 'warn'], down: ['¡Derrotado!', 'done'], escaped: ['Escapó', 'done'] })[s.jefe.status],
    stats: s => [['❤️', `${(s.jefe.hp || 0).toLocaleString('es')}/${(s.jefe.max || 0).toLocaleString('es')}`], ['⭐', `Nv ${s.jefe.level}`]],
    controls: s => [
      ['start', s.jefe.status === 'paused' ? '▶ Reanudar' : '⚔️ ¡Que aparezca!', 'go', s.jefe.status === 'fighting'],
      ['pause', '⏸ Pausar', 'warn', s.jefe.status !== 'fighting'],
      ['next', '⏭ Siguiente nivel', 'vio', s.jefe.status === 'idle'],
      ['reset', '↺ Reiniciar', 'danger', false, { confirm: '¿Reiniciar al jefe? Vuelve al nivel 1.' }],
    ],
    list: { title: '⚔️ Los que más daño hacen', rows: s => s.jefe.top.map(r => ({ id: r.user.id, user: r.user, value: `${r.value.toLocaleString('es')} 💥` })), empty: ['Nadie lo ha golpeado', 'Haz que aparezca: cada moneda es 1 de daño.'] },
    tabs: [
      { id: 'jefe', label: '👹 El jefe', fields: [
        F.chips('model', 'Monstruo', [...MONSTRUOS.ORDER.map(id => [id, `<span class="mchip">${MONSTRUOS.svg(id, 0)}</span>${MONSTRUOS.list[id].name}`]), ['auto', '<span class="mchip mauto">🔀</span>Uno distinto en cada nivel']], 'Si subes tu propia imagen abajo, se usa esa en vez del monstruo.'),
        F.text('bossName', 'Nombre del jefe', 'Vacío = el nombre del monstruo', 'Déjalo vacío y se llama como el monstruo que sale (por ejemplo Dragón de Fuego).'),
        F.image('bossImage', 'Imagen del jefe (PNG o GIF)', 'Si no subes nada, sale un monstruo de ChispaLive.'),
        F.step('hp', 'Vida del nivel 1', 10, 100000000, 100, 'de vida', '', { icon: '❤️' }),
        F.chips('levelUp', 'Cada nivel tiene', [[1, 'Igual vida'], [1.25, '+25%'], [1.5, '+50%'], [2, 'El doble']]),
        F.step('regen', 'Se cura solo', 0, 100000, 1, 'de vida por segundo', '0 = no se cura', { icon: '💚' }),
        F.step('timeLimit', 'Tiempo para derrotarlo', 0, 36000, 30, 'segundos', '0 = sin límite. Si se acaba, ¡escapa!', { icon: '⏱' }),
        F.step('nextDelay', 'Siguiente jefe aparece en', 0, 600, 1, 'segundos', '0 = lo haces aparecer tú', { icon: '⏭' }),
      ] },
      { id: 'dano', label: '💥 Daño', fields: [
        F.chips('damage.coins', 'Cada moneda hace', [[0.5, '½ de daño'], [1, '1 de daño'], [2, '2 de daño'], [5, '5 de daño']]),
        F.toggle('likes.on', 'Likes', 'Cada N likes hacen daño', { icon: '👍', color: 'pink', sub: [F.step('likes.every', 'Cada', 5, 100000, 5, 'likes'), F.step('likes.damage', 'Hacen', 1, 100000, 1, 'de daño')] }),
        F.toggle('follow.on', 'Seguidores', 'Cada follow hace daño', { icon: '💗', color: 'pink', sub: [F.step('follow.damage', 'Hace', 1, 100000, 5, 'de daño')] }),
        F.toggle('share.on', 'Compartidos', 'Cada vez que comparten', { icon: '📣', color: 'blue', sub: [F.step('share.damage', 'Hace', 1, 100000, 5, 'de daño')] }),
        F.toggle('crit.on', 'Golpes críticos', 'A veces el golpe hace el doble de daño', { icon: '💥', color: 'red', sub: [F.step('crit.chance', 'Probabilidad', 1, 100, 1, '%')] }),
      ] },
      soundsTab([['hit', 'Golpe', 'Cada golpe', '👊'], ['crit', 'Crítico', 'Golpe x2', '💥'], ['rage', 'Se enoja', 'Al 50% y 25% de vida', '😡'], ['down', 'Derrotado', 'Cuando lo vencen', '🏆'], ['spawn', 'Aparece', 'Cuando aparece un jefe', '✨']]),
      histTab(),
      design([['monstruo', 'Monstruo', 'grande al centro'], ['barra', 'Barra', 'solo la vida, compacta']]),
    ],
  },

  trivia: {
    icon: '❓', name: 'Trivia con el chat', overlay: 'trivia', group: 'Juegos', isNew: true, onoff: true,
    desc: 'Sale una pregunta con 4 opciones y tus viewers responden escribiendo A, B, C o D en el chat. ¡El más rápido en acertar gana más puntos!',
    status: s => ({ idle: ['Esperando', ''], question: [`Pregunta ${s.trivia.idx + 1}/${s.trivia.total}`, 'live'], reveal: ['Respuesta', 'live'], ended: ['Terminada', 'done'] })[s.trivia.status],
    stats: s => [['❓', `${s.trivia.bankSize} preguntas`], ['🙋', s.trivia.answered]],
    controls: s => [
      ['start', s.trivia.status === 'idle' || s.trivia.status === 'ended' ? '▶ Empezar trivia' : '🔁 Empezar de nuevo', 'go', false, s.trivia.status === 'question' || s.trivia.status === 'reveal' ? { confirm: '¿Empezar de nuevo? Se borran los puntos.' } : undefined],
      ['skip', s.trivia.status === 'question' ? '👁 Mostrar respuesta' : '⏭ Siguiente pregunta', 'vio', !['question', 'reveal'].includes(s.trivia.status)],
      ['end', '🏁 Terminar', 'warn', !['question', 'reveal'].includes(s.trivia.status)],
      ['reset', '↺ Reiniciar', 'danger', false, { confirm: '¿Reiniciar la trivia? Se borran los puntos.' }],
    ],
    list: { title: '🏆 Tabla de puntos', rows: s => s.trivia.top.map(r => ({ id: r.user.id, user: r.user, value: `${r.points.toLocaleString('es')} pts · ${r.right} ✓` })), empty: ['Nadie ha acertado todavía', 'Empieza la trivia: responden en el chat con A, B, C o D.'] },
    tabs: [
      { id: 'juego', label: '⚙️ Juego', fields: [
        F.step('rounds', 'Preguntas por partida', 1, 50, 1, 'preguntas', '', { icon: '❓' }),
        F.step('perQuestion', 'Tiempo para responder', 5, 120, 1, 'segundos', '', { icon: '⏱' }),
        F.step('revealSeconds', 'Mostrar la respuesta durante', 2, 60, 1, 'segundos', '', { icon: '👁' }),
        F.step('points', 'Puntos por acertar', 10, 10000, 10, 'puntos', '', { icon: '⭐' }),
        F.toggle('speedBonus', 'Bonus por rapidez', 'El que responde más rápido gana hasta el doble', { icon: '⚡', color: 'gold' }),
        F.toggle('autoNext', 'Pasar sola a la siguiente', 'Si lo apagas, tú pasas cada pregunta', { icon: '⏭', color: 'green' }),
        F.toggle('shuffle', 'Preguntas en desorden', 'Cada partida sale un orden distinto', { icon: '🔀', color: 'vio' }),
      ] },
      { id: 'preguntas', label: '📝 Preguntas', fields: [
        F.toggle('useDefault', 'Usar las preguntas de ejemplo', '38 preguntas de cultura general, Perú, ciencia y gaming', { icon: '📚', color: 'blue' }),
        F.questions(),
      ] },
      soundsTab([['question', 'Pregunta nueva', 'Al salir cada pregunta', '🔔'], ['answer', 'Alguien responde', 'Cada respuesta del chat', '🙋'], ['correct', 'Respuesta', 'Al mostrar la respuesta', '✅'], ['win', 'Ganador', 'Al terminar la partida', '🏆']]),
      histTab(),
      design([['tarjeta', 'Tarjeta', 'pregunta y 4 opciones'], ['concurso', 'Concurso', 'estilo programa de TV']]),
    ],
  },

  mascota: {
    icon: '🐣', name: 'Mascota del live', overlay: 'mascota', group: 'Juegos', isNew: true, onoff: true,
    desc: 'Una mascota que vive en tu stream y se guarda entre lives. Los regalos le dan experiencia y la hacen evolucionar (huevo → cría → joven → adulta → legendaria). Los likes la alimentan.',
    status: s => ({ feliz: ['😊 Feliz', 'live'], normal: ['😐 Normal', 'warn'], triste: ['😢 Con hambre', 'warn'] })[s.mascota.mood],
    stats: s => [['🐣', s.mascota.label], ['⭐', `${s.mascota.xp.toLocaleString('es')} XP`], ['🍖', `${Math.round(s.mascota.food)}%`]],
    controls: () => [
      ['test', '🎁 Probar regalo', 'go'],
      ['feed', '🍖 Darle de comer', 'warn'],
      ['reset', '🥚 Volver a huevo', 'danger', false, { confirm: '¿Volver la mascota a huevo? Se borra toda su experiencia y sus cuidadores.' }],
    ],
    list: { title: '💖 Sus mejores cuidadores', rows: s => (s.mascota.top || []).map(r => ({ id: r.user.id, user: r.user, value: `${r.xp.toLocaleString('es')} XP · 🍖 ${r.food}`, n: r.xp + r.food })),
      empty: ['Nadie la ha cuidado todavía', 'Cuando te den regalos y likes, aquí salen sus cuidadores de siempre.'] },
    tabs: [
      { id: 'mascota', label: '🐣 Mascota', fields: [
        F.text('petName', 'Nombre de la mascota', 'Ej: Chispita'),
        F.chips('color', 'Color', [['fuego', '🔥 Fuego'], ['hielo', '❄️ Hielo'], ['bosque', '🌿 Bosque'], ['galaxia', '🌌 Galaxia']]),
        F.note('Experiencia total que necesita para llegar a cada etapa. Se guarda entre lives: tus viewers vuelven para verla crecer.'),
        F.step('levels.cria', 'Cría', 1, 10000000, 50, 'XP', '', { icon: '🐣' }),
        F.step('levels.joven', 'Joven', 1, 10000000, 100, 'XP', '', { icon: '✨' }),
        F.step('levels.adulta', 'Adulta', 1, 10000000, 500, 'XP', '', { icon: '🔥' }),
        F.step('levels.legendaria', 'Legendaria', 1, 10000000, 1000, 'XP', '', { icon: '👑' }),
      ] },
      { id: 'cuidar', label: '🍖 Cuidados', fields: [
        F.step('xp.coins', 'XP por moneda', 0, 100, 1, 'XP', 'Un regalo de 30 monedas da 30 XP', { icon: '🎁' }),
        F.step('xp.follow', 'XP por follow', 0, 10000, 5, 'XP', '', { icon: '⭐' }),
        F.step('xp.share', 'XP por compartir', 0, 10000, 5, 'XP', '', { icon: '📣' }),
        F.step('feed.every', 'Comida: cada', 1, 100000, 5, 'likes', 'De la misma persona', { icon: '❤️' }),
        F.step('feed.amount', 'Cuánta comida le dan', 1, 100, 1, '%', '', { icon: '🍖' }),
        F.step('giftFood', 'Comida por cada regalo', 0, 100, 1, '%', '', { icon: '🍎' }),
        F.toggle('hunger.on', 'Le da hambre', 'Mientras estás en vivo la comida baja poco a poco. Con hambre se pone triste.', { icon: '😢', color: 'pink', sub: [F.step('hunger.perMin', 'Baja', 1, 50, 1, '% por minuto')] }),
        F.toggle('showTop', 'Mostrar cuidadores', 'Los 3 que más la han cuidado', { icon: '💖', color: 'gold' }),
      ] },
      soundsTab([['feed', 'Comida', 'Cuando come', '🍖'], ['xp', 'Experiencia', 'Cuando recibe un regalo', '⭐'], ['evolve', 'Evolución', 'Cuando sube de etapa', '🎉'], ['hungry', 'Hambre', 'Cuando le da hambre', '😢']]),
      histTab(),
      design([['tarjeta', 'Tarjeta', 'mascota con barras e info'], ['flotante', 'Flotante', 'solo la mascota, para una esquina']]),
    ],
  },

  bomba: {
    icon: '💣', name: 'Bomba caliente', overlay: 'bomba', group: 'Juegos', isNew: true, onoff: true,
    desc: 'Los viewers entran con !jugar. La bomba le cae a uno y tiene que pasarla con !pasar antes de que explote. Al que le explota, queda fuera. El último que queda gana.',
    status: s => ({ idle: ['Esperando', ''], lobby: ['Sala de espera', 'warn'], playing: [`Ronda ${s.bomba.round} · ${s.bomba.alive} vivos`, 'live'], between: ['💥 ¡BOOM!', 'live'], ended: ['Terminada', 'done'] })[s.bomba.status],
    stats: s => [['👥', `${s.bomba.players.length} jugadores`], ['❤️', `${s.bomba.alive} vivos`], ['🔁', `${s.bomba.passes} pases`]],
    controls: s => [
      ['start', s.bomba.status === 'lobby' ? '💣 ¡Empezar ya!' : '🚪 Abrir la sala', 'go', !['idle', 'ended', 'lobby'].includes(s.bomba.status)],
      ['pass', '🔁 Pasar la bomba', 'pri', s.bomba.status !== 'playing'],
      ['boom', '💥 Explotar ya', 'warn', s.bomba.status !== 'playing'],
      ['end', '🏁 Terminar', 'vio', !['playing', 'between', 'lobby'].includes(s.bomba.status)],
      ['reset', '↺ Reiniciar', 'danger', false, { confirm: '¿Reiniciar la bomba? Todos salen del juego.' }],
    ],
    list: { title: '👥 Jugadores', rows: s => s.bomba.players.map(p => ({ id: p.user.id, user: p.user, value: !p.alive ? `💥 fuera (ronda ${p.out})` : s.bomba.holder === p.user.id ? '💣 ¡la tiene!' : p.shield ? '🛡️ con escudo' : '❤️ vivo', n: p.alive ? 1 : 0 })),
      empty: ['No hay jugadores', 'Abre la sala y que escriban el comando para entrar.'] },
    tabs: [
      { id: 'juego', label: '💣 Juego', fields: [
        F.text('joinCommand', 'Comando para entrar', '!jugar'),
        F.text('passCommand', 'Comando para pasar la bomba', '!pasar', 'También pueden escribir !pasar @nombre para elegir a quién'),
        F.step('lobbySeconds', 'Sala de espera', 5, 600, 5, 'segundos', '', { icon: '🚪' }),
        F.step('minPlayers', 'Mínimo de jugadores', 2, 50, 1, 'jugadores', 'Si no llegan, la sala espera un poco más', { icon: '👥' }),
        F.step('maxPlayers', 'Máximo de jugadores', 2, 100, 1, 'jugadores', '', { icon: '🚫' }),
        F.step('fuseMin', 'Mecha más corta', 3, 120, 1, 'segundos', 'La mecha es secreta: dura algo entre estos dos tiempos', { icon: '🧨' }),
        F.step('fuseMax', 'Mecha más larga', 3, 300, 1, 'segundos', '', { icon: '🧨' }),
        F.step('betweenSeconds', 'Pausa entre rondas', 2, 60, 1, 'segundos', '', { icon: '⏸' }),
      ] },
      { id: 'ayudas', label: '🎁 Regalos y likes', fields: [
        F.toggle('giftJoin', 'Los regalos te meten al juego', 'Mandar un regalo en la sala de espera también te hace entrar', { icon: '🎁', color: 'gold' }),
        F.toggle('giftPass', 'Los regalos pasan la bomba', 'Si tienes la bomba y mandas cualquier regalo, se la pasas a otro', { icon: '🎁', color: 'green' }),
        F.toggle('likesPass.on', 'Los likes pasan la bomba', 'Si tienes la bomba y das likes, se pasa sola', { icon: '👍', color: 'pink', sub: [F.step('likesPass.every', 'Con', 1, 1000, 1, 'likes')] }),
        F.toggle('shield.on', 'Escudo', 'La próxima vez que te caiga la bomba, rebota a otro', { icon: '🛡️', color: 'vio', sub: [F.gift('shield.gift', 'Regalo del escudo')] }),
        F.buttons([['test', '🧪 Probar (mete gente de prueba)', 'go', {}]]),
      ] },
      soundsTab([['start', 'Empieza', 'Al empezar la partida', '🔔'], ['join', 'Alguien entra', 'Cada jugador nuevo', '👋'], ['pass', 'Pase', 'Cuando se pasa la bomba', '🔁'], ['tick', 'Tic-tac', 'Se acelera cuando falta poco', '⏱'], ['boom', 'Explosión', 'Cuando explota', '💥'], ['shield', 'Escudo', 'Cuando alguien tiene escudo', '🛡️'], ['win', 'Ganador', 'El último que queda', '🏆']]),
      histTab(),
      design([['circulo', 'Círculo', 'los jugadores en ronda y la bomba volando'], ['compacta', 'Compacta', 'solo quién tiene la bomba']]),
    ],
  },

  pesca: {
    icon: '🎣', name: 'Pesca', overlay: 'pesca', group: 'Juegos', isNew: true, onoff: true,
    desc: 'Tus viewers escriben !pescar y su boya cae al lago. Al rato algo pica: basura, peces, criaturas épicas, legendarias o un tesoro. Un regalo es mejor carnada y los grandes aseguran algo legendario.',
    status: s => ({ idle: ['Cerrada', ''], open: [s.pesca.school ? '🌊 ¡Banco de peces!' : '¡Pescando!', 'live'], ended: ['Terminada', 'done'] })[s.pesca.status],
    stats: s => [['🎣', `${s.pesca.lines.length} en el agua`], ['🐟', `${s.pesca.caught} pescados`], ['🏆', s.pesca.record ? `${s.pesca.record.emoji} ${s.pesca.record.kg} kg` : '—']],
    controls: s => [
      ['start', '🎣 Abrir la pesca', 'go', s.pesca.status === 'open'],
      ['school', '🌊 Banco de peces', 'pri', s.pesca.status !== 'open'],
      ['end', '🏁 Terminar', 'warn', s.pesca.status !== 'open'],
      ['reset', '↺ Reiniciar', 'danger', false, { confirm: '¿Reiniciar la pesca? Se borran los puntos (el récord se queda).' }],
    ],
    list: { title: '🏆 Mejores pescadores', rows: s => s.pesca.top.map(r => ({ id: r.user.id, user: r.user, value: `${r.points.toLocaleString('es')} pts · ${r.fish} 🐟${r.best ? ` · ${r.best.emoji}` : ''}` })),
      empty: ['Nadie ha pescado todavía', 'Abre la pesca y que escriban el comando en el chat.'] },
    tabs: [
      { id: 'pesca', label: '🎣 Pesca', fields: [
        F.text('command', 'Comando para pescar', '!pescar'),
        F.step('cooldown', 'Espera entre lanzadas', 0, 600, 5, 'segundos', 'Por viewer, para el comando del chat. Los regalos no esperan.', { icon: '⏳' }),
        F.step('maxLines', 'Boyas a la vez', 1, 16, 1, 'boyas', 'Si el lago está lleno, los demás esperan su turno', { icon: '🎈' }),
        F.step('duration', 'Torneo de pesca', 0, 36000, 30, 'segundos', '0 = abierta todo el live. Con tiempo, al final gana el que más puntos juntó.', { icon: '⏱' }),
        F.toggle('likes.on', 'Los likes lanzan la caña', 'Cada cierta cantidad de likes, el viewer lanza gratis', { icon: '👍', color: 'pink', sub: [F.step('likes.every', 'Cada', 5, 100000, 5, 'likes')] }),
        F.toggle('showTop', 'Mostrar récord y mejores', 'En el lago se ve el pez más pesado y el top 3', { icon: '🏆', color: 'vio' }),
      ] },
      { id: 'carnada', label: '🪱 Carnada', fields: [
        F.note('Cualquier regalo lanza la caña con <b>mejor carnada</b>: más monedas, más suerte para sacar algo raro. Además pica más rápido.'),
        F.toggle('giftCast', 'Los regalos lanzan la caña', 'Con suerte según las monedas del regalo', { icon: '🎁', color: 'gold' }),
        F.toggle('legend.on', 'Pesca legendaria asegurada', 'Un regalo grande saca sí o sí algo legendario o un tesoro', { icon: '🦈', color: 'gold', sub: [F.step('legend.minCoins', 'Desde', 10, 100000, 10, 'monedas')] }),
        F.toggle('escape.on', 'A veces se escapa', 'El pez rompe la línea (nunca pasa con regalos)', { icon: '💨', color: 'pink', sub: [F.step('escape.chance', 'Probabilidad', 1, 50, 1, '%')] }),
        F.buttons([['test', '🎣 Probar 4 lanzadas', 'go', {}], ['test', '🎁 Probar con regalo', 'warn', { type: 'gift' }], ['test', '🦈 Probar legendario', 'vio', { type: 'legend' }]]),
      ] },
      { id: 'banco', label: '🌊 Banco de peces', fields: [
        F.toggle('school.on', 'Banco de peces', 'Cada cierto tiempo llega un banco de peces y todo lo que saquen vale más', { icon: '🌊', color: 'blue', sub: [F.step('school.every', 'Cada', 30, 3600, 10, 'segundos'), F.step('school.seconds', 'Dura', 5, 300, 5, 'segundos'), F.step('school.mult', 'Puntos', 2, 10, 1, 'x')] }),
        F.buttons([['resetRecord', '🗑 Borrar el récord', 'danger', { confirm: '¿Borrar el récord del pez más pesado?' }]]),
      ] },
      soundsTab([['cast', 'Lanzar', 'Cuando cae una boya', '🎣'], ['bite', '¡Pica!', 'Cuando algo muerde', '❗'], ['catch', 'Pesca normal', 'Peces comunes y raros', '🐟'], ['epic', 'Pesca épica', 'Criaturas épicas', '🐙'], ['legend', 'Legendaria', 'Legendarios y tesoros', '🦈'], ['trash', 'Basura', 'Cuando sale una bota', '🥾'], ['escape', 'Se escapó', 'Cuando rompe la línea', '💨'], ['school', 'Banco de peces', 'Cuando llega el banco', '🌊']]),
      histTab(),
      design([['lago', 'Lago', 'el lago con las boyas y los peces'], ['lista', 'Lista', 'solo las últimas capturas, compacto']]),
    ],
  },

  adivina: {
    icon: '🔤', name: 'Adivina la palabra', overlay: 'adivina', group: 'Juegos', isNew: true, onoff: true,
    desc: 'Sale una palabra escondida y una pista. Tus viewers escriben la palabra en el chat y el primero que la adivina gana puntos. Escribir una sola letra la destapa si está.',
    status: s => ({ idle: ['Esperando', ''], running: [`Palabra ${s.adivina.round}${s.adivina.total ? '/' + s.adivina.total : ''}`, 'live'], between: ['¡Adivinada!', 'live'], paused: ['En pausa', 'warn'], ended: ['Terminada', 'done'] })[s.adivina.status],
    stats: s => [['📚', `${s.adivina.bankSize} palabras`], ['🙈', s.adivina.status === 'running' ? `${s.adivina.hidden} escondidas` : '—'], ['👁', s.adivina.secret ? `<span class="spoiler" title="Pasa el mouse para ver">${esc(s.adivina.secret)}</span>` : '—']],
    controls: s => [
      ['start', s.adivina.status === 'paused' ? '▶ Reanudar' : ['idle', 'ended'].includes(s.adivina.status) ? '▶ Empezar' : '🔁 Empezar de nuevo', 'go', s.adivina.status === 'running', ['running', 'between'].includes(s.adivina.status) ? { confirm: '¿Empezar de nuevo? Se borran los puntos.' } : undefined],
      ['hint', '💡 Dar una pista', 'pri', s.adivina.status !== 'running'],
      ['skip', s.adivina.status === 'running' ? '⏭ Saltar palabra' : '⏭ Siguiente', 'vio', !['running', 'between'].includes(s.adivina.status)],
      ['pause', '⏸ Pausar', 'warn', s.adivina.status !== 'running'],
      ['end', '🏁 Terminar', 'warn', !['running', 'between', 'paused'].includes(s.adivina.status)],
      ['reset', '↺ Reiniciar', 'danger', false, { confirm: '¿Reiniciar el juego? Se borran los puntos.' }],
    ],
    list: { title: '🏆 Tabla de puntos', rows: s => s.adivina.top.map(r => ({ id: r.user.id, user: r.user, value: `${r.points.toLocaleString('es')} pts · ${r.words} 🔤` })),
      empty: ['Nadie ha adivinado todavía', 'Dale a Empezar y que el chat escriba la palabra.'] },
    tabs: [
      { id: 'juego', label: '⚙️ Juego', fields: [
        F.step('rounds', 'Palabras por partida', 0, 200, 1, 'palabras', '0 = sin fin', { icon: '🔤' }),
        F.step('roundSeconds', 'Tiempo por palabra', 15, 600, 5, 'segundos', '', { icon: '⏱' }),
        F.step('betweenSeconds', 'Pausa entre palabras', 2, 60, 1, 'segundos', '', { icon: '⏸' }),
        F.step('points', 'Puntos por adivinar', 10, 100000, 10, 'puntos', 'Si la adivinan con más letras escondidas, ganan más', { icon: '⭐' }),
        F.toggle('streak', 'Racha', 'Si el mismo viewer adivina seguido, gana más (hasta el doble)', { icon: '🔥', color: 'gold' }),
        F.toggle('letters.on', 'Letras sueltas', 'Escribir una sola letra la destapa si está en la palabra', { icon: '🅰️', color: 'blue', sub: [F.step('letters.points', 'Puntos por letra', 0, 1000, 1, 'pts'), F.step('letters.cooldown', 'Espera entre letras', 0, 60, 1, 'segundos', 'Por viewer, para que no llenen el chat')] }),
        F.toggle('showGuesses', 'Mostrar los intentos', 'Los intentos del chat salen flotando en pantalla, con un ¡casi! si les faltó poquito', { icon: '💬', color: 'pink' }),
      ] },
      { id: 'pistas', label: '💡 Pistas', fields: [
        F.toggle('autoReveal.on', 'Pista sola', 'Si nadie destapa nada, sale una letra cada cierto tiempo', { icon: '⏳', color: 'green', sub: [F.step('autoReveal.every', 'Cada', 5, 300, 1, 'segundos')] }),
        F.gift('hint.gift', 'Regalo de pista', 'Destapa una letra cada vez que alguien lo manda'),
        F.toggle('hint.likesOn', 'Pista con likes', 'Los likes llenan una barra y al llenarse sale una letra', { icon: '👍', color: 'pink', sub: [F.step('hint.likes', 'Cada', 10, 100000, 10, 'likes')] }),
        F.step('keepHidden', 'Letras que nunca se destapan solas', 0, 10, 1, 'letras', 'Para que siempre haya que pensar un poco', { icon: '🙈' }),
      ] },
      { id: 'palabras', label: '📝 Palabras', fields: [
        F.toggle('useDefault', 'Usar las palabras de ejemplo', 'Más de 100 palabras de animales, comida, países, objetos, deportes y gaming', { icon: '📚', color: 'blue' }),
        F.area('words', 'Tus palabras', 'PIKACHU | Pokémon\nLOMO SALTADO | Comida peruana\nESNUTBEAR | El dueño del live', 'Una por línea. Después de la barra | va la pista (la categoría). Pueden tener espacios.', 9),
      ] },
      soundsTab([['start', 'Palabra nueva', 'Al salir cada palabra', '🔔'], ['reveal', 'Se destapa una letra', 'Cada letra que aparece', '🅰️'], ['close', '¡Casi!', 'Cuando alguien casi la adivina', '😱'], ['wrong', 'Intento fallido', 'Cada intento del chat', '💬'], ['correct', 'La adivinaron', 'Cuando alguien acierta', '🎉'], ['timeout', 'Nadie la adivinó', 'Cuando se acaba el tiempo', '⌛'], ['tick', 'Últimos segundos', 'Tic en los últimos 10 segundos', '⏱']]),
      histTab(),
      design([['tablero', 'Tablero', 'fichas grandes, intentos y puntos'], ['compacta', 'Compacta', 'solo las fichas y el tiempo']]),
    ],
  },

  castillos: {
    icon: '🏰', name: 'Guerra de castillos', overlay: 'castillos', group: 'Juegos', isNew: true, onoff: true,
    desc: 'Dos castillos frente a frente. El regalo de cada equipo dispara un cañonazo al castillo enemigo (1 moneda = 1 de daño). Gana el que lo derriba primero o el que tiene más vida al final.',
    status: s => ({ idle: ['Esperando', ''], running: [s.castillos.rush ? '🔥 ¡Asalto final!' : '¡En guerra!', 'live'], paused: ['En pausa', 'warn'], ended: ['Terminada', 'done'] })[s.castillos.status],
    stats: s => s.castillos.teams.map((t, i) => [t.emoji || '🏰', `${s.castillos.hp[i].toLocaleString('es')} ❤️`]),
    controls: s => [
      ['start', s.castillos.status === 'paused' ? '▶ Reanudar' : '⚔️ ¡A la guerra!', 'go', s.castillos.status === 'running'],
      ['pause', '⏸ Pausar', 'warn', s.castillos.status !== 'running'],
      ['end', '🏁 Terminar ya', 'vio', !['running', 'paused'].includes(s.castillos.status)],
      ['dragon', '🐉 Llamar al dragón', 'pri', s.castillos.status !== 'running'],
      ['reset', '↺ Reiniciar', 'danger', false, { confirm: '¿Reiniciar la guerra? Los dos castillos vuelven con la vida llena.' }],
    ],
    list: { title: '💣 Los que más disparan', rows: s => s.castillos.teams.flatMap(t => t.top.map(r => ({ id: r.user.id + t.name, user: r.user, value: `${t.emoji || ''} ${r.value.toLocaleString('es')} de daño`, n: r.value }))).sort((a, b) => b.n - a.n).slice(0, 10),
      empty: ['Nadie ha disparado todavía', 'Dale a ¡A la guerra! y los regalos de cada equipo disparan al castillo enemigo.'] },
    tabs: [
      { id: 'castillos', label: '🏰 Castillos', fields: [
        F.note('Cada castillo tiene <b>su regalo</b> (siempre dispara al enemigo) y <b>su comando</b> para unirse. Si te uniste, tus likes lanzan flechas y puedes usar los poderes.'),
        F.teams({ max: 2 }),
        F.step('hp', 'Vida de cada castillo', 100, 100000000, 500, '❤️', '1 moneda = 1 de daño', { icon: '🏰' }),
        F.step('duration', 'Tiempo de la guerra', 0, 36000, 30, 'segundos', '0 = sin límite: sigue hasta que caiga un castillo. Si se acaba el tiempo gana el que tiene más vida.', { icon: '⏱' }),
        F.toggle('anyGift', 'Cualquier regalo dispara', 'Si te uniste con el comando, todos tus regalos disparan desde tu castillo', { icon: '🎁', color: 'gold' }),
        F.toggle('likes.on', 'Los likes lanzan flechas', 'Solo de los que ya están en un castillo', { icon: '🏹', color: 'pink', sub: [F.step('likes.every', 'Cada', 5, 100000, 5, 'likes'), F.step('likes.damage', 'Daño', 1, 100000, 5, '')] }),
        F.toggle('follow.on', 'Los follows reparan', 'El castillo de quien te sigue recupera vida', { icon: '⭐', color: 'green', sub: [F.step('follow.heal', 'Repara', 1, 1000000, 50, '❤️')] }),
        F.step('autoRestart', 'Nueva guerra sola después de', 0, 600, 5, 'segundos', '0 = la empiezas tú', { icon: '🔁' }),
      ] },
      { id: 'poderes', label: '⚡ Poderes', fields: [
        F.note('La <b>bola de fuego</b> sale sola con regalos grandes. <b>Reparar</b> y <b>escudo</b> son para el castillo de quien los manda (tiene que haberse unido antes).'),
        F.toggle('mega.on', 'Bola de fuego', 'Los regalos grandes hacen daño extra', { icon: '☄️', color: 'gold', sub: [F.step('mega.minCoins', 'Desde', 2, 100000, 1, 'monedas'), F.step('mega.mult', 'Daño', 2, 10, 1, 'x')] }),
        F.toggle('repair.on', 'Reparar', 'Tu castillo recupera vida', { icon: '🔨', color: 'green', sub: [F.gift('repair.gift', 'Regalo para reparar'), F.step('repair.mult', 'Repara', 1, 100, 1, 'x las monedas')] }),
        F.toggle('shield.on', 'Escudo', 'Tu castillo no recibe daño por unos segundos', { icon: '🛡️', color: 'vio', sub: [F.gift('shield.gift', 'Regalo del escudo'), F.step('shield.seconds', 'Dura', 3, 300, 1, 'segundos')] }),
        F.buttons([['power', '☄️ Probar bola de fuego', 'warn', { type: 'mega' }], ['power', '🔨 Probar reparar', 'go', { type: 'repair' }], ['power', '🛡️ Probar escudo', 'pri', { type: 'shield' }], ['power', '🏹 Probar flechas', 'vio', { type: 'arrow' }]]),
      ] },
      { id: 'sorpresas', label: '🐉 Sorpresas', fields: [
        F.toggle('dragon.on', 'Dragón', 'Cada cierto tiempo llega un dragón y quema al castillo que va ganando. Así la pelea nunca está decidida.', { icon: '🐉', color: 'pink', sub: [F.step('dragon.every', 'Cada', 15, 3600, 5, 'segundos', 'Más o menos: varía un poco'), F.step('dragon.percent', 'Quema', 1, 50, 1, '% de la vida')] }),
        F.toggle('rush.on', 'Asalto final', 'En los últimos segundos todo el daño vale doble', { icon: '🔥', color: 'gold', sub: [F.step('rush.seconds', 'Últimos', 5, 600, 5, 'segundos')] }),
        F.toggle('showTop', 'Mostrar a los mejores', 'El MVP de cada castillo al terminar', { icon: '🏆', color: 'vio' }),
      ] },
      soundsTab([['start', 'Empieza', 'Al iniciar la guerra', '🔔'], ['hit', 'Cañonazo', 'Cada disparo', '💣'], ['mega', 'Bola de fuego', 'Con regalos grandes', '☄️'], ['repair', 'Reparar', 'Cuando un castillo se repara', '🔨'], ['shield', 'Escudo', 'Al activar el escudo', '🛡️'], ['crack', 'Se rompe', 'Cuando un castillo pierde una parte', '🧱'], ['dragon', 'Dragón', 'Cuando llega el dragón', '🐉'], ['rush', 'Asalto final', 'Al empezar el daño doble', '🔥'], ['win', 'Ganador', 'Al terminar', '🏆']]),
      histTab(),
      design([['campo', 'Campo de batalla', 'los dos castillos con cañonazos'], ['barras', 'Barras', 'solo las barras de vida, compacto']]),
    ],
  },

  meta: {
    icon: '🎯', name: 'Metas', overlay: 'meta', group: 'Widgets', isNew: true,
    desc: 'Barra, círculo o corazón que se llena con likes, monedas, seguidores o compartidos.',
    status: s => { const g = cfgG('meta'); return s.meta.value >= g.target ? ['¡Meta cumplida!', 'done'] : ['En progreso', 'live']; },
    stats: s => { const g = cfgG('meta'); return [['🎯', `${s.meta.value.toLocaleString('es')} / ${(+g.target).toLocaleString('es')}`], ['📈', Math.min(100, Math.floor(s.meta.value / Math.max(1, g.target) * 100)) + '%']]; },
    controls: () => [['test', '▶ Probar', 'go'], ['reset', '↺ Reiniciar progreso', 'danger']],
    adjust: [-1000, -100, -10, 10, 100, 1000],
    tabs: [
      { id: 'modo', label: '⚙️ Modo', fields: [
        F.chips('source', '¿Qué cuenta?', [['likes', '❤️ Likes'], ['diamonds', '🪙 Monedas'], ['follows', '⭐ Seguidores'], ['shares', '📣 Compartidos']]),
        F.step('target', 'Meta', 1, 1e9, 100, '', '', { icon: '🎯' }),
        F.step('step', 'Al cumplirla, subir la meta en', 0, 1e9, 100, '', 'La meta sube sola cada vez que se cumple', { icon: '📈', zero: 'Off' }),
        F.toggle('showNumbers', 'Mostrar números', 'Ej. 3.200 / 10.000', { icon: '🔢', color: 'green' }),
      ] },
      soundsTab([['reached', 'Meta cumplida', 'Al llegar al 100%', '🎉']]),
      histTab(),
      design([['barra', 'Barra', 'horizontal'], ['radial', 'Radial', 'círculo con %'], ['corazon', 'Corazón', 'se llena latiendo']]),
    ],
  },

  corazon: {
    icon: '💖', name: 'Meta de corazón', overlay: 'corazon', group: 'Widgets', isNew: true, onoff: true,
    desc: 'Un corazón con carita que se llena con el regalo que elijas (por ejemplo Heart Me). Al llenarse celebra, se pone su corona y la meta puede subir sola.',
    status: s => { const c = s.corazon; if (!c) return ['', '']; return c.reachedAt ? ['¡Meta cumplida!', 'done'] : ['Llenándose', 'live']; },
    stats: s => { const c = s.corazon || { count: 0, target: 1, level: 1 }; return [['💖', `${c.count.toLocaleString('es')} / ${c.target.toLocaleString('es')}`], ['📈', Math.min(100, Math.floor(c.count / Math.max(1, c.target) * 100)) + '%'], ['⭐', 'Nivel ' + c.level]]; },
    controls: () => [['test', '▶ Probar regalo', 'go'], ['reset', '↺ Poner en 0', 'danger']],
    adjust: [-10, -1, 1, 10, 100],
    gifts: 'count', giftsTitle: '💖 Regalo que llena el corazón', giftSingle: true, quickGifts: ['heart me'],
    cardsTop: [corGoalsCard], cards: [corActionCard], paint: corPaint,
    tabs: [
      { id: 'meta', label: '🎯 Meta', fields: [
        F.step('target', 'Meta', 1, 1e7, 1, '', 'Cuántos regalos (o monedas) llenan el corazón', { icon: '🎯' }),
        F.chips('whenReached', 'Cuando se llena', [['keep', '💖 Se queda lleno (100%)'], ['reset', '🔄 Vuelve a 0'], ['extend', '📈 Sube la meta'], ['hide', '🎉 Celebra y se oculta']]),
        { ...F.note('<b>Se queda lleno:</b> queda al 100% · <b>Vuelve a 0:</b> se vacía y empieza otra vez · <b>Sube la meta:</b> sigue llenándose hacia una meta más alta (nivel 2, 3…) · <b>Celebra y se oculta:</b> desaparece y vuelve a salir vacío con el próximo regalo') },
        F.step('resetDelay', 'Esperar antes de volver a 0', 0, 120, 1, 's', 'Después de la celebración', { icon: '⏳', when: g => g.whenReached === 'reset' }),
        { ...F.chips('extendMode', '¿Cómo sube la meta?', [['add', '➕ Sumar (100 → 200 → 300)'], ['mult', '✖️ Multiplicar']]), when: g => g.whenReached === 'extend' },
        F.step('extendMult', 'Multiplicar por', 1.1, 10, 0.1, '×', 'Ej. 1.5: 100 → 150 → 225', { icon: '✖️', when: g => g.whenReached === 'extend' && g.extendMode === 'mult' }),
      ] },
      { id: 'logro', label: '🏆 Al cumplirla', fields: [
        F.step('celebrate', 'Duración de la celebración', 1, 60, 1, 's', 'Corona, estrellas y confeti', { icon: '🎉' }),
        F.toggle('hideStatus', 'Ocultar el cartel "¡Meta cumplida!"', 'Solo celebra, sin el texto', { icon: '🏷️', color: 'vio' }),
        F.step('autoHide', 'Ocultar el corazón después de', 0, 600, 5, 's', 'Solo cuando se queda lleno', { icon: '🙈', zero: 'Nunca', when: g => g.whenReached === 'keep' }),
      ] },
      { id: 'pantalla', label: '👁️ Pantalla', fields: [
        F.toggle('showTitle', 'Título arriba del corazón', 'Usa el texto de "Título en pantalla" (pestaña Diseño)', { icon: '🔤', color: 'blue' }),
        F.toggle('showPill', 'Contador debajo', 'La pastilla con 37 / 100', { icon: '💊', color: 'pink', sub: [F.toggle('showNumbers', 'Mostrar números', 'Si lo apagas, muestra el %', { icon: '🔢', color: 'green' })] }),
        F.toggle('flip', 'Mostrar a quien regala', 'El nombre aparece un momento en el contador', { icon: '🔁', color: 'gold', sub: [
          F.step('flipSeconds', 'Cuánto tiempo', 1, 15, 1, 's', '', { icon: '⏱' }),
          F.text('flipLabel', 'Texto antes del nombre', '¡Gracias!'),
        ] }),
      ] },
      { id: 'live', label: '📡 Entre lives', fields: [
        F.toggle('resetOnStream', 'Reiniciar en cada live nuevo', 'Si lo apagas, el progreso sigue de un live a otro (se guarda aunque cierres el programa)', { icon: '🔄', color: 'green' }),
        F.toggle('hidden', 'Ocultar el corazón', 'Lo esconde del stream sin borrar el progreso', { icon: '🙈', color: 'red' }),
      ] },
      soundsTab([['add', 'Cada regalo', 'Cuando suma al corazón', '💗'], ['reached', 'Meta cumplida', 'Al llenarse', '🎉']]),
      histTab(),
      design([['classic', '❤️ Clásico'], ['sakura', '🌸 Sakura'], ['fire', '🔥 Fuego'], ['golden', '👑 Dorado'], ['ocean', '🌊 Océano'], ['ice', '🧊 Hielo'],
        ['emerald', '💚 Esmeralda'], ['neon', '💜 Neón'], ['galaxy', '🌌 Galaxia'], ['dark', '🖤 Oscuro'], ['black', '⚫ Negro']], { image: false }),
    ],
  },

  top: {
    icon: '🏆', name: 'Rankings', overlay: 'top', group: 'Widgets',
    desc: 'Top donadores, top likes y top compartidos. Puede rotar entre ellos solo.',
    status: () => ['Activo', 'live'],
    stats: s => { const r = rankSrc(s); return [[PERIODS[cfgG('top').period || 'live'][0], PERIODS[cfgG('top').period || 'live'][1]], ['🎁', r.gifts.length], ['❤️', r.likes.length]]; },
    controls: () => { const p = cfgG('top').period || 'live'; return [['test', '▶ Probar con datos', 'go'], ...(p === 'live' ? [] : [['clear', `🗑 Borrar ranking ${PERIODS[p][2]}`, 'danger', false, { period: p, confirm: `¿Borrar el ranking ${PERIODS[p][2]}? No se puede deshacer.` }]])]; },
    list: { title: '🎁 Top donadores', rows: s => { const g = rankSrc(s).gifts, t = g.reduce((a, r) => a + r.value, 0) || 1; return g.map(r => ({ id: r.user.id, user: r.user, value: `${r.value} 🪙`, pct: Math.round(r.value / t * 100) })); }, empty: ['Aún no hay datos', 'Aparecen cuando lleguen regalos.'] },
    tabs: [
      { id: 'periodo', label: '📅 Período', fields: [
        F.chips('period', '¿De cuándo es el ranking?', [['live', '🔴 Este live', 'se reinicia en cada live'], ['week', '📅 Esta semana', 'se reinicia solo'], ['month', '🗓 Este mes', 'se reinicia solo'], ['all', '♾️ De siempre', 'nunca se borra']]),
        F.chips('weekStart', 'La semana empieza el', [[1, 'Lunes'], [0, 'Domingo']]),
        F.note('El ranking semanal, mensual y de siempre <b>solo cuenta tus lives reales</b> (las pruebas del Simulador no se guardan ahí).<br>¿Quieres dos rankings a la vez en OBS? Usa el link del overlay y agrégale <b>?periodo=semana</b>, <b>?periodo=mes</b> o <b>?periodo=siempre</b>.'),
        { t: 'note', html: '<div data-r="lastweek"></div>' },
      ] },
      { id: 'modo', label: '⚙️ Modo', fields: [
        F.group('Tablas que rotan', [F.toggle('boards.gifts', 'Top donadores', '', { icon: '🎁', color: 'gold' }), F.toggle('boards.likes', 'Top likes', '', { icon: '❤️', color: 'pink' }), F.toggle('boards.shares', 'Top compartidos', '', { icon: '📣', color: 'blue' })]),
        F.range('rotate', 'Cambiar de tabla cada', 3, 60), F.range('count', 'Puestos en pantalla', 3, 10, 1, ''),
      ] },
      soundsTab([['leader', 'Nuevo líder', 'Cuando cambia el #1', '👑']]),
      design([['lista', 'Lista', 'clásica'], ['podio', 'Podio', 'top 3 con corona'], ['barras', 'Barras', 'de colores']]),
    ],
  },

  alertas: {
    icon: '🔔', name: 'Alertas', overlay: 'alertas', group: 'Widgets', onoff: true,
    desc: 'Animación cuando alguien regala, te sigue o comparte. Regalos más grandes = alerta más grande.',
    status: () => ['Activo', 'live'],
    stats: () => [],
    controls: () => [['test', '🎁 Probar regalo', 'go', false, { kind: 'gift', coins: 1 }], ['test', '💥 Probar regalo grande', 'pri', false, { kind: 'gift', coins: 1000 }], ['test', '⭐ Probar seguidor', 'vio', false, { kind: 'follow' }], ['test', '📣 Probar compartido', 'warn', false, { kind: 'share' }]],
    gifts: 'filter', giftsTitle: '🎁 ¿Qué regalos muestran alerta?', noValue: true,
    tabs: [
      { id: 'tipos', label: '🔔 Tipos', fields: [
        F.note('Textos: usa <b>{usuario}</b>, <b>{regalo}</b>, <b>{cantidad}</b>, <b>{diamantes}</b>.'),
        F.group('🎁 Regalos', [F.toggle('gift.on', 'Mostrar', '', { icon: '🎁', color: 'gold' }), F.text('gift.text', 'Texto'), F.image('gift.image', 'GIF o imagen', 'Si no subes nada, se usa la imagen del regalo.')]),
        F.group('⭐ Seguidores', [F.toggle('follow.on', 'Mostrar', '', { icon: '⭐', color: 'gold' }), F.text('follow.text', 'Texto'), F.image('follow.image', 'GIF o imagen')]),
        F.group('📣 Compartidos', [F.toggle('share.on', 'Mostrar', '', { icon: '📣', color: 'gold' }), F.text('share.text', 'Texto'), F.image('share.image', 'GIF o imagen')]),
      ] },
      { id: 'modo', label: '⏱ Tiempos', fields: [F.range('duration', 'Duración en pantalla', 2, 15), F.range('confettiFrom', 'Confeti y rayos desde', 1, 5000, 1, ' 🪙')] },
      soundsTab([['gift', 'Regalo', 'Regalo normal', '🎁', true], ['follow', 'Seguidor', '', '⭐'], ['share', 'Compartido', '', '📣']]),
      design([['tarjeta', 'Tarjeta', 'centrada'], ['banner', 'Banner', 'barra arriba'], ['grande', 'Grande', 'GIF gigante']], { title: false, image: false }),
    ],
  },

  chat: {
    icon: '💬', name: 'Chat en pantalla', overlay: 'chat', group: 'Widgets',
    desc: 'Muestra los comentarios y regalos del live en tu stream.',
    status: () => ['Activo', 'live'], stats: () => [],
    controls: () => [['test', '💬 Mensaje de prueba', 'go']],
    tabs: [
      { id: 'modo', label: '⚙️ Modo', fields: [
        F.range('max', 'Mensajes visibles', 3, 20, 1, ''),
        F.toggle('showGifts', 'Mostrar regalos', 'Los regalos aparecen en el chat con su imagen', { icon: '🎁', color: 'gold' }),
        F.toggle('hideCommands', 'Ocultar comandos', 'Esconde mensajes que empiezan con !', { icon: '🙈', color: 'vio' }),
        F.toggle('showAvatars', 'Fotos de perfil', '', { icon: '🖼️', color: 'green' }),
      ] },
      soundsTab([['message', 'Mensaje', 'Con cada comentario', '💬'], ['gift', 'Regalo', 'Con cada regalo', '🎁', true]]),
      design([['burbujas', 'Burbujas', 'tarjetas'], ['minimal', 'Minimal', 'solo texto']], { title: false, image: false }),
    ],
  },
};

// ---------- Utilidades ----------
const getP = (o, p) => p.split('.').reduce((a, k) => a?.[k], o);
function setP(o, p, v) { const ks = p.split('.'); let x = o; ks.slice(0, -1).forEach(k => x = x[k] = x[k] || {}); x[ks.at(-1)] = v; }
const cfgG = k => window.cfg?.games?.[k] || {};
let DEFAULTS = {};
socket.on('defaults', d => { DEFAULTS = d; Object.keys(STUDIOS).forEach(paintDiff); });
const pending = {}; const pendT = {};
function flushG(key) {
  if (!pending[key]) return;
  clearTimeout(pendT[key]); socket.emit('saveConfig', { games: { [key]: pending[key] } }); delete pending[key];
}
function saveG(key, path, value) {
  setP(window.cfg.games[key], path, value);
  setP(pending[key] = pending[key] || {}, path, value);
  clearTimeout(pendT[key]);
  pendT[key] = setTimeout(() => {
    socket.emit('saveConfig', { games: { [key]: pending[key] } }); delete pending[key];
    const sv = document.querySelector(`#s-${key} .saved`); if (sv) { sv.classList.add('on'); setTimeout(() => sv.classList.remove('on'), 1200); }
  }, 300);
  paintDiff(key);
}
const act = (key, action, data) => socket.emit('game', { key, action, data });
function readImage(file, cb) {
  if (!file || !file.type.startsWith('image/')) return toast('Eso no es una imagen');
  const rd = new FileReader();
  rd.onload = () => {
    if (file.type === 'image/gif') return file.size > 8e6 ? toast('El GIF pesa demasiado (máx. 8 MB)') : cb(rd.result);
    const img = new Image();
    img.onload = () => {
      const k = Math.min(1, 512 / Math.max(img.width, img.height)), c = document.createElement('canvas');
      c.width = img.width * k; c.height = img.height * k; c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
      cb(c.toDataURL('image/png'));
    };
    img.src = rd.result;
  };
  rd.readAsDataURL(file);
}
function readAudio(file, cb) {
  if (!file || !file.type.startsWith('audio/')) return toast('Eso no es un sonido (usa MP3, WAV u OGG)');
  if (file.size > 6e6) return toast('El sonido pesa demasiado (máx. 6 MB)');
  const rd = new FileReader(); rd.onload = () => cb(rd.result); rd.readAsDataURL(file);
}
function pickAudio(target) {
  const f = Object.assign(document.createElement('input'), { type: 'file', accept: 'audio/*' });
  f.onchange = () => f.files[0] && readAudio(f.files[0], d => socket.emit('uploadAsset', { target, dataUrl: d }));
  f.click();
}
function pickImage(target) {
  const f = Object.assign(document.createElement('input'), { type: 'file', accept: 'image/*' });
  f.onchange = () => f.files[0] && readImage(f.files[0], d => socket.emit('uploadAsset', { target, dataUrl: d }));
  f.click();
}
function avHtml(u) { return `<img src="${esc(u?.avatar || faceSvg(u?.name || '?'))}" referrerpolicy="no-referrer">`; }
const panelVol = key => VOLUME * ((cfgG(key).volume ?? 70) / 100) || .5;
const presetOpts = (sel, withFile = true) => PRESETS.map(([v, l]) => `<option value="${v}" ${v === sel ? 'selected' : ''}>${l}</option>`).join('') + (withFile ? '<option value="__file">📁 Subir mi sonido…</option>' : '');

// ---------- Diferencias con los valores por defecto ----------
function diffList(a, b, pre = '', out = []) {
  const keys = new Set([...Object.keys(a || {}), ...Object.keys(b || {})]);
  keys.forEach(k => {
    const p = pre ? pre + '.' + k : k, x = a?.[k], y = b?.[k];
    if (p === 'enabled') return;
    if (x && y && typeof x === 'object' && typeof y === 'object' && !Array.isArray(x) && !Array.isArray(y)) diffList(x, y, p, out);
    else if (JSON.stringify(x ?? null) !== JSON.stringify(y ?? null)) out.push(p);
  });
  return out;
}
function paintDiff(key) {
  const sec = document.getElementById('s-' + key); if (!sec || !DEFAULTS[key]) return;
  const d = diffList(cfgG(key), DEFAULTS[key]);
  const rb = sec.querySelector('[data-r=resetall]'); if (rb) { rb.querySelector('b').textContent = d.length; rb.classList.toggle('dim', !d.length); }
  sec.querySelectorAll('.stab').forEach(t => {
    const paths = (t._paths || []), n = d.filter(p => paths.some(tp => p === tp || p.startsWith(tp + '.'))).length;
    let b = t.querySelector('.tb'); if (!b) { b = document.createElement('i'); b.className = 'tb'; t.appendChild(b); }
    b.textContent = n ? '↺' + n : ''; b.style.display = n ? '' : 'none';
  });
}
function fieldPaths(f, out = []) {
  if (f.path) out.push(f.path);
  if (f.t === 'entry') out.push('entry');
  if (f.t === 'sounds') out.push('sounds', 'volume', 'effects.sound');
  if (f.t === 'evo') out.push('evo');
  if (f.t === 'colors') out.push('colors');
  if (f.t === 'questions') out.push('questions');
  (f.fields || []).forEach(x => fieldPaths(x, out)); (f.sub || []).forEach(x => fieldPaths(x, out));
  return out;
}

// =====================================================================
// SELECTOR DE REGALOS (ventana grande con buscador y filtros)
// =====================================================================
const GP = { q: '', range: 'all', sort: 'low' };
function giftCatalog() {
  const seen = window.state?.seenGifts || {};
  const all = (window.CATALOG || []).map(g => ({ ...g }));
  Object.entries(seen).forEach(([n, g]) => { const f = all.find(x => x.name.toLowerCase() === n.toLowerCase()); if (f) { f.image = f.image || g.image; f.live = true; } else all.push({ name: n, coins: g.coins, icon: g.icon, image: g.image, live: true }); });
  return all;
}
function giftImg(g, size = 32) {
  return g.image ? `<img src="${esc(g.image)}" referrerpolicy="no-referrer" style="width:${size}px;height:${size}px;object-fit:contain" onerror="this.outerHTML='${g.icon || '🎁'}'">` : (g.icon || '🎁');
}
function openGiftPicker({ title = 'Elegir regalo', multi = false, selected = [], onPick, onDone }) {
  let sel = [...selected];
  const m = document.createElement('div'); m.className = 'gpm';
  m.innerHTML = `<div class="gpm-box">
    <div class="gpm-hd"><span class="s-icon" style="width:46px;height:46px;font-size:22px;border-radius:14px">🎁</span><div style="flex:1"><h2 class="display" style="margin:0">${title}</h2><span class="hint" data-cnt></span></div><button class="btn sm" data-x>✕</button></div>
    <div class="gpm-bar"><input class="i" data-q placeholder="🔍 Buscar regalo…" value="${esc(GP.q)}"><button class="btn sm" data-sort></button></div>
    <div class="gpm-rng">${[['all', 'Todos'], ['lt100', '< 100'], ['100', '100–999'], ['1k', '1K–5K'], ['5k', '5K+']].map(([v, l]) => `<button data-rng="${v}">🪙 ${l}</button>`).join('')}</div>
    <div class="gpm-grid" data-grid></div>
    <div class="gpm-ft">${multi ? `<input class="i" data-cn placeholder="¿No aparece? Escribe el nombre exacto en TikTok"><button class="btn sm" data-add>＋ Agregar</button>` : '<span class="hint">Toca un regalo para elegirlo</span>'}
      <button class="btn sm" data-load>🔄 Traer regalos de TikTok</button>${multi ? '<button class="btn pri" data-done>Listo</button>' : ''}</div></div>`;
  document.body.appendChild(m);
  const close = () => { m.remove(); document.removeEventListener('keydown', esc_); onDone && onDone(sel); };
  const esc_ = e => { if (e.key === 'Escape') close(); };
  document.addEventListener('keydown', esc_);
  m.onclick = e => { if (e.target === m) close(); };
  m.querySelector('[data-x]').onclick = close;
  m.querySelector('[data-done]')?.addEventListener('click', close);
  m.querySelector('[data-load]').onclick = () => { socket.emit('loadGifts', document.getElementById('user')?.value); toast('Buscando regalos de TikTok…'); };
  const draw = () => {
    const q = GP.q.toLowerCase();
    let list = giftCatalog().filter(g => g.name.toLowerCase().includes(q)).filter(g => {
      const c = +g.coins || 0;
      return GP.range === 'all' || (GP.range === 'lt100' && c < 100) || (GP.range === '100' && c >= 100 && c < 1000) || (GP.range === '1k' && c >= 1000 && c <= 5000) || (GP.range === '5k' && c > 5000);
    });
    list.sort((a, b) => GP.sort === 'low' ? a.coins - b.coins : b.coins - a.coins);
    const isSel = g => sel.map(x => x.toLowerCase()).includes(g.name.toLowerCase());
    m.querySelector('[data-cnt]').textContent = `${giftCatalog().length} regalos${multi ? ` · ${sel.length} elegidos` : ''}`;
    m.querySelector('[data-sort]').textContent = GP.sort === 'low' ? '⇅ Menor precio' : '⇅ Mayor precio';
    m.querySelectorAll('[data-rng]').forEach(b => b.classList.toggle('on', b.dataset.rng === GP.range));
    m.querySelector('[data-grid]').innerHTML = list.map(g => `<button class="gpt ${isSel(g) ? 'on' : ''}" data-n="${esc(g.name)}">
      <span class="gpi">${giftImg(g, 58)}</span><span class="gpn">${esc(g.name)}</span><span class="gpc">🪙 ${(+g.coins || 0).toLocaleString('es')}</span>${g.live ? '<i class="gplive">LIVE</i>' : ''}</button>`).join('') || '<div class="hint" style="padding:30px;text-align:center">No hay regalos con ese filtro</div>';
    m.querySelectorAll('[data-n]').forEach(b => b.onclick = () => {
      const g = list.find(x => x.name === b.dataset.n);
      if (multi) { const i = sel.map(x => x.toLowerCase()).indexOf(g.name.toLowerCase()); i >= 0 ? sel.splice(i, 1) : sel.push(g.name); onPick && onPick(g, sel); draw(); }
      else { onPick && onPick(g); close(); }
    });
  };
  m.querySelector('[data-q]').oninput = e => { GP.q = e.target.value; draw(); };
  m.querySelector('[data-sort]').onclick = () => { GP.sort = GP.sort === 'low' ? 'high' : 'low'; draw(); };
  m.querySelectorAll('[data-rng]').forEach(b => b.onclick = () => { GP.range = b.dataset.rng; draw(); });
  const addB = m.querySelector('[data-add]');
  if (addB) { const add = () => { const v = m.querySelector('[data-cn]').value.trim(); if (!v) return; if (!sel.map(x => x.toLowerCase()).includes(v.toLowerCase())) sel.push(v); onPick && onPick({ name: v }, sel); m.querySelector('[data-cn]').value = ''; draw(); }; addB.onclick = add; m.querySelector('[data-cn]').onkeydown = e => { if (e.key === 'Enter') add(); }; }
  socket.on('catalog', draw);
  const obs = new MutationObserver(() => { if (!document.body.contains(m)) { socket.off('catalog', draw); obs.disconnect(); } });
  obs.observe(document.body, { childList: true });
  draw();
  setTimeout(() => m.querySelector('[data-q]').focus(), 50);
}

// ---------- Construcción del estudio ----------
function buildStudio(key) {
  const S = STUDIOS[key], sec = document.createElement('section');
  sec.className = 'sec'; sec.id = 's-' + key;
  const url = `${location.origin}/overlay/${S.overlay}.html`;
  sec.innerHTML = `
    <div class="studio-head">
      <div class="s-title"><h1><span class="s-icon" data-r="icon">${S.icon}</span><span data-r="name">${S.name}</span><span class="s-pill" data-r="pill"></span><span class="saved">✓ Guardado</span></h1>
        <p class="lead s-lead">${S.desc}</p>
        <div class="s-links"><button data-copy="${url}">🔗 Copiar link para OBS</button><a href="${url}" target="_blank">↗ Abrir overlay</a></div></div>
      ${S.onoff ? `<label class="sw onoff" title="Si lo apagas, este juego ignora los regalos y comandos del live"><input type="checkbox" data-onoff> <b data-r="onlab">Activo</b></label>` : ''}
      <div class="s-stats" data-r="stats"></div>
    </div>
    <div class="presets"><span class="plab">PRESETS</span><div class="pchips" data-r="presets"></div><button class="btn sm" data-pnew>＋ Nuevo preset</button></div>
    <div class="s-controls" data-r="controls"></div>
    <div class="s-grid"><div class="s-col" data-r="left"></div><div class="s-col" data-r="right"></div></div>`;
  const left = sec.querySelector('[data-r=left]'), right = sec.querySelector('[data-r=right]');

  if (S.cardsTop) S.cardsTop.forEach(f => left.appendChild(f(key, S)));
  if (S.timer) left.appendChild(timerCard(key, S));
  if (S.adjust) left.appendChild(adjustCard(key, S));
  if (S.gifts) left.appendChild(giftCard(key, S));
  if (S.wheels) left.appendChild(wheelsCard(key));
  if (S.prizes) left.appendChild(prizesCard(key));
  if (S.odds) { const oc = oddsCard(key, S); oc.dataset.card = 'odds'; left.appendChild(oc); }
  if (S.list) left.appendChild(listCard(key, S));
  if (S.cards) S.cards.forEach(f => left.appendChild(f(key, S)));

  // Vista previa con fondo oscuro / cuadros / claro, zona segura y probar
  const pv = document.createElement('div'); pv.className = 'panel';
  pv.innerHTML = `<div class="ptitle c3" style="justify-content:space-between"><span>👁️ Vista previa</span><button class="btn sm pri" data-pvtest>🔥 Probar</button></div>
    <div class="pvbar"><div class="seg sm">${[['dark', '🌙 Oscuro'], ['checker', '▦ Cuadros'], ['light', '☀ Claro']].map(([v, l]) => `<button data-bg="${v}">${l}</button>`).join('')}</div>
      <label class="sw" style="margin:0;font-size:13px"><input type="checkbox" data-safe> Zona segura</label></div>
    <div class="pv-box ${S.portrait ? 'portrait' : ''}"><iframe data-src="${url}" loading="lazy"></iframe><div class="safez"><i class="t"></i><i class="b"></i><i class="r"></i></div></div>`;
  pv.querySelector('[data-pvtest]').onclick = () => act(key, 'test', { kind: 'gift', coins: 1000 });
  const box = pv.querySelector('.pv-box');
  const setBg = v => { box.dataset.bg = v; pv.querySelectorAll('[data-bg]').forEach(b => b.classList.toggle('on', b.dataset.bg === v)); try { localStorage.setItem('pvbg', v); } catch {} };
  pv.querySelectorAll('[data-bg]').forEach(b => b.onclick = () => setBg(b.dataset.bg));
  let bg0 = 'dark'; try { bg0 = localStorage.getItem('pvbg') || 'dark'; } catch {}
  setBg(bg0);
  pv.querySelector('[data-safe]').onchange = e => box.classList.toggle('safe', e.target.checked);
  right.appendChild(pv);

  // Ajustes con pestañas + buscador + restablecer
  const st = document.createElement('div'); st.className = 'panel settings';
  st.innerHTML = `<div class="ptitle c1">⚙️ Ajustes</div>
    <input class="i ssearch" placeholder="🔍 Buscar ajuste…">
    <div class="stabs">${S.tabs.map((t, i) => `<button class="stab ${i ? '' : 'on'}" data-tab="${t.id}">${t.label}</button>`).join('')}</div>`;
  S.tabs.forEach((t, i) => {
    const pane = document.createElement('div'); pane.className = 'spane' + (i ? '' : ' on'); pane.dataset.pane = t.id;
    t.fields.forEach(f => { const el = fieldEl(key, f); if (f.when) { el._when = f.when; el.classList.add('has-when'); } el.dataset.s = `${f.label || ''} ${f.desc || ''} ${t.label} ${(f.sub || f.fields || []).map(x => x.label).join(' ')} ${f.t === 'sounds' ? 'sonido volumen audio' : ''} ${f.t === 'evo' ? 'evolución nivel personaje monedas' : ''}`.toLowerCase(); pane.appendChild(el); });
    st.appendChild(pane);
    st.querySelector(`.stab[data-tab="${t.id}"]`)._paths = t.fields.flatMap(f => fieldPaths(f));
  });
  st.insertAdjacentHTML('beforeend', `<div class="nomatch-msg hint hidden">Ningún ajuste coincide</div><div class="sfoot"><button class="btn sm danger" data-r="resetall">↺ Restablecer todo <b>0</b></button></div>`);
  st.querySelectorAll('.stab').forEach(b => b.onclick = () => {
    st.querySelector('.ssearch').value = ''; st.classList.remove('searching');
    st.querySelectorAll('.stab').forEach(x => x.classList.toggle('on', x === b));
    st.querySelectorAll('.spane').forEach(p => p.classList.toggle('on', p.dataset.pane === b.dataset.tab));
  });
  st.querySelector('.ssearch').oninput = e => {
    const q = e.target.value.trim().toLowerCase();
    st.classList.toggle('searching', !!q);
    let any = false;
    st.querySelectorAll('.spane > *').forEach(el => { const ok = !q || (el.dataset.s || '').includes(q) || el.textContent.toLowerCase().includes(q); el.classList.toggle('nomatch', !ok); any = any || ok; });
    st.querySelector('.nomatch-msg').classList.toggle('hidden', !q || any);
  };
  st.querySelector('[data-r=resetall]').onclick = () => {
    const n = diffList(cfgG(key), DEFAULTS[key] || {}).length;
    if (!n) return toast('Ya está todo por defecto');
    if (confirm(`¿Restablecer ${n} ajustes de ${S.name} a los valores por defecto?`)) { act(key, 'resetDefaults'); toast('Restablecido ✓'); }
  };
  right.appendChild(st);

  sec.querySelector('[data-pnew]').onclick = () => {
    const name = prompt('Nombre del preset (guarda toda la configuración actual de este juego):', `Preset ${((window.cfg.presets || {})[key] || []).length + 1}`);
    if (name && name.trim()) act(key, 'savePreset', { name: name.trim() });
  };
  const onoff = sec.querySelector('[data-onoff]');
  if (onoff) onoff.onchange = () => { saveG(key, 'enabled', onoff.checked); sec.classList.toggle('disabled', !onoff.checked); sec.querySelector('[data-r=onlab]').textContent = onoff.checked ? 'Activo' : 'Apagado'; };
  sec.querySelector('[data-copy]').onclick = e => { navigator.clipboard.writeText(e.target.dataset.copy); toast('Link copiado ✓ Pégalo como Fuente de navegador'); };
  return sec;
}

// Temporizador con − / + y saltos de ±10 y ±30 s
function timerCard(key, S) {
  const c = document.createElement('div'); c.className = 'panel';
  c.innerHTML = `<div class="ptitle c1">⏱ ${S.timer.label}</div>
    <div class="timer-box"><button class="tbtn" data-add="-60">−</button>
      <div class="tdig"><input type="number" min="0" data-u="h"><small>h</small><input type="number" min="0" max="59" data-u="m"><small>m</small><input type="number" min="0" max="59" data-u="s"><small>s</small></div>
      <button class="tbtn" data-add="60">+</button></div>
    <div class="tchips"><button class="tchip neg" data-add="-30">−30s</button><button class="tchip neg" data-add="-10">−10s</button><button class="tchip pos" data-add="10">+10s</button><button class="tchip pos" data-add="30">+30s</button></div>
    <div class="tlive" data-r="tlive"></div>`;
  c.querySelectorAll('[data-add]').forEach(b => b.onclick = () => {
    const sec = +b.dataset.add, live = S.timer.ms(window.state || {});
    if (live != null) act(key, 'addTime', { seconds: sec });
    else { saveG(key, S.timer.path, Math.max(0, (+getP(cfgG(key), S.timer.path) || 0) + sec)); paintTimer(key); }
  });
  c.querySelectorAll('.tdig input').forEach(inp => inp.onchange = () => {
    const v = u => +c.querySelector(`[data-u=${u}]`).value || 0;
    saveG(key, S.timer.path, Math.max(0, v('h') * 3600 + v('m') * 60 + v('s')));
  });
  return c;
}
function paintTimer(key) {
  const S = STUDIOS[key]; if (!S.timer) return;
  const sec = document.getElementById('s-' + key); if (!sec) return;
  const live = window.state ? S.timer.ms(window.state) : null;
  const total = live != null ? Math.max(0, Math.ceil(live / 1000)) : (+getP(cfgG(key), S.timer.path) || 0);
  const ins = sec.querySelectorAll('.tdig input');
  const vals = [Math.floor(total / 3600), Math.floor(total % 3600 / 60), total % 60];
  ins.forEach((inp, i) => { if (document.activeElement !== inp) inp.value = String(vals[i]).padStart(i ? 2 : 1, '0'); inp.disabled = live != null; });
  sec.querySelector('[data-r=tlive]').textContent = live != null ? '🔴 Corriendo: los botones suman o quitan tiempo en vivo'
    : (!total && S.timer.zero ? S.timer.zero : 'Así empezará. Ajusta antes de iniciar.');
}

function adjustCard(key, S) {
  const c = document.createElement('div'); c.className = 'panel';
  c.innerHTML = `<div class="ptitle c2">✋ Ajustar a mano <span class="hint">suma o resta al progreso</span></div>
    <div class="adjust">${S.adjust.map(n => `<button class="tchip ${n < 0 ? 'neg' : 'pos'}" data-n="${n}">${n > 0 ? '+' : ''}${n.toLocaleString('es')}</button>`).join('')}</div>`;
  c.querySelectorAll('[data-n]').forEach(b => b.onclick = () => act(key, 'adjust', { amount: +b.dataset.n }));
  return c;
}

// ---------- Regalos que cuentan (fila rápida + ventana grande) ----------
function giftCard(key, S) {
  const c = document.createElement('div'); c.className = 'panel'; c.dataset.gifts = '1';
  c.innerHTML = `<div class="ptitle c2" data-r="gtitle">${S.giftsTitle || '🎁 Regalos que cuentan'}</div><div data-r="gbody"></div>`;
  return c;
}
const POPULAR = ['rose', 'finger heart', 'doughnut', 'hand hearts', 'corgi', 'money gun', 'galaxy'];
function giftTile(g, cls) {
  return `<button class="gt ${cls}${g.community ? ' comm' : ''}${g.ph ? ' ph' : ''}" data-gn="${esc(g.name)}" data-gc="${g.coins}" title="${esc(g.name)} · ${g.coins} monedas${g.community ? ' · Regalo de tu comunidad' : ''}">${g.community ? '<i class="gcomm">⭐ TU COMUNIDAD</i>' : ''}
    <span class="gi">${giftImg(g)}</span><span class="gc">🪙 ${(+g.coins || 0).toLocaleString('es')}</span><span class="gn">${esc(g.name)}</span></button>`;
}
function paintGifts(key) {
  const S = STUDIOS[key]; if (!S.gifts) return;
  const box = document.querySelector(`#s-${key} [data-r=gbody]`); if (!box || (box.contains(document.activeElement) && document.activeElement.tagName === 'INPUT' && document.activeElement.type !== 'checkbox')) return;
  const rule = getP(cfgG(key), S.gifts) || {};
  const all = giftCatalog();
  (rule.list || []).forEach(n => { if (!all.find(x => x.name.toLowerCase() === n.toLowerCase())) all.push({ name: n, coins: '?', icon: '🎁' }); });
  all.sort((a, b) => (+a.coins || 0) - (+b.coins || 0));
  const mode = S.giftSingle ? 'list' : (rule.mode || 'any'), on = rule.on !== false;
  if (S.giftSingle && !(rule.list || []).length) rule.list = ['Heart Me'];
  const inList = g => (rule.list || []).map(x => x.toLowerCase()).includes(g.name.toLowerCase());
  // En "Mínimo" solo se marca el regalo que elegiste (los demás de igual o mayor valor cuentan, pero no se pintan todos)
  const pick = mode === 'min' && rule.pick && all.find(g => g.name.toLowerCase() === String(rule.pick).toLowerCase() && +g.coins === +rule.min) ? rule.pick.toLowerCase() : '';
  const cls = g => g.ph ? 'on' : (mode === 'min' ? (pick ? (g.name.toLowerCase() === pick ? 'on' : +g.coins < +rule.min ? 'off' : '') : +g.coins < +rule.min ? 'off' : '') : mode === 'list' ? (inList(g) ? 'on' : 'off') : '') + (g.live ? ' real' : '');
  let quick = all.filter(g => g.community || POPULAR.includes(g.name.toLowerCase()) || (S.quickGifts || []).includes(g.name.toLowerCase()) || (mode === 'list' && inList(g)) || (mode === 'min' && pick && g.name.toLowerCase() === pick));
  quick.sort((a, b) => (b.community ? 1 : 0) - (a.community ? 1 : 0));
  if (mode === 'min' && !pick) quick.unshift({ name: `Mínimo ${rule.min}`, coins: rule.min, icon: '🪙', ph: true });
  const realCount = all.filter(g => g.real).length;
  box.innerHTML = `
    ${S.gifts.startsWith('entry') ? `<label class="sw"><input type="checkbox" data-g="on" ${on ? 'checked' : ''}> Los regalos cuentan en este juego</label>` : ''}
    ${S.giftSingle ? '' : `<div class="seg">${[['any', '🎁 Cualquiera'], ['min', '⬆️ Mínimo'], ['list', '✅ Solo estos']].map(([v, l]) => `<button data-gm="${v}" class="${mode === v ? 'on' : ''}">${l}</button>`).join('')}</div>`}
    <div class="ghint">${mode === 'any' ? (S.giftTap === 'min' ? 'Cualquier regalo cuenta. Toca uno y <b>su valor</b> será la puja mínima: entra todo regalo que valga eso o más, y sus monedas se suman.' : 'Cualquier regalo cuenta. Toca uno para que <b>solo ese regalo</b> cuente.') : mode === 'min' ? (pick ? `Elegiste <b>${esc(all.find(g => g.name.toLowerCase() === pick).name)}</b> (${(+rule.min).toLocaleString('es')} 🪙). Cuenta ese regalo y cualquier otro que valga <b>${(+rule.min).toLocaleString('es')} monedas o más</b>; las monedas se suman.` : `Puja mínima: <b>${(rule.min || 1).toLocaleString('es')} monedas</b>. Cuenta cualquier regalo de ese valor o más.`) : (S.giftSingle ? `Solo cuenta: <b>${esc((rule.list || [])[0] || 'ninguno')}</b>. Ningún otro regalo lo llena. Toca otro regalo para cambiarlo.` : `Solo cuentan: <b>${(rule.list || []).join(', ') || 'ninguno'}</b>. Toca para agregar o quitar.`)}</div>
    <div class="quick">
      ${S.giftSingle ? '' : `<button class="gt none ${mode === 'any' ? 'on' : ''}" data-gnone><span class="gi">✖</span><span class="gn" style="color:inherit">Ninguno</span></button>`}
      ${quick.map(g => giftTile(g, cls(g))).join('')}
      <button class="gt more" data-gmore><span class="gi" style="font-size:18px;font-weight:800">+${Math.max(0, all.length - quick.length)}</span><span class="gn" style="color:inherit">MÁS</span></button>
    </div>
    ${mode === 'min' && S.gifts.startsWith('entry') ? `<div class="tcard sm ${rule.stack ? 'is-on' : ''}" data-color="green" style="margin-top:10px"><div class="tc-head"><span class="tc-ic">🪙</span><div class="tc-t"><b>Acumular regalos</b><small>Los regalos pequeños se suman hasta llegar al mínimo</small></div><label class="sw2"><input type="checkbox" data-g="stack" ${rule.stack ? 'checked' : ''}><i></i></label></div></div>` : ''}
    <div class="greal"><span>${realCount ? `✅ ${realCount} regalos oficiales de TikTok con su imagen` : '⚠️ Usando íconos de respaldo. Trae las imágenes oficiales:'}</span><button class="btn sm" data-gload>🔄 ${realCount ? 'Actualizar' : 'Traer'} regalos de TikTok</button></div>
    ${S.noValue ? '' : `<div class="row" style="margin:12px 0 0"><label class="f">Cada regalo cuenta como
      <select class="i" data-g="value"><option value="coins" ${rule.value !== 'one' ? 'selected' : ''}>Sus monedas (Galaxy = 1000)</option><option value="one" ${rule.value === 'one' ? 'selected' : ''}>1 punto por regalo</option></select></label></div>`}`;
  const save = (p, v) => { saveG(key, `${S.gifts}.${p}`, v); paintGifts(key); };
  box.querySelector('[data-g=on]')?.addEventListener('change', e => save('on', e.target.checked));
  box.querySelector('[data-g=stack]')?.addEventListener('change', e => save('stack', e.target.checked));
  box.querySelector('[data-g=value]')?.addEventListener('change', e => save('value', e.target.value));
  box.querySelectorAll('[data-gm]').forEach(b => b.onclick = () => save('mode', b.dataset.gm));
  box.querySelector('[data-gnone]')?.addEventListener('click', () => save('mode', 'any'));
  box.querySelector('[data-gload]').onclick = () => { socket.emit('loadGifts', document.getElementById('user')?.value); toast('Buscando regalos de TikTok…'); };
  const pickMin = g => { saveG(key, `${S.gifts}.mode`, 'min'); saveG(key, `${S.gifts}.pick`, g.name || ''); save('min', Math.max(1, +g.coins || 1)); if (g.name) toast(`🎁 ${g.name}: cuenta desde ${(+g.coins).toLocaleString('es')} 🪙`); };
  // Elegir un regalo = solo ese regalo cuenta (en "Mínimo" fija la puja mínima)
  const pickOnly = g => { saveG(key, `${S.gifts}.list`, [g.name]); saveG(key, `${S.gifts}.on`, true); save('mode', 'list'); toast(`🎁 Solo cuenta: ${g.name}`); };
  box.querySelector('[data-gmore]').onclick = () => mode === 'list' && !S.giftSingle
    ? openGiftPicker({ title: 'Regalos que cuentan', multi: true, selected: rule.list || [], onPick: (g, sel) => saveG(key, `${S.gifts}.list`, [...sel]), onDone: () => paintGifts(key) })
    : mode === 'min' || S.giftTap === 'min' ? openGiftPicker({ title: 'Elegir regalo mínimo', onPick: pickMin })
    : openGiftPicker({ title: 'Elegir regalo', onPick: pickOnly });
  box.querySelectorAll('[data-gn]').forEach(b => b.onclick = () => {
    if (S.giftSingle) { if ((rule.list || [])[0] !== b.dataset.gn || rule.mode !== 'list') pickOnly({ name: b.dataset.gn }); }
    else if (mode === 'list') {
      const l = [...(rule.list || [])], i = l.map(x => x.toLowerCase()).indexOf(b.dataset.gn.toLowerCase());
      i >= 0 ? l.splice(i, 1) : l.push(b.dataset.gn); save('list', l);
    } else if (mode === 'min' || S.giftTap === 'min') { if (!b.classList.contains('ph')) pickMin({ name: b.dataset.gn, coins: b.dataset.gc }); }
    else pickOnly({ name: b.dataset.gn });
  });
}

// Editor de probabilidades (acciones / premios) con auto-guardado
function oddsCard(key, S) {
  const c = document.createElement('div'); c.className = 'panel';
  c.innerHTML = `<div class="ptitle c4">${S.odds.title} <span class="hint" data-r="otot"></span></div>
    <div class="oddhead"><span></span><span>${S.odds.label}</span><span>Peso</span><span>Probabilidad</span><span></span></div>
    <div class="odds" data-r="odds"></div>
    <div class="row" style="margin:0">${S.odds.removable ? '<button class="btn sm" data-o="add">➕ Agregar</button>' : ''}<button class="btn sm" data-o="eq">⚖️ Igualar %</button></div>`;
  c.querySelector('[data-o=add]')?.addEventListener('click', () => { const l = oddsRows(key); l.push({ text: '', weight: 10 }); saveG(key, S.odds.path, l); paintOdds(key, true); c.querySelector('.odd:last-child input')?.focus(); });
  c.querySelector('[data-o=eq]').onclick = () => { saveG(key, S.odds.path, oddsRows(key).map(r => ({ ...r, weight: 10 }))); paintOdds(key, true); };
  return c;
}
function oddsRows(key) {
  const S = STUDIOS[key], g = cfgG(key);
  let rows = clone(getP(g, S.odds.path) || []);
  if (key === 'lucky') { const n = +g.sides || 6; while (rows.length < n) rows.push({ text: '', weight: 10 }); rows = rows.slice(0, n); }
  return rows;
}
function paintOdds(key, force) {
  const S = STUDIOS[key]; if (!S.odds) return;
  const box = document.querySelector(`#s-${key} [data-r=odds]`); if (!box || (!force && box.contains(document.activeElement))) return;
  const rows = oddsRows(key), pal = wheelPalette();
  box.innerHTML = rows.map((r, i) => `<div class="odd">
      <span class="num" style="background:${S.odds.numbered ? 'linear-gradient(135deg,var(--spark),var(--spark2))' : pal[i % pal.length]}">${S.odds.numbered ? i + 1 : ''}</span>
      <input class="i" data-k="text" data-i="${i}" value="${esc(r.text)}" placeholder="${S.odds.ph}">
      <input class="i" type="number" min="0" data-k="weight" data-i="${i}" value="${r.weight}">
      <div class="pc"><span data-pc="${i}"></span><i data-bar="${i}"></i></div>
      ${S.odds.removable ? `<button class="del" data-del="${i}" title="Quitar">✕</button>` : '<span></span>'}</div>`).join('');
  const pct = () => {
    const tot = rows.reduce((a, r) => a + (+r.weight || 0), 0);
    rows.forEach((r, i) => { const p = tot ? r.weight / tot * 100 : 0; box.querySelector(`[data-pc="${i}"]`).textContent = (p < 10 && p > 0 ? p.toFixed(1) : Math.round(p)) + '%'; box.querySelector(`[data-bar="${i}"]`).style.width = p + '%'; });
    document.querySelector(`#s-${key} [data-r=otot]`).textContent = tot ? '' : '· ⚠️ pon al menos un peso mayor a 0';
  };
  box.querySelectorAll('input').forEach(inp => inp.oninput = () => {
    rows[inp.dataset.i][inp.dataset.k] = inp.dataset.k === 'weight' ? Math.max(0, +inp.value || 0) : inp.value;
    if (inp.dataset.k === 'weight') pct();
    saveG(key, S.odds.path, clone(rows));
  });
  box.querySelectorAll('[data-del]').forEach(b => b.onclick = () => { if (rows.length <= 2) return toast('Mínimo 2 opciones'); rows.splice(+b.dataset.del, 1); saveG(key, S.odds.path, clone(rows)); paintOdds(key, true); });
  pct();
}

// Lista de jugadores / pujas con agregar a mano
function listCard(key, S) {
  const c = document.createElement('div'); c.className = 'panel';
  c.innerHTML = `<div class="ptitle c3">${S.list.title} <span class="hint" data-r="lcount"></span></div><div class="plist" data-r="plist"></div>
    ${S.list.add ? `<div class="addrow"><input class="i" placeholder="${S.list.add}" data-a="name"><input class="i" type="number" min="1" value="1" data-a="amount" title="${S.list.amount}"><button class="btn sm pri" data-a="go">＋</button></div>
    <div class="hint" style="margin-top:6px">Para gente que participa fuera de TikTok (o por otra cosa que no sea regalo).</div>` : ''}`;
  const go = c.querySelector('[data-a=go]');
  if (go) {
    const add = () => { const n = c.querySelector('[data-a=name]'); act(key, 'addEntry', { name: n.value, amount: +c.querySelector('[data-a=amount]').value || 1 }); n.value = ''; n.focus(); };
    go.onclick = add; c.querySelector('[data-a=name]').onkeydown = e => { if (e.key === 'Enter') add(); };
  }
  return c;
}
function paintList(key) {
  const S = STUDIOS[key]; if (!S.list || !window.state) return;
  const box = document.querySelector(`#s-${key} [data-r=plist]`); if (!box) return;
  const rows = S.list.rows(window.state);
  document.querySelector(`#s-${key} [data-r=lcount]`).textContent = rows.length ? `· ${rows.length}` : '';
  box.innerHTML = rows.length ? rows.map(r => `<div class="pl ${r.out ? 'out' : ''}" ${r.win ? 'style="border-color:var(--gold)"' : ''}>
      <span class="av">${avHtml(r.user)}</span><span class="pn">${r.win ? '👑 ' : ''}${esc(r.user.name)}</span><span class="pv">${r.value}</span>
      ${r.pct != null ? `<span class="ppc">${r.pct}%</span>` : ''}${S.list.remove ? `<button class="x" data-rm="${esc(r.id)}" title="Quitar">✕</button>` : ''}</div>`).join('')
    : `<div class="pempty"><span style="font-size:26px">👥</span><div><b>${S.list.empty[0]}</b>${S.list.empty[1]}</div></div>`;
  box.querySelectorAll('[data-rm]').forEach(b => b.onclick = () => act(key, 'removeEntry', { id: b.dataset.rm }));
}

// ---------- Campos de ajustes ----------
function fieldEl(key, f) {
  const w = document.createElement('div');
  if (f.t === 'note') { w.className = 'hint'; w.innerHTML = f.html; return w; }
  if (f.t === 'group') { w.className = 'fblock'; w.innerHTML = `<span class="flab">${f.label}</span>`; const inner = document.createElement('div'); inner.style.cssText = 'display:flex;flex-direction:column;gap:10px'; f.fields.forEach(x => inner.appendChild(fieldEl(key, x))); w.appendChild(inner); return w; }
  if (f.t === 'entry') return entryEl(key);
  if (f.t === 'teams') return teamsEl(key, f.max);
  if (f.t === 'questions') return questionsEl(key);
  if (f.t === 'buttons') {
    w.className = 'fbtns';
    w.innerHTML = f.list.map(([a, l, cls, d], i) => `<button class="btn sm ${cls || ''}" data-fb="${i}">${l}</button>`).join('');
    w.querySelectorAll('[data-fb]').forEach(b => b.onclick = () => { const [a, , , d] = f.list[+b.dataset.fb]; if (d?.confirm && !confirm(d.confirm)) return; act(key, a, d || {}); });
    return w;
  }
  if (f.t === 'sounds') return soundsEl(key, f.list);
  if (f.t === 'evo') return evoEl(key, f);
  if (f.t === 'history') { w.className = 'histbox'; w.innerHTML = `<div class="row" style="justify-content:space-between;margin:0"><span class="flab" style="margin:0">RESULTADOS RECIENTES</span><button class="btn sm" data-hclear>🗑 Limpiar</button></div><div data-r="hist"></div>`; w.querySelector('[data-hclear]').onclick = () => act(key, 'clearHistory'); return w; }
  if (f.t === 'tiles') {
    w.className = 'fblock';
    w.innerHTML = `<span class="flab">${f.label}</span>${tilePicker(f.path)}`;
    bindTilePicker(w, v => { saveG(key, f.path, v); paintFields(key); });
    return w;
  }
  if (f.t === 'colors') {
    w.className = 'colors';
    w.innerHTML = [['primary', 'Principal'], ['secondary', 'Secundario'], ['accent', 'Detalles']].map(([k, l]) => `<label><input type="color" data-path="colors.${k}"> ${l}</label>`).join('');
    w.querySelectorAll('input').forEach(inp => inp.oninput = () => saveG(key, inp.dataset.path, inp.value));
    return w;
  }
  const desc = f.desc ? `<div class="fdesc">${f.desc}</div>` : '';
  if (f.t === 'area') {
    w.className = 'fblock';
    w.innerHTML = `<span class="flab">${f.label}</span>${desc}<textarea class="i area" rows="${f.rows || 8}" data-path="${f.path}" placeholder="${esc(f.ph || '')}" spellcheck="false"></textarea>`;
    const inp = w.querySelector('textarea'); inp.oninput = () => saveG(key, f.path, inp.value);
  } else if (f.t === 'text') {
    w.className = 'fblock';
    w.innerHTML = `<span class="flab">${f.label}</span>${desc}<input class="i" data-path="${f.path}" placeholder="${esc(f.ph || '')}">`;
    const inp = w.querySelector('input'); inp.oninput = () => saveG(key, f.path, inp.value);
  } else if (f.t === 'step') {
    w.className = 'stepf';
    w.innerHTML = `${f.icon ? `<span class="tc-ic">${f.icon}</span>` : ''}<div class="tc-t"><b>${f.label}</b>${f.desc ? `<small>${f.desc}</small>` : ''}</div>
      <div class="stepper"><button data-d="-1">−</button><input class="stp" inputmode="numeric" data-path="${f.path}"><button data-d="1">+</button></div>${f.unit ? `<span class="unit">${f.unit}</span>` : ''}`;
    const inp = w.querySelector('input');
    inp._f = f;
    const set = v => { v = Math.min(f.max, Math.max(f.min, Math.round(v / (f.step || 1)) * (f.step || 1) || 0)); saveG(key, f.path, v); paintStep(inp, v); };
    w.querySelectorAll('[data-d]').forEach(b => b.onclick = () => set((+getP(cfgG(key), f.path) || 0) + (+b.dataset.d) * (f.step || 1)));
    inp.onfocus = () => { inp.value = getP(cfgG(key), f.path) || 0; inp.select(); };
    inp.onchange = () => set(+String(inp.value).replace(/\D/g, '') || 0);
    inp.onkeydown = e => { if (e.key === 'Enter') inp.blur(); };
    inp.onblur = () => paintStep(inp, getP(cfgG(key), f.path));
  } else if (f.t === 'gift') {
    w.className = 'stepf giftf';
    w.innerHTML = `${f.icon ? `<span class="tc-ic">${f.icon}</span>` : ''}<div class="tc-t"><b>${f.label}</b>${f.desc ? `<small>${f.desc}</small>` : ''}</div>
      <button class="gbtn" data-gpath="${f.path}" title="Elegir regalo">${giftChip(getP(cfgG(key), f.path))}</button>`;
    w.querySelector('[data-gpath]').onclick = () => openGiftPicker({ title: f.label, onPick: g => { saveG(key, f.path, g.name); w.querySelector('[data-gpath]').innerHTML = giftChip(g.name); } });
  } else if (f.t === 'range') {
    w.className = 'fblock';
    w.innerHTML = `<div class="rng"><div class="lab"><span class="flab" style="margin:0">${f.label}</span><b data-out></b></div>${desc}<input type="range" data-path="${f.path}" min="${f.min}" max="${f.max}" step="${f.step}"></div>`;
    const inp = w.querySelector('input');
    inp.oninput = () => { paintRange(inp); w.querySelector('[data-out]').textContent = inp.value + f.unit; saveG(key, f.path, +inp.value); };
    inp._f = f;
  } else if (f.t === 'toggle') {
    w.className = 'tcard'; w.dataset.color = f.color || 'vio';
    w.innerHTML = `<div class="tc-head">${f.icon ? `<span class="tc-ic">${f.icon}</span>` : ''}<div class="tc-t"><b>${f.label}</b>${f.desc ? `<small>${f.desc}</small>` : ''}</div>
      <label class="sw2"><input type="checkbox" data-path="${f.path}"><i></i></label></div>${f.sub ? '<div class="tc-sub"></div>' : ''}`;
    if (f.sub) f.sub.forEach(x => w.querySelector('.tc-sub').appendChild(fieldEl(key, x)));
    const inp = w.querySelector('input');
    inp.onchange = () => { saveG(key, f.path, inp.checked); w.classList.toggle('is-on', inp.checked); };
  } else if (f.t === 'chips') {
    w.className = 'fblock';
    w.innerHTML = `<span class="flab">${f.label}</span>${desc}<div class="vchips" data-chips="${f.path}">${f.opts.map(([v, l, d]) => `<button data-v="${v}">${l}${d ? `<small>${d}</small>` : ''}</button>`).join('')}</div>`;
    w.querySelectorAll('[data-v]').forEach(b => b.onclick = () => {
      const v = typeof f.opts[0][0] === 'number' ? +b.dataset.v : b.dataset.v;
      saveG(key, f.path, v); paintFields(key);
      if (f.path === 'sides') paintOdds(key, true);
      if (f.path === 'anim') setTimeout(() => key === 'alertas' ? act(key, 'test', { kind: 'gift', coins: 1000 }) : socket.emit('preview', { key }), 350);
    });
  } else if (f.t === 'image') {
    w.className = 'fblock';
    w.innerHTML = `<span class="flab">${f.label}</span>
      <div class="imgpick"><div class="ph" data-img="${f.path}">🖼️</div><div class="it"><b>Subir PNG o GIF</b><br>${f.desc || 'Haz clic o arrastra una imagen.'}</div>
      <button class="btn sm danger" data-rmimg>Quitar</button></div>`;
    imgDrop(w.querySelector('.imgpick'), `games.${key}.${f.path}`);
  }
  return w;
}
function imgDrop(pick, target) {
  pick.onclick = e => { if (e.target.closest('[data-rmimg]')) return socket.emit('removeAsset', target); pickImage(target); };
  pick.ondragover = e => { e.preventDefault(); pick.classList.add('over'); };
  pick.ondragleave = () => pick.classList.remove('over');
  pick.ondrop = e => { e.preventDefault(); pick.classList.remove('over'); e.dataTransfer.files[0] && readImage(e.dataTransfer.files[0], d => socket.emit('uploadAsset', { target, dataUrl: d })); };
}
function paintStep(inp, v) {
  if (document.activeElement === inp) return;
  const f = inp._f; v = +v || 0;
  inp.value = !v && f.zero ? f.zero : v.toLocaleString('es');
  inp.classList.toggle('zero', !v && !!f.zero);
}

// Formas de entrar (regalo, chat, likes, follow, share)
function entryEl(key) {
  const w = document.createElement('div'); w.className = 'src';
  const rows = [
    ['gift', '🎁', 'Regalos', 'Configura cuáles en "Regalos que cuentan"', [], 'gold'],
    ['chat', '💬', 'Comando en el chat', 'Escriben un comando para entrar', [['command', 'text', 'Comando'], ['value', 'num', 'vale']], 'blue'],
    ['likes', '👍', 'Likes', 'Dar likes cuenta para entrar', [['every', 'num', 'cada'], ['value', 'num', 'likes = puntos']], 'pink'],
    ['follow', '💗', 'Seguir la cuenta', 'Los nuevos seguidores entran solos', [['value', 'num', 'vale']], 'red'],
    ['share', '📣', 'Compartir el live', 'Quien comparte entra', [['value', 'num', 'vale']], 'green'],
  ];
  w.innerHTML = rows.map(([k, ic, l, d, xs, col]) => `<div class="tcard" data-color="${col}"><div class="tc-head"><span class="tc-ic">${ic}</span><div class="tc-t"><b>${l}</b><small>${d}</small></div>
    <label class="sw2"><input type="checkbox" data-path="entry.${k}.on"><i></i></label></div>
    ${xs.length ? `<div class="tc-sub row-sub">${xs.map(([p, t, lab]) => `<span>${lab}</span> <input class="i" data-path="entry.${k}.${p}" ${t === 'num' ? 'type="number" min="1"' : ''}>`).join(' ')}</div>` : ''}</div>`).join('')
    + `<div class="fblock"><div class="rng"><div class="lab"><span class="flab" style="margin:0">⏳ Espera entre comandos del mismo viewer</span><b data-out></b></div><input type="range" data-path="entry.cooldown" min="0" max="300" step="5"></div></div>`;
  w.querySelectorAll('[data-path]').forEach(inp => {
    const p = inp.dataset.path;
    inp.addEventListener(inp.type === 'checkbox' ? 'change' : 'input', () => {
      const v = inp.type === 'checkbox' ? inp.checked : inp.type === 'number' ? Math.max(1, +inp.value || 1) : inp.type === 'range' ? +inp.value : inp.value;
      if (inp.type === 'range') { paintRange(inp); inp.closest('.rng').querySelector('[data-out]').textContent = v + ' s'; }
      saveG(key, p, v);
      if (inp.type === 'checkbox') inp.closest('.tcard')?.classList.toggle('is-on', v);
      if (p === 'entry.gift.on') paintGifts(key);
    });
    if (inp.type === 'range') inp._f = { unit: ' s' };
  });
  return w;
}

// ---------- Sonidos ----------
function soundsEl(key, list) {
  const w = document.createElement('div'); w.className = 'snds'; w.dataset.key = key; w._list = list;
  w.innerHTML = `<div class="fblock"><div class="rng"><div class="lab"><span class="flab" style="margin:0">🔊 Volumen de este juego</span><b data-out></b></div><input type="range" data-path="volume" min="0" max="100"></div></div>
    <div class="tcard" data-color="blue"><div class="tc-head"><span class="tc-ic">🔊</span><div class="tc-t"><b>Sonidos activados</b><small>Apaga todos los sonidos de este juego de una vez</small></div><label class="sw2"><input type="checkbox" data-path="effects.sound"><i></i></label></div></div>
    <div class="flab" style="margin:6px 0 0">EFECTOS DE SONIDO</div><div data-r="slist" style="display:flex;flex-direction:column;gap:8px"></div>
    <div class="hint">🔈 Los sonidos suenan dentro del overlay (OBS / LIVE Studio). En OBS marca <b>"Controlar audio vía OBS"</b> en la fuente si no los escuchas.</div>`;
  const vol = w.querySelector('[data-path=volume]'); vol._f = { unit: '%' };
  vol.oninput = () => { paintRange(vol); w.querySelector('[data-out]').textContent = vol.value + '%'; saveG(key, 'volume', +vol.value); };
  w.querySelector('[data-path="effects.sound"]').onchange = e => { saveG(key, 'effects.sound', e.target.checked); e.target.closest('.tcard').classList.toggle('is-on', e.target.checked); };
  return w;
}
function paintSounds(key, force) {
  const w = document.querySelector(`#s-${key} .snds`); if (!w) return;
  const box = w.querySelector('[data-r=slist]');
  if (!force && box.contains(document.activeElement) && document.activeElement.tagName !== 'BUTTON') return;
  const S = cfgG(key).sounds || {};
  const nameOf = s => s?.file ? '🎵 Mi sonido' : (SFX[s?.preset] || 'Ninguno');
  box.innerHTML = w._list.map(([k, label, desc, icon, tiers]) => {
    const s = S[k] || {};
    const tl = s.tiers || [];
    return `<div class="tcard ${s.on ? 'is-on' : ''}" data-color="${k === 'winner' || k === 'jackpot' ? 'gold' : k === 'elimination' ? 'red' : k === 'entry' ? 'green' : 'blue'}" data-snd="${k}">
      <div class="tc-head"><span class="tc-ic">${icon}</span><div class="tc-t"><b>${label} ${tl.length ? '<span class="tierbadge">NIVELES</span>' : ''}</b><small>${desc || ''}</small></div>
        <label class="sw2"><input type="checkbox" data-on ${s.on ? 'checked' : ''}><i></i></label></div>
      <div class="snd-ctl"><button class="ib" data-play title="Escuchar">▶</button>
        <select class="i sel" data-preset>${presetOpts(s.file ? '__mine' : s.preset)}${s.file ? '<option value="__mine" selected>🎵 Mi sonido</option>' : ''}</select>
        ${s.file ? '<span class="hint">🎵 Mi sonido</span>' : ''}</div>
      ${tiers ? `<div class="tc-sub stiers">
        <div class="hint">Niveles de sonido: regalos más grandes, sonido más grande. ${tl.length ? 'Con niveles, un regalo menor a todos no suena.' : ''}</div>
        ${tl.map((t, i) => `<div class="strow" data-ti="${i}"><span>Desde</span><input class="i" type="number" min="0" data-tmin value="${t.min}"><span>🪙</span>
          <select class="i sel" data-tpre>${presetOpts(t.file ? '__mine' : t.preset)}${t.file ? '<option value="__mine" selected>🎵 Mi sonido</option>' : ''}</select>
          <button class="ib" data-tplay>▶</button><button class="ib" data-tdel>✕</button></div>`).join('')}
        <button class="addtier" data-tadd>＋ Agregar nivel</button>
        ${tl.length ? `<div class="hint" data-thint></div>` : ''}</div>` : ''}</div>`;
  }).join('');
  const save = (k, p, v) => { saveG(key, `sounds.${k}.${p}`, v); };
  box.querySelectorAll('[data-snd]').forEach(card => {
    const k = card.dataset.snd, s = clone(S[k] || {});
    card.querySelector('[data-play]').onclick = () => playSpec({ ...s, on: true }, panelVol(key));
    card.querySelector('[data-on]').onchange = e => { save(k, 'on', e.target.checked); card.classList.toggle('is-on', e.target.checked); };
    card.querySelector('[data-preset]').onchange = e => {
      const v = e.target.value;
      if (v === '__file') { pickAudio(`games.${key}.sounds.${k}.file`); return paintSounds(key, true); }
      if (v === '__mine') return;
      save(k, 'preset', v); save(k, 'file', ''); playSpec({ on: true, preset: v }, panelVol(key)); setTimeout(() => paintSounds(key, true), 50);
    };
    const tl = s.tiers || [];
    const saveT = () => { save(k, 'tiers', clone(tl)); };
    card.querySelectorAll('[data-ti]').forEach(row => {
      const i = +row.dataset.ti;
      row.querySelector('[data-tmin]').oninput = e => { tl[i].min = Math.max(0, +e.target.value || 0); saveT(); hint(); };
      row.querySelector('[data-tpre]').onchange = e => {
        const v = e.target.value;
        if (v === '__file') { pickAudio(`games.${key}.sounds.${k}.tiers.${i}.file`); return; }
        if (v === '__mine') return;
        tl[i].preset = v; tl[i].file = ''; saveT(); playSpec({ on: true, preset: v }, panelVol(key));
      };
      row.querySelector('[data-tplay]').onclick = () => playSpec({ on: true, preset: tl[i].preset, file: tl[i].file }, panelVol(key));
      row.querySelector('[data-tdel]').onclick = () => { tl.splice(i, 1); saveT(); paintSounds(key, true); };
    });
    card.querySelector('[data-tadd]')?.addEventListener('click', () => {
      const last = tl.length ? Math.max(...tl.map(t => +t.min || 0)) : 0;
      tl.push({ min: last ? last * 10 : 1, preset: ['coin', 'gift', 'fanfare', 'airhorn'][Math.min(3, tl.length)], file: '' }); saveT(); paintSounds(key, true);
    });
    const hint = () => {
      const h = card.querySelector('[data-thint]'); if (!h) return;
      const t = [...tl].filter(x => 10 >= x.min).sort((a, b) => b.min - a.min)[0];
      h.innerHTML = `🔈 Un regalo de 10 monedas suena: <b>${t ? (t.file ? 'Mi sonido' : SFX[t.preset] || 'nada') : 'nada (ningún nivel llega)'}</b>`;
    };
    hint();
  });
}

// ---------- Evoluciones ----------
function evoEl(key, f) {
  const w = document.createElement('div'); w.className = 'evos'; w._f = f;
  w.innerHTML = `<div class="tcard" data-color="vio"><div class="tc-head"><span class="tc-ic">🧬</span><div class="tc-t"><b>${f.alert ? 'Niveles de alerta' : 'Evoluciones'}</b><small>${f.desc}</small></div>
      <label class="sw2"><input type="checkbox" data-path="evo.on"><i></i></label></div></div>
    <div data-r="tiers" style="display:flex;flex-direction:column;gap:10px"></div>
    <button class="addtier big" data-add>＋ Agregar nivel</button>
    <div class="hint">En los textos puedes usar <b>{usuario}</b>, <b>{monedas}</b> y <b>{nivel}</b>.</div>`;
  w.querySelector('[data-path="evo.on"]').onchange = e => { saveG(key, 'evo.on', e.target.checked); e.target.closest('.tcard').classList.toggle('is-on', e.target.checked); };
  w.querySelector('[data-add]').onclick = () => {
    const tiers = clone(cfgG(key).evo?.tiers || []);
    const last = tiers.length ? Math.max(...tiers.map(t => +t.coins || 0)) : 0;
    tiers.push({ coins: last ? last * 2 : 100, name: `Nivel ${tiers.length + 1}`, text: '', image: '', sound: 'levelup', soundFile: '', confetti: true, effect: 'flash', variant: '' });
    saveG(key, 'evo.tiers', tiers); paintEvo(key, true);
  };
  return w;
}
function paintEvo(key, force) {
  const w = document.querySelector(`#s-${key} .evos`); if (!w) return;
  const box = w.querySelector('[data-r=tiers]'), f = w._f;
  if (!force && box.contains(document.activeElement) && ['INPUT', 'SELECT'].includes(document.activeElement.tagName) && document.activeElement.type !== 'checkbox') return;
  const tiers = clone(cfgG(key).evo?.tiers || []);
  const order = tiers.map((t, i) => i).sort((a, b) => (+tiers[a].coins || 0) - (+tiers[b].coins || 0));
  const skins = STUDIOS[key].tabs.find(t => t.id === 'diseno')?.fields.find(x => x.path === 'variant')?.opts || [];
  box.innerHTML = order.map((i, n) => {
    const t = tiers[i];
    return `<div class="evocard" data-i="${i}">
      <div class="ev-hd"><span class="ev-n">NIVEL ${n + 1}</span><b>${esc(t.name || '')}</b><span style="flex:1"></span>
        <button class="btn sm" data-test>▶ Probar</button><button class="ib" data-del title="Quitar nivel">✕</button></div>
      <div class="ev-grid">
        <div class="imgpick ev-img" data-pick><div class="ph">${t.image ? `<img src="${esc(t.image)}">` : '🖼️'}</div><div class="it"><b>${f.imgLabel || 'Imagen o GIF del nivel'}</b><br>${f.imgDesc || 'Sale en el banner de evolución'}</div>${t.image ? '<button class="btn sm danger" data-rmimg>Quitar</button>' : ''}</div>
        <div class="stepf"><span class="tc-ic">🪙</span><div class="tc-t"><b>Desde</b><small>${f.unit}</small></div>
          <div class="stepper"><button data-cd="-1">−</button><input class="stp" inputmode="numeric" data-k="coins" value="${(+t.coins || 0).toLocaleString('es')}"><button data-cd="1">+</button></div>
          <button class="btn sm" data-gift title="Usar el valor de un regalo">🎁</button></div>
        <label class="f">Nombre del nivel<input class="i" data-k="name" value="${esc(t.name)}"></label>
        ${f.alert ? '' : `<label class="f">Mensaje<input class="i" data-k="text" value="${esc(t.text)}" placeholder="¡{usuario} evolucionó!"></label>`}
        <div class="ev-row"><span class="flab" style="margin:0">Sonido</span>
          <select class="i sel" data-snd>${presetOpts(t.soundFile ? '__mine' : t.sound)}${t.soundFile ? '<option value="__mine" selected>🎵 Mi sonido</option>' : ''}</select><button class="ib" data-play>▶</button></div>
        <div class="ev-row"><span class="flab" style="margin:0">Efecto</span><div class="seg sm">${EFFECTS.map(([v, l]) => `<button data-fx="${v}" class="${(t.effect || 'none') === v ? 'on' : ''}">${l}</button>`).join('')}</div></div>
        <label class="sw" style="margin:0"><input type="checkbox" data-k="confetti" ${t.confetti !== false ? 'checked' : ''}> 🎉 Confeti</label>
        ${f.variants ? `<div class="ev-row"><span class="flab" style="margin:0">El frasco se convierte en</span><div class="seg sm">${[['', 'Igual'], ...skins].map(([v, l]) => `<button data-skin="${v}" class="${(t.variant || '') === v ? 'on' : ''}">${l}</button>`).join('')}</div></div>` : ''}
      </div></div>`;
  }).join('') || `<div class="pempty"><span style="font-size:26px">🧬</span><div><b>Sin niveles</b>Agrega un nivel: elige las monedas, sube tu GIF y su sonido.</div></div>`;
  const saveAll = () => saveG(key, 'evo.tiers', clone(tiers));
  box.querySelectorAll('.evocard').forEach(card => {
    const i = +card.dataset.i, t = tiers[i];
    card.querySelectorAll('input.i[data-k]').forEach(inp => {
      if (inp.dataset.k === 'coins') {
        inp.onfocus = () => { inp.value = t.coins; inp.select(); };
        inp.onchange = () => { t.coins = Math.max(1, +String(inp.value).replace(/\D/g, '') || 1); saveAll(); };
        inp.onblur = () => { inp.value = (+t.coins).toLocaleString('es'); };
      } else inp.oninput = () => { t[inp.dataset.k] = inp.value; saveAll(); if (inp.dataset.k === 'name') card.querySelector('.ev-hd b').textContent = inp.value; };
    });
    card.querySelectorAll('[data-cd]').forEach(b => b.onclick = () => { const step = t.coins >= 1000 ? 100 : t.coins >= 100 ? 10 : 1; t.coins = Math.max(1, (+t.coins || 0) + (+b.dataset.cd) * step); saveAll(); paintEvo(key, true); });
    card.querySelector('[data-gift]').onclick = () => openGiftPicker({ title: 'Usar el valor de un regalo', onPick: g => { t.coins = Math.max(1, +g.coins || 1); saveAll(); paintEvo(key, true); } });
    card.querySelector('[data-k=confetti]').onchange = e => { t.confetti = e.target.checked; saveAll(); };
    card.querySelectorAll('[data-fx]').forEach(b => b.onclick = () => { t.effect = b.dataset.fx; saveAll(); paintEvo(key, true); });
    card.querySelectorAll('[data-skin]').forEach(b => b.onclick = () => { t.variant = b.dataset.skin; saveAll(); paintEvo(key, true); });
    card.querySelector('[data-snd]').onchange = e => {
      const v = e.target.value;
      if (v === '__file') { pickAudio(`games.${key}.evo.tiers.${i}.soundFile`); return; }
      if (v === '__mine') return;
      t.sound = v; t.soundFile = ''; saveAll(); playSpec({ on: true, preset: v }, panelVol(key));
    };
    card.querySelector('[data-play]').onclick = () => playSpec({ on: true, preset: t.sound, file: t.soundFile }, panelVol(key));
    card.querySelector('[data-test]').onclick = () => { act(key, 'evoTest', { i }); playSpec({ on: true, preset: t.sound, file: t.soundFile }, panelVol(key)); };
    card.querySelector('[data-del]').onclick = () => { tiers.splice(i, 1); saveAll(); paintEvo(key, true); };
    const pick = card.querySelector('[data-pick]');
    imgDrop(pick, `games.${key}.evo.tiers.${i}.image`);
  });
}

// Pinta los valores actuales en los campos (sin pisar lo que el usuario escribe)
function paintFields(key) {
  const sec = document.getElementById('s-' + key); if (!sec) return;
  const g = cfgG(key);
  sec.querySelectorAll('.settings [data-path], .studio-head [data-path]').forEach(inp => {
    if (document.activeElement === inp) return;
    const v = getP(g, inp.dataset.path);
    if (inp.type === 'checkbox') { inp.checked = !!v; inp.closest('.tcard')?.classList.toggle('is-on', inp.checked); }
    else if (inp.type === 'range') { inp.value = v ?? inp.min; paintRange(inp); const o = inp.closest('.rng')?.querySelector('[data-out]'); if (o) o.textContent = inp.value + (inp._f?.unit ?? ''); }
    else if (inp.classList.contains('stp')) paintStep(inp, v);
    else inp.value = v ?? '';
  });
  sec.querySelectorAll('[data-gpath]').forEach(b => { b.innerHTML = giftChip(getP(g, b.dataset.gpath)); });
  sec.querySelectorAll('[data-chips]').forEach(box => { const v = String(getP(g, box.dataset.chips) ?? ''); box.querySelectorAll('[data-v]').forEach(b => b.classList.toggle('on', b.dataset.v === v)); });
  sec.querySelectorAll('[data-img]').forEach(ph => { const v = getP(g, ph.dataset.img); ph.innerHTML = v ? `<img src="${esc(v)}">` : '🖼️'; ph.closest('.imgpick').querySelector('[data-rmimg]').style.display = v ? '' : 'none'; });
  sec.querySelectorAll('.has-when').forEach(el => el.classList.toggle('hidden', !el._when(g)));
  sec.querySelectorAll('[data-tp]').forEach(gr => gr.querySelectorAll('[data-tile]').forEach(b => b.classList.toggle('on', b.dataset.tile === getP(g, gr.dataset.tp))));
  const S = STUDIOS[key];
  if (S.giftsTitleFn) sec.querySelector('[data-r=gtitle]').textContent = S.giftsTitleFn(g);
  if (S.odds?.when) sec.querySelector('[data-card=odds]')?.classList.toggle('hidden', !S.odds.when(g));
  if (S.prizes) sec.querySelector('[data-card=prizes]')?.classList.toggle('hidden', g.mode !== 'cofre');
  paintPresets(key); paintWheels(key); paintPrizes(key); paintTeams(key); paintQuestions(key);
  const on = g.enabled !== false; sec.classList.toggle('disabled', !on);
  const oo = sec.querySelector('[data-onoff]'); if (oo) oo.checked = on;
  const lab = sec.querySelector('[data-r=onlab]'); if (lab) lab.textContent = on ? 'Activo' : 'Apagado';
  const icon = sec.querySelector('[data-r=icon]'); icon.innerHTML = g.image ? `<img src="${esc(g.image)}">` : STUDIOS[key].icon;
  paintTimer(key); paintSounds(key); paintEvo(key); paintDiff(key);
}

// Cabecera, botones y lista según el estado en vivo
function paintState(key) {
  const S = STUDIOS[key], s = window.state, sec = document.getElementById('s-' + key); if (!sec || !s) return;
  let [pt, pc] = S.status(s) || ['', ''];
  if (S.onoff && cfgG(key).enabled === false) [pt, pc] = ['Apagado', ''];
  const pill = sec.querySelector('[data-r=pill]'); pill.textContent = '● ' + pt; pill.className = 's-pill ' + pc;
  const timerTxt = S.timer ? (() => { const ms = S.timer.ms(s); return ms != null ? fmtTime(ms) : null; })() : null;
  sec.querySelector('[data-r=stats]').innerHTML = [...S.stats(s), ...(timerTxt ? [['⏱', timerTxt]] : [])].map(([i, v]) => `<span class="s-stat">${i} ${v}</span>`).join('');
  const ctr = sec.querySelector('[data-r=controls]');
  const list = S.controls(s);
  const sig = JSON.stringify(list.map(x => x.slice(0, 4)));
  if (ctr.dataset.sig !== sig) {
    ctr.dataset.sig = sig;
    ctr.innerHTML = list.map(([a, l, c, dis], i) => `<button class="bigbtn ${c} ${dis ? 'dim' : ''}" data-i="${i}">${l}</button>`).join('');
    ctr.querySelectorAll('[data-i]').forEach(b => b.onclick = () => { const x = list[+b.dataset.i]; if (x[4]?.confirm && !confirm(x[4].confirm)) return; act(key, x[0], x[4]); });
  }
  paintList(key);
  paintTimer(key);
  paintHistory(key);
}

function initStudios(container) { Object.keys(STUDIOS).forEach(k => container.appendChild(buildStudio(k))); }
const safe = (k, fn) => { try { fn(); } catch (e) { console.warn('[estudio ' + k + ']', e); } };
function studiosOnConfig() { Object.keys(STUDIOS).forEach(k => { safe(k, () => paintFields(k)); safe(k, () => paintGifts(k)); safe(k, () => paintOdds(k)); safe(k, () => STUDIOS[k].paint?.(k, 'config')); }); }
function studiosOnState() { Object.keys(STUDIOS).forEach(k => { if (STUDIOS[k].onoff && window.state && !window.state[k] && STUDIOS[k].status) return; safe(k, () => paintState(k)); safe(k, () => STUDIOS[k].paint?.(k, 'state')); }); }
function studioOpened(key) {
  const f = document.querySelector(`#s-${key} iframe[data-src]`);
  if (f && !f.src) f.src = f.dataset.src;
  paintGifts(key); paintOdds(key); paintSounds(key, true); paintEvo(key, true); paintWheels(key, true); paintPrizes(key, true);
}
setInterval(() => { if (!window.state) return; Object.keys(STUDIOS).forEach(k => { const S = STUDIOS[k]; if (S.timer && document.getElementById('s-' + k)?.classList.contains('on')) { paintTimer(k); const ms = S.timer.ms(window.state); const st = document.querySelector(`#s-${k} .s-stat:last-child`); if (ms != null && st) st.textContent = '⏱ ' + fmtTime(ms); } }); }, 250);

// =====================================================================
// PRESETS e HISTORIAL (todos los juegos)
// =====================================================================
function paintPresets(key) {
  const box = document.querySelector(`#s-${key} [data-r=presets]`); if (!box) return;
  const list = (window.cfg.presets || {})[key] || [], active = (window.cfg.activePreset || {})[key];
  box.innerHTML = list.map(p => `<span class="pchip ${p.name === active ? 'on' : ''}"><button data-pa="${esc(p.name)}">${p.name === active ? '✓ ' : ''}${esc(p.name)}</button><button class="px" data-pd="${esc(p.name)}" title="Borrar">✕</button></span>`).join('')
    + (active ? `<button class="btn sm" data-psave title="Guarda los cambios actuales en el preset activo">💾 Guardar en "${esc(active)}"</button>` : '')
    + (list.length ? '' : '<span class="hint">Guarda configuraciones para cambiar rápido entre ellas.</span>');
  box.querySelectorAll('[data-pa]').forEach(b => b.onclick = () => { act(key, 'applyPreset', { name: b.dataset.pa }); toast(`Preset "${b.dataset.pa}" aplicado`); });
  box.querySelectorAll('[data-pd]').forEach(b => b.onclick = () => confirm(`¿Borrar el preset "${b.dataset.pd}"?`) && act(key, 'deletePreset', { name: b.dataset.pd }));
  box.querySelector('[data-psave]')?.addEventListener('click', () => act(key, 'savePreset', { name: active }));
}
function ago(t) { const s = Math.round((Date.now() - t) / 1000); return s < 60 ? 'ahora' : s < 3600 ? `hace ${Math.round(s / 60)} min` : s < 86400 ? `hace ${Math.round(s / 3600)} h` : `hace ${Math.round(s / 86400)} d`; }
function paintHistory(key) {
  const box = document.querySelector(`#s-${key} [data-r=hist]`); if (!box) return;
  const h = window.state?.history?.[key] || [];
  box.innerHTML = h.length ? h.map(x => `<div class="hrow"><span class="av">${avHtml(x.user || { name: '★' })}</span>
      <div class="hb"><div><b>${esc(x.user?.name || 'Juego')}</b> <span class="hint">${ago(x.t)}</span></div><div class="ht">${esc(x.text)}</div>${x.detail ? `<div class="hint">${esc(x.detail)}</div>` : ''}</div></div>`).join('')
    : `<div class="pempty"><span style="font-size:26px">📜</span><div><b>Sin resultados todavía</b>Aquí aparecen los ganadores y premios de este juego.</div></div>`;
}

// =====================================================================
// FONDOS DE CASILLA
// =====================================================================
function tilePicker(path, extraAttr = '') {
  return `<div class="tilegrid" ${path ? `data-tp="${path}"` : ''} ${extraAttr}>${Object.entries(TILES).map(([k, t]) => `<button class="tsw" data-tile="${k}" title="${t.n}" style="background:${t.bg}"></button>`).join('')}
    <button class="tsw rnd" data-tile="__rnd" title="Al azar">🎲</button></div>`;
}
function bindTilePicker(el, cb) {
  el.querySelectorAll('[data-tile]').forEach(b => b.onclick = () => {
    let v = b.dataset.tile; if (v === '__rnd') { const ks = Object.keys(TILES); v = ks[Math.floor(Math.random() * ks.length)]; }
    cb(v);
  });
}

// =====================================================================
// RULETA: editor de varias ruedas
// =====================================================================
const TRIG = [['gift', '🎁 Solo un regalo'], ['min', '⬆️ Valor mínimo'], ['any', '✨ Cualquier regalo'], ['command', '💬 Comando'], ['likes', '👍 Likes'], ['follow', '⭐ Follow'], ['share', '📣 Compartir']];
const ACTS = [['none', 'Sin acción'], ['sound', '🔊 Sonido'], ['tts', '🗣️ Voz (TTS)'], ['msg', '💬 Mensaje en pantalla']];
const wheelOpen = {};
function wheelsCard(key) {
  const c = document.createElement('div'); c.className = 'panel';
  c.innerHTML = `<div class="ptitle c4" style="justify-content:space-between"><span>🎡 Ruedas <span class="hint" data-r="wcount"></span></span><button class="btn sm pri" data-wadd>＋ Nueva rueda</button></div><div data-r="wheels" class="wlist"></div>`;
  c.querySelector('[data-wadd]').onclick = () => {
    const ws = clone(cfgG(key).wheels || []);
    const pal = ['#ff6a2b', '#ff2e7e', '#ffd23f', '#7c5cff', '#2ea7ff', '#2ee6a6'];
    const id = 'w' + Math.random().toString(36).slice(2, 8);
    ws.push({ id, on: true, name: `Rueda ${ws.length + 1}`, trigger: { type: 'gift', gift: 'Rose', min: 1, command: '!ruleta', every: 100, cooldown: 30 },
      segments: ['Premio 1', 'Premio 2', 'Premio 3', 'Sigue intentando'].map((t, i) => ({ on: true, text: t, weight: 10, color: pal[i], image: '', action: { type: 'none', value: '' } })) });
    wheelOpen[id] = true; saveG(key, 'wheels', ws); paintWheels(key, true);
  };
  return c;
}
function giftChip(name) {
  const g = (giftCatalog().find(x => x.name.toLowerCase() === String(name || '').toLowerCase())) || { name: name || 'Elegir regalo', icon: '🎁', coins: '' };
  return `<span class="gchip">${giftImg(g, 26)}<b>${esc(g.name)}</b>${g.coins !== '' ? `<small>🪙 ${g.coins}</small>` : ''}<i>▾</i></span>`;
}
function paintWheels(key, force) {
  const box = document.querySelector(`#s-${key} [data-r=wheels]`); if (!box) return;
  if (!force && box.contains(document.activeElement) && ['INPUT', 'SELECT'].includes(document.activeElement.tagName) && !['checkbox', 'color'].includes(document.activeElement.type)) return;
  const ws = clone(cfgG(key).wheels || []);
  document.querySelector(`#s-${key} [data-r=wcount]`).textContent = `· ${ws.filter(w => w.on).length} activas de ${ws.length}`;
  if (Object.keys(wheelOpen).length === 0 && ws[0]) wheelOpen[ws[0].id] = true;
  const save = () => saveG(key, 'wheels', clone(ws));
  box.innerHTML = ws.map((w, wi) => {
    const segs = w.segments || [], act = segs.filter(x => x.on !== false), tot = act.reduce((a, x) => a + (+x.weight || 0), 0) || 1;
    let acc = 0; const donut = act.map(x => { const a = acc; acc += (+x.weight || 0) / tot * 360; return `${x.color} ${a}deg ${acc}deg`; }).join(',');
    const t = w.trigger || {}, open = !!wheelOpen[w.id];
    const trigDetail = t.type === 'gift' ? `<button class="gpick" data-tg>${giftChip(t.gift)}</button>`
      : t.type === 'min' ? `<div class="stepper"><button data-tm="-1">−</button><input class="stp" data-tmin value="${t.min || 1}"><button data-tm="1">+</button></div><span class="unit">monedas o más</span><button class="btn sm" data-tgm title="Usar el valor de un regalo">🎁</button>`
      : t.type === 'command' ? `<input class="i" data-tcmd value="${esc(t.command || '!ruleta')}" style="max-width:160px"><span class="unit">espera</span><input class="i" type="number" min="0" data-tcd value="${t.cooldown ?? 30}" style="width:80px"><span class="unit">s por viewer</span>`
      : t.type === 'likes' ? `<span class="unit">cada</span><input class="i" type="number" min="1" data-tev value="${t.every || 100}" style="width:100px"><span class="unit">likes = 1 giro</span>`
      : `<span class="hint">${t.type === 'any' ? 'Cualquier regalo gira esta rueda.' : t.type === 'follow' ? 'Cada nuevo seguidor gira esta rueda.' : 'Cada vez que compartan el live gira esta rueda.'}</span>`;
    return `<div class="wcard ${w.on ? '' : 'off'} ${open ? 'open' : ''}" data-wi="${wi}">
      <div class="wc-hd">
        <span class="donut" style="background:conic-gradient(${donut || '#333 0 360deg'})"></span>
        <label class="sw2" title="Activar o apagar esta rueda"><input type="checkbox" data-won ${w.on ? 'checked' : ''}><i></i></label>
        <input class="i wname" data-wname value="${esc(w.name)}">
        <button class="ib" data-wspin title="Girar ahora">▶</button><button class="ib" data-wdup title="Duplicar">⧉</button><button class="ib" data-wdel title="Borrar">🗑</button>
        <button class="ib" data-wtog title="${open ? 'Cerrar' : 'Editar'}">${open ? '▴' : '▾'}</button>
      </div>
      <div class="wc-body">
        <div class="flab">⚡ ¿Qué la activa?</div>
        <div class="seg sm wtrig">${TRIG.map(([v, l]) => `<button data-tt="${v}" class="${t.type === v ? 'on' : ''}">${l}</button>`).join('')}</div>
        <div class="trow">${trigDetail}</div>
        <div class="flab" style="margin-top:6px">🍕 Porciones <span class="hint">(${act.length} activas)</span></div>
        <div class="segs">${segs.map((x, si) => {
          const p = x.on !== false ? (+x.weight || 0) / tot * 100 : 0, a = x.action || { type: 'none' };
          return `<div class="sg ${x.on === false ? 'off' : ''}" data-si="${si}">
            <input type="checkbox" data-son ${x.on !== false ? 'checked' : ''} title="Activa">
            <input type="color" data-scol value="${x.color || '#ff6a2b'}" title="Color">
            <input class="i" data-stext value="${esc(x.text)}" placeholder="Texto de la porción">
            <input class="i sw8" type="number" min="0" data-sw value="${x.weight}" title="Peso">
            <span class="pct">${p < 10 && p > 0 ? p.toFixed(1) : Math.round(p)}%</span>
            <button class="ib simg" data-simg title="Imagen de la porción">${x.image ? `<img src="${esc(x.image)}">` : '🖼'}</button>
            <button class="ib" data-sdel title="Quitar">✕</button>
            <div class="sact"><select class="i sel" data-sat>${ACTS.map(([v, l]) => `<option value="${v}" ${a.type === v ? 'selected' : ''}>${l}</option>`).join('')}</select>
              ${a.type === 'sound' ? `<select class="i sel" data-sav>${PRESETS.filter(([v]) => v !== 'none').map(([v, l]) => `<option value="${v}" ${a.value === v ? 'selected' : ''}>${l}</option>`).join('')}</select><button class="ib" data-splay>▶</button>`
                : a.type === 'tts' || a.type === 'msg' ? `<input class="i" data-sav value="${esc(a.value || '')}" placeholder="${a.type === 'tts' ? '{usuario} ganó {premio}' : 'Mensaje: usa {usuario} y {premio}'}">` : ''}</div>
          </div>`;
        }).join('')}</div>
        <div class="row" style="margin:6px 0 0"><button class="btn sm" data-sadd>＋ Porción</button><button class="btn sm" data-seq>⚖️ Igualar %</button></div>
      </div></div>`;
  }).join('') || `<div class="pempty"><span style="font-size:26px">🎡</span><div><b>Sin ruedas</b>Crea una con "＋ Nueva rueda".</div></div>`;

  box.querySelectorAll('.wcard').forEach(card => {
    const wi = +card.dataset.wi, w = ws[wi], t = w.trigger = w.trigger || {};
    const $ = q => card.querySelector(q);
    $('[data-won]').onchange = e => { w.on = e.target.checked; save(); card.classList.toggle('off', !w.on); };
    $('[data-wname]').oninput = e => { w.name = e.target.value; save(); };
    $('[data-wspin]').onclick = () => act(key, 'test', { wi });
    $('[data-wdup]').onclick = () => { const cp = clone(w); cp.id = 'w' + Math.random().toString(36).slice(2, 8); cp.name += ' (copia)'; ws.splice(wi + 1, 0, cp); wheelOpen[cp.id] = true; save(); paintWheels(key, true); };
    $('[data-wdel]').onclick = () => { if (confirm(`¿Borrar la rueda "${w.name}"?`)) { ws.splice(wi, 1); save(); paintWheels(key, true); } };
    $('[data-wtog]').onclick = () => { wheelOpen[w.id] = !wheelOpen[w.id]; paintWheels(key, true); };
    card.querySelectorAll('[data-tt]').forEach(b => b.onclick = () => { t.type = b.dataset.tt; save(); paintWheels(key, true); });
    $('[data-tg]')?.addEventListener('click', () => openGiftPicker({ title: `Regalo que activa "${w.name}"`, onPick: g => { t.gift = g.name; save(); paintWheels(key, true); } }));
    $('[data-tgm]')?.addEventListener('click', () => openGiftPicker({ title: 'Monedas mínimas = valor del regalo', onPick: g => { t.min = Math.max(1, +g.coins || 1); save(); paintWheels(key, true); } }));
    card.querySelectorAll('[data-tm]').forEach(b => b.onclick = () => { t.min = Math.max(1, (+t.min || 1) + (+b.dataset.tm) * ((t.min || 1) >= 100 ? 10 : 1)); save(); paintWheels(key, true); });
    $('[data-tmin]')?.addEventListener('change', e => { t.min = Math.max(1, +e.target.value || 1); save(); });
    $('[data-tcmd]')?.addEventListener('input', e => { t.command = e.target.value; save(); });
    $('[data-tcd]')?.addEventListener('input', e => { t.cooldown = Math.max(0, +e.target.value || 0); save(); });
    $('[data-tev]')?.addEventListener('input', e => { t.every = Math.max(1, +e.target.value || 1); save(); });
    $('[data-sadd]').onclick = () => { const pal = wheelPalette(); w.segments.push({ on: true, text: '', weight: 10, color: pal[w.segments.length % pal.length], image: '', action: { type: 'none', value: '' } }); save(); paintWheels(key, true); card.querySelector('.sg:last-child [data-stext]')?.focus(); };
    $('[data-seq]').onclick = () => { w.segments.forEach(x => x.weight = 10); save(); paintWheels(key, true); };
    card.querySelectorAll('.sg').forEach(row => {
      const si = +row.dataset.si, x = w.segments[si], a = x.action = x.action || { type: 'none', value: '' };
      const q = s => row.querySelector(s);
      q('[data-son]').onchange = e => { x.on = e.target.checked; save(); paintWheels(key, true); };
      q('[data-scol]').oninput = e => { x.color = e.target.value; save(); };
      q('[data-scol]').onchange = () => paintWheels(key, true);
      q('[data-stext]').oninput = e => { x.text = e.target.value; save(); };
      q('[data-sw]').oninput = e => { x.weight = Math.max(0, +e.target.value || 0); save(); };
      q('[data-sw]').onchange = () => paintWheels(key, true);
      q('[data-simg]').onclick = () => x.image && confirm('¿Quitar la imagen de esta porción? (Cancelar = cambiarla)') ? (x.image = '', save(), paintWheels(key, true)) : pickImage(`games.${key}.wheels.${wi}.segments.${si}.image`);
      q('[data-sdel]').onclick = () => { if (w.segments.length <= 2) return toast('Mínimo 2 porciones'); w.segments.splice(si, 1); save(); paintWheels(key, true); };
      q('[data-sat]').onchange = e => { a.type = e.target.value; a.value = a.type === 'sound' ? 'fanfare' : ''; save(); paintWheels(key, true); };
      const av = q('[data-sav]');
      if (av) av.addEventListener(av.tagName === 'SELECT' ? 'change' : 'input', e => { a.value = e.target.value; save(); if (av.tagName === 'SELECT') playSpec({ on: true, preset: a.value }, panelVol(key)); });
      q('[data-splay]')?.addEventListener('click', () => playSpec({ on: true, preset: a.value }, panelVol(key)));
    });
  });
}

// =====================================================================
// COFRE DE PREMIOS: editor de premios + barra de probabilidades
// =====================================================================
const prizeOpen = {};
function prizesCard(key) {
  const c = document.createElement('div'); c.className = 'panel'; c.dataset.card = 'prizes';
  c.innerHTML = `<div class="ptitle c4" style="justify-content:space-between"><span>🎁 Premios del cofre <span class="hint" data-r="pcount"></span></span><button class="btn sm pri" data-padd>＋ Agregar premio</button></div>
    <div data-r="prizes" class="plist2"></div>
    <div class="oddsbox"><div class="ob-hd"><span class="flab" style="margin:0">PROBABILIDADES</span><b data-r="pused"></b></div><div class="obar" data-r="obar"></div><div class="olegend" data-r="olegend"></div><div class="hint" data-r="onote"></div></div>`;
  c.querySelector('[data-padd]').onclick = () => {
    const P = clone(cfgG(key).prizes || []), ks = Object.keys(TILES);
    P.push({ on: true, name: `Premio ${P.length + 1}`, image: '', tile: ks[(P.length * 3 + 1) % ks.length], chance: 5, gift: '', action: { type: 'none', value: '' } });
    prizeOpen[P.length - 1] = true; saveG(key, 'prizes', P); paintPrizes(key, true);
  };
  return c;
}
function paintPrizes(key, force) {
  const box = document.querySelector(`#s-${key} [data-r=prizes]`); if (!box) return;
  if (!force && box.contains(document.activeElement) && ['INPUT', 'SELECT'].includes(document.activeElement.tagName) && document.activeElement.type !== 'checkbox' && document.activeElement.type !== 'range') { paintOddsBar(key); return; }
  const g = cfgG(key), P = clone(g.prizes || []);
  const save = () => { saveG(key, 'prizes', clone(P)); paintOddsBar(key); };
  document.querySelector(`#s-${key} [data-r=pcount]`).textContent = `· ${P.filter(p => p.on !== false).length}`;
  const giftOf = n => giftCatalog().find(x => x.name.toLowerCase() === String(n || '').toLowerCase());
  box.innerHTML = P.map((p, i) => {
    const gi = p.gift ? giftOf(p.gift) : null, im = p.image || gi?.image || '', open = !!prizeOpen[i];
    return `<div class="pz ${p.on === false ? 'off' : ''} ${open ? 'open' : ''}" data-pi="${i}">
      <div class="pz-hd">
        <span class="pzt" style="background:${tileBg(p.tile)}">${im ? `<img src="${esc(im)}" referrerpolicy="no-referrer">` : '🎁'}</span>
        <div class="pzn"><b>${esc(p.name || 'Sin nombre')}</b><small>${(+p.chance || 0)}% ${p.gift ? `· regalo propio: ${esc(p.gift)}` : ''}</small></div>
        <label class="sw2"><input type="checkbox" data-pon ${p.on !== false ? 'checked' : ''}><i></i></label>
        <button class="ib" data-ptog>${open ? '▴' : '✏️'}</button><button class="ib" data-pdel title="Borrar">🗑</button>
      </div>
      <div class="pz-body">
        <label class="f">Nombre del premio<input class="i" data-pname value="${esc(p.name)}"></label>
        <div class="imgpick" data-pimg><div class="ph">${p.image ? `<img src="${esc(p.image)}">` : '🖼️'}</div><div class="it"><b>Imagen del premio (PNG o GIF)</b><br>Si no subes una, se usa la del regalo propio.</div>${p.image ? '<button class="btn sm danger" data-rmimg>Quitar</button>' : ''}</div>
        <div class="flab">🎯 Probabilidad de ganar</div>
        <div class="chrow"><input type="range" min="0" max="100" step="0.5" data-pch value="${+p.chance || 0}"><input class="i" type="number" min="0" max="100" step="0.01" data-pchn value="${+p.chance || 0}"><span class="unit">%</span></div>
        <div class="flab">🎁 Regalo propio (opcional)</div>
        <div class="trow"><button class="gpick" data-pgift>${p.gift ? giftChip(p.gift) : '<span class="gchip"><b>Sin regalo propio</b><i>▾</i></span>'}</button>${p.gift ? '<button class="btn sm" data-pgx>Quitar</button>' : ''}</div>
        <div class="hint">Si alguien envía este regalo, tiene ${(+p.chance || 0)}% de ganar este premio (si no, sale "${esc(g.nothing?.label || 'Nada')}").</div>
        <div class="flab">🎨 Fondo de la casilla</div>
        <div data-ptiles>${tilePicker('', `data-cur="${p.tile}"`)}</div>
        <div class="flab">⚡ Al ganar este premio</div>
        <div class="sact"><select class="i sel" data-pat>${ACTS.map(([v, l]) => `<option value="${v}" ${(p.action?.type || 'none') === v ? 'selected' : ''}>${l}</option>`).join('')}</select>
          ${p.action?.type === 'sound' ? `<select class="i sel" data-pav>${PRESETS.filter(([v]) => v !== 'none').map(([v, l]) => `<option value="${v}" ${p.action.value === v ? 'selected' : ''}>${l}</option>`).join('')}</select><button class="ib" data-pplay>▶</button>`
            : p.action?.type === 'tts' || p.action?.type === 'msg' ? `<input class="i" data-pav value="${esc(p.action.value || '')}" placeholder="{usuario} ganó {premio}">` : ''}</div>
      </div></div>`;
  }).join('') || `<div class="pempty"><span style="font-size:26px">🎁</span><div><b>Sin premios</b>Agrega premios con su imagen y su %.</div></div>`;

  box.querySelectorAll('.pz').forEach(card => {
    const i = +card.dataset.pi, p = P[i]; p.action = p.action || { type: 'none', value: '' };
    const q = s => card.querySelector(s);
    q('[data-pon]').onchange = e => { p.on = e.target.checked; save(); card.classList.toggle('off', !p.on); };
    q('[data-ptog]').onclick = () => { prizeOpen[i] = !prizeOpen[i]; paintPrizes(key, true); };
    q('[data-pdel]').onclick = () => { if (confirm(`¿Borrar "${p.name}"?`)) { P.splice(i, 1); delete prizeOpen[i]; save(); paintPrizes(key, true); } };
    q('[data-pname]').oninput = e => { p.name = e.target.value; card.querySelector('.pzn b').textContent = p.name; save(); };
    const setCh = v => { p.chance = Math.max(0, Math.min(100, Math.round((+v || 0) * 100) / 100)); q('[data-pch]').value = p.chance; q('[data-pchn]').value = p.chance; paintRange(q('[data-pch]')); card.querySelector('.pzn small').firstChild.textContent = `${p.chance}% `; save(); };
    q('[data-pch]').oninput = e => setCh(e.target.value); paintRange(q('[data-pch]'));
    q('[data-pchn]').oninput = e => setCh(e.target.value);
    q('[data-pgift]').onclick = () => openGiftPicker({ title: `Regalo propio de "${p.name}"`, onPick: gg => { p.gift = gg.name; save(); paintPrizes(key, true); } });
    q('[data-pgx]')?.addEventListener('click', () => { p.gift = ''; save(); paintPrizes(key, true); });
    imgDrop(q('[data-pimg]'), `games.${key}.prizes.${i}.image`);
    const tp = q('[data-ptiles]'); tp.querySelectorAll('[data-tile]').forEach(b => b.classList.toggle('on', b.dataset.tile === p.tile));
    bindTilePicker(tp, v => { p.tile = v; save(); paintPrizes(key, true); });
    q('[data-pat]').onchange = e => { p.action.type = e.target.value; p.action.value = p.action.type === 'sound' ? 'fanfare' : ''; save(); paintPrizes(key, true); };
    const av = q('[data-pav]');
    if (av) av.addEventListener(av.tagName === 'SELECT' ? 'change' : 'input', e => { p.action.value = e.target.value; save(); if (av.tagName === 'SELECT') playSpec({ on: true, preset: p.action.value }, panelVol(key)); });
    q('[data-pplay]')?.addEventListener('click', () => playSpec({ on: true, preset: p.action.value }, panelVol(key)));
  });
  paintOddsBar(key);
}
function paintOddsBar(key) {
  const sec = document.getElementById('s-' + key); if (!sec) return;
  const g = cfgG(key), P = (g.prizes || []).filter(p => p.on !== false);
  const raw = P.reduce((a, p) => a + (+p.chance || 0), 0), used = Math.min(100, raw), nada = Math.max(0, 100 - used);
  const parts = [...P.map(p => ({ n: p.name, c: +p.chance || 0, bg: tileBg(p.tile) })), ...(nada > 0 ? [{ n: g.nothing?.label || 'Nada', c: nada, bg: tileBg(g.nothing?.tile || 'carbon'), nada: true }] : [])];
  const scale = raw > 100 ? 100 / (raw + nada) : 1;
  sec.querySelector('[data-r=pused]').textContent = `${Math.round(used * 100) / 100}% usado`;
  sec.querySelector('[data-r=pused]').className = raw > 100 ? 'warn' : '';
  sec.querySelector('[data-r=obar]').innerHTML = parts.map(x => `<span style="flex:${Math.max(.0001, x.c * scale)};background:${x.bg}" title="${esc(x.n)} ${x.c}%">${x.c * scale >= 6 ? Math.round(x.c) + '%' : ''}</span>`).join('');
  sec.querySelector('[data-r=olegend]').innerHTML = parts.map(x => `<span><i style="background:${x.bg}"></i>${esc(x.n)} ${x.c < 1 ? x.c : Math.round(x.c * 100) / 100}%</span>`).join('');
  sec.querySelector('[data-r=onote]').textContent = raw > 100 ? `⚠️ La suma es ${raw}%: los últimos premios no podrán salir completos. Baja algunos %.` : g.global === false ? 'Activador global apagado: cada premio solo se gana con su propio regalo.' : `Con el activador global, cada tirada usa estas probabilidades. Lo que sobra (${Math.round(nada * 100) / 100}%) es "${g.nothing?.label || 'Nada'}".`;
}

// =====================================================================
// META DE CORAZÓN: varias metas + acciones al cumplirla
// =====================================================================
const corUrl = id => { const g = cfgG('corazon').goals || []; return `${location.origin}/overlay/corazon.html${g[0]?.id === id ? '' : '?meta=' + id}`; };
function corGoalsCard(key) {
  const c = document.createElement('div'); c.className = 'panel'; c.dataset.card = 'corgoals';
  c.innerHTML = `<div class="ptitle c3">📂 Tus metas <span class="hint">cada una con su regalo, su meta, su diseño y su link</span></div>
    <div class="cg-list" data-r="cglist"></div>
    <div class="cg-new"><input class="i" data-r="cgname" placeholder="Nueva meta…" maxlength="40"><button class="btn" data-r="cgadd">＋</button></div>
    <div class="hint" style="margin-top:8px">Toca una meta para editarla (doble clic en el nombre para renombrar). El regalo, la meta y el diseño cambian solo para esa meta. 🔗 copia su link para OBS.</div>`;
  const add = () => { const n = c.querySelector('[data-r=cgname]').value.trim(); flushG(key); act(key, 'goalAdd', { name: n }); c.querySelector('[data-r=cgname]').value = ''; };
  c.querySelector('[data-r=cgadd]').onclick = add;
  c.querySelector('[data-r=cgname]').onkeydown = e => { if (e.key === 'Enter') add(); };
  return c;
}
function corActionCard(key) {
  const c = document.createElement('div'); c.className = 'panel'; c.dataset.card = 'coract';
  c.innerHTML = `<div class="ptitle c4">⚡ Acción al cumplir la meta</div>
    <div class="hint" style="margin-bottom:10px">Elige acciones de <b>Acciones y eventos</b>: se ejecutan cada vez que esta meta se llena (también en cada nivel si la meta sube sola).</div>
    <div class="cg-acts" data-r="cgacts"></div>`;
  return c;
}
let corLastSel = null;
function corPaint(key, why) {
  const g = cfgG(key), sec = document.getElementById('s-' + key); if (!sec || !g) return;
  const goals = g.goals?.length ? g.goals : [{ id: 'm1', name: 'Meta principal' }], all = window.state?.corazones || {};
  // lista de metas
  const box = sec.querySelector('[data-r=cglist]');
  if (box && !(box.contains(document.activeElement) && document.activeElement.tagName === 'INPUT')) {
    box.innerHTML = goals.map((x, i) => { const st = all[x.id] || { count: 0, target: x.id === g.sel ? g.target : (x.cfg?.target || 100) };
      return `<div class="cg ${x.id === g.sel ? 'on' : ''}" data-id="${x.id}"><span class="cg-dot">${x.id === g.sel ? '✏️' : '💖'}</span>
        <div class="cg-main"><input class="cg-name" value="${esc(x.name || 'Meta')}" maxlength="40" title="Doble clic para renombrar" readonly><small>${(st.count || 0).toLocaleString('es')} / ${(st.target || 0).toLocaleString('es')}${i === 0 ? ' · principal' : ''}</small></div>
        <div class="cg-btns"><button class="ib" data-cgcopy title="Copiar su link para OBS">🔗</button>${goals.length > 1 ? '<button class="ib" data-cgdel title="Borrar meta">🗑</button>' : ''}</div></div>`; }).join('');
    box.querySelectorAll('.cg').forEach(el => {
      const id = el.dataset.id, inp = el.querySelector('.cg-name');
      el.onclick = e => { if (e.target.closest('button') || !inp.readOnly) return; if (id !== g.sel) { flushG(key); act(key, 'goalSel', { id }); } };
      inp.ondblclick = () => { inp.readOnly = false; inp.focus(); inp.select(); };
      const done = () => { if (inp.readOnly) return; inp.readOnly = true; const n = inp.value.trim(); if (n) act(key, 'goalRename', { id, name: n }); };
      inp.onblur = done; inp.onkeydown = e => { if (e.key === 'Enter') inp.blur(); if (e.key === 'Escape') { inp.value = goals.find(x => x.id === id)?.name || ''; inp.blur(); } };
      el.querySelector('[data-cgcopy]').onclick = () => { navigator.clipboard.writeText(corUrl(id)); toast('Link de "' + (goals.find(x => x.id === id)?.name || 'Meta') + '" copiado ✓'); };
      el.querySelector('[data-cgdel]')?.addEventListener('click', () => { if (confirm(`¿Borrar la meta "${goals.find(x => x.id === id)?.name}"? Su link de OBS dejará de funcionar.`)) act(key, 'goalDel', { id }); });
    });
  }
  if (why === 'state') return;
  // acciones al cumplir
  const ab = sec.querySelector('[data-r=cgacts]');
  if (ab) {
    const rules = window.cfg?.actions?.rules || [], picked = new Set(g.actions || []);
    ab.innerHTML = rules.length ? rules.map(r => `<label class="cg-act ${picked.has(r.id) ? 'on' : ''}"><input type="checkbox" data-aid="${r.id}" ${picked.has(r.id) ? 'checked' : ''}><i></i><span>${esc(r.name || 'Sin nombre')}</span>${r.on ? '' : '<small>apagada en la lista</small>'}</label>`).join('')
      + `<div class="hint" style="margin-top:8px">${picked.size ? `✅ Al cumplirse se ejecutan <b>${picked.size}</b> acción(es).` : 'Nada elegido: al cumplirse no se ejecuta ninguna acción extra.'}</div>`
      : `<div class="hint">Todavía no tienes acciones. Créalas en <b>Acciones y eventos</b> (por ejemplo "sonido + GIF") y luego elígelas aquí.</div><button class="btn sm" style="margin-top:8px" data-goact>⚡ Ir a Acciones y eventos</button>`;
    ab.querySelectorAll('[data-aid]').forEach(i => i.onchange = () => { const l = new Set(cfgG(key).actions || []); i.checked ? l.add(i.dataset.aid) : l.delete(i.dataset.aid); saveG(key, 'actions', [...l]); corPaint(key, 'config'); });
    ab.querySelector('[data-goact]')?.addEventListener('click', () => document.querySelector('.nav[data-s="acciones"]')?.click());
  }
  // link y vista previa de la meta elegida
  if (corLastSel !== g.sel) {
    corLastSel = g.sel; const url = corUrl(g.sel);
    const cp = sec.querySelector('.s-links [data-copy]'); if (cp) cp.dataset.copy = url;
    const op = sec.querySelector('.s-links a'); if (op) op.href = url;
    const f = sec.querySelector('iframe[data-src]'); if (f) { f.dataset.src = url; if (f.src) f.src = url; }
    const nm = sec.querySelector('[data-r=name]'); if (nm) nm.textContent = 'Meta de corazón' + (goals.length > 1 ? ' · ' + (goals.find(x => x.id === g.sel)?.name || '') : '');
  }
}

// ---------- Equipos de la Batalla ----------
const TEAM_COLORS = ['#ff3b5c', '#2ea7ff', '#2ee6a6', '#ffd23f'];
const TEAM_EMOJI = ['🔴', '🔵', '🟢', '🟡'];
function teamsEl(key, max = 4) {
  const w = document.createElement('div'); w.className = 'fblock teams-ed'; w.dataset.teams = key;
  w.innerHTML = '<span class="flab">EQUIPOS</span><div class="teams-list" data-r="tlist"></div>' + (max > 2 ? '<button class="btn sm" data-r="tadd">＋ Agregar equipo</button>' : '');
  if (max <= 2) return w;
  w.querySelector('[data-r=tadd]').onclick = () => {
    const T = clone(cfgG(key).teams || []); if (T.length >= 4) return toast('Máximo 4 equipos');
    const n = T.length; T.push({ name: `Equipo ${n + 1}`, emoji: TEAM_EMOJI[n], color: TEAM_COLORS[n], gift: '', command: `!equipo${n + 1}` });
    saveG(key, 'teams', T); paintTeams(key, true);
  };
  return w;
}
function paintTeams(key, force) {
  const w = document.querySelector(`#s-${key} [data-teams]`); if (!w) return;
  const box = w.querySelector('[data-r=tlist]');
  if (!force && box.contains(document.activeElement)) return;
  const T = cfgG(key).teams || [];
  const giftOf = n => giftCatalog().find(g => g.name.toLowerCase() === String(n || '').toLowerCase()) || (n ? { name: n } : null);
  box.innerHTML = T.map((t, i) => { const g = giftOf(t.gift); return `<div class="team-row" data-ti="${i}" style="--tc:${esc(t.color || TEAM_COLORS[i])}">
    <input type="color" data-tf="color" value="${esc(t.color || TEAM_COLORS[i])}" title="Color">
    <input class="i team-emo" data-tf="emoji" value="${esc(t.emoji || '')}" maxlength="4" title="Emoji">
    <input class="i" data-tf="name" value="${esc(t.name || '')}" maxlength="24" placeholder="Nombre del equipo">
    <button class="btn sm team-gift" data-tg title="Regalo del equipo">${g ? `${giftImg(g, 22)} ${esc(g.name)}` : '🎁 Elegir regalo'}</button>
    <input class="i team-cmd" data-tf="command" value="${esc(t.command || '')}" maxlength="20" placeholder="!comando">
    ${T.length > 2 ? '<button class="x" data-tdel title="Quitar">✕</button>' : ''}</div>`; }).join('');
  const upd = (i, f, v) => { const A = clone(cfgG(key).teams || []); A[i] = { ...A[i], [f]: v }; saveG(key, 'teams', A); };
  box.querySelectorAll('.team-row').forEach(row => {
    const i = +row.dataset.ti;
    row.querySelectorAll('[data-tf]').forEach(inp => inp.addEventListener('input', () => { let v = inp.value; if (inp.dataset.tf === 'command') { v = v.trim().toLowerCase().replace(/\s+/g, ''); if (v && !v.startsWith('!')) v = '!' + v; } if (inp.dataset.tf === 'color') row.style.setProperty('--tc', v); upd(i, inp.dataset.tf, v); }));
    row.querySelector('[data-tf=command]').addEventListener('blur', () => paintTeams(key, true));
    row.querySelector('[data-tg]').onclick = () => openGiftPicker({ title: `Regalo de ${esc(T[i].name || 'este equipo')}`, onPick: g => { const used = (cfgG(key).teams || []).findIndex((x, j) => j !== i && String(x.gift).toLowerCase() === g.name.toLowerCase()); if (used >= 0) return toast(`Ese regalo ya es de ${cfgG(key).teams[used].name}`); upd(i, 'gift', g.name); paintTeams(key, true); } });
    row.querySelector('[data-tdel]')?.addEventListener('click', () => { if (!confirm(`¿Quitar ${T[i].name}?`)) return; const A = clone(cfgG(key).teams || []); A.splice(i, 1); saveG(key, 'teams', A); paintTeams(key, true); });
  });
}

function subFmt(sec) { sec = Math.max(0, Math.round(+sec || 0)); const h = Math.floor(sec / 3600), m = Math.floor(sec % 3600 / 60), x = sec % 60; return h ? `${h} h ${m} min` : m ? `${m} min${x ? ` ${x} s` : ''}` : `${x} s`; }

// ---------- Ranking por período ----------
const PERIODS = { live: ['🔴', 'Este live', 'de este live'], week: ['📅', 'Semana', 'de esta semana'], month: ['🗓', 'Mes', 'de este mes'], all: ['♾️', 'Siempre', 'de siempre'] };
function rankSrc(s) { const p = cfgG('top').period || 'live'; return p === 'live' ? s.ranks : (s.ranksP?.[p] || { gifts: [], likes: [], shares: [] }); }
function paintLastWeek() {
  const el = document.querySelector('#s-top [data-r=lastweek]'); if (!el || !window.state?.ranksP) return;
  const L = window.state.ranksP.lastWeek?.gifts || [], ends = window.state.ranksP.weekEndsAt;
  const left = ends ? Math.max(0, ends - Date.now()) : 0, d = Math.floor(left / 864e5), h = Math.floor(left % 864e5 / 36e5);
  const html = `<div class="lw-box"><b>🏆 Ganadores de la semana pasada</b>${L.length ? L.map((r, i) => `<span>${['🥇', '🥈', '🥉'][i]} ${esc(r.user.name)} · ${r.value.toLocaleString('es')} 🪙</span>`).join('') : '<span class="hint">Todavía no hay una semana anterior.</span>'}<small>⏳ Esta semana se reinicia en ${d ? `${d} d ` : ''}${h} h</small></div>`;
  if (el.innerHTML !== html) el.innerHTML = html;
}
socket.on('state', () => paintLastWeek());

// ---------- Preguntas propias de la Trivia ----------
function questionsEl(key) {
  const w = document.createElement('div'); w.className = 'fblock q-ed'; w.dataset.questions = key;
  w.innerHTML = `<span class="flab">TUS PREGUNTAS</span><div class="q-list" data-r="qlist"></div>
    <div class="row" style="margin:6px 0 0;gap:6px;flex-wrap:wrap"><button class="btn sm pri" data-r="qadd">＋ Agregar pregunta</button><button class="btn sm" data-r="qpaste">📋 Pegar varias</button></div>`;
  const save = Q => { saveG(key, 'questions', Q); paintQuestions(key, true); };
  w.querySelector('[data-r=qadd]').onclick = () => { const Q = clone(cfgG(key).questions || []); if (Q.length >= 300) return toast('Máximo 300 preguntas'); Q.unshift({ q: '', options: ['', '', '', ''], answer: 0 }); save(Q); setTimeout(() => w.querySelector('[data-qf=q]')?.focus(), 50); };
  w.querySelector('[data-r=qpaste]').onclick = () => {
    const txt = prompt('Pega una pregunta por línea, así:\nPregunta | opción A | opción B | opción C | opción D | letra correcta\n\nEjemplo:\n¿Capital de Francia? | Roma | París | Madrid | Lisboa | B');
    if (!txt) return;
    const add = [];
    for (const line of txt.split(/\r?\n/)) {
      const p = line.split('|').map(x => x.trim()); if (p.length < 4) continue;
      const ans = p.pop(), opts = p.slice(1, 5), i = /^[a-d]$/i.test(ans) ? 'abcd'.indexOf(ans.toLowerCase()) : /^[1-4]$/.test(ans) ? +ans - 1 : opts.findIndex(o => o.toLowerCase() === ans.toLowerCase());
      if (!p[0] || opts.length < 2 || i < 0 || i >= opts.length) continue;
      while (opts.length < 4) opts.push('');
      add.push({ q: p[0], options: opts, answer: i });
    }
    if (!add.length) return toast('No encontré preguntas con ese formato');
    save([...add, ...(cfgG(key).questions || [])].slice(0, 300)); toast(`✓ ${add.length} preguntas agregadas`);
  };
  return w;
}
function paintQuestions(key, force) {
  const w = document.querySelector(`#s-${key} [data-questions]`); if (!w) return;
  const box = w.querySelector('[data-r=qlist]'); if (!force && box.contains(document.activeElement)) return;
  const Q = cfgG(key).questions || [];
  box.innerHTML = Q.length ? Q.map((q, i) => `<div class="q-row" data-qi="${i}">
      <div class="q-top"><span class="q-n">${i + 1}</span><input class="i" data-qf="q" value="${esc(q.q || '')}" placeholder="Escribe la pregunta" maxlength="160"><button class="x" data-qdel title="Borrar">✕</button></div>
      <div class="q-opts">${[0, 1, 2, 3].map(j => `<label class="q-opt ${q.answer === j ? 'ok' : ''}"><input type="radio" name="qa${i}" data-qa="${j}" ${q.answer === j ? 'checked' : ''} title="Respuesta correcta"><b>${'ABCD'[j]}</b><input class="i" data-qo="${j}" value="${esc(q.options?.[j] || '')}" placeholder="Opción ${'ABCD'[j]}" maxlength="60"></label>`).join('')}</div></div>`).join('')
    : '<div class="hint">No tienes preguntas propias. Agrega las tuyas o usa las de ejemplo. Marca el círculo de la opción correcta.</div>';
  const upd = (i, fn) => { const A = clone(cfgG(key).questions || []); fn(A[i]); saveG(key, 'questions', A); };
  box.querySelectorAll('.q-row').forEach(row => {
    const i = +row.dataset.qi;
    row.querySelector('[data-qf=q]').addEventListener('input', e => upd(i, q => q.q = e.target.value));
    row.querySelectorAll('[data-qo]').forEach(inp => inp.addEventListener('input', () => upd(i, q => { q.options = q.options || ['', '', '', '']; q.options[+inp.dataset.qo] = inp.value; })));
    row.querySelectorAll('[data-qa]').forEach(r => r.addEventListener('change', () => { upd(i, q => q.answer = +r.dataset.qa); paintQuestions(key, true); }));
    row.querySelector('[data-qdel]').onclick = () => { if (!confirm('¿Borrar esta pregunta?')) return; const A = clone(cfgG(key).questions || []); A.splice(i, 1); saveG(key, 'questions', A); paintQuestions(key, true); };
  });
}
