// ===== Conexión con Roblox — página del panel =====
(function () {
  const R = () => window.cfg?.roblox || {};
  let ST = {}, LOG = [];
  const KINDS = [['gift', '🎁 Regalos'], ['like', '👍 Likes'], ['follow', '💗 Seguidores'], ['share', '📣 Compartidos'], ['chat', '💬 Comentarios'], ['join', '🚪 Entradas al live'], ['sub', '👑 Super fans']];

  let pend = {}, pt;
  function save(key, v) {
    window.cfg.roblox = window.cfg.roblox || {};
    if (key.startsWith('events.')) { const k = key.slice(7); window.cfg.roblox.events = { ...(window.cfg.roblox.events || {}), [k]: v }; pend.events = { ...(pend.events || {}), [k]: v }; }
    else { window.cfg.roblox[key] = v; pend[key] = v; }
    clearTimeout(pt); pt = setTimeout(() => { socket.emit('saveConfig', { roblox: pend }); pend = {}; flash(); }, 350);
    paint();
  }
  function flash() { const s = sec.querySelector('.saved'); if (s) { s.classList.add('on'); setTimeout(() => s.classList.remove('on'), 1200); } }

  const sec = document.createElement('section'); sec.className = 'sec'; sec.id = 's-roblox';
  sec.innerHTML = `
  <div class="vz-head panel">
    <div class="vz-mascot rbx-logo">🧱</div>
    <div class="vz-ttl"><h1 class="display">Roblox <span class="saved">✓ Guardado</span></h1><p class="hint">Tu live controla tu juego de Roblox: los regalos, likes y comentarios activan poderes dentro del juego.</p></div>
    <label class="vz-power"><input type="checkbox" data-k="on"><span class="vz-pw"><i></i></span><b data-r="pwlab">Apagado</b></label>
  </div>
  <div class="vz-offbar" data-r="offbar">🧱 <b>La conexión con Roblox está apagada:</b> no se manda nada al juego. <button class="btn sm pri" data-r="turnon">Encender</button></div>
  <div class="rbx-status panel" data-r="status"></div>
  <div class="rbx-grid">
    <div class="panel">
      <h2>1️⃣ Pon el script en tu juego</h2>
      <p class="hint">Descarga el script y ponlo en <b>ServerScriptService</b> de tu juego en Roblox Studio. Ahí mismo puedes cambiar lo que hace cada poder (vienen de ejemplo <b>turbo</b> y <b>salto</b>).</p>
      <div class="row" style="margin:0;gap:8px;flex-wrap:wrap"><a class="btn pri" href="/roblox/ChispaLive.server.lua" download data-r="dl">⬇ Descargar script para Roblox</a><button class="btn" data-r="test">▶ Probar conexión</button></div>
      <div class="hint" style="margin-top:10px">🧪 <b>Para probar en Roblox Studio:</b> en Game Settings → Security activa <b>"Allow HTTP Requests"</b>, deja ChispaLive abierto y dale Play. No necesitas nada más.</div>
    </div>
    <div class="panel">
      <h2>2️⃣ Para tu juego publicado</h2>
      <p class="hint">En el juego publicado los eventos viajan por la nube de Roblox. Crea una API key en el <b>Creator Dashboard → Open Cloud → API Keys</b> con el permiso <b>messaging-service → universe-messaging-service:publish</b> para tu juego.</p>
      <label class="f">Universe ID del juego<input class="i" data-k="universeId" inputmode="numeric" placeholder="Ej. 1234567890"></label>
      <label class="f">API key de Open Cloud<input class="i" type="password" data-k="apiKey" placeholder="Pega aquí tu API key" autocomplete="off"></label>
      <label class="f">Canal (topic)<input class="i" data-k="topic" maxlength="80" placeholder="ChispaLive"></label>
      <div class="hint">El canal tiene que ser el mismo en el script. Si lo cambias, descarga el script otra vez.</div>
    </div>
    <div class="panel">
      <h2>3️⃣ ¿Qué se manda al juego?</h2>
      <label class="sw"><input type="checkbox" data-k="allEvents"> Mandar todos los eventos del live</label>
      <div class="rbx-kinds" data-r="kinds">${KINDS.map(([k, n]) => `<label class="sw"><input type="checkbox" data-ev="${k}"> ${n}</label>`).join('')}</div>
      <div class="hint">Con esto tu juego recibe cada evento (data.cmd = "gift", "like", "chat"…) y tú decides qué hacer en el script.</div>
      <div class="hint" style="margin-top:8px">⚡ <b>Para poderes por regalo</b> (ej. Rosa → turbo) ve a <b>Acciones y eventos → Nueva acción</b> y elige <b>🧱 Poder en Roblox</b>.</div>
    </div>
    <div class="panel">
      <h2>📜 Últimos envíos</h2>
      <div class="rbx-log" data-r="log"></div>
    </div>
  </div>`;
  document.getElementById('studios').after(sec);
  const $ = q => sec.querySelector(q);

  sec.querySelectorAll('[data-k]').forEach(i => i.addEventListener(i.type === 'checkbox' ? 'change' : 'input', () => {
    let v = i.type === 'checkbox' ? i.checked : i.value;
    if (i.dataset.k === 'universeId') { v = v.replace(/\D/g, ''); i.value = v; }
    save(i.dataset.k, v);
  }));
  sec.querySelectorAll('[data-ev]').forEach(i => i.addEventListener('change', () => save('events.' + i.dataset.ev, i.checked)));
  $('[data-r=turnon]').onclick = () => { $('[data-k=on]').checked = true; save('on', true); };
  $('[data-r=test]').onclick = () => { if (!R().on) return toast('🧱 Primero enciende la conexión con Roblox'); socket.emit('rbx:test'); toast('🧱 Prueba enviada: en Roblox debe salir "✅ ChispaLive conectado" en la consola'); };
  $('[data-r=dl]').addEventListener('click', () => { if (pt) { clearTimeout(pt); socket.emit('saveConfig', { roblox: pend }); pend = {}; } });

  function ago(t) { if (!t) return ''; const s = Math.round((Date.now() - t) / 1000); return s < 60 ? `hace ${s} s` : `hace ${Math.round(s / 60)} min`; }
  function paintStatus() {
    const c = R(), box = $('[data-r=status]');
    const studio = ST.studio ? '<span class="rbx-dot ok"></span><b>Roblox Studio conectado</b>' : '<span class="rbx-dot"></span>Roblox Studio: sin conectar';
    let cloud;
    if (!c.universeId || !c.apiKey) cloud = '<span class="rbx-dot"></span>Juego publicado: falta Universe ID y API key';
    else if (ST.cloud?.ok === true) cloud = `<span class="rbx-dot ok"></span><b>Juego publicado: conectado</b> · ${ST.cloud.sent} enviados · ${ago(ST.cloud.t)}`;
    else if (ST.cloud?.ok === false) cloud = `<span class="rbx-dot bad"></span>Juego publicado: <b>${esc(ST.cloud.msg)}</b>`;
    else cloud = '<span class="rbx-dot"></span>Juego publicado: listo, aún no se envía nada';
    box.innerHTML = `<div>${studio}</div><div>${cloud}</div>${ST.queued ? `<div class="hint">⏳ ${ST.queued} en cola</div>` : ''}`;
  }
  function paintLog() {
    $('[data-r=log]').innerHTML = LOG.length ? LOG.map(m => `<div class="rbx-li"><b>${esc(m.cmd)}</b><span>${esc(m.user || '')}${m.gift ? ` · ${esc(m.gift)}` : ''}${m.count > 1 ? ` x${m.count}` : ''}</span><small>${new Date(m.t).toLocaleTimeString()}</small></div>`).join('')
      : '<div class="hint">Todavía no se mandó nada. Usa el Simulador o el botón ▶ Probar conexión.</div>';
  }
  function paint() {
    const c = R();
    sec.querySelectorAll('[data-k]').forEach(i => { if (document.activeElement === i) return; const v = c[i.dataset.k]; if (i.type === 'checkbox') i.checked = i.dataset.k === 'allEvents' ? v !== false : !!v; else i.value = v ?? (i.dataset.k === 'topic' ? 'ChispaLive' : ''); });
    sec.querySelectorAll('[data-ev]').forEach(i => { i.checked = (c.events || {})[i.dataset.ev] ?? i.dataset.ev !== 'join'; });
    $('[data-r=kinds]').classList.toggle('dim', c.allEvents === false);
    $('[data-r=pwlab]').textContent = c.on ? 'Encendido' : 'Apagado';
    $('[data-r=offbar]').hidden = !!c.on;
    paintStatus(); paintLog();
  }
  socket.on('config', () => setTimeout(paint, 0));
  socket.on('rbx:status', s => { ST = s || {}; paintStatus(); });
  socket.on('rbx:log', m => { LOG.unshift(m); LOG = LOG.slice(0, 12); paintLog(); });
  if (window.cfg?.roblox) paint();
  socket.emit('rbx:get'); socket.on('connect', () => socket.emit('rbx:get'));
})();
