// ===== Plantillas y pasar a otra PC — página del panel =====
(function () {
  let PL = { ready: [], toggles: [], saved: [] };
  const sec = document.createElement('section'); sec.className = 'sec'; sec.id = 's-plantillas';
  sec.innerHTML = `
  <div class="vz-head panel">
    <div class="vz-mascot rbx-logo">📦</div>
    <div class="vz-ttl"><h1 class="display">Plantillas</h1><p class="hint">Con un clic dejas listo tu panel para el tipo de live que vas a hacer. También puedes guardar cómo tienes todo y llevarlo a otra computadora.</p></div>
  </div>
  <div class="panel"><h2>✨ Plantillas listas</h2><p class="hint">Prenden los juegos que van con ese tipo de live y apagan los demás. Tus ajustes de cada juego (premios, regalos, textos) no cambian.</p>
    <div class="pl-ready" data-r="ready"></div></div>
  <div class="pl-grid">
    <div class="panel"><h2>💾 Mis plantillas</h2><p class="hint">Guarda cómo tienes todo ahora: los ajustes de cada juego, tus Acciones, tu estilo y la voz. Después lo vuelves a poner con un clic.</p>
      <div class="row pl-saverow"><input class="i" data-r="name" maxlength="40" placeholder="Ej: Live de los viernes"><button class="btn pri" data-r="save">💾 Guardar</button></div>
      <div class="pl-saved" data-r="saved"></div></div>
    <div class="panel"><h2>🚚 Pasar a otra PC</h2>
      <ol class="pl-steps">
        <li><b>En esta PC</b> descarga tu paquete. Lleva tu configuración, tus plantillas y tus imágenes, GIFs y sonidos.<a class="btn pri" href="/paquete.chispalive" download data-r="dl">⬇️ Descargar mi paquete</a></li>
        <li><b>En la otra PC</b> instala ChispaLive, abre esta misma página y carga el archivo.<label class="btn">⬆️ Cargar un paquete<input type="file" data-r="up" accept=".chispalive" hidden></label></li>
      </ol>
      <p class="hint">La licencia no va en el paquete: en la otra PC la activas con tu clave (primero quítala de esta en 💎 Licencia). Antes de cargar se guarda una copia de lo que tenías.</p>
      <div class="pl-prog" data-r="prog" hidden><i></i><span></span></div>
    </div>
  </div>`;
  document.getElementById('studios').after(sec);
  const $ = q => sec.querySelector(q);
  const nameOf = k => { const S = typeof STUDIOS !== 'undefined' ? STUDIOS[k] : null; return S ? `${S.icon} ${S.name}` : k; };
  const enabledNow = () => (PL.toggles || []).filter(k => window.cfg?.games?.[k] && window.cfg.games[k].enabled !== false);

  function paint() {
    const now = enabledNow().sort().join(',');
    $('[data-r=ready]').innerHTML = PL.ready.map(t => {
      const cur = [...t.on].filter(k => PL.toggles.includes(k)).sort().join(',') === now;
      return `<div class="pl-card ${cur ? 'cur' : ''}"><div class="pl-h"><span>${t.icon}</span><b>${t.name}</b>${cur ? '<em>✓ La que tienes</em>' : ''}</div><p>${t.desc}</p>
        <div class="pl-chips">${t.on.map(k => `<span>${nameOf(k)}</span>`).join('')}</div>
        <button class="btn ${cur ? '' : 'pri'} sm" data-ready="${t.id}">${cur ? 'Volver a ponerla' : 'Usar esta'}</button></div>`;
    }).join('');
    $('[data-r=saved]').innerHTML = PL.saved.length ? PL.saved.map(t => `<div class="pl-row"><div><b data-noi18n>${esc(t.name)}</b><small>${new Date(t.at).toLocaleDateString('es', { day: 'numeric', month: 'short' })} · ${t.on.length} juegos prendidos</small></div>
        <button class="btn sm pri" data-apply="${t.id}">Poner</button><button class="btn sm danger" data-del="${t.id}" title="Borrar">🗑</button></div>`).join('')
      : `<p class="hint pl-empty">Todavía no guardaste ninguna.</p>`;
    sec.querySelectorAll('[data-ready]').forEach(b => b.onclick = () => {
      const t = PL.ready.find(x => x.id === b.dataset.ready);
      if (!confirm(`¿Usar la plantilla "${t.name}"? Se prenden ${t.on.length} cosas y se apagan los demás juegos.`)) return;
      socket.emit('plantillas:ready', t.id, err => toast(err ? '⚠️ ' + err : `${t.icon} Plantilla "${t.name}" lista`));
    });
    sec.querySelectorAll('[data-apply]').forEach(b => b.onclick = () => {
      const t = PL.saved.find(x => x.id === b.dataset.apply);
      if (!confirm(`¿Poner "${t.name}"? Tus ajustes de ahora se cambian por los de esa plantilla (antes se guarda una copia).`)) return;
      socket.emit('plantillas:apply', t.id, err => toast(err ? '⚠️ ' + err : '💾 Plantilla puesta'));
    });
    sec.querySelectorAll('[data-del]').forEach(b => b.onclick = () => { const t = PL.saved.find(x => x.id === b.dataset.del); if (confirm(`¿Borrar la plantilla "${t.name}"?`)) socket.emit('plantillas:del', t.id); });
  }
  $('[data-r=save]').onclick = () => {
    const n = $('[data-r=name]').value.trim(); if (!n) return toast('Ponle un nombre a tu plantilla');
    socket.emit('plantillas:save', n, err => { toast(err ? '⚠️ ' + err : '💾 Guardada'); if (!err) $('[data-r=name]').value = ''; });
  };
  $('[data-r=name]').addEventListener('keydown', e => { if (e.key === 'Enter') $('[data-r=save]').click(); });
  $('[data-r=up]').addEventListener('change', async e => {
    const f = e.target.files[0]; e.target.value = ''; if (!f) return;
    if (!confirm(`¿Cargar "${f.name}"? Se reemplaza tu configuración por la del paquete (antes se guarda una copia).`)) return;
    const pr = $('[data-r=prog]'); pr.hidden = false; pr.querySelector('span').textContent = 'Cargando tu paquete…';
    try {
      const r = await (await fetch('/paquete', { method: 'POST', headers: { 'Content-Type': 'application/octet-stream' }, body: f })).json();
      toast(r.err ? '⚠️ ' + r.err : `🚚 ¡Listo! Se cargó tu configuración y ${r.files} archivos`);
    } catch { toast('⚠️ No se pudo cargar el paquete'); }
    pr.hidden = true;
  });
  socket.on('plantillas', l => { PL = l || PL; paint(); });
  socket.on('config', () => { if (PL.ready.length) paint(); });
  socket.emit('plantillas:get'); socket.on('connect', () => socket.emit('plantillas:get'));
})();
