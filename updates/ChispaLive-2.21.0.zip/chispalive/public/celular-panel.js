// ===== Control desde el celular — página del panel =====
(function () {
  let INFO = { on: false, ips: [], url: '', devices: 0 }, ipSel = 0;
  const sec = document.createElement('section'); sec.className = 'sec'; sec.id = 's-celular';
  sec.innerHTML = `
  <div class="vz-head panel">
    <div class="vz-mascot rbx-logo">📱</div>
    <div class="vz-ttl"><h1 class="display">Celular <span class="saved">✓ Guardado</span></h1><p class="hint">Maneja tu live desde el celular: juegos, subathon, batalla, escenas de OBS y acciones, sin tocar la PC.</p></div>
    <label class="vz-power"><input type="checkbox" data-k="on"><span class="vz-pw"><i></i></span><b data-r="pwlab">Apagado</b></label>
  </div>
  <div data-r="body"></div>`;
  document.getElementById('studios').after(sec);
  const $ = q => sec.querySelector(q);
  $('[data-k=on]').addEventListener('change', e => {
    window.cfg.remote = { ...(window.cfg.remote || {}), on: e.target.checked };
    socket.emit('saveConfig', { remote: { on: e.target.checked } });
    const s = sec.querySelector('.saved'); s.classList.add('on'); setTimeout(() => s.classList.remove('on'), 1200);
  });

  function qrSvg(text) {
    try { const q = qrcode(0, 'M'); q.addData(text); q.make(); return q.createSvgTag({ cellSize: 6, margin: 3, scalable: true }); } catch { return ''; }
  }
  function paint() {
    const on = !!window.cfg?.remote?.on;
    $('[data-k=on]').checked = on; $('[data-r=pwlab]').textContent = on ? 'Encendido' : 'Apagado';
    const ips = INFO.ips || [], ip = ips[ipSel] || ips[0];
    const url = ip ? `http://${ip.ip}:${INFO.port || 3939}/m?t=${INFO.token}` : '';
    if (!on) {
      $('[data-r=body]').innerHTML = `<div class="panel"><h2>🔒 Tu ChispaLive está protegido</h2>
        <p class="hint">Ahora mismo <b>solo esta PC</b> puede abrir tu panel. Nadie más en tu WiFi puede entrar ni ver tus claves.</p>
        <p class="hint">Enciende <b>Celular</b> arriba para manejar tu live desde el teléfono: te sale un código QR que solo funciona con tu código secreto.</p></div>`;
      return;
    }
    $('[data-r=body]').innerHTML = `<div class="rbx-grid">
      <div class="panel cel-qr"><h2>1️⃣ Escanea con tu celular</h2>
        ${url ? `<div class="qr-box">${qrSvg(url)}</div><p class="hint">Abre la cámara del celular y apunta al código. Tu celular tiene que estar en el <b>mismo WiFi</b> que esta PC.</p>
          <div class="cel-url"><code>${esc(url.replace(/t=.*/, 't=••••••'))}</code><button class="btn sm" data-r="copy">📋 Copiar link</button></div>
          ${ips.length > 1 ? `<label class="f">¿No abre? Prueba con otra red de esta PC<select class="i" data-r="ip">${ips.map((x, i) => `<option value="${i}" ${i === ipSel ? 'selected' : ''}>${esc(x.ip)} · ${esc(x.name)}${x.virt ? ' (virtual)' : ''}</option>`).join('')}</select></label>` : ''}`
        : '<div class="hint">⚠️ Esta PC no está conectada a una red WiFi o cableada. Conéctala a tu red para usar el celular.</div>'}
      </div>
      <div class="panel"><h2>📲 Celulares conectados</h2>
        <div class="cel-dev"><span class="rbx-dot ${INFO.devices ? 'ok' : ''}"></span><b>${INFO.devices || 0}</b> ${INFO.devices === 1 ? 'celular conectado' : 'celulares conectados'}</div>
        <p class="hint">El código QR es secreto: <b>no lo muestres en tu live</b>. Si alguien más lo vio, cámbialo y los celulares que tenían el anterior se desconectan.</p>
        <button class="btn sm danger" data-r="rotate">🔄 Cambiar código secreto</button>
        <h2 style="margin-top:16px">❓ ¿No abre en el celular?</h2>
        <ul class="hint obs-list"><li>Revisa que el celular esté en el <b>mismo WiFi</b> que la PC (no con datos móviles).</li><li>Si Windows preguntó por el <b>Firewall</b>, permite Node.js en <b>redes privadas</b>.</li><li>Prueba con otra red de la lista (si sale más de una).</li></ul>
      </div></div>`;
    $('[data-r=copy]')?.addEventListener('click', () => navigator.clipboard.writeText(url).then(() => toast('📋 Link copiado (no lo compartas)')));
    $('[data-r=ip]')?.addEventListener('change', e => { ipSel = +e.target.value; paint(); });
    $('[data-r=rotate]')?.addEventListener('click', () => { if (confirm('¿Cambiar el código secreto? Los celulares conectados se desconectan y tendrás que escanear el QR otra vez.')) socket.emit('remote:rotate'); });
  }
  socket.on('remote:info', i => { INFO = i || INFO; paint(); });
  socket.on('config', () => setTimeout(paint, 0));
  socket.emit('remote:get'); socket.on('connect', () => socket.emit('remote:get'));
})();
