// ===== Resúmenes de tus lives — página del panel =====
(function () {
  let ST = { live: null, list: [] }, sel = null, data = null, liveT = null;
  const n = v => (+v || 0).toLocaleString('es');
  const dur = ms => { const s = Math.max(0, Math.round(ms / 1000)), h = Math.floor(s / 3600), m = Math.floor(s % 3600 / 60); return h ? `${h} h ${m} min` : `${m} min`; };
  const fday = t => new Date(t).toLocaleDateString('es', { weekday: 'long', day: 'numeric', month: 'short' });
  const fhour = t => new Date(t).toLocaleTimeString('es', { hour: '2-digit', minute: '2-digit' });
  const medal = i => ['🥇', '🥈', '🥉'][i] || `${i + 1}.`;
  const CREDITS_URL = `${location.origin}/overlay/creditos.html`;

  const sec = document.createElement('section'); sec.className = 'sec'; sec.id = 's-resumen';
  sec.innerHTML = `
  <div class="vz-head panel">
    <div class="vz-mascot rbx-logo">📈</div>
    <div class="vz-ttl"><h1 class="display">Resúmenes</h1><p class="hint">Cómo te fue en cada live: monedas, regalos, seguidores, tus mejores donadores y el momento con más gente.</p></div>
  </div>
  <div class="rs-bar panel" data-r="bar"></div>
  <div class="rs-grid">
    <div class="panel rs-listp"><h2>🗓 Tus lives</h2><div class="rs-list" data-r="list"></div></div>
    <div class="rs-detail" data-r="detail"></div>
  </div>`;
  document.getElementById('studios').after(sec);
  const $ = q => sec.querySelector(q);

  function paintBar() {
    const L = ST.live;
    $('[data-r=bar]').innerHTML = L
      ? `<span class="rbx-dot ok"></span><div style="flex:1"><b>Contando este live</b> desde las ${fhour(L.startedAt)} · ${dur(Date.now() - L.startedAt)} · 🪙 ${n(L.coins)} · ❤️ ${n(L.likes)} · 💗 ${n(L.follows)}</div>
         <button class="btn sm" data-r="credits">🎬 Mostrar créditos</button><button class="btn sm danger" data-r="finish">⏹ Terminar y guardar</button>`
      : `<span class="rbx-dot"></span><div style="flex:1">No hay un live contándose. Empieza solo cuando te conectas a tu live.</div><button class="btn sm pri" data-r="start">▶ Empezar a contar ahora</button>`;
    $('[data-r=start]')?.addEventListener('click', () => socket.emit('resumen:start'));
    $('[data-r=finish]')?.addEventListener('click', () => { if (confirm('¿Terminar y guardar el resumen de este live? Si sigues en vivo, se empieza uno nuevo cuando te vuelvas a conectar.')) socket.emit('resumen:finish'); });
    $('[data-r=credits]')?.addEventListener('click', () => { socket.emit('resumen:credits', 'live'); toast('🎬 Créditos enviados al overlay de OBS'); });
  }
  function paintList() {
    const items = [...(ST.live ? [{ ...ST.live, id: 'live' }] : []), ...ST.list];
    $('[data-r=list]').innerHTML = items.length ? items.map(L => `<button class="rs-item ${sel === L.id ? 'on' : ''}" data-id="${L.id}">
        <b>${L.live ? '🔴 En vivo ahora' : esc(fday(L.startedAt))}</b><small>${fhour(L.startedAt)}${L.endedAt ? ` · ${dur(L.endedAt - L.startedAt)}` : ''}</small>
        <span>🪙 ${n(L.coins)} · 💗 ${n(L.follows)} · 👀 ${n(L.peakViewers)}</span></button>`).join('')
      : '<div class="hint">Todavía no hay lives guardados. Cuando termines tu próximo live, aparece aquí.</div>';
    $('[data-r=list]').querySelectorAll('[data-id]').forEach(b => b.onclick = () => open(b.dataset.id));
  }
  function open(id) {
    sel = id; paintList();
    socket.emit('resumen:get', id, L => { data = L; paintDetail(); });
  }

  function chart(tl) {
    if (!tl?.length) return '<div class="hint">Sin datos todavía.</div>';
    // agrupa en máximo 60 barras
    const per = Math.max(1, Math.ceil(tl.length / 60)), bars = [];
    for (let i = 0; i < tl.length; i += per) { const g = tl.slice(i, i + per); bars.push({ m: g[0].m, coins: g.reduce((a, b) => a + b.coins, 0), viewers: Math.max(...g.map(b => b.viewers || 0)) }); }
    while (bars.length < 12) bars.push({ m: (bars.at(-1)?.m ?? -1) + per, coins: 0, viewers: bars.at(-1)?.viewers || 0, pad: true });
    const W = 640, H = 180, bw = W / bars.length, maxC = Math.max(1, ...bars.map(b => b.coins)), maxV = Math.max(1, ...bars.map(b => b.viewers));
    const line = bars.filter(b => !b.pad).map((b, i) => `${(i * bw + bw / 2).toFixed(1)},${(H - 4 - (b.viewers / maxV) * (H - 20)).toFixed(1)}`).join(' ');
    const best = bars.reduce((a, b) => b.coins > a.coins ? b : a, bars[0]);
    return `<svg class="rs-chart" viewBox="0 0 ${W} ${H + 18}" preserveAspectRatio="none">
      ${bars.map((b, i) => `<rect x="${(i * bw + 1).toFixed(1)}" y="${(H - (b.coins / maxC) * (H - 20)).toFixed(1)}" width="${Math.max(1, bw - 2).toFixed(1)}" height="${((b.coins / maxC) * (H - 20)).toFixed(1)}" rx="2" fill="${b === best && b.coins ? 'var(--gold, #ffd23f)' : 'url(#rsg)'}"><title>min ${b.m}: ${n(b.coins)} monedas · ${n(b.viewers)} viewers</title></rect>`).join('')}
      <defs><linearGradient id="rsg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ff6a2b"/><stop offset="1" stop-color="#ff2e7e"/></linearGradient></defs>
      ${maxV > 1 ? `<polyline points="${line}" fill="none" stroke="#2ea7ff" stroke-width="2.5" stroke-linejoin="round"/>` : ''}
      <text x="0" y="${H + 15}" class="rs-ax">0 min</text><text x="${W}" y="${H + 15}" text-anchor="end" class="rs-ax">${tl.at(-1).m + 1} min</text></svg>
      <div class="rs-legend"><span><i style="background:#ff6a2b"></i> Monedas por minuto</span>${maxV > 1 ? '<span><i style="background:#2ea7ff"></i> Espectadores</span>' : ''}${best?.coins ? `<span>⭐ Mejor momento: minuto ${best.m}</span>` : ''}</div>`;
  }

  function paintDetail() {
    const L = data, box = $('[data-r=detail]');
    if (!L) { box.innerHTML = `<div class="panel"><div class="hint">Elige un live de la lista para ver su resumen.</div></div>`; return; }
    const end = L.endedAt || Date.now();
    const tiles = [['⏱', 'Duración', dur(end - L.startedAt)], ['🪙', 'Monedas', n(L.coins)], ['🎁', 'Regalos', n(L.gifts)], ['❤️', 'Likes', n(L.likes)],
      ['💗', 'Seguidores nuevos', n(L.follows)], ['📣', 'Compartidos', n(L.shares)], ['💬', 'Comentarios', n(L.comments)], ['👀', 'Pico de espectadores', `${n(L.peakViewers)}${L.peakAt ? ` <small>a las ${fhour(L.peakAt)}</small>` : ''}`]];
    const donors = (L.donors || []).slice(0, 10), gifts = (L.giftTypes || []).slice(0, 8), chat = (L.chatters || []).slice(0, 5);
    box.innerHTML = `
      <div class="panel">
        <div class="rs-title"><div><h2 style="margin:0">${L.live ? '🔴 Live en curso' : esc(fday(L.startedAt))}</h2><div class="hint">${fhour(L.startedAt)} – ${L.endedAt ? fhour(L.endedAt) : 'ahora'}${L.username ? ` · @${esc(L.username)}` : ''}</div></div>
          <div class="rs-btns"><button class="btn sm" data-a="copy">📋 Copiar agradecimiento</button><button class="btn sm" data-a="img">🖼 Descargar imagen</button><button class="btn sm" data-a="credits">🎬 Créditos en OBS</button>${L.live ? '' : '<button class="btn sm danger" data-a="del">🗑</button>'}</div></div>
        <div class="rs-tiles">${tiles.map(([i, l, v]) => `<div class="rs-tile"><span>${i}</span><b>${v}</b><small>${l}</small></div>`).join('')}</div>
      </div>
      <div class="panel"><h2>📊 Cómo fue tu live</h2>${chart(L.timeline)}</div>
      <div class="rs-two">
        <div class="panel"><h2>🏆 Top donadores <span class="hint">${n(L.donorsCount || donors.length)} en total</span></h2>${donors.length ? `<div class="rs-rows">${donors.map((d, i) => `<div class="rs-row"><span class="rs-md">${medal(i)}</span>${avHtml(d.user)}<b>${esc(d.user.name)}</b><span>🪙 ${n(d.coins)}</span></div>`).join('')}</div>` : '<div class="hint">Nadie mandó regalos.</div>'}</div>
        <div class="panel"><h2>🎁 Regalos más enviados</h2>${gifts.length ? `<div class="rs-rows">${gifts.map(g => `<div class="rs-row"><span class="rs-gi">${g.image ? `<img src="${esc(g.image)}" referrerpolicy="no-referrer">` : '🎁'}</span><b>${esc(g.name)}</b><span>x${n(g.count)} · 🪙 ${n(g.coins)}</span></div>`).join('')}</div>` : '<div class="hint">Sin regalos.</div>'}
          ${L.biggest ? `<div class="rs-big"><span class="rs-gi">${L.biggest.image ? `<img src="${esc(L.biggest.image)}" referrerpolicy="no-referrer">` : '💎'}</span><div><small>REGALO MÁS GRANDE</small><b>${esc(L.biggest.user?.name || '')} · ${L.biggest.count > 1 ? `${L.biggest.count}x ` : ''}${esc(L.biggest.gift)}</b><span>🪙 ${n(L.biggest.coins)} a las ${fhour(L.biggest.t)}</span></div></div>` : ''}</div>
      </div>
      <div class="rs-two">
        <div class="panel"><h2>💬 Los más activos en el chat</h2>${chat.length ? `<div class="rs-rows">${chat.map((c, i) => `<div class="rs-row"><span class="rs-md">${medal(i)}</span>${avHtml(c.user)}<b>${esc(c.user.name)}</b><span>${n(c.n)} mensajes</span></div>`).join('')}</div>` : '<div class="hint">Sin comentarios.</div>'}</div>
        <div class="panel"><h2>💗 Seguidores nuevos</h2>${(L.followers || []).length ? `<div class="rs-chips">${L.followers.slice(-30).reverse().map(u => `<span>${esc(u.name)}</span>`).join('')}</div>` : '<div class="hint">Sin seguidores nuevos.</div>'}
          ${(L.results || []).length ? `<h2 style="margin-top:14px">🎮 Juegos</h2><div class="rs-rows">${L.results.map(r => `<div class="rs-row"><span class="rs-md">${r.icon}</span><b>${esc(r.text)}</b><span>${fhour(r.t)}</span></div>`).join('')}</div>` : ''}</div>
      </div>
      <div class="panel"><div class="hint">🎬 <b>Créditos para el final de tu live:</b> agrega este link como fuente de navegador en OBS / LIVE Studio y toca "Créditos en OBS": pasan los nombres de tus donadores y seguidores, como en una película. <button class="btn sm" data-copy="${CREDITS_URL}">🔗 Copiar link</button></div></div>`;
    box.querySelector('[data-a=copy]').onclick = () => { navigator.clipboard.writeText(thanks(L)).then(() => toast('📋 Agradecimiento copiado')); };
    box.querySelector('[data-a=img]').onclick = () => downloadImage(L);
    box.querySelector('[data-a=credits]').onclick = () => { socket.emit('resumen:credits', L.live ? 'live' : L.id); toast('🎬 Créditos enviados al overlay de OBS'); };
    box.querySelector('[data-a=del]')?.addEventListener('click', () => { if (confirm('¿Borrar el resumen de este live?')) { socket.emit('resumen:delete', L.id); sel = null; data = null; paintDetail(); } });
    box.querySelector('[data-copy]').onclick = e => navigator.clipboard.writeText(e.target.dataset.copy).then(() => toast('🔗 Link copiado'));
  }

  function thanks(L) {
    const top = (L.donors || []).slice(0, 5);
    return [`💖 ¡Gracias por el live de hoy!`,
      `⏱ ${dur((L.endedAt || Date.now()) - L.startedAt)} · 🪙 ${n(L.coins)} monedas · 💗 ${n(L.follows)} seguidores nuevos · ❤️ ${n(L.likes)} likes`,
      ...(top.length ? ['', '🏆 Mis mejores donadores:', ...top.map((d, i) => `${medal(i)} @${d.user.id || d.user.name} — ${n(d.coins)} 🪙`)] : []),
      '', '¡Nos vemos en el próximo live! 🔥'].join('\n');
  }

  // Imagen para redes (1080 x 1350), sin fotos de terceros para que se pueda descargar
  function downloadImage(L) {
    const c = document.createElement('canvas'); c.width = 1080; c.height = 1350; const x = c.getContext('2d');
    const css = getComputedStyle(document.documentElement), col = (v, d) => (css.getPropertyValue(v) || '').trim() || d;
    const c1 = window.cfg?.brand?.colors?.primary || '#ff6a2b', c2 = window.cfg?.brand?.colors?.secondary || '#ff2e7e', gold = window.cfg?.brand?.colors?.accent || '#ffd23f';
    const bg = x.createLinearGradient(0, 0, 1080, 1350); bg.addColorStop(0, '#17121f'); bg.addColorStop(1, '#2a1230'); x.fillStyle = bg; x.fillRect(0, 0, 1080, 1350);
    const glow = x.createRadialGradient(900, 120, 10, 900, 120, 600); glow.addColorStop(0, c2 + '88'); glow.addColorStop(1, 'transparent'); x.fillStyle = glow; x.fillRect(0, 0, 1080, 1350);
    const font = s => `800 ${s}px "Bricolage Grotesque", Outfit, system-ui, sans-serif`;
    x.fillStyle = '#fff'; x.font = font(64); x.fillText('Resumen del live', 70, 140);
    x.font = '500 34px Outfit, system-ui, sans-serif'; x.fillStyle = 'rgba(255,255,255,.7)';
    x.fillText(`${fday(L.startedAt)} · ${dur((L.endedAt || Date.now()) - L.startedAt)}${L.username ? ` · @${L.username}` : ''}`, 70, 195);
    const tiles = [['🪙', n(L.coins), 'monedas'], ['💗', n(L.follows), 'seguidores'], ['❤️', n(L.likes), 'likes'], ['👀', n(L.peakViewers), 'pico de viewers'], ['🎁', n(L.gifts), 'regalos'], ['💬', n(L.comments), 'comentarios']];
    tiles.forEach(([ic, v, l], i) => {
      const tx = 70 + (i % 3) * 320, ty = 250 + Math.floor(i / 3) * 200;
      x.fillStyle = 'rgba(255,255,255,.07)'; round(x, tx, ty, 290, 170, 28); x.fill();
      x.fillStyle = '#fff'; x.font = '56px system-ui'; x.fillText(ic, tx + 26, ty + 74);
      x.fillStyle = '#fff'; x.font = font(52); x.fillText(v, tx + 26, ty + 132);
      x.fillStyle = 'rgba(255,255,255,.6)'; x.font = '500 26px Outfit, system-ui'; x.fillText(l, tx + 26, ty + 160);
    });
    x.fillStyle = gold; x.font = font(44); x.fillText('🏆 Top donadores', 70, 740);
    (L.donors || []).slice(0, 5).forEach((d, i) => {
      const y = 800 + i * 92;
      x.fillStyle = i === 0 ? 'rgba(255,210,63,.18)' : 'rgba(255,255,255,.06)'; round(x, 70, y, 940, 76, 22); x.fill();
      x.fillStyle = '#fff'; x.font = font(38); x.fillText(`${medal(i)} ${String(d.user.name).slice(0, 22)}`, 96, y + 50);
      x.textAlign = 'right'; x.fillStyle = gold; x.fillText(`${n(d.coins)} 🪙`, 990, y + 50); x.textAlign = 'left';
    });
    if (!(L.donors || []).length) { x.fillStyle = 'rgba(255,255,255,.6)'; x.font = '500 32px Outfit, system-ui'; x.fillText('¡Gracias a todos por acompañarme!', 70, 820); }
    const bar = x.createLinearGradient(0, 0, 1080, 0); bar.addColorStop(0, c1); bar.addColorStop(1, c2); x.fillStyle = bar; x.fillRect(0, 1300, 1080, 50);
    x.fillStyle = '#fff'; x.font = font(28); x.fillText(`${window.cfg?.brand?.name || 'ChispaLive'} · ¡Gracias por el apoyo! 💖`, 70, 1335);
    c.toBlob(b => { const a = document.createElement('a'); a.href = URL.createObjectURL(b); const dd = new Date(L.startedAt); a.download = `resumen-live-${dd.getFullYear()}-${String(dd.getMonth() + 1).padStart(2, '0')}-${String(dd.getDate()).padStart(2, '0')}.png`; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 2000); toast('🖼 Imagen descargada'); }, 'image/png');
  }
  function round(x, X, Y, w, h, r) { x.beginPath(); x.moveTo(X + r, Y); x.arcTo(X + w, Y, X + w, Y + h, r); x.arcTo(X + w, Y + h, X, Y + h, r); x.arcTo(X, Y + h, X, Y, r); x.arcTo(X, Y, X + w, Y, r); x.closePath(); }

  socket.on('resumen:status', s => {
    ST = s || ST; paintBar(); paintList();
    if (!sel) { if (ST.live) open('live'); else if (ST.list[0]) open(ST.list[0].id); else paintDetail(); }
    else if (sel === 'live' && !ST.live) { sel = ST.list[0]?.id || null; sel ? open(sel) : (data = null, paintDetail()); }
  });
  socket.on('resumen:live', L => {
    ST.live = L; paintBar();
    if (sel === 'live' && document.getElementById('s-resumen').classList.contains('on')) { clearTimeout(liveT); liveT = setTimeout(() => open('live'), 300); }
  });
  socket.on('resumen:saved', L => { if (L) toast(`📈 Resumen del live guardado: 🪙 ${n(L.coins)} · 💗 ${n(L.follows)}`); });
  document.querySelector('button.nav[data-s="resumen"]')?.addEventListener('click', () => { if (sel) open(sel); });
  socket.emit('resumen:get'); socket.on('connect', () => socket.emit('resumen:get'));
  setInterval(() => { if (ST.live && sec.classList.contains('on')) paintBar(); }, 30000);
})();
