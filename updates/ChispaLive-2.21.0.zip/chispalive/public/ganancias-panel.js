// ===== Cuánto ganaste — página del panel =====
// Pasa las monedas de tus lives a soles o dólares, con gráfico por día, semana y mes.
(function () {
  let G = { days: {}, today: '' }, view = 'dias';
  const C = () => ({ currency: 'pen', usdPer1000: 5, penPerUsd: 3.75, agency: 0, goal: 0, ...(window.cfg?.ganancias || {}) });
  const n = v => Math.round(+v || 0).toLocaleString('es');
  const key = d => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  const parse = k => { const [y, m, d] = k.split('-').map(Number); return new Date(y, m - 1, d); };
  const monday = d => { const x = new Date(d); x.setHours(0, 0, 0, 0); x.setDate(x.getDate() - ((x.getDay() + 6) % 7)); return x; };
  function money(coins, cur) {
    const c = C(), usd = coins / 1000 * (+c.usdPer1000 || 0) * (1 - Math.min(100, Math.max(0, +c.agency || 0)) / 100);
    return (cur || c.currency) === 'usd' ? usd : usd * (+c.penPerUsd || 0);
  }
  const fmt = (v, cur) => { const c = cur || C().currency, d = v < 100 ? 2 : 0; return (c === 'usd' ? '$' : 'S/ ') + v.toLocaleString('es', { minimumFractionDigits: d, maximumFractionDigits: d }); };
  const coinsOf = k => G.days[k]?.coins || 0;
  const sumRange = (from, to) => { let s = 0; for (const [k, v] of Object.entries(G.days)) { const t = parse(k); if (t >= from && t < to) s += v.coins || 0; } return s; };
  const EN = () => window.i18n?.lang === 'en';
  const MES_ES = ['ene', 'feb', 'mar', 'abr', 'may', 'jun', 'jul', 'ago', 'sep', 'oct', 'nov', 'dic'], MES_EN = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const DIA_ES = ['dom', 'lun', 'mar', 'mié', 'jue', 'vie', 'sáb'], DIA_EN = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  const MES = new Proxy([], { get: (_, i) => (EN() ? MES_EN : MES_ES)[i] }), DIA = new Proxy([], { get: (_, i) => (EN() ? DIA_EN : DIA_ES)[i] });

  const sec = document.createElement('section'); sec.className = 'sec'; sec.id = 's-ganancias';
  sec.innerHTML = `
  <div class="vz-head panel">
    <div class="vz-mascot rbx-logo">💰</div>
    <div class="vz-ttl"><h1 class="display">Cuánto ganaste</h1><p class="hint">Las monedas de tus lives pasadas a soles o dólares, por día, por semana y por mes. Solo cuentan los regalos de tus lives de verdad, no las pruebas.</p></div>
  </div>
  <div class="gn-cards" data-r="cards"></div>
  <div class="panel gn-chartp">
    <div class="gn-ch-head"><h2>📊 Tus ganancias</h2><div class="seg" data-r="view"><button data-v="dias">Días</button><button data-v="semanas">Semanas</button><button data-v="meses">Meses</button></div></div>
    <div class="gn-chart" data-r="chart"></div>
    <div class="gn-note" data-r="note"></div>
  </div>
  <div class="gn-grid">
    <div class="panel"><h2>🎯 Meta del mes</h2><div data-r="goal"></div></div>
    <div class="panel"><h2>⚙️ Cómo se calcula</h2>
      <div class="row"><label class="f">Mostrar en<select class="i" data-c="currency"><option value="pen">Soles (S/)</option><option value="usd">Dólares ($)</option></select></label>
        <label class="f">Por cada 1000 monedas te pagan ($)<input class="i" type="number" step="0.1" min="0" data-c="usdPer1000"></label></div>
      <div class="row"><label class="f">1 dólar en soles<input class="i" type="number" step="0.01" min="0" data-c="penPerUsd"></label>
        <label class="f">Tu agencia se queda (%)<input class="i" type="number" step="1" min="0" max="100" data-c="agency"></label></div>
      <label class="f">Meta del mes (en tu moneda, 0 = sin meta)<input class="i" type="number" step="1" min="0" data-c="goal"></label>
      <p class="hint" style="margin-top:8px">TikTok le paga al streamer más o menos $5 por cada 1000 monedas que recibe (puede variar según tu país). Es un cálculo aproximado: tu saldo real lo ves en TikTok → Monetización.</p>
      <button class="btn sm danger" data-r="reset" style="margin-top:6px">🧹 Borrar el historial</button>
    </div>
  </div>`;
  document.getElementById('studios').after(sec);
  const $ = q => sec.querySelector(q);

  // ---------- tarjetas ----------
  function paintCards() {
    const now = new Date(), today = new Date(now.getFullYear(), now.getMonth(), now.getDate()), tomorrow = new Date(today); tomorrow.setDate(tomorrow.getDate() + 1);
    const wk = monday(now), mo = new Date(now.getFullYear(), now.getMonth(), 1);
    const total = Object.values(G.days).reduce((a, v) => a + (v.coins || 0), 0);
    const tCoins = sumRange(today, tomorrow), wCoins = sumRange(wk, tomorrow), mCoins = sumRange(mo, tomorrow);
    const best = Object.entries(G.days).sort((a, b) => b[1].coins - a[1].coins)[0];
    const card = (ic, t, coins, extra = '') => `<div class="panel gn-card"><span class="gn-ic">${ic}</span><small>${t}</small><b>${fmt(money(coins))}</b><em>🪙 ${n(coins)} monedas</em>${extra}</div>`;
    $('[data-r=cards]').innerHTML = card('☀️', 'Hoy', tCoins) + card('📅', 'Esta semana', wCoins) + card('🗓️', 'Este mes', mCoins)
      + card('🏆', 'En total', total, best ? `<em class="gn-best">Mejor día: ${parse(best[0]).getDate()} ${MES[parse(best[0]).getMonth()]} · ${fmt(money(best[1].coins))}</em>` : '');
    // meta del mes
    const c = C(), goal = +c.goal || 0, have = money(mCoins);
    const dim = new Date(now.getFullYear(), now.getMonth() + 1, 0).getDate(), proj = have / now.getDate() * dim;
    $('[data-r=goal]').innerHTML = goal > 0
      ? `<div class="gn-goal"><div class="gn-gbar"><i style="width:${Math.min(100, have / goal * 100)}%"></i></div><div class="gn-gtxt"><b>${fmt(have)}</b> / ${fmt(goal)} <span>(${Math.min(999, Math.round(have / goal * 100))}%)</span></div>
         <p class="hint">${have >= goal ? '🎉 ¡Llegaste a tu meta de este mes!' : `Te faltan <b>${fmt(goal - have)}</b>. A este ritmo cerrarías el mes con unos <b>${fmt(proj)}</b>.`}</p></div>`
      : `<p class="hint">Ponle una meta al mes abajo en ⚙️ y aquí verás cuánto te falta. ${mCoins ? `A este ritmo cerrarías el mes con unos <b>${fmt(proj)}</b>.` : ''}</p>`;
  }

  // ---------- gráfico ----------
  function series() {
    const now = new Date(), out = [];
    if (view === 'dias') for (let i = 13; i >= 0; i--) { const d = new Date(now.getFullYear(), now.getMonth(), now.getDate() - i); out.push({ label: `${DIA[d.getDay()]} ${d.getDate()}`, tip: `${DIA[d.getDay()]} ${d.getDate()} ${MES[d.getMonth()]}`, coins: coinsOf(key(d)), now: i === 0 }); }
    else if (view === 'semanas') for (let i = 11; i >= 0; i--) { const a = monday(now); a.setDate(a.getDate() - 7 * i); const b = new Date(a); b.setDate(b.getDate() + 7); const e = new Date(b); e.setDate(e.getDate() - 1); out.push({ label: `${a.getDate()} ${MES[a.getMonth()]}`, tip: EN() ? `Week of ${MES[a.getMonth()]} ${a.getDate()} – ${MES[e.getMonth()]} ${e.getDate()}` : `Semana del ${a.getDate()} ${MES[a.getMonth()]} al ${e.getDate()} ${MES[e.getMonth()]}`, coins: sumRange(a, b), now: i === 0 }); }
    else for (let i = 11; i >= 0; i--) { const a = new Date(now.getFullYear(), now.getMonth() - i, 1), b = new Date(now.getFullYear(), now.getMonth() - i + 1, 1); out.push({ label: MES[a.getMonth()], tip: `${MES[a.getMonth()]} ${a.getFullYear()}`, coins: sumRange(a, b), now: i === 0 }); }
    return out;
  }
  function nice(max) { if (max <= 0) return 1; const p = Math.pow(10, Math.floor(Math.log10(max))), f = max / p; return (f <= 1 ? 1 : f <= 2 ? 2 : f <= 5 ? 5 : 10) * p; }
  function paintChart() {
    const S = series(), vals = S.map(s => money(s.coins)), top = nice(Math.max(...vals) * 1.1);
    const W = 760, H = 260, L = 64, R = 12, T = 14, B = 34, pw = W - L - R, ph = H - T - B, bw = pw / S.length, gap = Math.max(4, bw * 0.28);
    const y = v => T + ph - v / top * ph;
    let g = '';
    for (let i = 0; i <= 4; i++) { const v = top * i / 4, yy = y(v); g += `<line x1="${L}" x2="${W - R}" y1="${yy}" y2="${yy}" class="gn-gl${i ? '' : ' base'}"/><text x="${L - 8}" y="${yy + 4}" class="gn-ax" text-anchor="end">${fmt(v).replace(/[.,]00$/, '')}</text>`; }
    const bars = S.map((s, i) => {
      const v = vals[i], x = L + i * bw + gap / 2, w = bw - gap, h = Math.max(v > 0 ? 3 : 0, T + ph - y(v)), yy = T + ph - h, r = Math.min(4, w / 2, h);
      const path = h ? `M${x},${T + ph} V${yy + r} Q${x},${yy} ${x + r},${yy} H${x + w - r} Q${x + w},${yy} ${x + w},${yy + r} V${T + ph} Z` : '';
      return `<g class="gn-b${s.now ? ' now' : ''}" data-i="${i}"><rect x="${L + i * bw}" y="${T}" width="${bw}" height="${ph}" class="gn-hit"/>${path ? `<path d="${path}"/>` : ''}<text x="${x + w / 2}" y="${H - 12}" class="gn-ax" text-anchor="middle">${s.label}</text></g>`;
    }).join('');
    const box = $('[data-r=chart]');
    box.innerHTML = `<svg data-noi18n viewBox="0 0 ${W} ${H}" role="img" aria-label="Ganancias">${g}${bars}</svg><div class="gn-tip" hidden></div>`;
    const tip = box.querySelector('.gn-tip');
    box.querySelectorAll('.gn-b').forEach(el => {
      const place = e => { const r = box.getBoundingClientRect(); tip.style.left = Math.min(r.width - 170, e.clientX - r.left + 14) + 'px'; tip.style.top = (e.clientY - r.top - 20) + 'px'; };
      el.onmouseenter = e => { const s = S[+el.dataset.i]; tip.innerHTML = `<small data-noi18n>${s.tip}</small><b>${fmt(money(s.coins))}</b><em>🪙 ${n(s.coins)} monedas</em>`; place(e); tip.hidden = false; };
      el.onmousemove = place;
      el.onmouseleave = () => { tip.hidden = true; };
    });
    const tot = S.reduce((a, s) => a + s.coins, 0);
    $('[data-r=note]').innerHTML = tot ? `<span>${view === 'dias' ? 'En estos 14 días:' : view === 'semanas' ? 'En estas 12 semanas:' : 'En estos 12 meses:'}</span> <b>${fmt(money(tot))}</b> (🪙 ${n(tot)} monedas)` : 'Todavía no hay regalos en este tiempo. Se van sumando solos en cada live.';
    sec.querySelectorAll('[data-v]').forEach(b => b.classList.toggle('on', b.dataset.v === view));
  }

  // ---------- ajustes ----------
  function paintCfg() {
    const c = C();
    sec.querySelectorAll('[data-c]').forEach(i => { if (document.activeElement !== i) i.value = c[i.dataset.c]; });
  }
  sec.querySelectorAll('[data-c]').forEach(i => i.addEventListener(i.tagName === 'SELECT' ? 'change' : 'input', () => {
    const v = i.tagName === 'SELECT' ? i.value : Math.max(0, +i.value || 0);
    window.cfg.ganancias = { ...C(), [i.dataset.c]: v };
    socket.emit('saveConfig', { ganancias: { [i.dataset.c]: v } });
    paintAll();
  }));
  sec.querySelectorAll('[data-v]').forEach(b => b.onclick = () => { view = b.dataset.v; paintChart(); });
  $('[data-r=reset]').onclick = () => { if (confirm('¿Borrar todo el historial de ganancias? No se puede deshacer.')) socket.emit('ganancias:reset'); };

  function paintAll() { try { paintCards(); paintChart(); paintCfg(); } catch (e) { console.warn('[ganancias]', e); } }
  socket.on('ganancias', s => { G = s || G; paintAll(); });
  socket.on('config', () => paintAll());
  document.addEventListener('click', e => { if (e.target.closest('[data-lang],.lang button,#langEs,#langEn')) setTimeout(paintAll, 50); });
  socket.emit('ganancias:get'); socket.on('connect', () => socket.emit('ganancias:get'));
  setInterval(() => { if (sec.classList.contains('on')) paintCards(); }, 60000);
})();
