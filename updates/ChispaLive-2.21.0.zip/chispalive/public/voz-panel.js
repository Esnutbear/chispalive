// ===== Voz del chat (TTS) — página del panel =====
(function () {
  const T = () => window.cfg?.tts || {};
  let META = { banned: [], scripts: [] };
  socket.on('tts:meta', m => { META = m; paintAll(); });
  const SCRIPT_NAMES = { latino: 'Latino (español, inglés…)', arabe: 'Árabe', hebreo: 'Hebreo', chino: 'Chino', japones: 'Japonés', coreano: 'Coreano', hindi: 'Hindi', tailandes: 'Tailandés', cirilico: 'Cirílico (ruso…)', griego: 'Griego' };

  // ---------- guardar con espera ----------
  let pend = {}, pt;
  function save(path, v) {
    setP(window.cfg.tts, path, v); setP(pend, path, v);
    clearTimeout(pt); pt = setTimeout(() => { socket.emit('saveConfig', { tts: pend }); pend = {}; flash(); }, 300);
    paintSummary();
  }
  function flash() { const s = document.querySelector('#s-voz .saved'); if (s) { s.classList.add('on'); setTimeout(() => s.classList.remove('on'), 1200); } }

  // ---------- estructura ----------
  const sec = document.createElement('section'); sec.className = 'sec'; sec.id = 's-voz';
  sec.innerHTML = `
  <div class="vz-head panel">
    <img class="vz-mascot" src="/brand/oso-voz.svg" alt="">
    <div class="vz-ttl"><h1 class="display">Voz del chat <span class="saved">✓ Guardado</span></h1><p class="hint">Tus viewers hablan en tu live: sus mensajes se leen en voz alta.</p></div>
    <label class="vz-power"><input type="checkbox" data-p="enabled"><span class="vz-pw"><i></i></span><b data-r="pwlab">Apagada</b></label>
  </div>
  <div class="vz-offbar" data-r="offbar">🔇 <b>La voz está apagada:</b> los mensajes del chat no se leen. <button class="btn sm pri" data-r="turnon">Encender voz</button></div>
  <div class="vz-warn" data-r="vwarn" hidden></div>
  <div class="vz-warn" data-r="vwarn2" hidden>⚠️ Elegiste que la voz suene <b>en un overlay</b>, pero ese overlay no está abierto en OBS / TikTok LIVE Studio. Mientras tanto la voz suena <b>aquí en el panel</b>. Para usar el overlay agrega su link como fuente de navegador.</div>
  <div class="vz-sum" data-r="sum"></div>
  <div class="vz-grid">
    <div class="vz-main panel">
      <div class="vz-tabs">${[['voz', '🎙️ Voz'], ['act', '⚡ Activadores'], ['quien', '👥 Quién puede'], ['filtros', '🧹 Filtros'], ['avz', '🛠️ Avanzado']].map(([k, l], i) => `<button data-vt="${k}" class="${i ? '' : 'on'}">${l}<i data-vc="${k}"></i></button>`).join('')}</div>

      <div class="vz-pane on" data-vp="voz">
        <div class="vz-wave" data-r="wave"><span class="vz-dot"></span><div class="bars">${Array.from({ length: 48 }, (_, i) => `<i style="--d:${(i % 7) * 0.09}s;--h:${20 + (i * 37) % 70}%"></i>`).join('')}</div><div class="vz-now"><b data-r="wstate">Lista</b><small data-r="wvoice"></small></div></div>
        <div class="flab">VOZ</div>
        <div class="vz-voicebox"><input class="i" data-r="vsearch" placeholder="🔍 Buscar voz (ej. Spanish, Sabina, Pablo)…"><div class="vz-voices" data-r="voices"></div></div>
        <div class="flab">REPRODUCCIÓN</div>
        <div class="vz-sliders">
          <div class="rng"><div class="lab">🔊 Volumen <b data-o="volume"></b></div><input type="range" min="0" max="100" data-p="volume" data-u="%"></div>
          <div class="rng"><div class="lab">⏩ Velocidad <b data-o="rate"></b></div><input type="range" min="0.5" max="2" step="0.1" data-p="rate" data-u="x"></div>
          <div class="rng"><div class="lab">🎵 Tono <b data-o="pitch"></b></div><input type="range" min="0.5" max="2" step="0.1" data-p="pitch" data-u=""></div>
        </div>
        <div class="flab">¿DÓNDE SUENA?</div>
        <div class="vz-where">
          <button data-where="panel"><b>🖥️ En esta ventana</b><small>Captura el audio del escritorio en OBS / LIVE Studio</small></button>
          <button data-where="overlay"><b>📺 En un overlay</b><small>Agrega el link como fuente de navegador</small></button>
        </div>
        <div class="url hidden" data-r="vurl"><code>${location.origin}/overlay/voz.html</code><button class="btn sm" data-copy="${location.origin}/overlay/voz.html">Copiar</button></div>
      </div>

      <div class="vz-pane" data-vp="act">
        <div class="flab">¿CÓMO ACTIVAN LA VOZ LOS VIEWERS?</div>
        <div class="vz-cards3">
          <button data-trig="all"><span>💬</span><b>Todo el chat</b><small>Se lee cada mensaje</small></button>
          <button data-trig="prefix"><span>❗</span><b>Con prefijo</b><small>Mensajes que empiezan con <code data-r="pfx">!</code></small></button>
          <button data-trig="command"><span>⌨️</span><b>Con comando</b><small>Escriben <code data-r="cmd">!say</code> + mensaje</small></button>
        </div>
        <div class="row" style="margin:12px 0 0"><label class="f">Prefijo<input class="i" data-p="prefix" maxlength="5"></label><label class="f">Comando<input class="i" data-p="command" maxlength="20"></label></div>
        <div class="tcard" data-color="gold"><div class="tc-head"><span class="tc-ic">🎁</span><div class="tc-t"><b>Leer los regalos</b><small>Anuncia en voz alta quién envió un regalo</small></div><label class="sw2"><input type="checkbox" data-p="gift.on"><i></i></label></div>
          <div class="tc-sub"><label class="f">Texto<input class="i" data-p="gift.text"></label><label class="f">Desde (monedas)<input class="i" type="number" min="1" data-p="gift.min"></label><div class="hint">Usa {usuario}, {regalo}, {cantidad}, {monedas}.</div></div></div>
        <div class="tcard" data-color="pink"><div class="tc-head"><span class="tc-ic">⭐</span><div class="tc-t"><b>Leer los nuevos seguidores</b><small>Da las gracias en voz alta</small></div><label class="sw2"><input type="checkbox" data-p="follow.on"><i></i></label></div>
          <div class="tc-sub"><label class="f">Texto<input class="i" data-p="follow.text"></label></div></div>
      </div>

      <div class="vz-pane" data-vp="quien">
        <div class="vz-seg2"><button data-who="all"><b>🌍 Todos</b><small>Cualquier viewer</small></button><button data-who="some"><b>🎯 Solo algunos</b><small>Elige los grupos de abajo</small></button></div>
        <div class="vz-groups" data-r="groups">
          ${grp('followers', '⭐', 'Seguidores', 'Personas que te siguen')}
          ${grp('subs', '👑', 'Super fans', 'Suscriptores de pago')}
          ${grp('fan.on', '💖', 'Club de fans', 'Miembros de tu club', 'fan.level', 'Nivel', 1, 50)}
          ${grp('mods', '🛡️', 'Moderadores', 'Tus moderadores del live')}
          ${grp('gifters.on', '🎁', 'Nivel de donador', 'Donadores con nivel de TikTok', 'gifters.level', 'Nivel', 1, 50)}
          ${grp('top.on', '🏆', 'Top donadores', 'Los que más regalan en tu live', 'top.rank', 'Top', 1, 10)}
          ${grp('donors', '💸', 'Regalaron hoy', 'Mandaron al menos un regalo en este live')}
        </div>
        <div class="vz-special">
          <div class="vz-sphd"><b>⭐ Usuarios especiales</b>
            <label class="pillsw"><input type="checkbox" data-p="special.on"><span>Especiales: <em data-r="spon"></em></span></label>
            <label class="pillsw red"><input type="checkbox" data-p="special.readAll"><span>Leer todo lo suyo: <em data-r="spall"></em></span></label></div>
          <div class="addrow"><input class="i" data-r="spin" placeholder="Usuario (@handle)"><button class="btn sm pri" data-r="spadd">＋ Especial</button><button class="btn sm" data-r="spblock">⛔ Bloquear</button></div>
          <input class="i" data-r="spsearch" placeholder="🔍 Buscar usuarios…" style="margin-top:8px">
          <div class="vz-users" data-r="users"></div>
        </div>
      </div>

      <div class="vz-pane" data-vp="filtros">
        <div class="vz-two">
          <div class="stepf"><span class="tc-ic">✂️</span><div class="tc-t"><b>Largo máximo</b><small>letras por mensaje</small></div><input class="i" type="number" min="10" max="1000" data-p="filters.maxLength" style="width:100px"></div>
          <div class="stepf"><span class="tc-ic">⏳</span><div class="tc-t"><b>Espera por usuario</b><small>segundos entre mensajes</small></div><input class="i" type="number" min="0" max="600" data-p="filters.cooldown" style="width:100px"></div>
        </div>
        <div class="flab">FILTROS DE CONTENIDO</div>
        <div class="vz-checks">
          ${chk('filters.spam', 'Quitar spam (aaaaaaa → aaa)')}${chk('filters.skipBang', 'Saltar comandos (!) cuando se lee todo')}
          ${chk('filters.skipMention', 'Saltar mensajes que empiezan con @')}${chk('filters.urls', 'Cambiar links por "link"')}
          ${chk('filters.emoji', 'Quitar emojis')}
        </div>
        <div class="flab">IDIOMAS QUE SE LEEN <span class="hint" data-r="langhint"></span></div>
        <div class="vz-langs" data-r="langs"></div>
        <div class="flab" style="display:flex;justify-content:space-between">PALABRAS PROHIBIDAS <span class="hint" data-r="bcount"></span></div>
        <div class="row" style="margin:0 0 8px"><label class="pillsw"><input type="checkbox" data-p="banned.useDefault"><span>Usar lista incluida (${'{n}'})</span></label>
          <div class="seg sm"><button data-bact="skip">No leer el mensaje</button><button data-bact="censor">Cambiar por "piii"</button></div></div>
        <div class="addrow"><input class="i" data-r="bword" placeholder="Agregar palabra…"><button class="btn sm pri" data-r="badd">Agregar</button></div>
        <div class="vz-words" data-r="words"></div>
      </div>

      <div class="vz-pane" data-vp="avz">
        <div class="tcard" data-color="vio"><div class="tc-head"><span class="tc-ic">🏷️</span><div class="tc-t"><b>Decir el nombre</b><small>Lee quién escribió antes del mensaje</small></div><label class="sw2"><input type="checkbox" data-p="readName"><i></i></label></div>
          <div class="tc-sub"><label class="f">Formato<input class="i" data-p="nameFormat"></label><div class="hint">Usa {usuario} y {mensaje}.</div></div></div>
        <div class="vz-two">
          <div class="stepf"><span class="tc-ic">📋</span><div class="tc-t"><b>Cola máxima</b><small>mensajes esperando</small></div><input class="i" type="number" min="1" max="200" data-p="queueMax" style="width:100px"></div>
          <div class="stepf"><span class="tc-ic">⏸️</span><div class="tc-t"><b>Pausa entre mensajes</b><small>segundos</small></div><input class="i" type="number" min="0" max="10" step="0.1" data-p="gap" style="width:100px"></div>
        </div>
        <div class="tcard" data-color="blue"><div class="tc-head"><span class="tc-ic">💭</span><div class="tc-t"><b>Burbuja en el overlay</b><small>Muestra el mensaje que se está leyendo (overlay de voz)</small></div><label class="sw2"><input type="checkbox" data-p="bubble"><i></i></label></div></div>
      </div>
    </div>

    <div class="vz-side">
      <div class="panel"><div class="ptitle c3">▶️ Probar voz</div><textarea class="i" data-r="ttxt" rows="3">¡Hola! Bienvenidos a mi live</textarea><div class="hint" style="margin-top:6px">Se prueba con tus filtros: así sonará en el live.</div>
        <button class="bigbtn pri" data-r="tbtn" style="width:100%;margin-top:10px">▶ Probar voz</button></div>
      <div class="panel"><div class="ptitle c2" style="justify-content:space-between"><span>📋 Cola <b class="qn" data-r="qn">0</b></span><span><button class="btn sm" data-r="qpause">⏸</button> <button class="btn sm" data-r="qskip">⏭</button> <button class="btn sm danger" data-r="qclear">🗑</button></span></div>
        <div class="vz-queue" data-r="queue"></div></div>
      <div class="panel"><div class="ptitle c4">🕑 Recientes</div>
        <div class="seg sm" style="margin-bottom:10px"><button data-hf="all" class="on">Todos</button><button data-hf="ok">Leídos</button><button data-hf="skip">No leídos</button></div>
        <div class="vz-hist" data-r="hist"></div></div>
    </div>
  </div>`;
  function grp(path, ic, t, d, lvlPath, lvlLab, min, max) {
    return `<div class="vz-g" data-g="${path}"><label class="vz-gck"><input type="checkbox" data-p="who.${path}"><i></i></label><span class="tc-ic">${ic}</span><div class="tc-t"><b>${t}</b><small>${d}</small></div>
      ${lvlPath ? `<div class="vz-lvl"><input type="range" min="${min}" max="${max}" data-p="who.${lvlPath}" data-u=""><b><span data-o="who.${lvlPath}"></span> ${lvlLab === 'Top' ? '' : 'o más'}</b><small>${lvlLab}</small></div>` : ''}</div>`;
  }
  function chk(path, label) { return `<label class="vz-ck"><input type="checkbox" data-p="${path}"><i></i><span>${label}</span></label>`; }
  document.getElementById('studios').after(sec);
  const $ = q => sec.querySelector(q);

  // ---------- eventos de los campos ----------
  sec.querySelectorAll('[data-p]').forEach(inp => {
    const p = inp.dataset.p, isCk = inp.type === 'checkbox';
    inp.addEventListener(isCk ? 'change' : 'input', () => {
      const v = isCk ? inp.checked : (inp.type === 'range' || inp.type === 'number') ? +inp.value : inp.value;
      if (inp.type === 'range') { paintRange(inp); const o = sec.querySelector(`[data-o="${p}"]`); if (o) o.textContent = v + (inp.dataset.u || ''); }
      save(p, v); paintToggles();
    });
  });
  sec.querySelectorAll('[data-vt]').forEach(b => b.onclick = () => {
    sec.querySelectorAll('[data-vt]').forEach(x => x.classList.toggle('on', x === b));
    sec.querySelectorAll('[data-vp]').forEach(x => x.classList.toggle('on', x.dataset.vp === b.dataset.vt));
  });
  sec.querySelectorAll('[data-where]').forEach(b => b.onclick = () => { save('where', b.dataset.where); paintToggles(); });
  sec.querySelectorAll('[data-trig]').forEach(b => b.onclick = () => { save('trigger', b.dataset.trig); paintToggles(); });
  sec.querySelectorAll('[data-who]').forEach(b => b.onclick = () => { save('who.mode', b.dataset.who); paintToggles(); });
  sec.querySelectorAll('[data-bact]').forEach(b => b.onclick = () => { save('banned.action', b.dataset.bact); paintToggles(); });
  sec.querySelector('[data-copy]').onclick = e => { navigator.clipboard.writeText(e.target.dataset.copy); toast('Link copiado ✓'); };
  // usuarios especiales
  const addUser = list => { const v = $('[data-r=spin]').value.trim().replace(/^@/, ''); if (!v) return; const L = [...(T().special?.[list] || [])]; if (!L.includes(v)) L.push(v); save(`special.${list}`, L); $('[data-r=spin]').value = ''; paintUsers(); };
  $('[data-r=spadd]').onclick = () => addUser('users'); $('[data-r=spblock]').onclick = () => addUser('blocked');
  $('[data-r=spin]').onkeydown = e => { if (e.key === 'Enter') addUser('users'); };
  $('[data-r=spsearch]').oninput = paintUsers;
  // palabras
  const addWord = () => { const v = $('[data-r=bword]').value.trim(); if (!v) return; const L = [...(T().banned?.words || [])]; if (!L.includes(v)) L.push(v); save('banned.words', L); $('[data-r=bword]').value = ''; paintWords(); };
  $('[data-r=badd]').onclick = addWord; $('[data-r=bword]').onkeydown = e => { if (e.key === 'Enter') addWord(); };

  // ---------- pintar ----------
  function paintFields() {
    const t = T();
    sec.querySelectorAll('[data-p]').forEach(inp => {
      if (document.activeElement === inp) return;
      const v = getP(t, inp.dataset.p);
      if (inp.type === 'checkbox') inp.checked = !!v;
      else { inp.value = v ?? ''; if (inp.type === 'range') { paintRange(inp); const o = sec.querySelector(`[data-o="${inp.dataset.p}"]`); if (o) o.textContent = (v ?? '') + (inp.dataset.u || ''); } }
    });
    paintToggles();
  }
  function paintToggles() {
    const t = T();
    $('[data-r=pwlab]').textContent = t.enabled ? 'Encendida' : 'Apagada';
    $('[data-r=offbar]').hidden = !!t.enabled;
    sec.classList.toggle('vz-off', !t.enabled);
    sec.querySelectorAll('[data-where]').forEach(b => b.classList.toggle('on', (t.where || 'panel') === b.dataset.where));
    $('[data-r=vurl]').classList.toggle('hidden', t.where !== 'overlay');
    sec.querySelectorAll('[data-trig]').forEach(b => b.classList.toggle('on', t.trigger === b.dataset.trig));
    $('[data-r=pfx]').textContent = t.prefix || '!'; $('[data-r=cmd]').textContent = t.command || '!say';
    sec.querySelectorAll('[data-who]').forEach(b => b.classList.toggle('on', (t.who?.mode || 'all') === b.dataset.who));
    $('[data-r=groups]').classList.toggle('dim', (t.who?.mode || 'all') !== 'some');
    sec.querySelectorAll('[data-bact]').forEach(b => b.classList.toggle('on', (t.banned?.action || 'skip') === b.dataset.bact));
    sec.querySelectorAll('.tcard').forEach(c => { const i = c.querySelector('.sw2 input'); if (i) c.classList.toggle('is-on', i.checked); });
    $('[data-r=spon]').textContent = t.special?.on !== false ? 'SÍ' : 'NO'; $('[data-r=spall]').textContent = t.special?.readAll ? 'SÍ' : 'NO';
    sec.querySelectorAll('.vz-g').forEach(g => g.classList.toggle('on', !!getP(t.who || {}, g.dataset.g)));
    // contadores de las pestañas
    const cnt = { voz: [t.voice, t.rate !== 1, t.where === 'overlay'].filter(Boolean).length, act: [t.gift?.on, t.follow?.on].filter(Boolean).length + 1,
      quien: (t.who?.mode === 'some' ? ['followers', 'subs', 'fan.on', 'mods', 'gifters.on', 'top.on', 'donors'].filter(k => getP(t.who, k)).length : 0) + (t.special?.users?.length || 0) + (t.special?.blocked?.length || 0),
      filtros: ['spam', 'skipBang', 'skipMention', 'urls', 'emoji'].filter(k => t.filters?.[k]).length + (t.filters?.langs?.length || 0), avz: [t.readName, t.bubble].filter(Boolean).length };
    Object.entries(cnt).forEach(([k, n]) => { const e = sec.querySelector(`[data-vc="${k}"]`); e.textContent = n || ''; });
  }
  function paintSummary() {
    const t = T(), words = (t.banned?.useDefault !== false ? META.banned.length : 0) + (t.banned?.words?.length || 0);
    const trig = t.trigger === 'all' ? 'todo el chat' : t.trigger === 'prefix' ? `prefijo ${t.prefix}` : `comando ${t.command}`;
    $('[data-r=sum]').innerHTML = `<span class="vz-st ${window.state?.session?.status === 'live' ? 'live' : ''}">${window.state?.session?.status === 'live' ? '● Conectado al live' : '○ Sin conectar · conéctate en el Dashboard'}</span>
      <span class="lbl">LEYENDO</span><span>💬 ${esc(trig)}</span>${t.who?.mode === 'some' ? '<span>🎯 solo algunos</span>' : '<span>🌍 todos</span>'}
      <span>⏳ ${t.filters?.cooldown ?? 1}s de espera</span><span>🚫 ${words} palabras</span>${t.filters?.skipBang ? '<span>sin comandos</span>' : ''}<span>📋 cola máx. ${t.queueMax || 20}</span>`;
  }
  function paintUsers() {
    const t = T(), q = ($('[data-r=spsearch]').value || '').toLowerCase();
    const rows = [...(t.special?.users || []).map(u => [u, 'users']), ...(t.special?.blocked || []).map(u => [u, 'blocked'])].filter(([u]) => u.toLowerCase().includes(q));
    $('[data-r=users]').innerHTML = rows.length ? rows.map(([u, l]) => `<span class="vz-u ${l}">${l === 'users' ? '⭐' : '⛔'} @${esc(u)}<button data-ru="${esc(u)}" data-rl="${l}">✕</button></span>`).join('') : '<span class="hint">Sin usuarios especiales ni bloqueados.</span>';
    $('[data-r=users]').querySelectorAll('[data-ru]').forEach(b => b.onclick = () => { save(`special.${b.dataset.rl}`, (T().special?.[b.dataset.rl] || []).filter(x => x !== b.dataset.ru)); paintUsers(); });
  }
  function paintLangs() {
    const sel = T().filters?.langs || [];
    $('[data-r=langhint]').textContent = sel.length ? `· solo ${sel.length} seleccionados` : '· se leen todos';
    $('[data-r=langs]').innerHTML = (META.scripts || Object.keys(SCRIPT_NAMES)).map(k => `<button class="${sel.includes(k) ? 'on' : ''}" data-lg="${k}">${SCRIPT_NAMES[k] || k}</button>`).join('');
    $('[data-r=langs]').querySelectorAll('[data-lg]').forEach(b => b.onclick = () => { const L = [...(T().filters?.langs || [])], i = L.indexOf(b.dataset.lg); i >= 0 ? L.splice(i, 1) : L.push(b.dataset.lg); save('filters.langs', L); paintLangs(); paintToggles(); });
  }
  function paintWords() {
    const t = T(), def = t.banned?.useDefault !== false ? META.banned : [], own = t.banned?.words || [];
    $('[data-r=bcount]').textContent = `${def.length + own.length} palabras`;
    sec.querySelector('[data-p="banned.useDefault"]').nextElementSibling.textContent = `Usar lista incluida (${META.banned.length})`;
    $('[data-r=words]').innerHTML = own.map(w => `<span class="vz-w own">${esc(w)}<button data-rw="${esc(w)}">✕</button></span>`).join('') + def.map(w => `<span class="vz-w def" title="Incluida">${esc(w)}</span>`).join('');
    $('[data-r=words]').querySelectorAll('[data-rw]').forEach(b => b.onclick = () => { save('banned.words', (T().banned?.words || []).filter(x => x !== b.dataset.rw)); paintWords(); });
  }
  function paintAll() { if (!window.cfg?.tts) return; paintFields(); paintSummary(); paintUsers(); paintLangs(); paintWords(); paintVoices(); }
  socket.on('config', () => setTimeout(paintAll, 0));
  socket.on('state', () => paintSummary());

  // ---------- voces del sistema ----------
  let voices = [];
  function loadVoices() { voices = ('speechSynthesis' in window) ? speechSynthesis.getVoices() : []; paintVoices(); }
  if ('speechSynthesis' in window) { loadVoices(); speechSynthesis.onvoiceschanged = loadVoices; }
  $('[data-r=vsearch]').oninput = paintVoices;
  function pickVoice() { const n = T().voice; return voices.find(v => v.name === n) || voices.find(v => /^es/i.test(v.lang)) || null; }
  function paintVoices() {
    const box = $('[data-r=voices]'); if (!box) return;
    const q = ($('[data-r=vsearch]').value || '').toLowerCase(), cur = pickVoice();
    const list = [...voices].sort((a, b) => (/^es/i.test(b.lang) - /^es/i.test(a.lang)) || a.name.localeCompare(b.name)).filter(v => (v.name + ' ' + v.lang).toLowerCase().includes(q));
    box.innerHTML = list.length ? list.slice(0, 80).map(v => `<button class="${cur?.name === v.name ? 'on' : ''}" data-vn="${esc(v.name)}"><b>${esc(v.name.replace(/Microsoft |Google /, ''))}</b><small>${esc(v.lang)}${v.localService ? '' : ' · en línea'}</small></button>`).join('')
      : '<div class="hint">No se encontraron voces. En Windows: Configuración → Hora e idioma → Voz, para instalar voces en español.</div>';
    box.querySelectorAll('[data-vn]').forEach(b => b.onclick = () => { save('voice', b.dataset.vn); paintVoices(); speak({ text: 'Hola, así sueno en tu live', user: {} }, true); });
    $('[data-r=wvoice]').textContent = cur ? cur.name : 'Voz del sistema';
    const want = T().voice, w = $('[data-r=vwarn]');
    if (w) { const miss = want && voices.length && !voices.find(v => v.name === want); w.hidden = !miss; if (miss) w.innerHTML = `⚠️ La voz <b>${esc(want)}</b> no está en este navegador. Se usa <b>${esc(cur?.name || 'la del sistema')}</b>. Elige otra en la pestaña Voz.`; }
  }

  // ---------- reproducción (cola) ----------
  const Q = []; let speaking = false, paused = false; const H = [];
  // Si elegiste "En un overlay" pero no está abierto en OBS / LIVE Studio, suena aquí para no perder mensajes
  let vozOv = 0;
  socket.on('voz:overlays', n => { vozOv = n; const w = $('[data-r=vwarn2]'); if (w) { const miss = T().where === 'overlay' && !n; w.hidden = !miss; } });
  // Habla un texto. Arregla 3 fallas de Chrome: la voz que se corta a los ~15 s, el "onend" que nunca llega
  // (la cola se quedaba trabada) y el mensaje que se pierde si el navegador borra la frase de memoria.
  let live = null, keep = null, guard = null;
  function speak(item, direct) {
    if (!('speechSynthesis' in window)) return toast('Este navegador no tiene voz (usa Chrome o Edge)');
    const t = T(), u = new SpeechSynthesisUtterance(item.text), v = pickVoice();
    if (v) { u.voice = v; u.lang = v.lang; } else u.lang = 'es-ES';
    u.volume = (t.volume ?? 100) / 100; u.rate = t.rate || 1; u.pitch = t.pitch || 1;
    if (direct) { stopTimers(); speechSynthesis.cancel(); if (speaking) { speaking = false; } }
    let fin = false;
    const done = () => {
      if (fin) return; fin = true; stopTimers(); live = null; wave(false);
      setTimeout(() => { speaking = false; next(); }, (t.gap ?? 0.3) * 1000);
    };
    u.onstart = () => wave(true); u.onend = u.onerror = done;
    live = u; // que el navegador no la borre antes de terminar
    speechSynthesis.speak(u);
    // Chrome corta las voces en línea a los ~15 s: pausar y seguir la mantiene viva
    if (v && !v.localService) keep = setInterval(() => { if (speechSynthesis.speaking && !speechSynthesis.paused) { speechSynthesis.pause(); speechSynthesis.resume(); } }, 10000);
    // Si nunca avisa que terminó, seguimos igual
    const est = 2500 + item.text.length * 110 / (t.rate || 1), t0 = Date.now();
    const check = () => { if (fin) return; if (!speechSynthesis.speaking || Date.now() - t0 > est + 15000) { speechSynthesis.cancel(); done(); } else guard = setTimeout(check, 1500); };
    guard = setTimeout(check, est + 1500);
  }
  function stopTimers() { clearInterval(keep); clearTimeout(guard); keep = guard = null; }
  function wave(on) { $('[data-r=wave]').classList.toggle('talking', on); $('[data-r=wstate]').textContent = on ? 'Hablando…' : paused ? 'En pausa' : 'Lista'; }
  function next() {
    if (speaking || paused || !Q.length) return paintQueue();
    speaking = true; const it = Q.shift(); paintQueue(); speak(it);
  }
  function paintQueue() {
    $('[data-r=qn]').textContent = Q.length;
    $('[data-r=queue]').innerHTML = Q.length ? Q.map((q, i) => `<div class="vz-q"><span class="av">${avHtml(q.user)}</span><div><b>${esc(q.user?.name || '')}</b><small>${esc(q.text)}</small></div><button data-qx="${i}">✕</button></div>`).join('') : '<div class="vz-empty">💬<br>Cola vacía</div>';
    $('[data-r=queue]').querySelectorAll('[data-qx]').forEach(b => b.onclick = () => { Q.splice(+b.dataset.qx, 1); paintQueue(); });
  }
  let hf = 'all';
  sec.querySelectorAll('[data-hf]').forEach(b => b.onclick = () => { hf = b.dataset.hf; sec.querySelectorAll('[data-hf]').forEach(x => x.classList.toggle('on', x === b)); paintHist(); });
  function paintHist() {
    const L = H.filter(h => hf === 'all' || (hf === 'ok' ? !h.reason : h.reason));
    $('[data-r=hist]').innerHTML = L.length ? L.slice(0, 40).map(h => `<div class="vz-h ${h.reason ? 'skip' : ''}"><b>${esc(h.user?.name || '')}</b> <span class="hint">${ago(h.t)}</span><div>${esc(h.text)}</div>${h.reason ? `<small>🚫 ${esc(h.reason)}</small>` : ''}</div>`).join('') : '<div class="vz-empty">🕑<br>Sin historial todavía</div>';
  }
  socket.on('tts', it => {
    H.unshift(it); if (H.length > 80) H.pop(); paintHist();
    if (T().where === 'overlay' && vozOv > 0) return; // suena en el overlay de OBS / LIVE Studio
    if (it.kind === 'test') { Q.length = 0; paintQueue(); speaking = true; return speak(it, true); }
    if (Q.length >= (T().queueMax || 20)) { H[0].reason = 'cola llena'; paintHist(); return; }
    Q.push(it); next();
  });
  socket.on('tts:skip', it => { H.unshift(it); if (H.length > 80) H.pop(); paintHist(); if (it.test) toast(`🚫 No se leería: ${it.reason}`); });
  $('[data-r=tbtn]').onclick = () => { const txt = $('[data-r=ttxt]').value.trim(); if (!txt) return; socket.emit('tts:test', txt); };
  $('[data-r=turnon]').onclick = () => { save('enabled', true); toast('🔊 Voz encendida'); };
  $('[data-r=qpause]').onclick = () => { paused = !paused; $('[data-r=qpause]').textContent = paused ? '▶' : '⏸'; if (paused) speechSynthesis.pause(); else { speechSynthesis.resume(); next(); } wave(false); };
  $('[data-r=qskip]').onclick = () => { speechSynthesis.cancel(); };
  $('[data-r=qclear]').onclick = () => { Q.length = 0; speechSynthesis.cancel(); paintQueue(); };
  paintQueue(); paintHist();
  window.vozSpeak = (text) => speak({ text, user: {} }, true);
})();
// Texto de prueba en el idioma elegido (solo si no lo cambiaste)
window.addEventListener('chispa:lang', e => {
  const t = document.querySelector('#s-voz [data-r="ttxt"]'), ES = '¡Hola! Bienvenidos a mi live', EN = 'Hi! Welcome to my live';
  if (t && (t.value === ES || t.value === EN)) t.value = e.detail === 'en' ? EN : ES;
});
