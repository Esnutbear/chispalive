// Utilidades compartidas por panel y overlays
const socket = io();

// ---------- Temas, fuentes y animaciones ----------
const THEMES = {
  chispa:   { name: 'Chispa Neón',  primary: '#ff6a2b', secondary: '#ff2e7e', accent: '#ffd23f', extra: ['#7c5cff', '#2ea7ff', '#2ee6a6', '#ff8f3f', '#c13cff'], bg: [14, 12, 22] },
  cyber:    { name: 'Cyber Azul',   primary: '#00e5ff', secondary: '#7c5cff', accent: '#00ffa3', extra: ['#2979ff', '#d500f9', '#18ffff', '#651fff', '#00b8d4'], bg: [6, 10, 24] },
  kawaii:   { name: 'Rosa Kawaii',  primary: '#ff7eb6', secondary: '#c77dff', accent: '#ffe066', extra: ['#ffadad', '#a0c4ff', '#bdb2ff', '#ffc6ff', '#9bf6ff'], bg: [36, 16, 40] },
  toxic:    { name: 'Tóxico',       primary: '#39ff14', secondary: '#00c853', accent: '#e6ff00', extra: ['#76ff03', '#1de9b6', '#c6ff00', '#00e676', '#64dd17'], bg: [6, 16, 8] },
  oro:      { name: 'Oro Real',     primary: '#ffcc33', secondary: '#ff8c00', accent: '#fff3b0', extra: ['#b8860b', '#ffd700', '#e09b2d', '#ffe08a', '#c58b00'], bg: [20, 14, 4] },
  terror:   { name: 'Terror',       primary: '#ff1e3c', secondary: '#7a0010', accent: '#f5f5f5', extra: ['#3d0008', '#b3001b', '#4a4a4a', '#d50000', '#1a1a1a'], bg: [8, 2, 4] },
  brainrot: { name: 'Brainrot',     primary: '#ff00e6', secondary: '#00f0ff', accent: '#fff200', extra: ['#00ff6a', '#ff6a00', '#7b00ff', '#ff0055', '#00a2ff'], bg: [12, 4, 24] },
  hielo:    { name: 'Hielo',        primary: '#7dd3fc', secondary: '#a5b4fc', accent: '#ffffff', extra: ['#38bdf8', '#c7d2fe', '#e0f2fe', '#818cf8', '#bae6fd'], bg: [8, 18, 32] },
};
const FONTS = {
  'Bricolage Grotesque': { label: 'Moderna',   pkg: 'bricolage-grotesque', w: [600, 800] },
  'Bungee':              { label: 'Gamer',     pkg: 'bungee', w: [400] },
  'Luckiest Guy':        { label: 'Cartoon',   pkg: 'luckiest-guy', w: [400] },
  'Fredoka':             { label: 'Redondita', pkg: 'fredoka', w: [500, 700] },
  'Press Start 2P':      { label: 'Pixel',     pkg: 'press-start-2p', w: [400] },
  'Russo One':           { label: 'Deportiva', pkg: 'russo-one', w: [400] },
  'Creepster':           { label: 'Terror',    pkg: 'creepster', w: [400] },
  'Bangers':             { label: 'Cómic',     pkg: 'bangers', w: [400] },
  'Outfit':              { label: 'Limpia',    pkg: 'outfit', w: [400, 600, 800] },
};
// ---------- Tienda de diseños (pieles de temporada para todos los overlays) ----------
const DESIGN_SKINS = {
  navidad:     { name: 'Navidad',       icon: '🎄', desc: 'Nieve cayendo, gorro de nieve en las tarjetas y colores rojo, verde y dorado.', font: 'Luckiest Guy', fx: 'snow',    colors: { primary: '#e53935', secondary: '#1b8a3a', accent: '#ffd54f' }, extra: ['#c62828', '#2e7d32', '#ffffff', '#ffb300', '#66bb6a'], bg: [10, 26, 16] },
  halloween:   { name: 'Halloween',     icon: '🎃', desc: 'Murciélagos volando, telarañas y colores naranja y morado.',                 font: 'Creepster',    fx: 'bats',    colors: { primary: '#ff7a00', secondary: '#8e24aa', accent: '#b6ff3b' }, extra: ['#ff9800', '#6a1b9a', '#212121', '#ffeb3b', '#4a148c'], bg: [18, 8, 24] },
  anime:       { name: 'Anime',         icon: '🌸', desc: 'Pétalos de sakura, letra redondita y colores pastel.',                       font: 'Fredoka',      fx: 'sakura',  colors: { primary: '#ff8fc8', secondary: '#7ec8ff', accent: '#fff3a8' }, extra: ['#ffc6ff', '#a0c4ff', '#bdb2ff', '#caffbf', '#ffadad'], bg: [42, 20, 50] },
  anonuevo:    { name: 'Año Nuevo',     icon: '🎆', desc: 'Brillos dorados, letra gamer y negro con oro para la cuenta regresiva.',     font: 'Bungee',       fx: 'sparkle', colors: { primary: '#ffd23f', secondary: '#b388ff', accent: '#ffffff' }, extra: ['#ffb300', '#7c4dff', '#e0e0e0', '#ffe082', '#651fff'], bg: [8, 8, 16] },
  sanvalentin: { name: 'San Valentín',  icon: '💘', desc: 'Corazones flotando y todo en rosa y rojo.',                                  font: 'Fredoka',      fx: 'hearts',  colors: { primary: '#ff4d8d', secondary: '#ff1744', accent: '#ffd1e3' }, extra: ['#f06292', '#d50000', '#ff80ab', '#ffcdd2', '#c2185b'], bg: [42, 8, 22] },
};
// "Automático por fecha": elige solo el diseño de la temporada
function skinByDate(d = new Date()) {
  const m = d.getMonth() + 1, day = d.getDate();
  if ((m === 12 && day === 31) || (m === 1 && day <= 2)) return 'anonuevo';
  if (m === 12) return 'navidad';
  if (m === 10 && day >= 15) return 'halloween';
  if (m === 2 && day <= 14) return 'sanvalentin';
  return '';
}
const IS_OVERLAY = /\/overlay\//.test(location.pathname);
// cada overlay se identifica (ej. data-game="trivia") para que overlay.css pula cada juego por separado
if (IS_OVERLAY && window.GAME_KEY) document.documentElement.dataset.game = window.GAME_KEY;
const SKIN_Q = new URLSearchParams(location.search).get('skin');
function activeSkin(c) {
  if (!IS_OVERLAY) return null;
  const s = c?.skin || {}; let id = SKIN_Q ?? s.id;
  if (id === 'auto') id = skinByDate();
  return DESIGN_SKINS[id] ? { id, ...DESIGN_SKINS[id], opt: s } : null;
}
// los colores de cada piel también se usan en la ruleta y el fondo de las tarjetas
Object.entries(DESIGN_SKINS).forEach(([k, v]) => { THEMES['sk-' + k] = { name: v.name, ...v.colors, extra: v.extra, bg: v.bg }; });
const ANIMS = { pop: 'Pop', rebote: 'Rebote', zoom: 'Zoom', deslizar: 'Deslizar', giro: 'Giro', glitch: 'Glitch' };

let BRAND = {};
let VOLUME = 0.6;

function hexToRgb(h) {
  h = String(h || '#ffffff').replace('#', '');
  if (h.length === 3) h = h.split('').map(c => c + c).join('');
  const n = parseInt(h, 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}
const rgba = (hex, a) => `rgba(${hexToRgb(hex).join(',')},${a})`;

function loadFont(name) {
  const f = FONTS[name]; if (!f) return;
  f.w.forEach(w => {
    const id = `font-${f.pkg}-${w}`;
    if (document.getElementById(id)) return;
    const l = document.createElement('link'); l.id = id; l.rel = 'stylesheet';
    l.href = `/fonts/${f.pkg}/${w}.css`; // fuentes locales: funcionan sin internet
    document.head.appendChild(l);
  });
}

function wheelPalette() {
  const c = BRAND.colors || {}; const t = THEMES[BRAND.theme] || THEMES.chispa;
  return [c.primary, c.secondary, c.accent, ...t.extra].filter(Boolean);
}

// Aplica el estilo del canal a la página actual
function applyTheme(b) {
  BRAND = b || {};
  const c = BRAND.colors || THEMES.chispa;
  const t = THEMES[BRAND.theme] || THEMES.chispa;
  const g = (BRAND.glow ?? 70) / 100;
  const r = document.documentElement.style;
  r.setProperty('--spark', c.primary); r.setProperty('--spark2', c.secondary); r.setProperty('--gold', c.accent);
  r.setProperty('--glass', `rgba(${t.bg.join(',')},${(BRAND.opacity ?? 85) / 100})`);
  r.setProperty('--glow1', rgba(c.primary, 0.25 + g * 0.45));
  r.setProperty('--glow2', rgba(c.secondary, 0.3 + g * 0.6));
  r.setProperty('--glowk', g);
  r.setProperty('--radius', (BRAND.radius ?? 20) + 'px');
  r.setProperty('--font', `'${BRAND.font || 'Bricolage Grotesque'}'`);
  r.setProperty('--speed', BRAND.speed || 1);
  r.setProperty('--scale', (BRAND.scale || 100) / 100);
  r.setProperty('--enter', BRAND.animation || 'pop');
  VOLUME = (BRAND.volume ?? 60) / 100;
  loadFont(BRAND.font || 'Bricolage Grotesque'); loadFont('Outfit');
  document.querySelectorAll('[data-brand]').forEach(addBrandTag);
  if (BRAND.logo) { _logoImg = new Image(); _logoImg.src = BRAND.logo; } else _logoImg = null;
}
function addBrandTag(el) {
  el.querySelector(':scope > .brandtag')?.remove();
  if (!BRAND.showLogo || (!BRAND.logo && !BRAND.name)) return;
  const t = document.createElement('div'); t.className = 'brandtag' + (BRAND.name ? '' : ' noname');
  if (BRAND.logo) { const i = new Image(); i.src = BRAND.logo; t.appendChild(i); }
  if (BRAND.name) t.appendChild(document.createTextNode(BRAND.name));
  el.appendChild(t);
}
let _logoImg = null;

// ---------- Ajustes propios de cada juego ----------
// Cada overlay define window.GAME_KEY antes de cargar este archivo.
const gcfg = () => window.CFG?.games?.[window.GAME_KEY] || {};
const fx = k => gcfg().effects?.[k] !== false;
let _gameImg = null;
function applyGame() {
  const g = gcfg(), r = document.documentElement.style;
  if (g.anim) r.setProperty('--enter', g.anim);
  document.documentElement.classList.toggle('noglow', !fx('glow'));
  document.documentElement.classList.toggle('clasico', (window.CFG?.brand?.finish || BRAND.finish) === 'clasico'); // Acabado: Lujo (por defecto) o Clásico
  // Posición y escala propias del juego (se suman a "Mi estilo")
  r.setProperty('--scale', ((BRAND.scale || 100) / 100) * ((g.scale || 100) / 100));
  r.setProperty('--ox', (g.x || 0) + 'px'); r.setProperty('--oy', (g.y || 0) + 'px');
  if (g.image) { if (!_gameImg || _gameImg._src !== g.image) { _gameImg = new Image(); _gameImg.src = g.image; _gameImg._src = g.image; } } else _gameImg = null;
}
socket.on('config', c => {
  window.CFG = c;
  const g = c.games?.[window.GAME_KEY];
  // Diseño de la tienda (Navidad, Halloween...) encima de "Mi estilo"
  const sk = activeSkin(c); let brand = c.brand;
  if (sk) brand = { ...brand, ...(sk.opt.colors !== false ? { colors: sk.colors, theme: 'sk-' + sk.id } : {}), ...(sk.opt.font !== false ? { font: sk.font } : {}) };
  applySkinFx(sk);
  // Colores propios del juego (si los activaste en su estudio)
  applyTheme(g?.colors?.custom ? { ...brand, colors: { primary: g.colors.primary, secondary: g.colors.secondary, accent: g.colors.accent } } : brand);
  applyGame();
  window.onConfig && window.onConfig(c);
});
socket.on('catalog', c => window.CATALOG = c);
// Reloj sincronizado con el servidor (para los temporizadores)
let TOFF = 0;
socket.on('state', s => { if (s.now) TOFF = s.now - Date.now(); });
const nowMs = () => Date.now() + TOFF;
function fmtTime(ms) {
  const s = Math.max(0, Math.ceil(ms / 1000)), h = Math.floor(s / 3600), m = Math.floor(s % 3600 / 60), ss = s % 60;
  return (h ? h + ':' + String(m).padStart(2, '0') : m) + ':' + String(ss).padStart(2, '0');
}
function gameImgEl(size = 40) {
  const g = gcfg(); if (!g.image) return null;
  const i = new Image(); i.src = g.image; i.className = 'gameimg'; i.style.width = i.style.height = size + 'px'; return i;
}
function avatarEl(user, size = 44) {
  const el = document.createElement(user?.avatar ? 'img' : 'div');
  el.className = 'avatar';
  el.style.width = el.style.height = size + 'px';
  if (user?.avatar) { el.src = user.avatar; el.referrerPolicy = 'no-referrer'; }
  else { el.textContent = (user?.name || '?').slice(0, 1).toUpperCase(); el.style.fontSize = size * 0.42 + 'px'; }
  return el;
}
function esc(s) { return String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }
// Variables en inglés ({user}, {gift}…) valen igual que en español
const VAR_EN = { user: 'usuario', gift: 'regalo', amount: 'cantidad', count: 'cantidad', coins: 'monedas', diamonds: 'diamantes', level: 'nivel', message: 'mensaje', prize: 'premio', viewers: 'espectadores' };
const enVars = s => String(s ?? '').replace(/\{(user|gift|amount|count|coins|diamonds|level|message|prize|viewers)\}/g, (m, k) => '{' + VAR_EN[k] + '}');
// Reemplaza {usuario} {regalo} {cantidad} {diamantes} {monedas} {nivel} en los textos
function fillText(tpl, d) {
  return enVars(tpl || '')
    .replaceAll('{usuario}', d.user?.name || '').replaceAll('{regalo}', d.giftName || '')
    .replaceAll('{cantidad}', d.count || 1).replaceAll('{diamantes}', d.diamonds || 0)
    .replaceAll('{monedas}', (d.total ?? d.diamonds ?? 0).toLocaleString('es')).replaceAll('{nivel}', (d.i ?? 0) + 1)
    .replace(/\b1x /, ''); // "1x Rose" queda como "Rose"
}

// =====================================================================
// SONIDOS: efectos sintetizados (no necesitan archivos) + tus propios MP3
// =====================================================================
const SFX = {
  tick: 'Tic', pop: 'Pop', coin: 'Moneda', gift: 'Regalo', bell: 'Campana', win: 'Victoria', fanfare: 'Fanfarria',
  levelup: 'Subir de nivel', magic: 'Magia', whoosh: 'Whoosh', boom: 'Explosión', oof: 'Oof (eliminado)',
  airhorn: 'Bocina', drum: 'Redoble', laser: 'Láser', boing: 'Boing',
};
let _ctx;
const ac = () => (_ctx = _ctx || new (window.AudioContext || window.webkitAudioContext)());
function _tone(f, t, d, type = 'triangle', g = .3, f2 = null) {
  const c = ac(), o = c.createOscillator(), gn = c.createGain();
  o.type = type; o.frequency.setValueAtTime(f, t); if (f2) o.frequency.exponentialRampToValueAtTime(f2, t + d);
  gn.gain.setValueAtTime(.0001, t); gn.gain.exponentialRampToValueAtTime(Math.max(.0002, g), t + .015); gn.gain.exponentialRampToValueAtTime(.0001, t + d);
  o.connect(gn).connect(_out); o.start(t); o.stop(t + d + .05);
}
function _noise(t, d, g = .3, type = 'lowpass', f1 = 1200, f2 = 200) {
  const c = ac(), b = c.createBuffer(1, c.sampleRate * d, c.sampleRate), data = b.getChannelData(0);
  for (let i = 0; i < data.length; i++) data[i] = Math.random() * 2 - 1;
  const s = c.createBufferSource(), fl = c.createBiquadFilter(), gn = c.createGain();
  s.buffer = b; fl.type = type; fl.frequency.setValueAtTime(f1, t); fl.frequency.exponentialRampToValueAtTime(f2, t + d);
  gn.gain.setValueAtTime(g, t); gn.gain.exponentialRampToValueAtTime(.0001, t + d);
  s.connect(fl).connect(gn).connect(_out); s.start(t);
}
let _out;
function synth(name, vol = .6) {
  if (previewMuted()) return;
  try {
    const c = ac(); if (c.state === 'suspended') c.resume();
    _out = c.createGain(); _out.gain.value = Math.max(0, Math.min(1, vol)); _out.connect(c.destination);
    const t = c.currentTime + .01;
    const seq = (notes, step, type, g, dur) => notes.forEach((f, i) => _tone(f, t + i * step, dur || step * 1.6, type, g));
    switch (name) {
      case 'tick': _tone(1400, t, .04, 'square', .12); break;
      case 'pop': _tone(500, t, .08, 'sine', .4, 1100); break;
      case 'coin': _tone(988, t, .08, 'square', .18); _tone(1319, t + .08, .3, 'square', .18); break;
      case 'gift': seq([660, 880, 1320], .09, 'triangle', .3, .3); break;
      case 'bell': _tone(880, t, 1.2, 'sine', .35); _tone(1760, t, .8, 'sine', .12); _tone(2640, t, .4, 'sine', .06); break;
      case 'win': seq([523, 659, 784, 1046], .1, 'triangle', .3, .35); break;
      case 'fanfare': seq([392, 523, 659], .12, 'sawtooth', .12, .2); [523, 659, 784].forEach(f => _tone(f, t + .38, .9, 'sawtooth', .1)); _tone(1046, t + .38, .9, 'triangle', .2); break;
      case 'levelup': seq([523, 659, 784, 1046, 1319, 1568, 2093], .05, 'square', .12, .12); break;
      case 'magic': for (let i = 0; i < 12; i++) _tone(1200 + Math.random() * 1800, t + i * .05, .4, 'sine', .12); break;
      case 'whoosh': _noise(t, .45, .5, 'bandpass', 300, 3000); break;
      case 'boom': _noise(t, .8, .8, 'lowpass', 900, 60); _tone(120, t, .6, 'sine', .6, 40); break;
      case 'oof': _tone(320, t, .35, 'sawtooth', .25, 110); _noise(t, .25, .2, 'lowpass', 600, 100); break;
      case 'airhorn': [0, .28, .56].forEach((d, i) => { _tone(466, t + d, i === 2 ? .7 : .22, 'sawtooth', .18); _tone(470, t + d, i === 2 ? .7 : .22, 'sawtooth', .18); }); break;
      case 'drum': for (let i = 0; i < 16; i++) _noise(t + i * .055, .07, .25 + i * .02, 'highpass', 900, 600); _noise(t + .9, .5, .7, 'lowpass', 600, 80); break;
      case 'laser': _tone(1800, t, .25, 'sawtooth', .2, 200); break;
      case 'boing': _tone(180, t, .5, 'sine', .45, 600); _tone(600, t + .25, .25, 'sine', .2, 300); break;
      default: _tone(880, t, .2, 'triangle', .3);
    }
  } catch {}
}
// Las vistas previas del panel (los cuadritos con el overlay) van en silencio por defecto,
// así no se escucha doble con el overlay de OBS / TikTok LIVE Studio. Se activan con el botón 🔊 del panel.
var IN_PREVIEW = (() => { try { return window.self !== window.top && /panel\.html/.test(window.top.location.pathname); } catch { return false; } })();
function previewMuted() { return !!IN_PREVIEW && !window.CFG?.panelSound; }
// Reproduce un sonido configurado { on, preset, file }
function playSpec(spec, vol = .6) {
  if (!spec || spec.on === false || vol <= 0 || previewMuted()) return;
  if (spec.file) { try { const a = new Audio(spec.file); a.volume = Math.max(0, Math.min(1, vol)); a.play().catch(() => {}); } catch {} }
  else if (spec.preset && spec.preset !== 'none') synth(spec.preset, vol);
}
const gameVol = () => VOLUME * ((gcfg().volume ?? 70) / 100);
// Sonido de un evento del juego. "coins" elige el nivel de sonido (regalos más grandes = sonido más grande)
function playSound(name, coins) {
  if (!fx('sound')) return;
  const s = gcfg().sounds?.[name]; if (!s || !s.on) return;
  if (s.tiers?.length && coins != null) {
    const t = [...s.tiers].filter(x => coins >= (+x.min || 0)).sort((a, b) => b.min - a.min)[0];
    if (!t) return; // con niveles, un regalo menor a todos no suena
    return playSpec({ on: true, preset: t.preset, file: t.file }, gameVol());
  }
  playSpec(s, gameVol());
}
// Compatibilidad: sonidos sueltos
function beep(kind = 'gift') { if (fx('sound')) synth(kind, gameVol()); }

// Confeti con los colores del tema
function confetti(count = 140) {
  if (BRAND.confetti === false || !fx('confetti')) return;
  const c = document.createElement('canvas');
  c.style.cssText = 'position:fixed;inset:0;pointer-events:none;z-index:999';
  c.width = innerWidth; c.height = innerHeight; document.body.appendChild(c);
  const x = c.getContext('2d');
  const colors = wheelPalette();
  const ps = Array.from({ length: count }, () => ({
    x: c.width / 2 + (Math.random() - .5) * 200, y: c.height / 2,
    vx: (Math.random() - .5) * 16, vy: -Math.random() * 16 - 4,
    s: 6 + Math.random() * 6, r: Math.random() * 6, c: colors[Math.random() * colors.length | 0]
  }));
  let f = 0;
  (function loop() {
    x.clearRect(0, 0, c.width, c.height);
    ps.forEach(p => { p.vy += .45; p.x += p.vx; p.y += p.vy; p.r += .2; x.save(); x.translate(p.x, p.y); x.rotate(p.r); x.fillStyle = p.c; x.fillRect(-p.s / 2, -p.s / 4, p.s, p.s / 2); x.restore(); });
    if (++f < 160) requestAnimationFrame(loop); else c.remove();
  })();
}
// Efectos de pantalla: temblor, flash, zoom
function screenFx(kind, el) {
  if (!kind || kind === 'none') return;
  if (kind === 'shake' && fx('shake')) { const t = el || document.body; t.classList.remove('shake'); void t.offsetWidth; t.classList.add('shake'); }
  if (kind === 'flash') { const f = document.createElement('div'); f.className = 'fxflash'; document.body.appendChild(f); setTimeout(() => f.remove(), 700); }
  if (kind === 'zoom' && el) { el.classList.remove('fxzoom'); void el.offsetWidth; el.classList.add('fxzoom'); }
}

// =====================================================================
// EVOLUCIONES: banner que aparece al pasar un nivel de monedas
// =====================================================================
const _evoQ = []; let _evoBusy = false;
socket.on('evolve', e => {
  if (!window.GAME_KEY || e.key !== window.GAME_KEY || e.key !== 'jar') return;
  window.onEvolve && window.onEvolve(e);
  if (window.NO_EVO_BANNER) return;
  _evoQ.push(e); _evoNext();
});
function _evoNext() {
  if (_evoBusy || !_evoQ.length) return; _evoBusy = true;
  const e = _evoQ.shift(), t = e.tier || {};
  const el = document.createElement('div'); el.className = 'evo card enter pulse';
  el.innerHTML = `${t.image ? `<img class="evo-img" src="${esc(t.image)}">` : `<div class="evo-ico">🧬</div>`}
    <div class="evo-body"><div class="evo-tag">¡Evolución! · Nivel ${e.i + 1}</div>
    <div class="evo-name grad-text">${esc(t.name)}</div>
    <div class="evo-txt">${esc(fillText(t.text || (e.user?.name ? '{usuario} llegó a {monedas}' : ''), e))}</div></div>`;
  if (e.user && e.user.id !== 'meta' && e.user.id !== 'jar') el.querySelector('.evo-body').prepend(Object.assign(avatarEl(e.user, 30), { className: 'avatar evo-av' }));
  document.body.appendChild(el);
  playSpec({ on: true, preset: t.sound || 'levelup', file: t.soundFile || '' }, gameVol());
  if (t.confetti !== false) confetti(160);
  screenFx(t.effect, el);
  setTimeout(() => { el.classList.add('out'); setTimeout(() => { el.remove(); _evoBusy = false; _evoNext(); }, 400); }, 4200);
}
// Nivel actual para un valor (el más alto alcanzado)
function tierFor(value) {
  if (window.GAME_KEY !== 'jar') return null; // solo el frasco evoluciona
  const g = gcfg(); if (!g.evo?.on) return null;
  let best = null;
  (g.evo.tiers || []).forEach((t, i) => { if (t.coins > 0 && value >= t.coins && (!best || t.coins >= best.coins)) best = { ...t, i }; });
  return best;
}

// =====================================================================
// RULETA: porciones con peso (más monedas = porción más grande)
// =====================================================================
function _segAngles(n, weights) {
  const w = (weights && weights.length === n) ? weights.map(x => Math.max(0.0001, +x || 0)) : Array(n).fill(1);
  const tot = w.reduce((a, b) => a + b, 0); let a = 0;
  return w.map(x => { const a0 = a; a += x / tot * Math.PI * 2; return [a0, a]; });
}
function drawWheel(canvas, labels, rotation, opts) {
  const ctx = canvas.getContext('2d');
  const size = canvas.width, r = size / 2 - 10, n = labels.length;
  const style = opts?.style || gcfg().variant || 'clasica';
  let palette = wheelPalette();
  if (style === 'pastel') palette = palette.map(c => { const [r, g, b] = hexToRgb(c); return `rgb(${(r + 255 * 1.4) / 2.4 | 0},${(g + 255 * 1.4) / 2.4 | 0},${(b + 255 * 1.4) / 2.4 | 0})`; });
  const font = BRAND.font || 'Bricolage Grotesque';
  const ang = _segAngles(n, opts?.weights);
  // color por "dueño" de la porción (para que las casillas de un mismo jugador se vean iguales)
  const keys = opts?.keys || labels.map((_, i) => i), uniq = [...new Set(keys)];
  ctx.clearRect(0, 0, size, size);
  ctx.save(); ctx.translate(size / 2, size / 2);
  ctx.beginPath(); ctx.arc(0, 0, r + 6, 0, Math.PI * 2); ctx.fillStyle = BRAND.colors?.accent || '#ffd23f'; ctx.fill();
  ctx.rotate(rotation);
  for (let i = 0; i < n; i++) {
    const [a0, a1] = ang[i], span = a1 - a0;
    ctx.beginPath(); ctx.moveTo(0, 0); ctx.arc(0, 0, r, a0, a1); ctx.closePath();
    const col = opts?.colors?.[i] || palette[uniq.indexOf(keys[i]) % palette.length];
    const light = col.startsWith('#') && (([r, g, b]) => (r * .299 + g * .587 + b * .114) / 255)(hexToRgb(col)) > .72;
    if (style === 'neon') {
      ctx.fillStyle = i % 2 ? '#0d0a16' : '#160f24'; ctx.fill();
      ctx.save(); ctx.shadowColor = col; ctx.shadowBlur = 16; ctx.strokeStyle = col; ctx.lineWidth = 3; ctx.stroke(); ctx.restore();
    } else {
      const grd = ctx.createRadialGradient(0, 0, r * 0.15, 0, 0, r);
      grd.addColorStop(0, col.startsWith('#') ? rgba(col, 0.75) : col); grd.addColorStop(1, col);
      ctx.fillStyle = grd; ctx.fill();
      ctx.strokeStyle = 'rgba(0,0,0,.35)'; ctx.lineWidth = n > 40 ? 1 : 3; ctx.stroke();
    }
    if (span < 0.06) continue; // porción muy fina: sin texto
    ctx.save(); ctx.rotate((a0 + a1) / 2);
    // imagen de la porción (opcional), cerca del borde
    const im = opts?.images?.[i]; let pad = 18;
    if (im && im.complete && im.naturalWidth) {
      const isz = Math.min(span * r * 0.55, r * 0.2);
      ctx.save(); ctx.translate(r - 14 - isz / 2, 0); ctx.rotate(Math.PI / 2); ctx.drawImage(im, -isz / 2, -isz / 2, isz, isz); ctx.restore();
      pad = 22 + isz;
    }
    ctx.fillStyle = style === 'neon' ? col : (style === 'pastel' || light) ? '#2a1d3a' : '#fff'; ctx.textAlign = 'right'; ctx.textBaseline = 'middle';
    const fs = Math.max(10, Math.min(22, span * r * 0.55)) * (font === 'Press Start 2P' ? 0.6 : 1) * (opts?.fontScale || 1);
    ctx.font = `800 ${fs}px '${font}', Outfit, sans-serif`;
    ctx.shadowColor = style === 'neon' ? col : (style === 'pastel' || light) ? 'transparent' : 'rgba(0,0,0,.7)'; ctx.shadowBlur = style === 'neon' ? 10 : 5;
    let t = String(labels[i]); if (t.length > 18) t = t.slice(0, 17) + '…';
    ctx.fillText(t, r - pad, 0); ctx.restore();
  }
  ctx.rotate(-rotation);
  const bulbs = 24;
  for (let i = 0; i < bulbs; i++) {
    const a = (i / bulbs) * Math.PI * 2;
    ctx.beginPath(); ctx.arc(Math.cos(a) * (r + 1), Math.sin(a) * (r + 1), 3.2, 0, Math.PI * 2);
    ctx.fillStyle = (i + Math.floor(performance.now() / 180)) % 2 ? '#fff' : 'rgba(255,255,255,.35)'; ctx.fill();
  }
  ctx.restore();
  const cr = opts?.centerSize ? Math.max(16, size * opts.centerSize / 2) : 34;
  ctx.save(); ctx.beginPath(); ctx.arc(size / 2, size / 2, cr, 0, Math.PI * 2);
  ctx.fillStyle = '#14101e'; ctx.fill();
  const center = opts && 'center' in opts ? opts.center : (_gameImg && _gameImg.complete && _gameImg.naturalWidth) ? _gameImg : (BRAND.logoInWheel !== false ? _logoImg : null);
  if (center && center.complete && center.naturalWidth) { ctx.clip(); ctx.drawImage(center, size / 2 - cr, size / 2 - cr, cr * 2, cr * 2); }
  ctx.restore();
  ctx.beginPath(); ctx.arc(size / 2, size / 2, cr, 0, Math.PI * 2);
  ctx.lineWidth = 5; ctx.strokeStyle = BRAND.colors?.accent || '#ffd23f'; ctx.stroke();
}
function spinWheel(canvas, labels, index, duration = 6000, onTick, opts) {
  return new Promise(res => {
    const ang = _segAngles(labels.length, opts?.weights);
    const [a0, a1] = ang[index], span = a1 - a0;
    // El puntero está arriba (-90°): llevamos el centro de la porción ganadora allí (con un poco de azar)
    const target = -Math.PI / 2 - (a0 + span / 2) + (Math.random() - .5) * span * 0.6;
    const turns = opts?.turns || Math.max(3, Math.round(duration / 900));
    const total = target - Math.PI * 2 * turns;
    const start = performance.now(); let last = -1;
    (function frame(now) {
      const t = Math.min(1, (now - start) / duration);
      const rot = total * (1 - Math.pow(1 - t, 4));
      drawWheel(canvas, labels, rot, opts);
      const p = (((-Math.PI / 2 - rot) % (Math.PI * 2)) + Math.PI * 2) % (Math.PI * 2);
      const s = ang.findIndex(([x, y]) => p >= x && p < y);
      if (s !== last) { last = s; onTick && onTick(); }
      if (t < 1) requestAnimationFrame(frame); else res();
    })(performance.now());
  });
}

// Regalos acumulándose hacia el mínimo (opción "Acumular regalos")
socket.on('stack', s => {
  if (!window.GAME_KEY || s.key !== window.GAME_KEY) return;
  let el = document.querySelector(`.stackpill[data-u="${CSS.escape(s.user.id)}"]`);
  if (!el) { el = document.createElement('div'); el.className = 'stackpill card'; el.dataset.u = s.user.id; document.body.appendChild(el); }
  el.innerHTML = `${esc(s.user.name)} <b>${s.acc}/${s.min} 🪙</b><i style="width:${Math.min(100, s.acc / s.min * 100)}%"></i>`;
  clearTimeout(el._t); el._t = setTimeout(() => el.remove(), 3500);
});

// =====================================================================
// FONDOS DE CASILLA (diseño propio de ChispaLive)
// =====================================================================
const TILES = {
  carbon:  { n: 'Carbón',   bg: 'linear-gradient(145deg,#2b2733,#121017)' },
  oceano:  { n: 'Océano',   bg: 'linear-gradient(145deg,#38bdf8,#1d4ed8)' },
  aurora:  { n: 'Aurora',   bg: 'linear-gradient(145deg,#5eead4,#0f766e)' },
  lima:    { n: 'Lima',     bg: 'linear-gradient(145deg,#d9f99d,#4d7c0f)' },
  fuego:   { n: 'Fuego',    bg: 'linear-gradient(145deg,#fdba74,#dc2626)' },
  chicle:  { n: 'Chicle',   bg: 'linear-gradient(145deg,#f9a8d4,#db2777)' },
  uva:     { n: 'Uva',      bg: 'linear-gradient(145deg,#c4b5fd,#6d28d9)' },
  rubi:    { n: 'Rubí',     bg: 'linear-gradient(145deg,#fb7185,#9f1239)' },
  oro:     { n: 'Oro',      bg: 'linear-gradient(145deg,#fde68a,#d97706)' },
  hielo:   { n: 'Hielo',    bg: 'linear-gradient(145deg,#f0f9ff,#7dd3fc)' },
  galaxia: { n: 'Galaxia',  bg: 'radial-gradient(circle at 30% 25%,#f0abfc 0,#7c3aed 35%,#1e1b4b 75%)' },
  radar:   { n: 'Radar',    bg: 'repeating-radial-gradient(circle at 50% 50%,#2563eb 0 10px,#1e3a8a 10px 20px)' },
  rayas:   { n: 'Rayas',    bg: 'repeating-linear-gradient(135deg,#f43f5e 0 12px,#be123c 12px 24px)' },
  menta:   { n: 'Menta',    bg: 'repeating-linear-gradient(45deg,#34d399 0 10px,#059669 10px 20px)' },
  puntos:  { n: 'Puntos',   bg: 'radial-gradient(#fff3 2px,transparent 3px) 0 0/14px 14px,linear-gradient(145deg,#a855f7,#581c87)' },
  noche:   { n: 'Noche',    bg: 'radial-gradient(#ffffff55 1px,transparent 2px) 0 0/18px 18px,linear-gradient(160deg,#1e293b,#020617)' },
};
const tileBg = id => (TILES[id] || TILES.carbon).bg;

// =====================================================================
// PERSONAJES: avatar generado a partir del nombre (para quien no tiene foto)
// =====================================================================
function _hash(s) { let h = 2166136261; for (const c of String(s || '?')) { h ^= c.charCodeAt(0); h = Math.imul(h, 16777619); } return h >>> 0; }
const FACE_BG = ['#ffd6a5', '#caffbf', '#9bf6ff', '#bdb2ff', '#ffc6ff', '#fdffb6', '#a0c4ff', '#ffadad', '#b9fbc0', '#f1c0e8'];
const FACE_SKIN = ['#8b5a2b', '#f2c49b', '#7cc36a', '#5fb7d4', '#e8e8f0', '#ff9ec7', '#ffcf5a', '#b58df0', '#ff8c5a', '#4b9e8f'];
const _faceCache = {};
function faceSvg(name) {
  if (_faceCache[name]) return _faceCache[name];
  const h = _hash(name), bg = FACE_BG[h % FACE_BG.length], sk = FACE_SKIN[(h >>> 4) % FACE_SKIN.length], type = (h >>> 8) % 6;
  const eyes = (h >>> 12) % 4, mouth = (h >>> 14) % 3, ink = '#1a1426';
  const E = [
    `<circle cx="24" cy="30" r="4" fill="${ink}"/><circle cx="40" cy="30" r="4" fill="${ink}"/><circle cx="25.5" cy="28.5" r="1.4" fill="#fff"/><circle cx="41.5" cy="28.5" r="1.4" fill="#fff"/>`,
    `<path d="M20 30q4-5 8 0M36 30q4-5 8 0" stroke="${ink}" stroke-width="3" fill="none" stroke-linecap="round"/>`,
    `<rect x="17" y="25" width="13" height="9" rx="3" fill="${ink}"/><rect x="34" y="25" width="13" height="9" rx="3" fill="${ink}"/><path d="M30 29h4" stroke="${ink}" stroke-width="2.5"/><rect x="19" y="26.5" width="4" height="2" fill="#fff" opacity=".7"/>`,
    `<path d="M20 27l7 5M27 27l-7 5M37 27l7 5M44 27l-7 5" stroke="${ink}" stroke-width="2.6" stroke-linecap="round"/>`,
  ][eyes];
  const M = [`<path d="M26 40q6 6 12 0" stroke="${ink}" stroke-width="3" fill="none" stroke-linecap="round"/>`,
    `<ellipse cx="32" cy="42" rx="4.5" ry="3.5" fill="${ink}"/><ellipse cx="32" cy="43.5" rx="2.6" ry="1.5" fill="#ff6b8b"/>`,
    `<path d="M25 40h14" stroke="${ink}" stroke-width="3" stroke-linecap="round"/>`][mouth];
  const blush = `<ellipse cx="18" cy="38" rx="4" ry="2.5" fill="#ff6b8b" opacity=".35"/><ellipse cx="46" cy="38" rx="4" ry="2.5" fill="#ff6b8b" opacity=".35"/>`;
  const body = [
    // oso
    `<circle cx="15" cy="17" r="8" fill="${sk}"/><circle cx="49" cy="17" r="8" fill="${sk}"/><circle cx="32" cy="35" r="22" fill="${sk}"/><ellipse cx="32" cy="41" rx="10" ry="7" fill="#fff" opacity=".55"/>`,
    // gato
    `<path d="M11 24L14 6l13 11zM53 24L50 6 37 17z" fill="${sk}"/><circle cx="32" cy="35" r="21" fill="${sk}"/><path d="M12 38h-8M12 42l-7 3M52 38h8M52 42l7 3" stroke="${ink}" stroke-width="1.5"/>`,
    // robot
    `<path d="M32 4v8" stroke="${ink}" stroke-width="3"/><circle cx="32" cy="4" r="3.5" fill="#ff2e7e"/><rect x="11" y="12" width="42" height="42" rx="11" fill="${sk}"/><rect x="5" y="28" width="6" height="12" rx="3" fill="${ink}"/><rect x="53" y="28" width="6" height="12" rx="3" fill="${ink}"/>`,
    // fantasma
    `<path d="M12 56V30a20 20 0 0 1 40 0v26l-6-5-7 5-7-5-7 5-7-5z" fill="${sk}"/>`,
    // slime
    `<path d="M8 54q0-30 24-38q24 8 24 38z" fill="${sk}"/><ellipse cx="22" cy="24" rx="5" ry="3" fill="#fff" opacity=".5"/>`,
    // alien
    `<path d="M32 10l-4-8M32 10l4-8" stroke="${sk}" stroke-width="3"/><ellipse cx="32" cy="34" rx="24" ry="21" fill="${sk}"/>`,
  ][type];
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64" fill="${bg}"/>${body}${blush}${E}${M}</svg>`;
  return (_faceCache[name] = 'data:image/svg+xml;utf8,' + encodeURIComponent(svg));
}
// Desde ahora, quien no tenga foto muestra su personaje
(function () {
  const orig = avatarEl;
  avatarEl = function (user, size = 44) {
    if (user?.avatar) return orig(user, size);
    const el = document.createElement('img'); el.className = 'avatar'; el.src = faceSvg(user?.name || user?.id || '?');
    el.style.width = el.style.height = size + 'px'; return el;
  };
})();

// Vista previa de animación: solo visual, no suma monedas ni regalos
socket.on('preview', d => {
  if (d?.key && d.key !== window.GAME_KEY) return;
  const vis = [...document.querySelectorAll('#stage > *, #wrap, .card')].filter(el => !el.classList.contains('hidden') && el.offsetParent !== null && el.offsetWidth > 20);
  if (vis.length) { const el = vis[0]; el.classList.remove('enter', 'out'); void el.offsetWidth; el.classList.add('enter'); return; }
  const c = document.createElement('div'); c.className = 'card enter';
  c.style.cssText = 'position:fixed;left:0;right:0;top:40%;margin:0 auto;width:fit-content;padding:16px 26px;font-size:24px;font-weight:800;z-index:99';
  c.innerHTML = '✨ <span class="grad-text">Vista previa</span>';
  document.body.appendChild(c);
  setTimeout(() => { c.classList.add('out'); setTimeout(() => c.remove(), 450); }, 1800);
});
// Si el programa se actualizó, los overlays (OBS / LIVE Studio) se recargan solos con lo nuevo
let __ver = null;
socket.on('hello', h => { if (!h?.version) return; if (__ver && __ver !== h.version && window.GAME_KEY !== 'panel') location.reload(); __ver = h.version; });

// ---------- Tienda de diseños: adornos y partículas ----------
let _skinFx = { id: null, raf: 0, cv: null, parts: [] };
function applySkinFx(sk) {
  const root = document.documentElement;
  [...root.classList].filter(c => c.startsWith('skin-')).forEach(c => root.classList.remove(c));
  if (sk && sk.opt.deco !== false) root.classList.add('skin-' + sk.id);
  const want = sk && sk.opt.particles !== false ? sk.fx + '|' + (sk.opt.amount || 'normal') : null;
  if (want === _skinFx.id) return;
  _skinFx.id = want; cancelAnimationFrame(_skinFx.raf); _skinFx.cv?.remove(); _skinFx.cv = null;
  if (!want) return;
  const cv = document.createElement('canvas'); cv.className = 'skin-fx';
  cv.style.cssText = 'position:fixed;inset:0;width:100vw;height:100vh;pointer-events:none;z-index:2147483000';
  document.documentElement.appendChild(cv); _skinFx.cv = cv;
  const x = cv.getContext('2d'), kind = sk.fx;
  const N = { poco: .5, normal: 1, mucho: 2 }[sk.opt.amount] || 1;
  let W = 0, H = 0;
  const size = () => { W = cv.width = innerWidth; H = cv.height = innerHeight; };
  size(); addEventListener('resize', size);
  const base = { snow: 70, bats: 6, sakura: 34, sparkle: 46, hearts: 16 }[kind] || 30;
  const R = (a, b) => a + Math.random() * (b - a);
  const mk = (first) => {
    const p = { x: R(0, W), y: first ? R(0, H) : -30, r: R(0, 1), t: R(0, 6.28), s: R(.5, 1.4) };
    if (kind === 'bats') { p.x = Math.random() < .5 ? -40 : W + 40; p.dir = p.x < 0 ? 1 : -1; p.y = R(H * .05, H * .6); if (first) p.x = R(0, W); }
    if (kind === 'hearts') { p.y = first ? R(0, H) : H + 30; }
    return p;
  };
  _skinFx.parts = Array.from({ length: Math.round(base * N) }, () => mk(true));
  const C = sk.colors;
  let last = performance.now();
  const step = now => {
    const dt = Math.min(50, now - last) / 16.7; last = now;
    x.clearRect(0, 0, W, H);
    _skinFx.parts.forEach((p, i) => {
      p.t += .03 * dt;
      if (kind === 'snow') {
        p.y += (.6 + p.r * 1.4) * dt; p.x += Math.sin(p.t) * .5 * dt;
        x.globalAlpha = .55 + p.r * .4; x.fillStyle = '#fff'; x.beginPath(); x.arc(p.x, p.y, 1.5 + p.r * 2.8, 0, 7); x.fill();
      } else if (kind === 'sakura') {
        p.y += (.5 + p.r) * dt; p.x += (Math.sin(p.t) * .8 + .4) * dt;
        x.save(); x.translate(p.x, p.y); x.rotate(p.t * 1.5); x.scale(1, Math.abs(Math.cos(p.t * 2)) * .7 + .3);
        x.globalAlpha = .8; x.fillStyle = i % 3 ? '#ffb7d5' : '#ffd6e8'; x.beginPath(); x.ellipse(0, 0, 6 + p.r * 4, 3.5 + p.r * 2, 0, 0, 7); x.fill(); x.restore();
      } else if (kind === 'sparkle') {
        p.y += (.3 + p.r * .8) * dt; const a = .35 + .65 * Math.abs(Math.sin(p.t * 2));
        x.globalAlpha = a; x.fillStyle = i % 4 ? C.primary : '#fff'; const s = 2 + p.r * 4;
        x.beginPath(); x.moveTo(p.x, p.y - s * 2); x.lineTo(p.x + s * .5, p.y - s * .5); x.lineTo(p.x + s * 2, p.y); x.lineTo(p.x + s * .5, p.y + s * .5); x.lineTo(p.x, p.y + s * 2); x.lineTo(p.x - s * .5, p.y + s * .5); x.lineTo(p.x - s * 2, p.y); x.lineTo(p.x - s * .5, p.y - s * .5); x.fill();
      } else if (kind === 'hearts') {
        p.y -= (.5 + p.r) * dt; p.x += Math.sin(p.t) * .6 * dt;
        x.globalAlpha = .45 + p.r * .4; x.font = `${16 + p.r * 18}px serif`; x.fillText(i % 3 ? '💗' : '❤️', p.x, p.y);
      } else if (kind === 'bats') {
        p.x += p.dir * (1.2 + p.r * 1.3) * dt; p.y += Math.sin(p.t * 2) * 1.2 * dt;
        x.globalAlpha = .85; x.font = `${22 + p.r * 18}px serif`;
        x.save(); x.translate(p.x, p.y); x.scale(p.dir > 0 ? -1 : 1, .8 + Math.abs(Math.sin(p.t * 6)) * .3); x.fillText('🦇', 0, 0); x.restore();
      }
      const out = kind === 'bats' ? (p.x < -60 || p.x > W + 60) : kind === 'hearts' ? p.y < -40 : p.y > H + 30;
      if (out) _skinFx.parts[i] = mk(false);
    });
    x.globalAlpha = 1;
    _skinFx.raf = requestAnimationFrame(step);
  };
  _skinFx.raf = requestAnimationFrame(step);
}
