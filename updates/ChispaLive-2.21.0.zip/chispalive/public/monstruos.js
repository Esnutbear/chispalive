// ChispaLive — Monstruos para "Derrota al jefe" (dibujos propios en SVG)
// Cada monstruo tiene 3 caras: normal (0), enojado (1) y furioso (2).
(function () {
  const OUT = '#2a0f2f';
  const eyeC = r => r >= 2 ? '#ff2a2a' : r >= 1 ? '#ff8a1f' : '#ffd23f';
  const grad = (id, a, b) => `<linearGradient id="${id}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${a}"/><stop offset="1" stop-color="${b}"/></linearGradient>`;
  const brows = (r, y = 92, lx = 70, rx = 190) => r ? `<path d="M${lx} ${y} L${lx + 38} ${y + 12} M${rx} ${y} L${rx - 38} ${y + 12}" stroke="${OUT}" stroke-width="10" stroke-linecap="round"/>` : '';
  const shine = '<circle cx="58" cy="160" r="9" fill="rgba(255,255,255,.15)"/><circle cx="206" cy="78" r="6" fill="rgba(255,255,255,.18)"/>';
  const uid = () => 'm' + Math.random().toString(36).slice(2, 8);

  const M = {
    golem: { name: 'Rey Gólem', emoji: '👹', draw(r) {
      const g = uid();
      return `<defs>${grad(g, r >= 2 ? '#a3243b' : '#7c3aed', r >= 2 ? '#4c0d1e' : '#3b1673')}</defs>
      <path d="M60 60 L44 14 L92 46 Z M200 60 L216 14 L168 46 Z" fill="#ffd23f" stroke="${OUT}" stroke-width="5" stroke-linejoin="round"/>
      <path d="M30 150 C24 80 70 40 130 40 C190 40 236 80 230 150 C226 196 190 220 130 220 C70 220 34 196 30 150 Z" fill="url(#${g})" stroke="${OUT}" stroke-width="6"/>
      <path d="M30 150 C10 150 6 120 22 104 M230 150 C250 150 254 120 238 104" stroke="${OUT}" stroke-width="12" stroke-linecap="round" fill="none"/>
      <ellipse cx="92" cy="118" rx="24" ry="${r ? 18 : 24}" fill="#fff"/><ellipse cx="168" cy="118" rx="24" ry="${r ? 18 : 24}" fill="#fff"/>
      <circle cx="96" cy="122" r="11" fill="${eyeC(r)}"/><circle cx="164" cy="122" r="11" fill="${eyeC(r)}"/><circle cx="99" cy="118" r="4" fill="#fff"/><circle cx="167" cy="118" r="4" fill="#fff"/>
      ${brows(r)}<path d="M84 170 Q130 ${r ? 150 : 196} 176 170 Z" fill="${OUT}"/><path d="M98 172 L104 184 L110 172 M150 172 L156 184 L162 172" fill="#fff"/>${shine}`; } },

    dragon: { name: 'Dragón de Fuego', emoji: '🐉', draw(r) {
      const g = uid(), s = uid();
      const body = r >= 2 ? ['#ef4444', '#7f1d1d'] : ['#34d399', '#065f46'];
      return `<defs>${grad(g, body[0], body[1])}${grad(s, r >= 2 ? '#fecaca' : '#d1fae5', r >= 2 ? '#f87171' : '#6ee7b7')}</defs>
      <path d="M62 112 L6 58 L24 112 L0 124 L36 140 L14 160 L64 156 Z" fill="${r >= 2 ? '#991b1b' : '#047857'}" stroke="${OUT}" stroke-width="5" stroke-linejoin="round"/>
      <path d="M198 112 L254 58 L236 112 L260 124 L224 140 L246 160 L196 156 Z" fill="${r >= 2 ? '#991b1b' : '#047857'}" stroke="${OUT}" stroke-width="5" stroke-linejoin="round"/>
      <path d="M86 62 C70 30 74 12 96 6 C88 26 98 42 108 54 Z M174 62 C190 30 186 12 164 6 C172 26 162 42 152 54 Z" fill="#fde68a" stroke="${OUT}" stroke-width="5" stroke-linejoin="round"/>
      <path d="M112 44 L120 28 L128 44 M132 44 L140 28 L148 44" fill="${body[1]}" stroke="${OUT}" stroke-width="4" stroke-linejoin="round"/>
      <ellipse cx="130" cy="120" rx="86" ry="74" fill="url(#${g})" stroke="${OUT}" stroke-width="6"/>
      <ellipse cx="130" cy="172" rx="58" ry="38" fill="url(#${s})" stroke="${OUT}" stroke-width="5"/>
      <ellipse cx="112" cy="160" rx="6" ry="4" fill="${OUT}"/><ellipse cx="148" cy="160" rx="6" ry="4" fill="${OUT}"/>
      <path d="M90 184 Q130 ${r ? 200 : 210} 170 184" stroke="${OUT}" stroke-width="6" fill="none" stroke-linecap="round"/>
      <path d="M100 187 L106 197 L112 189 M148 189 L154 197 L160 187" fill="#fff" stroke="${OUT}" stroke-width="2"/>
      <ellipse cx="96" cy="108" rx="20" ry="${r ? 14 : 19}" fill="#fff" stroke="${OUT}" stroke-width="3"/><ellipse cx="164" cy="108" rx="20" ry="${r ? 14 : 19}" fill="#fff" stroke="${OUT}" stroke-width="3"/>
      <ellipse cx="98" cy="110" rx="6" ry="${r ? 10 : 14}" fill="${eyeC(r)}"/><ellipse cx="162" cy="110" rx="6" ry="${r ? 10 : 14}" fill="${eyeC(r)}"/>
      <rect x="96" y="102" width="4" height="16" rx="2" fill="${OUT}"/><rect x="160" y="102" width="4" height="16" rx="2" fill="${OUT}"/>
      ${brows(r, 82, 72, 188)}
      ${r >= 2 ? `<path d="M118 206 Q130 232 142 206 Q138 222 130 226 Q122 222 118 206 Z" fill="#ff8a1f"/><path d="M124 208 Q130 222 136 208 Z" fill="#ffd23f"/>` : ''}
      <circle cx="70" cy="96" r="7" fill="rgba(255,255,255,.18)"/>`; } },

    skull: { name: 'Rey Calavera', emoji: '💀', draw(r) {
      const g = uid();
      return `<defs>${grad(g, r >= 2 ? '#fecaca' : '#f8fafc', r >= 2 ? '#b91c1c' : '#94a3b8')}</defs>
      <path d="M82 46 L90 14 L108 36 L130 8 L152 36 L170 14 L178 46 Z" fill="#ffd23f" stroke="${OUT}" stroke-width="5" stroke-linejoin="round"/>
      <circle cx="108" cy="34" r="4" fill="#ef4444"/><circle cx="130" cy="22" r="5" fill="#22d3ee"/><circle cx="152" cy="34" r="4" fill="#a855f7"/>
      <path d="M44 120 C44 70 82 44 130 44 C178 44 216 70 216 120 C216 150 202 166 190 172 L190 196 L70 196 L70 172 C58 166 44 150 44 120 Z" fill="url(#${g})" stroke="${OUT}" stroke-width="6" stroke-linejoin="round"/>
      <rect x="78" y="186" width="104" height="34" rx="10" fill="url(#${g})" stroke="${OUT}" stroke-width="6"/>
      <path d="M98 186 V220 M116 186 V220 M134 186 V220 M152 186 V220 M168 186 V220" stroke="${OUT}" stroke-width="4"/>
      <path d="M68 116 C68 94 86 86 104 92 C118 98 120 118 110 132 C98 146 70 142 68 116 Z" fill="${OUT}"/>
      <path d="M192 116 C192 94 174 86 156 92 C142 98 140 118 150 132 C162 146 190 142 192 116 Z" fill="${OUT}"/>
      <circle cx="92" cy="116" r="${r ? 9 : 7}" fill="${eyeC(r)}"/><circle cx="168" cy="116" r="${r ? 9 : 7}" fill="${eyeC(r)}"/>
      ${r ? `<circle cx="92" cy="116" r="16" fill="${eyeC(r)}" opacity=".25"/><circle cx="168" cy="116" r="16" fill="${eyeC(r)}" opacity=".25"/>` : ''}
      <path d="M130 140 L120 162 L140 162 Z" fill="${OUT}"/>
      <path d="M176 60 L166 78 L172 86" stroke="${OUT}" stroke-width="3" fill="none" opacity=".6"/>
      ${r >= 2 ? `<path d="M64 80 L80 92 M196 80 L180 92" stroke="${OUT}" stroke-width="8" stroke-linecap="round"/>` : ''}`; } },

    slime: { name: 'Slime Gigante', emoji: '🟢', draw(r) {
      const g = uid();
      const c = r >= 2 ? ['#f472b6', '#9d174d'] : r >= 1 ? ['#a3e635', '#3f6212'] : ['#4ade80', '#15803d'];
      return `<defs>${grad(g, c[0], c[1])}</defs>
      <path d="M26 196 C20 120 64 52 130 52 C196 52 240 120 234 196 C234 210 222 216 214 206 C206 222 192 222 186 208 C176 226 160 222 156 210 C144 226 120 226 108 210 C100 224 84 224 76 208 C68 222 50 220 46 206 C38 216 26 210 26 196 Z" fill="url(#${g})" stroke="${OUT}" stroke-width="6" stroke-linejoin="round"/>
      <path d="M70 92 C84 72 104 64 122 64" stroke="rgba(255,255,255,.55)" stroke-width="10" fill="none" stroke-linecap="round"/>
      <circle cx="62" cy="120" r="7" fill="rgba(255,255,255,.4)"/>
      <ellipse cx="98" cy="126" rx="22" ry="${r ? 17 : 24}" fill="#fff" stroke="${OUT}" stroke-width="4"/><ellipse cx="162" cy="126" rx="22" ry="${r ? 17 : 24}" fill="#fff" stroke="${OUT}" stroke-width="4"/>
      <circle cx="102" cy="130" r="10" fill="${r ? eyeC(r) : OUT}"/><circle cx="158" cy="130" r="10" fill="${r ? eyeC(r) : OUT}"/><circle cx="105" cy="125" r="4" fill="#fff"/><circle cx="161" cy="125" r="4" fill="#fff"/>
      ${brows(r, 98, 76, 184)}
      ${r ? `<path d="M100 178 Q130 160 160 178" stroke="${OUT}" stroke-width="7" fill="none" stroke-linecap="round"/>` : `<path d="M104 166 Q130 190 156 166" stroke="${OUT}" stroke-width="7" fill="none" stroke-linecap="round"/>`}
      <circle cx="196" cy="160" r="6" fill="rgba(0,0,0,.18)"/><circle cx="76" cy="176" r="5" fill="rgba(0,0,0,.18)"/>`; } },

    kraken: { name: 'Kraken', emoji: '🐙', draw(r) {
      const g = uid();
      const c = r >= 2 ? ['#fb7185', '#881337'] : ['#c084fc', '#6b21a8'];
      const t = (d) => `<path d="${d}" fill="none" stroke="${OUT}" stroke-width="20" stroke-linecap="round"/><path d="${d}" fill="none" stroke="${c[1]}" stroke-width="12" stroke-linecap="round"/>`;
      return `<defs>${grad(g, c[0], c[1])}</defs>
      ${t('M64 160 C36 176 30 204 52 214 C66 220 70 204 60 198')}${t('M196 160 C224 176 230 204 208 214 C194 220 190 204 200 198')}
      ${t('M96 176 C88 204 96 222 112 224')}${t('M164 176 C172 204 164 222 148 224')}${t('M130 180 C126 206 136 220 130 228')}
      <path d="M40 120 C40 64 80 30 130 30 C180 30 220 64 220 120 C220 160 184 184 130 184 C76 184 40 160 40 120 Z" fill="url(#${g})" stroke="${OUT}" stroke-width="6"/>
      <circle cx="84" cy="70" r="7" fill="rgba(255,255,255,.25)"/><circle cx="178" cy="62" r="5" fill="rgba(255,255,255,.25)"/><circle cx="196" cy="96" r="6" fill="rgba(0,0,0,.15)"/>
      <ellipse cx="96" cy="114" rx="26" ry="${r ? 18 : 26}" fill="#fff" stroke="${OUT}" stroke-width="4"/><ellipse cx="164" cy="114" rx="26" ry="${r ? 18 : 26}" fill="#fff" stroke="${OUT}" stroke-width="4"/>
      <rect x="84" y="${r ? 108 : 106}" width="24" height="${r ? 10 : 14}" rx="5" fill="${eyeC(r)}"/><rect x="152" y="${r ? 108 : 106}" width="24" height="${r ? 10 : 14}" rx="5" fill="${eyeC(r)}"/>
      ${brows(r, 82, 68, 192)}
      <ellipse cx="130" cy="156" rx="${r ? 14 : 10}" ry="${r ? 10 : 8}" fill="${OUT}"/>`; } },

    robot: { name: 'Mecha X-9', emoji: '🤖', draw(r) {
      const g = uid(), v = uid();
      const vis = r >= 2 ? '#ff2a2a' : r >= 1 ? '#ff8a1f' : '#22d3ee';
      return `<defs>${grad(g, r >= 2 ? '#fca5a5' : '#cbd5e1', r >= 2 ? '#7f1d1d' : '#475569')}${grad(v, '#0f172a', '#1e293b')}</defs>
      <line x1="130" y1="44" x2="130" y2="16" stroke="${OUT}" stroke-width="6"/><circle cx="130" cy="14" r="10" fill="${vis}" stroke="${OUT}" stroke-width="4"/>
      <rect x="20" y="96" width="24" height="56" rx="8" fill="#64748b" stroke="${OUT}" stroke-width="5"/><rect x="216" y="96" width="24" height="56" rx="8" fill="#64748b" stroke="${OUT}" stroke-width="5"/>
      <rect x="40" y="44" width="180" height="168" rx="30" fill="url(#${g})" stroke="${OUT}" stroke-width="6"/>
      <rect x="60" y="80" width="140" height="62" rx="18" fill="url(#${v})" stroke="${OUT}" stroke-width="5"/>
      ${r ? `<path d="M74 ${r >= 2 ? 98 : 104} L118 116 L118 126 L74 126 Z M186 ${r >= 2 ? 98 : 104} L142 116 L142 126 L186 126 Z" fill="${vis}"/>` : `<rect x="76" y="100" width="40" height="22" rx="8" fill="${vis}"/><rect x="144" y="100" width="40" height="22" rx="8" fill="${vis}"/>`}
      <rect x="80" y="104" width="12" height="6" rx="3" fill="rgba(255,255,255,.7)"/><rect x="148" y="104" width="12" height="6" rx="3" fill="rgba(255,255,255,.7)"/>
      <rect x="84" y="160" width="92" height="30" rx="8" fill="${OUT}"/>
      <path d="M100 164 V186 M115 164 V186 M130 164 V186 M145 164 V186 M160 164 V186" stroke="${r >= 2 ? '#ff2a2a' : '#94a3b8'}" stroke-width="4"/>
      <circle cx="56" cy="60" r="5" fill="${OUT}"/><circle cx="204" cy="60" r="5" fill="${OUT}"/><circle cx="56" cy="196" r="5" fill="${OUT}"/><circle cx="204" cy="196" r="5" fill="${OUT}"/>
      ${r >= 2 ? '<path d="M206 38 C214 26 206 18 214 8 M224 46 C234 36 226 26 236 18" stroke="rgba(255,255,255,.6)" stroke-width="5" fill="none" stroke-linecap="round"/>' : ''}`; } },

    ghost: { name: 'Fantasmón', emoji: '👻', draw(r) {
      const g = uid();
      const c = r >= 2 ? ['#c4b5fd', '#4c1d95'] : ['#f8fafc', '#a5b4fc'];
      return `<defs>${grad(g, c[0], c[1])}</defs>
      <path d="M40 120 C40 64 80 26 130 26 C180 26 220 64 220 120 L220 206 C208 222 196 196 184 210 C172 224 160 196 148 212 C136 226 124 196 112 212 C100 226 88 198 76 212 C64 224 52 200 40 210 Z" fill="url(#${g})" stroke="${OUT}" stroke-width="6" stroke-linejoin="round"/>
      <path d="M40 140 C18 136 14 112 26 100 M220 140 C242 136 246 112 234 100" stroke="${OUT}" stroke-width="10" stroke-linecap="round" fill="none"/>
      <ellipse cx="96" cy="110" rx="20" ry="${r ? 20 : 28}" fill="${OUT}"/><ellipse cx="164" cy="110" rx="20" ry="${r ? 20 : 28}" fill="${OUT}"/>
      <circle cx="98" cy="${r ? 112 : 104}" r="${r ? 8 : 6}" fill="${r ? eyeC(r) : '#fff'}"/><circle cx="166" cy="${r ? 112 : 104}" r="${r ? 8 : 6}" fill="${r ? eyeC(r) : '#fff'}"/>
      ${brows(r, 80, 72, 188)}
      <ellipse cx="130" cy="164" rx="${r ? 26 : 16}" ry="${r ? 20 : 22}" fill="${OUT}"/>
      ${r ? '<path d="M110 156 L116 166 L122 156 M138 156 L144 166 L150 156" fill="#fff"/>' : ''}
      <circle cx="70" cy="70" r="8" fill="rgba(255,255,255,.5)"/><circle cx="186" cy="176" r="6" fill="rgba(0,0,0,.08)"/>`; } },
  };
  const ORDER = ['golem', 'dragon', 'skull', 'slime', 'kraken', 'robot', 'ghost'];
  // Qué monstruo toca en un nivel ("auto" = uno distinto en cada nivel)
  const pick = (model, level = 1) => model === 'auto' ? ORDER[(Math.max(1, level) - 1) % ORDER.length] : (M[model] ? model : 'golem');
  const svg = (id, rage = 0) => `<svg viewBox="0 0 260 230" xmlns="http://www.w3.org/2000/svg">${(M[id] || M.golem).draw(rage)}</svg>`;
  window.MONSTRUOS = { list: M, ORDER, pick, svg };
})();
