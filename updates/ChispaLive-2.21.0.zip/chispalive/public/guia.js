// ===== Guía de bienvenida (tour paso a paso para clientes nuevos) =====
(function () {
  const STEPS = [
    { t: null, icon: '👋', title: '¡Bienvenido a ChispaLive!',
      body: 'Te enseño lo básico en menos de un minuto: cómo conectar tu live, elegir un juego y ponerlo en OBS. Puedes saltarla y volver a verla cuando quieras desde el botón ❓ de arriba.' },
    { t: '.top .conn', icon: '🔌', title: 'Conecta tu TikTok',
      body: 'Escribe tu usuario de TikTok (sin la @) y dale <b>Conectar</b>. Si todavía no estás en vivo, no pasa nada: ChispaLive se conecta solo apenas empieces.' },
    { t: '.nav[data-s="licencia"]', icon: '💎', title: 'Tu licencia',
      body: 'Empiezas con días de prueba gratis. Cuando compres, aquí pegas tu clave y listo.' },
    { t: '#nav-Juegos', icon: '🎮', title: 'Elige un juego',
      body: 'Aquí están todos los juegos: ruletas, subasta, batallas, carrera, jefe, trivia… Entra a uno, actívalo y ajústalo a tu gusto (regalos, tiempos, sonidos).' },
    { t: '.nav[data-s="overlays"]', icon: '🖥️', title: 'Ponlo en OBS',
      body: 'Cada juego tiene su link. Cópialo y en OBS o TikTok LIVE Studio agrega una <b>Fuente de navegador</b> y pégalo. Así tus viewers ven el juego en el live.' },
    { t: '.nav[data-s="sim"]', icon: '⚡', title: 'Prueba sin estar en vivo',
      body: 'Con el Simulador mandas regalos, likes y comentarios de mentira para ver cómo reacciona todo antes de salir en vivo.' },
    { t: '.nav[data-s="celular"]', icon: '📱', title: 'Contrólalo desde tu celular',
      body: 'Escanea el QR y manejas los juegos desde el celu mientras estás en cámara. Solo funciona en tu mismo WiFi.' },
    { t: null, icon: '🚀', title: '¡Listo para tu primer live!',
      body: 'Si algo no te sale o tienes una idea, escríbenos en Discord y te ayudamos.', end: true },
  ];
  const EN = {"¡Bienvenido a ChispaLive!": "Welcome to ChispaLive!", "Te enseño lo básico en menos de un minuto: cómo conectar tu live, elegir un juego y ponerlo en OBS. Puedes saltarla y volver a verla cuando quieras desde el botón ❓ de arriba.": "Here are the basics in under a minute: how to connect your live, pick a game and put it on OBS. You can skip this and open it again anytime from the ❓ button up top.", "Conecta tu TikTok": "Connect your TikTok", "Escribe tu usuario de TikTok (sin la @) y dale <b>Conectar</b>. Si todavía no estás en vivo, no pasa nada: ChispaLive se conecta solo apenas empieces.": "Type your TikTok username (without the @) and hit <b>Connect</b>. If you are not live yet, no worries: ChispaLive connects by itself as soon as you start.", "Tu licencia": "Your license", "Empiezas con días de prueba gratis. Cuando compres, aquí pegas tu clave y listo.": "You start with free trial days. When you buy, paste your key here and you are set.", "Elige un juego": "Pick a game", "Aquí están todos los juegos: ruletas, subasta, batallas, carrera, jefe, trivia… Entra a uno, actívalo y ajústalo a tu gusto (regalos, tiempos, sonidos).": "All the games are here: wheels, auction, battles, race, boss, trivia… Open one, turn it on and tweak it your way (gifts, timers, sounds).", "Ponlo en OBS": "Put it on OBS", "Cada juego tiene su link. Cópialo y en OBS o TikTok LIVE Studio agrega una <b>Fuente de navegador</b> y pégalo. Así tus viewers ven el juego en el live.": "Each game has its own link. Copy it, and in OBS or TikTok LIVE Studio add a <b>Browser source</b> and paste it. That way your viewers see the game on your live.", "Prueba sin estar en vivo": "Test without going live", "Con el Simulador mandas regalos, likes y comentarios de mentira para ver cómo reacciona todo antes de salir en vivo.": "With the Simulator you send fake gifts, likes and comments to see how everything reacts before you go live.", "Contrólalo desde tu celular": "Control it from your phone", "Escanea el QR y manejas los juegos desde el celu mientras estás en cámara. Solo funciona en tu mismo WiFi.": "Scan the QR code and run the games from your phone while you are on camera. It only works on your same WiFi.", "¡Listo para tu primer live!": "Ready for your first live!", "Si algo no te sale o tienes una idea, escríbenos en Discord y te ayudamos.": "If something does not work or you have an idea, message us on Discord and we will help.", "Saltar": "Skip", "← Atrás": "← Back", "Empezar →": "Start →", "Siguiente →": "Next →", "🔌 Ir a conectar": "🔌 Go connect", "Guía rápida": "Quick guide"};
  const L = x => document.documentElement.lang === 'en' ? (EN[x] || x) : x;
  const DISCORD = 'https://discord.gg/xwXS5TdtEY';
  let i = 0, open = false, target = null;

  const css = document.createElement('style');
  css.textContent = `
  .g-shade { position: fixed; inset: 0; z-index: 80; background: rgba(5,3,12,.72); backdrop-filter: blur(2px); }
  .g-shade.hole { background: transparent; backdrop-filter: none; }
  .g-spot { position: fixed; z-index: 81; border-radius: 14px; pointer-events: none; box-shadow: 0 0 0 9999px rgba(5,3,12,.72), 0 0 0 3px var(--c1, #ff6a2b), 0 0 30px 6px rgba(255,106,43,.55); transition: all .35s cubic-bezier(.2,.8,.2,1); }
  .g-card { position: fixed; z-index: 82; width: min(380px, calc(100vw - 28px)); padding: 20px 20px 16px; border-radius: 20px; background: linear-gradient(180deg, #1d1633, #110d1f); border: 1px solid rgba(255,255,255,.14); box-shadow: 0 24px 70px rgba(0,0,0,.65); transition: top .35s, left .35s; animation: gIn .3s ease; }
  .g-card.center { left: 50% !important; top: 50% !important; transform: translate(-50%, -50%); width: min(460px, calc(100vw - 28px)); text-align: center; padding: 28px 26px 20px; }
  .g-card .g-ic { font-size: 30px; line-height: 1; }
  .g-card.center .g-ic { font-size: 0; }
  .g-card .g-bear { display: none; width: 92px; height: 92px; margin: -6px auto 6px; filter: drop-shadow(0 8px 20px rgba(255,106,43,.45)); }
  .g-card.center .g-bear { display: block; }
  .g-card h3 { margin: 8px 0 6px; font-size: 20px; font-family: var(--display, inherit); }
  .g-card.center h3 { font-size: 26px; }
  .g-card p { margin: 0; color: rgba(255,255,255,.78); line-height: 1.5; font-size: 14.5px; }
  .g-foot { display: flex; align-items: center; gap: 8px; margin-top: 18px; }
  .g-card.center .g-foot { justify-content: center; flex-wrap: wrap; }
  .g-dots { display: flex; gap: 5px; margin-right: auto; }
  .g-card.center .g-dots { width: 100%; justify-content: center; margin: 0 0 6px; order: -1; }
  .g-dots i { width: 7px; height: 7px; border-radius: 9px; background: rgba(255,255,255,.2); transition: all .25s; }
  .g-dots i.on { width: 20px; background: linear-gradient(90deg, var(--c1, #ff6a2b), var(--c2, #ff2e7e)); }
  .g-skip { background: none; border: 0; color: rgba(255,255,255,.5); cursor: pointer; font: inherit; font-size: 13px; padding: 6px; }
  .g-skip:hover { color: #fff; }
  .g-arrow { position: absolute; width: 14px; height: 14px; background: #1d1633; border-left: 1px solid rgba(255,255,255,.14); border-top: 1px solid rgba(255,255,255,.14); }
  .g-card.center .g-arrow { display: none; }
  .g-help { width: 38px; height: 38px; border-radius: 12px; border: 1px solid rgba(255,255,255,.12); background: rgba(255,255,255,.05); color: #fff; font-size: 17px; cursor: pointer; }
  .g-help:hover { background: rgba(255,255,255,.12); }
  @keyframes gIn { from { opacity: 0; transform: translateY(8px) } }
  .g-card.center { animation: gInC .35s ease; }
  @keyframes gInC { from { opacity: 0; transform: translate(-50%, -46%) scale(.96) } }`;
  document.head.appendChild(css);

  const shade = document.createElement('div'); shade.className = 'g-shade'; shade.hidden = true;
  const spot = document.createElement('div'); spot.className = 'g-spot'; spot.hidden = true;
  const card = document.createElement('div'); card.className = 'g-card'; card.hidden = true;
  card.setAttribute('role', 'dialog'); card.setAttribute('aria-modal', 'true');
  document.body.append(shade, spot, card);

  // botón ❓ arriba para volver a verla
  const help = document.createElement('button'); help.className = 'g-help'; help.title = 'Guía rápida'; help.setAttribute('aria-label', 'Guía rápida'); help.textContent = '❓';
  help.onclick = () => start(0);
  document.getElementById('langSw')?.after(help);

  function visible(el) { if (!el) return false; const r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; }

  function show() {
    const s = STEPS[i];
    target = s.t ? document.querySelector(s.t) : null;
    if (target && !visible(target)) target = null;
    const center = !target;
    card.className = 'g-card' + (center ? ' center' : ''); card.setAttribute('data-noi18n', '');
    card.innerHTML = `<img class="g-bear" src="/brand/oso.svg" alt=""><div class="g-ic">${s.icon}</div><h3>${L(s.title)}</h3><p>${L(s.body)}</p>
      <div class="g-foot"><div class="g-dots">${STEPS.map((_, k) => `<i class="${k === i ? 'on' : ''}"></i>`).join('')}</div>
      ${s.end
        ? `<a class="btn sm" href="${DISCORD}" target="_blank" rel="noopener">💬 Discord</a><button class="btn sm pri" data-g="done">${L('🔌 Ir a conectar')}</button>`
        : `${i === 0 ? `<button class="g-skip" data-g="skip">${L('Saltar')}</button>` : `<button class="btn sm" data-g="prev">${L('← Atrás')}</button>`}<button class="btn sm pri" data-g="next">${L(i === 0 ? 'Empezar →' : 'Siguiente →')}</button>`}
      </div>${i > 0 && !s.end ? '<button class="g-skip" data-g="skip" style="position:absolute;top:10px;right:10px">✕</button>' : ''}<span class="g-arrow"></span>`;
    shade.hidden = false; shade.classList.toggle('hole', !center); card.hidden = false;
    spot.hidden = center;
    card.querySelectorAll('[data-g]').forEach(b => b.onclick = () => act(b.dataset.g));
    if (target) { target.scrollIntoView({ block: 'nearest', behavior: 'instant' }); }
    place();
    card.querySelector('[data-g=next],[data-g=done]')?.focus({ preventScroll: true });
  }

  function place() {
    if (!open || !target) return;
    const r = target.getBoundingClientRect(), pad = 6;
    const sr = { x: r.left - pad, y: r.top - pad, w: r.width + pad * 2, h: Math.min(r.height + pad * 2, innerHeight - 20) };
    Object.assign(spot.style, { left: sr.x + 'px', top: sr.y + 'px', width: sr.w + 'px', height: sr.h + 'px' });
    const cw = card.offsetWidth, ch = card.offsetHeight, gap = 18, vw = innerWidth, vh = innerHeight;
    const ar = card.querySelector('.g-arrow');
    let left, top, side;
    if (sr.x + sr.w + gap + cw < vw - 10) { side = 'right'; left = sr.x + sr.w + gap; top = sr.y + Math.min(sr.h, 60) / 2 - 34; }
    else { side = 'below'; left = Math.min(Math.max(10, sr.x), vw - cw - 10); top = sr.y + sr.h + gap; }
    top = Math.max(10, Math.min(top, vh - ch - 10));
    card.style.left = left + 'px'; card.style.top = top + 'px'; card.style.transform = '';
    if (ar) {
      if (side === 'right') Object.assign(ar.style, { left: '-8px', top: Math.max(16, Math.min(ch - 30, sr.y + Math.min(sr.h, 60) / 2 - top - 7)) + 'px', transform: 'rotate(-45deg)' });
      else Object.assign(ar.style, { top: '-8px', left: Math.max(16, Math.min(cw - 30, sr.x + 24 - left)) + 'px', transform: 'rotate(45deg)' });
    }
  }

  function act(a) {
    if (a === 'next') { i = Math.min(STEPS.length - 1, i + 1); show(); }
    else if (a === 'prev') { i = Math.max(0, i - 1); show(); }
    else if (a === 'skip') finish();
    else if (a === 'done') { finish(); if (typeof go === 'function') go('inicio'); setTimeout(() => document.getElementById('user')?.focus(), 50); }
  }

  function start(n) { i = n || 0; open = true; if (typeof go === 'function') go('inicio'); show(); }
  function finish() {
    open = false; shade.hidden = spot.hidden = card.hidden = true;
    try { localStorage.setItem('chispa.guia', '1'); } catch {}
    if (typeof socket !== 'undefined' && !window.cfg?.guideDone) socket.emit('saveConfig', { guideDone: true });
  }

  addEventListener('resize', place);
  document.querySelector('main')?.addEventListener('scroll', place, { passive: true });
  addEventListener('keydown', e => {
    if (!open) return;
    if (e.key === 'Escape') finish();
    else if (e.key === 'ArrowRight' || e.key === 'Enter') { e.preventDefault(); STEPS[i].end ? act('done') : act('next'); }
    else if (e.key === 'ArrowLeft' && i > 0) act('prev');
  });

  // Sale sola la primera vez: cliente nuevo (sin usuario guardado) que nunca la vio
  let decided = false;
  function maybe() {
    if (decided || !window.cfg?.brand) return; decided = true;
    let seen = false; try { seen = localStorage.getItem('chispa.guia') === '1'; } catch {}
    if (!cfg.guideDone && !cfg.username && !seen && !new URLSearchParams(location.search).has('noguia')) setTimeout(() => start(0), 600);
  }
  const iv = setInterval(() => { if (window.cfg?.brand) { clearInterval(iv); maybe(); } }, 200);
  setTimeout(() => clearInterval(iv), 15000);
  window.ChispaGuia = { start, finish };
})();
