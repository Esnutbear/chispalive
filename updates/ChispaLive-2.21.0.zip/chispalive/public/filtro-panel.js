// ===== Filtro del chat — página del panel =====
(function () {
  const sec = document.createElement('section'); sec.className = 'sec'; sec.id = 's-filtro';
  sec.innerHTML = `
  <div class="vz-head panel">
    <div class="vz-mascot rbx-logo">🛡️</div>
    <div class="vz-ttl"><h1 class="display">Filtro del chat</h1><p class="hint">Si alguien escribe una grosería, no sale en pantalla, no la lee la voz y no dispara Acciones. Tú la ves aquí en el panel, tachada y tapada.</p></div>
    <label class="vz-power"><input type="checkbox" data-k="on"><span class="vz-pw"><i></i></span><b data-r="pwlab">Apagado</b></label>
  </div>
  <div class="fl-grid">
    <div class="panel">
      <h2>⚙️ Qué hacer</h2>
      <div class="chips2 fl-act" data-r="act"><button data-v="hide">🚫 Ocultar el mensaje</button><button data-v="mask">✳️ Taparla con ****</button></div>
      <label class="tg"><input type="checkbox" data-k="useDefault"><span><b>Usar la lista de groserías incluida</b><small>Más de 80 palabras en español e inglés. Las detecta aunque escriban p.u.t.a, puuuta o con números.</small></span></label>
      <label class="tg"><input type="checkbox" data-k="links"><span><b>Quitar links</b><small>Cambia los links por 🔗 (para que no hagan spam).</small></span></label>
      <label class="tg"><input type="checkbox" data-k="names"><span><b>Revisar también los nombres</b><small>Si el nombre del usuario tiene una grosería, sale tapado en todas las alertas.</small></span></label>
      <h2 style="margin-top:16px">🧪 Pruébalo</h2>
      <div class="row" style="gap:8px;margin:0"><input class="i" data-r="tin" placeholder="Escribe un mensaje de prueba" style="flex:1"><button class="btn pri" data-r="tbtn">Probar</button></div>
      <div class="fl-res" data-r="tres"></div>
    </div>
    <div class="panel">
      <h2>✍️ Tus listas</h2>
      <label class="f">Palabras prohibidas extra<textarea class="i" rows="3" data-l="words" placeholder="Una por línea o separadas por coma"></textarea></label>
      <label class="f">Palabras permitidas<textarea class="i" rows="2" data-l="allow" placeholder="Si la lista incluida bloquea algo que en tu live es normal (ej: perra si hablas de tu perrita)"></textarea></label>
      <label class="f">Usuarios silenciados<textarea class="i" rows="2" data-l="users" placeholder="@usuario — nada de lo que escriban sale en pantalla"></textarea></label>
      <h2 style="margin-top:16px">🚫 Últimos ocultos</h2>
      <div class="fl-last" data-r="last"><p class="hint">Todavía nada. Aquí verás lo que el filtro va ocultando en tu live.</p></div>
    </div>
  </div>`;
  document.getElementById('studios').after(sec);
  const $ = q => sec.querySelector(q);
  const C = () => ({ on: true, useDefault: true, words: [], allow: [], action: 'hide', links: true, names: true, users: [], ...(window.cfg?.filtro || {}) });
  const save = patch => { window.cfg.filtro = { ...C(), ...patch }; socket.emit('saveConfig', { filtro: patch }); paint(); };
  const list = t => [...new Set(String(t || '').split(/[\n,]+/).map(x => x.trim()).filter(Boolean))].slice(0, 500);
  function paint() {
    const c = C();
    sec.querySelectorAll('[data-k]').forEach(i => { i.checked = c[i.dataset.k] !== false; });
    $('[data-r=pwlab]').textContent = c.on !== false ? 'Encendido' : 'Apagado';
    sec.querySelectorAll('[data-r=act] button').forEach(b => b.classList.toggle('on', b.dataset.v === (c.action || 'hide')));
    sec.querySelectorAll('[data-l]').forEach(t => { if (document.activeElement !== t) t.value = (c[t.dataset.l] || []).join('\n'); });
  }
  sec.querySelectorAll('[data-k]').forEach(i => i.onchange = () => save({ [i.dataset.k]: i.checked }));
  sec.querySelectorAll('[data-r=act] button').forEach(b => b.onclick = () => save({ action: b.dataset.v }));
  sec.querySelectorAll('[data-l]').forEach(t => t.addEventListener('change', () => save({ [t.dataset.l]: list(t.value) })));
  const test = () => {
    const t = $('[data-r=tin]').value; if (!t.trim()) return;
    socket.emit('filtro:test', t, r => {
      $('[data-r=tres]').innerHTML = r.hidden ? `🚫 <b>No sale.</b> <span class="hint">(${esc(r.reason)})</span><div class="fl-q"><s>${esc(r.masked)}</s></div>` : r.text !== t ? `✳️ <b>Sale así:</b><div class="fl-q">${esc(r.text)}</div>` : `✅ <b>Sale normal.</b><div class="fl-q">${esc(r.text)}</div>`;
    });
  };
  $('[data-r=tbtn]').onclick = test; $('[data-r=tin]').addEventListener('keydown', e => { if (e.key === 'Enter') test(); });
  const last = [];
  socket.on('event', e => {
    if (e.type !== 'chat' || !e.hidden) return;
    last.unshift(e); last.length = Math.min(last.length, 15);
    $('[data-r=last]').innerHTML = last.map((x, i) => `<div class="fl-row"><span data-noi18n><b>${esc(x.user.name)}</b>: <s>${esc(x.text)}</s></span><button class="btn sm" data-mute="${i}" title="Silenciar a este usuario">🔇</button></div>`).join('');
    sec.querySelectorAll('[data-mute]').forEach(b => b.onclick = () => { const u = last[+b.dataset.mute].user; const c = C(); if (!(c.users || []).includes('@' + u.id)) save({ users: [...(c.users || []), '@' + u.id] }); toast('🔇 Silenciado: ' + u.name); });
  });
  socket.on('config', paint); paint();
})();
