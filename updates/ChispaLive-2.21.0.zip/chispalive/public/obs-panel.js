// ===== Control de OBS — página del panel =====
(function () {
  const O = () => window.cfg?.obs || {};
  window.OBS = { status: 'off', scenes: [], items: {}, inputs: [], current: '' };

  let pend = {}, pt;
  function save(k, v) {
    window.cfg.obs = { ...(window.cfg.obs || {}), [k]: v }; pend[k] = v;
    clearTimeout(pt); pt = setTimeout(() => { socket.emit('saveConfig', { obs: pend }); pend = {}; flash(); }, 500);
    paint();
  }
  function flash() { const s = sec.querySelector('.saved'); if (s) { s.classList.add('on'); setTimeout(() => s.classList.remove('on'), 1200); } }

  const sec = document.createElement('section'); sec.className = 'sec'; sec.id = 's-obs';
  sec.innerHTML = `
  <div class="vz-head panel">
    <div class="vz-mascot rbx-logo">🎬</div>
    <div class="vz-ttl"><h1 class="display">OBS <span class="saved">✓ Guardado</span></h1><p class="hint">Los regalos controlan tu OBS: cambian de escena, muestran un video, guardan un clip…</p></div>
    <label class="vz-power"><input type="checkbox" data-k="on"><span class="vz-pw"><i></i></span><b data-r="pwlab">Apagado</b></label>
  </div>
  <div class="vz-offbar" data-r="offbar">🎬 <b>El control de OBS está apagado.</b> <button class="btn sm pri" data-r="turnon">Encender</button></div>
  <div class="rbx-status panel" data-r="status"></div>
  <div class="panel cfx">
    <div class="cfx-head"><h2>🎥 Efectos en la cámara</h2><span class="s-new">NUEVO</span></div>
    <p class="hint">Cuando te mandan un regalo, tu cámara tiembla, hace zoom, salta, da una vuelta o cambia de color por unos segundos. Después queda exactamente como estaba.</p>
    <div class="row cfx-cam"><label class="f">Escena donde está tu cámara<select class="i" data-c="scene"></select></label><label class="f">Tu cámara (la fuente)<select class="i" data-c="source"></select></label></div>
    <div class="cfx-rules" data-r="rules"></div>
    <div class="row" style="margin:10px 0 0;gap:8px;flex-wrap:wrap"><button class="btn sm pri" data-r="add">＋ Agregar efecto</button><button class="btn sm" data-r="sugg">✨ Poner los sugeridos</button><button class="btn sm" data-r="stop">⏹ Parar los efectos</button></div>
    <div class="hint" data-r="cfxwarn" style="margin-top:8px"></div>
  </div>
  <div class="rbx-grid">
    <div class="panel">
      <h2>1️⃣ Activa el WebSocket en OBS</h2>
      <p class="hint">En <b>OBS Studio</b> ve a <b>Herramientas → Ajustes del servidor WebSocket</b>, marca <b>"Habilitar servidor WebSocket"</b> y toca <b>"Mostrar información de conexión"</b> para ver el puerto y la contraseña.</p>
      <label class="f">Puerto<input class="i" data-k="port" inputmode="numeric" placeholder="4455"></label>
      <label class="f">Contraseña<input class="i" type="password" data-k="password" placeholder="La del WebSocket de OBS" autocomplete="off"></label>
      <details class="hint" style="margin-top:8px"><summary>OBS está en otra PC</summary><label class="f">Dirección (IP)<input class="i" data-k="host" placeholder="127.0.0.1"></label></details>
      <div class="hint" style="margin-top:8px">Funciona con <b>OBS Studio 28 o más nuevo</b>. TikTok LIVE Studio y Streamlabs no tienen esta conexión.</div>
    </div>
    <div class="panel">
      <h2>🎞 Tus escenas</h2>
      <div class="obs-scenes" data-r="scenes"></div>
      <div class="row" style="margin:8px 0 0;gap:8px"><button class="btn sm" data-r="refresh">🔄 Actualizar</button></div>
      <div class="hint" style="margin-top:8px">Toca una escena para probar el cambio.</div>
    </div>
    <div class="panel">
      <h2>2️⃣ Crea tus acciones</h2>
      <p class="hint">Ve a <b>Acciones y eventos → Nueva acción</b>, elige qué la activa (por ejemplo, la Galaxy) y en "¿Qué pasa?" elige <b>🎬 Controlar OBS</b>. Puedes:</p>
      <ul class="hint obs-list"><li>🎞 Cambiar de escena (y volver sola después de unos segundos)</li><li>👁 Mostrar u ocultar una fuente (un GIF, una cámara, un texto)</li><li>▶️ Reproducir un video o sonido</li><li>✏️ Cambiar un texto, por ejemplo "Último regalo: {usuario}"</li><li>🎬 Guardar una repetición (clip) del momento</li></ul>
    </div>
  </div>`;
  document.getElementById('studios').after(sec);
  const $ = q => sec.querySelector(q);

  sec.querySelectorAll('[data-k]').forEach(i => i.addEventListener(i.type === 'checkbox' ? 'change' : 'input', () => {
    let v = i.type === 'checkbox' ? i.checked : i.value;
    if (i.dataset.k === 'port') { v = v.replace(/\D/g, '').slice(0, 5); i.value = v; v = +v || 4455; }
    save(i.dataset.k, v);
  }));
  $('[data-r=turnon]').onclick = () => { $('[data-k=on]').checked = true; save('on', true); };
  $('[data-r=refresh]').onclick = () => socket.emit('obs:refresh');

  function paintStatus() {
    const S = window.OBS, cls = S.status === 'connected' ? 'ok' : S.status === 'error' ? 'bad' : '';
    $('[data-r=status]').innerHTML = `<div><span class="rbx-dot ${cls}"></span><b>${esc(S.msg || 'Apagado')}</b>${S.version && S.status === 'connected' ? ` <span class="hint">· WebSocket ${esc(S.version)}</span>` : ''}</div>${S.current ? `<div>🎞 Escena actual: <b>${esc(S.current)}</b></div>` : ''}`;
    const box = $('[data-r=scenes]');
    box.innerHTML = S.scenes?.length ? S.scenes.map(n => `<button class="obs-sc ${n === S.current ? 'on' : ''}" data-sc="${esc(n)}">${n === S.current ? '🔴 ' : ''}${esc(n)}<small>${(S.items[n] || []).length} fuentes</small></button>`).join('')
      : `<div class="hint">${S.status === 'connected' ? 'No hay escenas.' : 'Conecta OBS para ver tus escenas.'}</div>`;
    box.querySelectorAll('[data-sc]').forEach(b => b.onclick = () => socket.emit('obs:test', { do: 'scene', scene: b.dataset.sc }, err => err && toast('🎬 ' + err)));
  }
  // ---------- efectos en la cámara ----------
  const CF = () => ({ scene: '', source: '', rules: [], ...(O().camfx || {}) });
  const FXL = () => window.CAM_FX || [];
  const SUGG = [{ gift: 'Rose', effect: 'shake', seconds: 2 }, { gift: 'TikTok', effect: 'jump', seconds: 3 }, { gift: 'Finger Heart', effect: 'pulse', seconds: 4 }, { gift: 'Doughnut', effect: 'rainbow', seconds: 6 }, { gift: '', min: 99, effect: 'zoom', seconds: 4 }, { gift: '', min: 500, effect: 'spin', seconds: 3 }];
  function saveFx(c) { window.cfg.obs = { ...(window.cfg.obs || {}), camfx: c }; save('camfx', c); }
  const optl = (list, sel) => list.map(n => `<option value="${esc(n)}" ${n === sel ? 'selected' : ''}>${esc(n)}</option>`).join('');
  let filt = {};
  function loadFilters(src) { if (!src || filt[src] || window.OBS.status !== 'connected') return; filt[src] = []; socket.emit('obs:filters', src, l => { filt[src] = l || []; paintFx(); }); }
  function paintFx() {
    const c = CF(), S = window.OBS, keep = (l, v) => v && !l.includes(v) ? [v, ...l] : l;
    const scSel = $('[data-c=scene]'), srSel = $('[data-c=source]');
    if (document.activeElement !== scSel) scSel.innerHTML = `<option value="">— Elige —</option>${optl(keep(S.scenes || [], c.scene), c.scene)}`;
    if (document.activeElement !== srSel) srSel.innerHTML = `<option value="">— Elige —</option>${optl(keep((S.items?.[c.scene] || []).map(i => i.name), c.source), c.source)}`;
    loadFilters(c.source);
    const box = $('[data-r=rules]');
    if (box.contains(document.activeElement) && document.activeElement.tagName === 'INPUT') return;
    box.innerHTML = c.rules.length ? c.rules.map((r, i) => `<div class="cfx-row ${r.on === false ? 'off' : ''}" data-i="${i}">
        <label class="sw sm"><input type="checkbox" data-x="on" ${r.on !== false ? 'checked' : ''}><i></i></label>
        <div class="cfx-g"><button class="gpick" data-x="gift" title="Regalo">${r.gift ? giftChip(r.gift) : `<span class="gchip"><b>🎁 Cualquier regalo</b><i>▾</i></span>`}</button>${r.gift ? '' : `<label class="cfx-min">≥ <input class="i" type="number" min="1" data-x="min" value="${r.min || 1}"> 🪙</label>`}</div>
        <span class="cfx-arrow">→</span>
        <div class="cfx-e"><select class="i" data-x="effect">${FXL().map(([k, n]) => `<option value="${k}" ${r.effect === k ? 'selected' : ''}>${n}</option>`).join('')}</select>${r.effect === 'filter' ? `<select class="i" data-x="filter"><option value="">— Filtro —</option>${optl(keep(filt[c.source] || [], r.filter), r.filter)}</select>` : ''}</div>
        <label class="cfx-sec"><input class="i" type="number" min="1" max="120" data-x="seconds" value="${r.seconds || 3}"> s</label>
        <button class="btn sm" data-x="test" title="Probar">▶</button><button class="btn sm danger" data-x="del" title="Borrar">🗑</button></div>`).join('')
      : `<div class="hint">Todavía no tienes efectos. Toca <b>✨ Poner los sugeridos</b> o <b>＋ Agregar efecto</b>.</div>`;
    box.querySelectorAll('.cfx-row').forEach(row => {
      const i = +row.dataset.i, upd = (k, v, re) => { const cc = CF(); cc.rules = cc.rules.map((x, j) => j === i ? { ...x, [k]: v } : x); saveFx(cc); if (re) paintFx(); };
      row.querySelector('[data-x=on]').onchange = e => upd('on', e.target.checked, true);
      row.querySelector('[data-x=gift]').onclick = () => openGiftPicker({ title: 'Regalo que activa el efecto', onPick: g => upd('gift', g.name, true) });
      row.querySelector('[data-x=effect]').onchange = e => upd('effect', e.target.value, true);
      row.querySelector('[data-x=filter]')?.addEventListener('change', e => upd('filter', e.target.value));
      row.querySelector('[data-x=seconds]').oninput = e => upd('seconds', Math.max(1, Math.min(120, +e.target.value || 3)));
      row.querySelector('[data-x=min]')?.addEventListener('input', e => upd('min', Math.max(1, +e.target.value || 1)));
      row.querySelector('[data-x=test]').onclick = () => { const cc = CF(), r = cc.rules[i]; socket.emit('obs:test', { do: 'fx', scene: cc.scene, source: cc.source, effect: r.effect, seconds: r.seconds, filter: r.filter }, err => toast(err ? '🎥 ' + err : '🎥 Mira tu OBS')); };
      row.querySelector('[data-x=del]').onclick = () => { const cc = CF(); cc.rules.splice(i, 1); saveFx(cc); paintFx(); };
    });
    $('[data-r=sugg]').hidden = c.rules.length > 0;
    $('[data-r=cfxwarn]').innerHTML = !O().on ? '⚠️ Enciende el control de OBS (arriba a la derecha) para que funcione.' : S.status !== 'connected' ? '⚠️ OBS no está conectado: sigue el paso 1️⃣ de abajo.' : !c.source ? '👆 Elige tu cámara para empezar.' : '';
  }
  $('[data-c=scene]').onchange = e => { const c = CF(); c.scene = e.target.value; const its = (window.OBS.items?.[c.scene] || []).map(x => x.name); if (!its.includes(c.source)) c.source = its.find(n => /c[aá]m|webcam|video capture|captura/i.test(n)) || ''; saveFx(c); paintFx(); };
  $('[data-c=source]').onchange = e => { const c = CF(); c.source = e.target.value; saveFx(c); paintFx(); };
  $('[data-r=add]').onclick = () => { const c = CF(); c.rules = [...c.rules, { on: true, gift: 'Rose', effect: 'shake', seconds: 3 }]; saveFx(c); paintFx(); };
  $('[data-r=sugg]').onclick = () => { const c = CF(); c.rules = SUGG.map(x => ({ on: true, ...x })); saveFx(c); paintFx(); };
  $('[data-r=stop]').onclick = () => socket.emit('obs:stopfx');

  function paint() {
    const c = O();
    sec.querySelectorAll('[data-k]').forEach(i => { if (document.activeElement === i) return; const v = c[i.dataset.k]; if (i.type === 'checkbox') i.checked = !!v; else i.value = v ?? (i.dataset.k === 'port' ? 4455 : i.dataset.k === 'host' ? '127.0.0.1' : ''); });
    $('[data-r=pwlab]').textContent = c.on ? 'Encendido' : 'Apagado';
    $('[data-r=offbar]').hidden = !!c.on;
    paintStatus(); paintFx();
  }
  socket.on('config', () => setTimeout(paint, 0));
  socket.on('obs:status', s => { window.OBS = s || window.OBS; paintStatus(); paintFx(); document.dispatchEvent(new CustomEvent('obs:status')); });
  if (window.cfg?.obs) paint();
  socket.emit('obs:get'); socket.on('connect', () => socket.emit('obs:get'));
})();
