// ===== Tienda de diseños — página del panel =====
(function () {
  const sec = document.createElement('section'); sec.className = 'sec'; sec.id = 's-tienda';
  sec.innerHTML = `
  <div class="vz-head panel">
    <div class="vz-mascot rbx-logo">🎨</div>
    <div class="vz-ttl"><h1 class="display">Tienda de diseños</h1><p class="hint">Cambia el look de <b>todos</b> tus juegos y widgets de una vez. Cada diseño trae sus colores, su letra, adornos en las tarjetas y efectos en pantalla.</p></div>
    <span class="tn-inc">✅ Incluido en Básico y Pro</span>
  </div>
  <div class="tn-grid" data-r="grid"></div>
  <div class="panel tn-opts">
    <h2>⚙️ Qué cambia el diseño</h2>
    <div class="tn-row">
      <label class="tg"><input type="checkbox" data-k="colors"><span><b>Colores</b><small>Usa los colores del diseño en vez de los de "Mi estilo".</small></span></label>
      <label class="tg"><input type="checkbox" data-k="font"><span><b>Letra</b><small>Cambia la letra de los títulos.</small></span></label>
      <label class="tg"><input type="checkbox" data-k="deco"><span><b>Adornos</b><small>Arbolito, telaraña, flor… en la esquina de las tarjetas.</small></span></label>
      <label class="tg"><input type="checkbox" data-k="particles"><span><b>Efectos en pantalla</b><small>Nieve, murciélagos, pétalos, brillos o corazones.</small></span></label>
    </div>
    <div class="row" style="gap:10px;align-items:center;margin:12px 0 0"><span class="hint">Cantidad de efectos</span><div class="chips2" data-r="amt"><button data-v="poco">Poquito</button><button data-v="normal">Normal</button><button data-v="mucho">Mucho</button></div></div>
  </div>`;
  document.getElementById('studios').after(sec);
  const $ = q => sec.querySelector(q);
  const C = () => ({ id: '', colors: true, font: true, deco: true, particles: true, amount: 'normal', ...(window.cfg?.skin || {}) });
  const save = patch => { window.cfg.skin = { ...C(), ...patch }; socket.emit('saveConfig', { skin: patch }); paint(); };
  const LIST = [
    ['', '✨', 'Mi estilo', 'Sin diseño de temporada: tus overlays usan lo que elegiste en "Mi estilo".'],
    ['auto', '📅', 'Automático por fecha', 'Se pone solo: Halloween desde el 15 de octubre, Navidad en diciembre, Año Nuevo del 31 al 2 y San Valentín hasta el 14 de febrero. El resto del año, tu estilo.'],
    ...Object.entries(DESIGN_SKINS).map(([k, v]) => [k, v.icon, v.name, v.desc]),
  ];
  let built = false;
  function build() {
    $('[data-r=grid]').innerHTML = LIST.map(([id, ic, name, desc]) => `
      <div class="tn-card panel" data-id="${id}">
        <div class="tn-prev">${DESIGN_SKINS[id] ? `<iframe data-src="/overlay/destacado.html?skin=${id}" tabindex="-1"></iframe>` : `<div class="tn-ph">${ic}</div>`}</div>
        <div class="tn-b"><h3>${ic} ${name}</h3><p class="hint">${desc}</p>${id === 'auto' ? '<p class="tn-now"></p>' : ''}
        <button class="btn pri" data-use="${id}">Usar este</button></div>
      </div>`).join('');
    sec.querySelectorAll('[data-use]').forEach(b => b.onclick = () => { save({ id: b.dataset.use }); toast(b.dataset.use ? '🎨 Diseño puesto en todos tus overlays' : '✨ Volviste a Mi estilo'); });
    built = true;
  }
  function paint() {
    if (!built) build();
    const c = C();
    sec.querySelectorAll('.tn-card').forEach(el => {
      const on = el.dataset.id === (c.id || ''); el.classList.toggle('on', on);
      const b = el.querySelector('[data-use]'); b.textContent = on ? '✓ En uso' : 'Usar este'; b.classList.toggle('pri', !on); b.disabled = on;
    });
    const auto = sec.querySelector('.tn-now');
    if (auto) { const now = skinByDate(); auto.textContent = now ? `📍 Hoy toca: ${DESIGN_SKINS[now].icon} ${DESIGN_SKINS[now].name}` : '📍 Hoy toca: Mi estilo'; }
    sec.querySelectorAll('[data-k]').forEach(i => { i.checked = c[i.dataset.k] !== false; });
    sec.querySelectorAll('[data-r=amt] button').forEach(b => b.classList.toggle('on', b.dataset.v === (c.amount || 'normal')));
  }
  sec.querySelectorAll('[data-k]').forEach(i => i.onchange = () => save({ [i.dataset.k]: i.checked }));
  sec.querySelectorAll('[data-r=amt] button').forEach(b => b.onclick = () => save({ amount: b.dataset.v }));
  // Las vistas previas solo se cargan al entrar a la tienda (no gastan nada mientras tanto)
  const loadPrev = () => sec.querySelectorAll('iframe[data-src]').forEach(i => { i.src = i.dataset.src; i.removeAttribute('data-src'); });
  document.querySelector('.nav[data-s=tienda]')?.addEventListener('click', () => { if (!built) build(); paint(); loadPrev(); });
  if (location.hash === '#tienda') setTimeout(loadPrev, 500);
  socket.on('config', paint); if (window.cfg) paint();
})();
