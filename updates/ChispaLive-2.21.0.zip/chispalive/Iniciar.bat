@echo off
title ChispaLive
cd /d "%~dp0"
set CHISPALIVE_LOOP=1
if not exist node_modules (
  echo Instalando por primera vez, espera un momento...
  call npm install
)
start "" http://localhost:3939
:inicio
node server.js
if %errorlevel%==99 (
  echo.
  echo  Actualizado. Reiniciando ChispaLive...
  timeout /t 1 >nul
  goto inicio
)
pause
