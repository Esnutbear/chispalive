# ⚡ ChispaLive v0.9

Juegos y overlays interactivos para TikTok LIVE.

## Instalar (una sola vez)
1. Instala **Node.js LTS** desde https://nodejs.org
2. Descomprime esta carpeta.
3. Doble clic en **Iniciar.bat**. El panel se abre en `http://localhost:3939`.

## Usar
1. Abre tu LIVE en TikTok o TikTok LIVE Studio.
2. Escribe tu usuario en el panel y dale a **Conectar**.
3. Entra a cada juego, copia su link con **🔗 Copiar link para OBS** y pégalo como *Fuente de navegador* (1080 × 1920).

¿No estás en vivo? Usa el **Simulador**: puedes enviar regalos, likes, follows y escribir comandos como un viewer.

## Cada juego tiene su propio estudio
- **Botones de control**: iniciar, pausar, girar ya, terminar, reiniciar.
- **Temporizador** con −30s, −10s, +10s, +30s. Funciona antes de empezar y también en vivo.
- **Regalos que cuentan**: cualquiera, desde un mínimo (toca el regalo) o solo los que elijas. Incluye regalos personalizados.
- **Entrada**: además de regalos, la gente puede participar con un comando en el chat, likes, follow o compartir.
- **Agregar a mano**: para quien participa por fuera (Yape, Discord…).
- **Diseño**: título, tu imagen PNG/GIF, estilo del overlay y animación propia.
- **Efectos**: confeti, sonidos y brillo.
- **Activo / Apagado**: apaga un juego para que ignore el live.

| Juego | Estilos |
|---|---|
| 🔨 Live Auction | Tarjeta · Podio · Compacta, con victoria instantánea y anti-sniper |
| 👑 Spin Royale | Ruleta · Cuadrícula, modo eliminación o ganador directo |
| 🎡 Ruleta de acciones | Clásica · Neón · Pastel, con % por acción |
| 🎲 Lucky Roll | Dado · Neón, de 4 a 20 caras con % por número |
| 🫙 Frasco de regalos | Vidrio · Neón · Cofre · Caldero · Pecera, con física |
| 🎯 Metas | Barra · Radial · Corazón, para likes, monedas, seguidores o shares |
| 🏆 Rankings | Lista · Podio · Barras, rota entre top donadores, likes y shares |
| 🔔 Alertas | Tarjeta · Banner · Grande, con GIF propio por tipo |
| 💬 Chat | Burbujas · Minimal |

## Si no conecta
- Tienes que estar **en vivo** en ese momento.
- La conexión no es oficial de TikTok. Si TikTok cambia algo, actualiza con `npm update tiktok-live-connector`.
- Si falla seguido, crea una clave gratis en eulerstream.com y pégala en **Ajustes**.

## Regalos con imagen oficial de TikTok
La primera vez que te conectes en vivo, la app descarga la lista de regalos de TikTok con sus imágenes y la guarda (`gifts-cache.json`). Desde ahí todos los juegos, alertas, el frasco y el simulador usan las imágenes reales, aunque no estés en vivo. También puedes darle a **🔄 Traer regalos de TikTok** dentro de cualquier juego.

## Novedades v0.4
- **🧬 Evoluciones** en todos los juegos: niveles por monedas con su GIF, sonido, efecto (temblor, flash o zoom) y confeti.
  - Spin Royale: el jugador "desbloquea un nuevo personaje" y su foto cambia por la imagen del nivel.
  - Frasco: el frasco cambia de diseño al subir de nivel (vidrio → cofre → caldero).
  - Alertas: regalos más grandes = alerta más grande con su propio GIF y sonido.
- **🔊 Sonidos por evento** en cada juego: ▶ para escuchar, 16 sonidos incluidos o **sube tu MP3/WAV**. Además hay *niveles de sonido* por tamaño del regalo.
- **🎁 Selector de regalos** con buscador, filtros por precio y orden. Y **Acumular regalos**: los pequeños se suman hasta la puja mínima.
- **Spin Royale**: vista Ruleta, Cuadrícula, Pirámide y Hexágono; eliminaciones masivas; entradas múltiples; ventaja por monedas; victoria instantánea; mínimo de participantes; inscripción bloqueada; máximo de jugadores; banner de duelo 1 vs 1.
- **Posición, tamaño y colores** propios para cada juego.
- Vista previa con fondo Oscuro / Cuadros / Claro y **zona segura** de TikTok.
- **Buscador de ajustes** y **Restablecer todo (N)**, con contador de cambios por pestaña.

## Novedades v0.5
- **🎡 Ruleta con varias ruedas**: cada rueda tiene su activador (un regalo, desde X monedas, cualquier regalo, comando, likes, follow o compartir). Cada porción tiene color, imagen, % y una **acción al ganar** (sonido, voz TTS o mensaje). Además: anuncio antes de girar, base, ocultar hasta que gire, número de vueltas, tamaño e ícono central con la foto del viewer.
- **🎁 Lucky Roll · Cofre de premios**: premios con imagen, fondo y % de chance; activador global y/o regalo propio por premio; "Nada" usa el % que sobra; cofre animado (6 estilos), cinta de premios y 3 pantallas de espera (Vitrina, Cinta, Cuadrícula); barra de probabilidades.
- **💾 Presets** en todos los juegos: guarda configuraciones y cambia entre ellas con un clic.
- **📜 Historial** de ganadores y premios en cada juego.

## Cambio v0.5.1
- Las **evoluciones** quedan solo en el **🫙 Frasco de regalos**. Los demás juegos ya no tienen pestaña de Evoluciones, ni banner, ni personajes, ni niveles de alerta.

## Novedades v0.6
- **Nueva pantalla para conectar**: el oso polar con lentes 🐻‍❄️ te recibe, escribes tu @ y das a Conectar.
- **Voz del chat**: tus viewers hablan en tu live. Eliges quién puede (todos, seguidores, suscriptores, mods, club de fans, donadores, top), cómo se activa (todo el chat, prefijo o `!say`), filtros (largo, spam, links, emojis, idiomas, palabras prohibidas), cola y lista de mensajes leídos / no leídos. Suena en el panel o en el overlay `voz.html`.
- **Acciones y eventos**: reglas "CUANDO pasa algo → HACER algo". Más de 15 eventos (regalo, valor, seguir, compartir, chat, palabra clave, likes, metas, espectadores, suscripción, cofre, inicio/fin del live, atajo de teclado, cada X minutos) y reacciones (alerta con GIF, sonido, voz, confeti, temblor, destello, presionar tecla en Windows, mover un juego, webhook). Hasta 8 pantallas: cada una es un link `acciones.html?pantalla=N` para OBS / LIVE Studio.
- **Spin Royale vista "Arena"**: temporizador grande, insignia del modo, fichas de puja mínima / comando / jugadores / vivos / monedas, y cuadrícula de personajes.
- **Lucky Roll**: las probabilidades solo las ves tú en el panel. Si quieres que el público las vea, activa "Mostrar % al público".
- **Idioma Español / English**: botones ES / EN arriba a la derecha (o en Ajustes). Cambia el panel y los textos de todos los overlays. En los textos puedes usar las variables en español o en inglés: `{usuario}`/`{user}`, `{regalo}`/`{gift}`, `{cantidad}`/`{amount}`, `{monedas}`/`{coins}`, `{mensaje}`/`{message}`, `{premio}`/`{prize}`. Un overlay también puede forzar el idioma agregando `?lang=en` al link.

## Cambio v0.6.1
- Spin Royale (Cuadrícula y Arena): nuevo tablero que se achica solo para que entren todos. Con más de ~80 jugadores muestra los vivos con más monedas y los recién llegados, más una ficha "+N más". Ya no se corta abajo.
- Giro más rápido con mucha gente (salta entre fichas en vez de recorrerlas una por una).
- "Partidas grandes" (activado por defecto): con más de 20 vivos elimina a varios por ronda, para que 100 personas no tarden 20 minutos.
- El 👑 marca a quien más monedas lleva.

## Cambio v0.6.2
- Regalos de TikTok: si TikTok no deja bajar la lista completa, se intenta por el servidor de firmas (Euler Stream). Y aunque las dos fallen, cada regalo que te envían en vivo guarda su imagen oficial sola, así el catálogo se va llenando.

## Cambio v0.6.3
- Elegir regalo: si tocas un regalo con "Cualquiera" activo, ahora SOLO ese regalo cuenta (pasa a "Solo estos"). Los demás se ven apagados. Para usar una puja mínima, elige primero "⬆️ Mínimo".

## Cambio v0.6.4
- Los ~700 regalos oficiales de TikTok (con su imagen) se descargan solos al abrir ChispaLive, aunque no estés en vivo. Ya no salen emojis.

## Cambio v0.6.5
- Ruleta y Lucky Roll: eliges un regalo (ej. Doughnut) y SOLO ese regalo los activa. En la ruleta usa "🎁 Solo un regalo".
- Spin Royale y Subasta: el regalo que eliges marca el VALOR mínimo. Si eliges Rose (1 moneda), entra cualquier regalo de 1 moneda o más, y las monedas se suman (2 Doughnut = 60 puntos).

## Cambio v0.6.6
- Regalo de tu comunidad (ej. Cueva Bear): al conectarte en vivo se descarga la lista de TU sala, se detecta tu regalo de comunidad y sale primero con la insignia "⭐ TU COMUNIDAD". La sala se recuerda, así que la próxima vez aparece aunque no estés en vivo.

## Cambio v0.6.7
- Lucky Roll: cada regalo da tiradas según sus monedas (Doughnut = 30 tiradas, máximo configurable). Las tiradas van en fila: termina una persona y sigue la siguiente. Muestra "🎲 3/30" y desde la 2ª tirada gira más rápido.

## Cambio v0.6.8
- Spin Royale: "Tiempo entre giros" ahora es la espera real después de cada eliminación (antes se le restaba la duración del giro). El overlay muestra "giro en 5s".
- Los eliminados ya no desaparecen del tablero: se quedan en gris con una ✖ roja.

## Cambio v0.6.9
- Cambiar la animación o el estilo ya no manda regalos de prueba: la vista previa es solo visual (no suma monedas ni aparece en "Eventos en vivo").
- Al conectarte en vivo por primera vez se borran los datos de prueba (monedas, rankings y la lista de eventos).
- Voz del chat: la cola ya no se traba (arreglo de fallas de Chrome: voz que se cortaba a los 15 s o que nunca avisaba que terminó). "Probar voz" usa tus filtros (spam, palabras prohibidas, emojis) y te avisa si no se leería. Aviso grande cuando la voz está apagada y cuando la voz elegida no existe en ese navegador. Pestañas ordenadas.

## Cambio v0.7 — tus datos ya no se pierden al actualizar
- Toda tu configuración, los regalos y las imágenes/sonidos que subes se guardan en `%APPDATA%\ChispaLive` (fuera de la carpeta del programa).
- Para actualizar: descomprime la versión nueva y abre Iniciar.bat. La primera vez busca tu instalación anterior (Descargas, Escritorio, Documentos) y trae tu configuración sola.
- Respaldo automático cada vez que abres el programa (los últimos 10, en `%APPDATA%\ChispaLive\respaldos`).
- Ajustes → 💾 Tus datos: descargar o cargar un respaldo.
- Guardado seguro: si se apaga la PC mientras guarda, el archivo no se daña (y si se daña, usa el último respaldo).

## Cambio v0.8 — actualizaciones con un clic
- Cuando hay una versión nueva sale un aviso arriba en el panel: "Ver novedades" o "🚀 Actualizar". Se instala sola, se reinicia y te muestra lo nuevo.
- Cómo llega la versión nueva: deja el `ChispaLive-x.y.z.zip` en Descargas o en el Escritorio (el aviso aparece en menos de 30 s), o súbelo en Ajustes → 🚀 Actualizaciones → "Instalar desde archivo .zip". Si `update.json` tiene un enlace, también busca en internet.
- Los overlays de OBS / LIVE Studio se recargan solos con lo nuevo.
- Tu configuración no se toca (vive en %APPDATA%\ChispaLive).

## Cambio v0.9 — app instalable
- `ChispaLive-Setup-0.9.0.exe`: instalador con logo. Se instala en tu usuario (sin permisos de administrador), crea el icono en el escritorio y en el menú Inicio, y aparece en "Agregar o quitar programas".
- El icono abre ChispaLive en su propia ventana (sin ventana negra). El programa sigue corriendo aunque cierres la ventana, para que los overlays de OBS no se apaguen. Para apagarlo: Ajustes → ⏻ Cerrar ChispaLive.
- Actualizaciones: deja `ChispaLive-x.y.z.zip` en Descargas o el Escritorio → aviso en el panel → "Actualizar".
- Para construir una versión nueva (desarrollador): `sh instalador/construir.sh /ruta/node.exe carpeta-salida` (necesita makensis).
