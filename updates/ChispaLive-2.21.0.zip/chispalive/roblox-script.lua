--[[
	ChispaLive → Roblox
	Pon este Script en ServerScriptService.

	• En Roblox Studio: activa Game Settings → Security → "Allow HTTP Requests"
	  y deja ChispaLive abierto en tu PC. Los eventos llegan solos.
	• En tu juego publicado: los eventos llegan por la nube de Roblox
	  (en ChispaLive pon tu Universe ID y tu API key).

	Cada mensaje trae:
	  data.cmd    → el poder ("turbo", "salto"…) o el tipo de evento ("gift", "like", "follow", "chat"…)
	  data.kind   → qué pasó en el live (gift, like, follow, share, chat, join, sub, test)
	  data.user   → { id = "usuario_tiktok", name = "Nombre" }
	  data.gift   → nombre del regalo (si fue regalo)
	  data.count  → cantidad (regalos o likes)
	  data.coins  → monedas del regalo
	  data.text   → lo que escribió en el chat
	  data.value  → el valor extra que pusiste en la acción

	Otros scripts pueden escuchar todo así:
	  game.ServerStorage:WaitForChild("ChispaLiveEvento").Event:Connect(function(data) ... end)
]]

local TOPIC = "{{TOPIC}}"       -- debe ser igual al de ChispaLive
local PUERTO = {{PORT}}          -- puerto de ChispaLive en tu PC

local HttpService = game:GetService("HttpService")
local MessagingService = game:GetService("MessagingService")
local RunService = game:GetService("RunService")
local Players = game:GetService("Players")
local ServerStorage = game:GetService("ServerStorage")

local Evento = ServerStorage:FindFirstChild("ChispaLiveEvento") or Instance.new("BindableEvent")
Evento.Name = "ChispaLiveEvento"
Evento.Parent = ServerStorage

------------------------------------------------------------------
-- 🔧 TUS PODERES: agrega o cambia lo que hace cada comando
------------------------------------------------------------------
local Poderes = {}

-- Ejemplo: todos corren más rápido unos segundos
Poderes.turbo = function(data)
	local segundos = tonumber(data.value) or 5
	for _, p in ipairs(Players:GetPlayers()) do
		local h = p.Character and p.Character:FindFirstChildOfClass("Humanoid")
		if h then
			local antes = h.WalkSpeed
			h.WalkSpeed = antes * 2
			task.delay(segundos, function() if h.Parent then h.WalkSpeed = antes end end)
		end
	end
end

-- Ejemplo: todos saltan
Poderes.salto = function(data)
	for _, p in ipairs(Players:GetPlayers()) do
		local h = p.Character and p.Character:FindFirstChildOfClass("Humanoid")
		if h then h.Jump = true end
	end
end

-- Mensaje de prueba desde el botón "Probar" de ChispaLive
Poderes.test = function(data)
	print("✅ ChispaLive conectado:", data.text)
end

------------------------------------------------------------------
-- No hace falta tocar nada de aquí para abajo
------------------------------------------------------------------
local vistos, cuenta = {}, 0
local function procesar(data)
	if type(data) ~= "table" then return end
	local clave = tostring(data.sid) .. ":" .. tostring(data.seq)
	if vistos[clave] then return end
	vistos[clave] = true
	cuenta = cuenta + 1
	if cuenta > 2000 then vistos = {}; cuenta = 0 end
	Evento:Fire(data)
	local poder = Poderes[data.cmd]
	if poder then
		task.spawn(function()
			local ok, err = pcall(poder, data)
			if not ok then warn("[ChispaLive] Error en el poder '" .. tostring(data.cmd) .. "': " .. tostring(err)) end
		end)
	end
end

if RunService:IsStudio() then
	-- Roblox Studio: pregunta a ChispaLive en tu PC
	task.spawn(function()
		local desde, sesion, avisado = -1, nil, false
		while true do
			local ok, res = pcall(function()
				return HttpService:GetAsync(("http://localhost:%d/roblox/poll?since=%d"):format(PUERTO, desde), true)
			end)
			if ok then
				local data = HttpService:JSONDecode(res)
				if data.sid ~= sesion then sesion = data.sid; desde = data.seq; print("🔥 ChispaLive conectado (Studio)") end
				for _, m in ipairs(data.events or {}) do
					procesar(m)
					desde = math.max(desde, m.seq)
				end
				avisado = false
				task.wait(0.25)
			else
				if not avisado then
					warn("[ChispaLive] No hay conexión. Abre ChispaLive y activa 'Allow HTTP Requests'. (" .. tostring(res) .. ")")
					avisado = true
				end
				task.wait(2)
			end
		end
	end)
else
	-- Juego publicado: recibe por la nube de Roblox
	task.spawn(function()
		while true do
			local ok, err = pcall(function()
				MessagingService:SubscribeAsync(TOPIC, function(msg)
					local okj, data = pcall(HttpService.JSONDecode, HttpService, msg.Data)
					if okj then procesar(data) end
				end)
			end)
			if ok then print("🔥 ChispaLive conectado (nube)") break end
			warn("[ChispaLive] No se pudo conectar, reintentando: " .. tostring(err))
			task.wait(5)
		end
	end)
end
