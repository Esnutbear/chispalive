// ===== Lógica general del panel =====
const $ = id => document.getElementById(id);
window.cfg = {}; window.state = null;
let evN = 0;

// ---------- Utilidades de interfaz ----------
function toast(t) {
  document.querySelectorAll('.toast').forEach(x => x.remove());
  const d = Object.assign(document.createElement('div'), { className: 'toast', textContent: t });
  document.body.appendChild(d); setTimeout(() => d.remove(), 2600);
}
socket.on('toast', toast);
function paintRange(r) { r.style.setProperty('--p', ((r.value - r.min) / (r.max - r.min) * 100) + '%'); }

// ---------- Estudios + navegación ----------
initStudios($('studios'));
Object.entries(STUDIOS).forEach(([k, S]) => {
  const b = document.createElement('button'); b.className = 'nav'; b.dataset.s = k;
  b.innerHTML = `<span class="ic">${S.icon}</span>${S.name}${S.isNew ? '<span class="badge">NUEVO</span>' : ''}`;
  $('nav-' + S.group).appendChild(b);
});
function go(s) {
  document.querySelectorAll('.nav').forEach(x => x.classList.toggle('on', x.dataset.s === s));
  document.querySelectorAll('.sec').forEach(x => x.classList.toggle('on', x.id === 's-' + s));
  document.querySelector('main').scrollTop = 0;
  if (STUDIOS[s]) studioOpened(s);
}
document.querySelectorAll('.nav').forEach(b => b.onclick = () => go(b.dataset.s));
document.querySelectorAll('[data-go]').forEach(b => b.onclick = () => go(b.dataset.go));

// Accesos rápidos del dashboard
$('quickGames').innerHTML = Object.entries(STUDIOS).map(([k, S]) =>
  `<button class="panel" data-quick="${k}" style="text-align:left;cursor:pointer;margin:0;display:flex;gap:12px;align-items:center">
    <span class="s-icon" style="width:44px;height:44px;font-size:22px;border-radius:14px">${S.icon}</span>
    <span><b>${S.name}</b><br><span class="hint" data-qs="${k}"></span></span></button>`).join('');
document.querySelectorAll('[data-quick]').forEach(b => b.onclick = () => go(b.dataset.quick));

// ---------- Conexión ----------
$('btnConn').onclick = () => {
  const ss = state?.session || {};
  if (ss.status === 'live' || ss.status === 'connecting' || ss.wantLive) socket.emit('disconnectLive');
  else socket.emit('connectLive', $('user').value);
};
$('user').onkeydown = e => { if (e.key === 'Enter') $('btnConn').click(); };

// ---------- Links para OBS ----------
$('ovlList').innerHTML = Object.values(STUDIOS).map(S => {
  const url = `${location.origin}/overlay/${S.overlay}.html`;
  return `<div class="panel"><h2>${S.icon} ${S.name}</h2><p class="hint" style="margin-bottom:10px">${S.desc}</p>
    <div class="url"><code>${url}</code><button class="btn sm" onclick="navigator.clipboard.writeText('${url}');toast('Link copiado ✓')">Copiar</button><a class="btn sm" href="${url}" target="_blank">Ver</a></div></div>`;
}).join('');

// ---------- MI ESTILO ----------
let brand = {}, saveT;
const fmtB = { speed: v => v + 'x', glow: v => v + '%', opacity: v => v + '%', radius: v => v + ' px', scale: v => v + '%', volume: v => v + '%' };
function saveBrand(patch, now) {
  brand = { ...brand, ...patch, colors: { ...brand.colors, ...(patch.colors || {}) } };
  applyTheme(brand); paintBrand();
  clearTimeout(saveT);
  saveT = setTimeout(() => socket.emit('saveConfig', { brand }), now ? 0 : 250);
}
$('themes').innerHTML = Object.entries(THEMES).map(([k, t]) =>
  `<button class="th" data-th="${k}"><div class="sw3"><i style="background:${t.primary}"></i><i style="background:${t.secondary}"></i><i style="background:${t.accent}"></i></div><span>${t.name}</span></button>`).join('');
document.querySelectorAll('[data-th]').forEach(b => b.onclick = () => {
  const t = THEMES[b.dataset.th];
  saveBrand({ theme: b.dataset.th, colors: { primary: t.primary, secondary: t.secondary, accent: t.accent } }, true);
});
document.querySelectorAll('[data-c]').forEach(inp => inp.oninput = () => saveBrand({ colors: { [inp.dataset.c]: inp.value } }));
Object.keys(FONTS).forEach(loadFont);
$('fonts').innerHTML = Object.entries(FONTS).map(([k, f]) =>
  `<button class="fo" data-font="${k}"><div class="aa" style="font-family:'${k}', sans-serif">${k === 'Press Start 2P' ? 'Aa 123' : 'Aa ¡Gracias!'}</div><small>${f.label}</small></button>`).join('');
document.querySelectorAll('[data-font]').forEach(b => b.onclick = () => saveBrand({ font: b.dataset.font }, true));
$('anims').innerHTML = Object.entries(ANIMS).map(([k, n]) => `<button data-anim="${k}">${n}</button>`).join('');
document.querySelectorAll('[data-anim]').forEach(b => b.onclick = () => { saveBrand({ animation: b.dataset.anim }, true); setTimeout(testPreview, 350); });
document.querySelectorAll('input[data-b]').forEach(inp => {
  const k = inp.dataset.b;
  inp.addEventListener(inp.type === 'checkbox' ? 'change' : 'input', () => {
    const v = inp.type === 'checkbox' ? inp.checked : inp.type === 'range' ? +inp.value : inp.value;
    if (inp.type === 'range') { paintRange(inp); document.querySelector(`[data-o="${k}"]`).textContent = fmtB[k](v); }
    saveBrand({ [k]: v });
  });
});
function paintBrand() {
  document.querySelectorAll('[data-th]').forEach(b => b.classList.toggle('on', b.dataset.th === brand.theme));
  document.querySelectorAll('[data-font]').forEach(b => b.classList.toggle('on', b.dataset.font === brand.font));
  document.querySelectorAll('[data-anim]').forEach(b => b.classList.toggle('on', b.dataset.anim === brand.animation));
  const logoHtml = `<img src="${brand.logo || '/brand/oso.svg'}">`;
  ['sideLogo', 'heroLogo', 'dropLogo'].forEach(id => $(id).innerHTML = logoHtml);
  $('sideName').textContent = brand.name || 'ChispaLive';
  $('heroName').textContent = brand.name || 'Tu canal';
  $('rmLogo').style.display = brand.logo ? '' : 'none';
}
function fillBrandForm() {
  document.querySelectorAll('input[data-b]').forEach(inp => {
    const k = inp.dataset.b, v = brand[k];
    if (inp.type === 'checkbox') inp.checked = v !== false;
    else if (inp.type === 'range') { inp.value = v; paintRange(inp); document.querySelector(`[data-o="${k}"]`).textContent = fmtB[k](+v); }
    else if (document.activeElement !== inp) inp.value = v || '';
  });
  document.querySelectorAll('[data-c]').forEach(inp => inp.value = brand.colors?.[inp.dataset.c] || '#ffffff');
  paintBrand();
}
const drop = $('drop');
drop.onclick = () => $('logoFile').click();
$('logoFile').onchange = e => e.target.files[0] && readImage(e.target.files[0], d => socket.emit('uploadAsset', { target: 'brand.logo', dataUrl: d }));
drop.ondragover = e => { e.preventDefault(); drop.classList.add('over'); };
drop.ondragleave = () => drop.classList.remove('over');
drop.ondrop = e => { e.preventDefault(); drop.classList.remove('over'); e.dataTransfer.files[0] && readImage(e.dataTransfer.files[0], d => socket.emit('uploadAsset', { target: 'brand.logo', dataUrl: d })); };
$('rmLogo').onclick = () => socket.emit('removeAsset', 'brand.logo');

const PV = [['alertas', '🔔 Alerta', 'alertas'], ['ruleta', '🎡 Ruleta', 'ruleta'], ['lucky', '🎲 Dado', 'lucky'], ['meta', '🎯 Meta', 'meta'], ['frasco', '🫙 Frasco', 'jar'], ['top', '🏆 Top', 'top']];
let pvCur = PV[0];
$('pvTabs').innerHTML = PV.map(([k, n], i) => `<button class="tab ${i ? '' : 'on'}" data-pv-tab="${i}">${n}</button>`).join('');
document.querySelectorAll('[data-pv-tab]').forEach(b => b.onclick = () => {
  pvCur = PV[+b.dataset.pvTab];
  document.querySelectorAll('[data-pv-tab]').forEach(x => x.classList.toggle('on', x === b));
  $('pvFrame').src = `/overlay/${pvCur[0]}.html`;
  $('pvFrame').onload = () => setTimeout(testPreview, 300);
});
function testPreview() { pvCur[2] === 'alertas' ? act('alertas', 'test', { kind: 'gift' }) : socket.emit('preview', { key: pvCur[2] }); }
$('pvTest').onclick = testPreview;

// ---------- Config → formularios ----------
socket.on('config', c => {
  window.cfg = c; brand = clone(c.brand); fillBrandForm();
  if (!$('user').value) $('user').value = c.username || '';
  if (!$('cxUser').value) $('cxUser').value = c.username || '';
  document.querySelectorAll('[data-lang]').forEach(b => b.classList.toggle('on', b.dataset.lang === (c.lang || 'es')));
  $('apiKey').value = c.signApiKey || '';
  studiosOnConfig();
});
socket.on('catalog', c => {
  window.CATALOG = c;
  $('simGifts').innerHTML = c.filter(g => g.coins <= 2150).slice(0, 24).map(g => `<button class="btn" data-g="${esc(g.name)}">${g.image ? `<img src="${esc(g.image)}" referrerpolicy="no-referrer" style="width:22px;height:22px;object-fit:contain">` : g.icon} ${esc(g.name)} <span class="hint">(${g.coins})</span></button>`).join('') + '<button class="btn" data-g="">🎁 Aleatorio</button>';
  document.querySelectorAll('#simGifts [data-g]').forEach(b => b.onclick = () => socket.emit('simulate', { kind: 'gift', extra: { giftName: b.dataset.g || undefined, count: +$('simCount').value || 1 } }));
  studiosOnConfig();
});

function lsGet(k) { try { return localStorage.getItem(k); } catch { return null; } }
function lsSet(k, v) { try { localStorage.setItem(k, v); } catch {} }

// ---------- Simulador y ajustes ----------
document.querySelectorAll('[data-sim]').forEach(b => b.onclick = () => socket.emit('simulate', { kind: b.dataset.sim, extra: b.dataset.sim === 'like' ? { count: 500 } : {} }));
const sendSim = () => { const t = $('simText').value.trim() || '!unirme'; socket.emit('simulate', { kind: 'chat', extra: { text: t } }); };
$('simSend').onclick = sendSim; $('simText').onkeydown = e => { if (e.key === 'Enter') sendSim(); };
$('saveKey').onclick = () => { socket.emit('saveConfig', { signApiKey: $('apiKey').value.trim() }); toast('Clave guardada ✓'); };
$('btnReset').onclick = () => confirm('¿Reiniciar monedas, likes y rankings?') && socket.emit('resetSession');

// ---------- Estado en vivo ----------
const prevVals = {};
function setStat(id, card, v) {
  const t = typeof v === 'number' ? v.toLocaleString('es') : v;
  if (prevVals[id] !== undefined && prevVals[id] !== t) { const c = $(card); c.classList.remove('bump'); void c.offsetWidth; c.classList.add('bump'); }
  prevVals[id] = t; $(id).textContent = t;
}
socket.on('state', s => {
  window.state = s; const ss = s.session;
  $('dot').className = 'dot ' + ss.status; $('stMsg').textContent = ss.statusMsg || 'Desconectado';
  $('stBox').classList.toggle('live', ss.status === 'live');
  $('heroPill').className = 'pill' + (ss.status === 'live' ? ' live' : ''); $('heroPill').textContent = ss.status === 'live' ? '● EN VIVO' : '● OFFLINE';
  $('btnConn').textContent = ss.status === 'waiting' ? 'Detener' : ss.status === 'live' || ss.status === 'connecting' || ss.wantLive ? 'Desconectar' : 'Conectar';
  liveAlert(ss);
  setStat('kViewers', 'cViewers', ss.viewers); setStat('kDia', 'cDia', ss.totalDiamonds);
  setStat('kLikes', 'cLikes', ss.totalLikes); setStat('kFol', 'cFol', ss.followers);
  const tops = s.ranks.gifts, tot = tops.reduce((a, d) => a + d.value, 0);
  $('topList').innerHTML = tops.length ? tops.map((d, i) => `<div><span>${['🥇', '🥈', '🥉'][i] || (i + 1) + '.'} ${esc(d.user.name)}</span><b>${d.value} 💎 <span class="hint">${Math.round(d.value / tot * 100)}%</span></b></div>`).join('') : '<div class="hint">Todavía no hay regalos.</div>';
  Object.entries(STUDIOS).forEach(([k, S]) => { const el = document.querySelector(`[data-qs="${k}"]`); if (!el) return; try { el.textContent = '● ' + (S.status(s) || [''])[0]; } catch { el.textContent = '●'; } });
  studiosOnState();
});

// ---------- Feed ----------
function pushFeed(cls, html) {
  $('feedEmpty')?.remove();
  const d = document.createElement('div'); d.className = 'ev ' + cls; d.innerHTML = html;
  $('feed').prepend(d); $('evCount').textContent = ++evN;
  while ($('feed').children.length > 150) $('feed').lastChild.remove();
}
socket.on('event', e => {
  if (e.type === 'chat' && e.hidden) pushFeed('chat hid', `🚫 <b>${esc(e.user.name)}</b>: <s>${esc(e.text)}</s> <i class="hidtag">oculto · ${esc(e.reason || '')}</i>`);
  else if (e.type === 'chat') pushFeed('chat', `<b>${esc(e.user.name)}</b>: ${esc(e.text)}`);
  if (e.type === 'gift') pushFeed('gift', `${e.icon || '🎁'} <b>${esc(e.user.name)}</b> envió ${e.count > 1 ? e.count + 'x ' : ''}${esc(e.giftName)} · ${e.diamonds} 💎`);
  if (e.type === 'follow') pushFeed('follow', `⭐ <b>${esc(e.user.name)}</b> te siguió`);
  if (e.type === 'share') pushFeed('follow', `📣 <b>${esc(e.user.name)}</b> compartió`);
});

// ---------- Pantalla de conexión ----------
const cxGo = () => { const u = $('cxUser').value.trim(); if (!u) { $('cxUser').focus(); return toast('Escribe tu @ de TikTok'); } $('user').value = u; socket.emit('connectLive', u); };
$('cxBtn').onclick = cxGo; $('cxUser').onkeydown = e => { if (e.key === 'Enter') cxGo(); };
$('cxUser').oninput = () => { $('user').value = $('cxUser').value; };
(function snow() { const box = $('cxSnow'); for (let i = 0; i < 40; i++) { const f = document.createElement('i'); f.style.cssText = `left:${Math.random() * 100}%;animation-delay:${-Math.random() * 12}s;animation-duration:${8 + Math.random() * 8}s;width:${2 + Math.random() * 4}px;height:${2 + Math.random() * 4}px;opacity:${.3 + Math.random() * .6}`; box.appendChild(f); } })();
const BUB = ['¡Hola! ¿Listo para tu live? 🐻‍❄️', '¡Vamos por esos regalos! 🎁', 'Hoy se rompe la meta 🔥', 'Escribe tu @ y dale a Conectar 👆'];
let bubI = 0; setInterval(() => { const b = $('cxBubble'); if (!b) return; b.classList.remove('pop'); void b.offsetWidth; b.textContent = BUB[++bubI % BUB.length]; b.classList.add('pop'); }, 5000);
socket.on('state', s => {
  const st = s.session.status, live = st === 'live';
  $('connectHero').classList.toggle('hidden', live);
  document.querySelector('#s-inicio .hero').classList.toggle('hidden', !live);
  $('cxBtn').classList.toggle('busy', st === 'connecting');
  $('cxBtn').querySelector('b').textContent = st === 'connecting' ? 'Conectando…' : 'Conectar';
  $('cxState').textContent = st === 'connecting' ? '◌ CONECTANDO CON TIKTOK…' : st === 'waiting' ? '◌ ESPERANDO TU LIVE · SE CONECTA SOLO' : st === 'error' ? '● NO SE PUDO CONECTAR' : '● SIN CONECTAR · LISTO CUANDO TÚ LO ESTÉS';
  $('cxState').className = 'cx-state ' + st;
  $('cxErr').classList.toggle('hidden', st !== 'error'); $('cxErr').textContent = st === 'error' ? s.session.statusMsg : '';
});
// ---------- Idioma ----------
document.querySelectorAll('[data-lang]').forEach(b => b.onclick = () => { socket.emit('saveConfig', { lang: b.dataset.lang }); });

// Al reiniciar (o al conectarte en vivo) se limpia la lista de eventos de prueba
socket.on('session:reset', () => { const f = $('feed'); if (f) f.innerHTML = '<div class="empty-feed" id="feedEmpty">Aquí verás regalos, comentarios y follows en tiempo real ✨<br>Prueba el Simulador.</div>'; evN = 0; const c = $('evCount'); if (c) c.textContent = 0; });

// ---------- Tus datos (respaldo) ----------
socket.on('dataInfo', d => {
  const a = $('dataDir'); if (a) a.textContent = d.dir;
  const b = $('dataBk'); if (b) b.textContent = `${d.backups} respaldos guardados`;
  if (d.migratedFrom && !window.__migToast) { window.__migToast = true; toast('💾 Se trajo tu configuración de la versión anterior ✓'); }
});
$('importCfg')?.addEventListener('change', e => {
  const f = e.target.files[0]; if (!f) return;
  const r = new FileReader();
  r.onload = () => {
    try { const c = JSON.parse(r.result); if (!c || typeof c !== 'object' || !c.games) throw 0;
      if (confirm('¿Cargar este respaldo? Se reemplaza tu configuración actual (antes se guarda una copia).')) socket.emit('importConfig', c);
    } catch { toast('Ese archivo no es un respaldo de ChispaLive'); }
    e.target.value = '';
  };
  r.readAsText(f);
});

// ---------- Actualizaciones con un clic ----------
(function () {
  const bar = document.createElement('div'); bar.className = 'upd-bar'; bar.hidden = true;
  document.body.appendChild(bar);
  const modal = document.createElement('div'); modal.className = 'upd-modal'; modal.hidden = true;
  document.body.appendChild(modal);
  let upd = null, restarting = false;
  const list = notes => (notes || []).map(n => `<div class="upd-v"><b>v${esc(n.version)}</b>${n.titulo ? ` · ${esc(n.titulo)}` : ''}<ul>${(n.cambios || []).map(c => `<li>${esc(c)}</li>`).join('')}</ul></div>`).join('') || '<p class="hint">Mejoras y arreglos.</p>';
  function showBar() {
    if (!upd) return (bar.hidden = true);
    bar.innerHTML = `<img src="/brand/oso.svg" alt=""><div><b>¡Nueva actualización v${esc(upd.version)}!</b><small>Tienes la v${esc(upd.current)} · ${upd.notes?.[0]?.titulo ? esc(upd.notes[0].titulo) : 'mejoras y arreglos'}</small></div>
      <button class="btn sm" data-u="ver">Ver novedades</button><button class="btn sm pri" data-u="go">🚀 Actualizar</button><button class="ib" data-u="x" title="Después">✕</button>`;
    bar.hidden = false;
    bar.querySelector('[data-u=ver]').onclick = () => openModal();
    bar.querySelector('[data-u=go]').onclick = () => openModal(true);
    bar.querySelector('[data-u=x]').onclick = () => { bar.hidden = true; };
  }
  function openModal(start) {
    modal.innerHTML = `<div class="upd-card"><img class="upd-bear" src="/brand/oso.svg" alt=""><h2>Actualización v${esc(upd.version)}</h2>
      <p class="hint">Tu configuración, regalos e imágenes se quedan como están. El programa se reinicia solo (tarda unos segundos).</p>
      <div class="upd-notes">${list(upd.notes)}</div>
      <div class="upd-prog" hidden><div class="upd-track"><i></i></div><span>Preparando…</span></div>
      <div class="row" style="justify-content:flex-end;margin:14px 0 0"><button class="btn" data-m="x">Después</button><button class="btn pri" data-m="go">🚀 Actualizar ahora</button></div></div>`;
    modal.hidden = false;
    modal.querySelector('[data-m=x]').onclick = () => { if (!restarting) modal.hidden = true; };
    modal.querySelector('[data-m=go]').onclick = go;
    if (start) go();
  }
  function go() {
    modal.querySelector('.upd-prog').hidden = false;
    modal.querySelectorAll('[data-m]').forEach(b => b.disabled = true);
    socket.emit('update:install');
  }
  socket.on('update:available', u => { upd = u; showBar(); });
  socket.on('update:progress', p => {
    if (modal.hidden && upd) openModal();
    const pr = modal.querySelector('.upd-prog'); if (!pr) return; pr.hidden = false;
    pr.querySelector('i').style.width = (p.pct || 0) + '%'; pr.querySelector('span').textContent = p.txt;
  });
  socket.on('update:error', e => {
    toast('No se pudo actualizar: ' + e.msg);
    const pr = modal.querySelector('.upd-prog span'); if (pr) pr.textContent = '❌ ' + e.msg;
    modal.querySelectorAll('[data-m]').forEach(b => b.disabled = false);
  });
  socket.on('update:restarting', () => {
    restarting = true;
    modal.innerHTML = `<div class="upd-card" style="text-align:center"><img class="upd-bear spin" src="/brand/oso.svg" alt=""><h2>Reiniciando ChispaLive…</h2><p class="hint">Esta página se recarga sola cuando esté lista.</p></div>`;
    modal.hidden = false;
    const t0 = Date.now();
    const want = upd?.version;
    const poll = setInterval(() => {
      const late = Date.now() - t0 > 60000;
      fetch('/api/ver', { cache: 'no-store' }).then(r => r.ok ? r.json() : null).then(v => { if ((v && (!want || v.version === want) && Date.now() - t0 > 1500) || late) { clearInterval(poll); location.reload(); } }).catch(() => { if (late) { clearInterval(poll); location.reload(); } });
    }, 1000);
  });
  // Después de actualizar: qué hay de nuevo
  socket.on('update:done', d => {
    upd = { version: d.to, notes: d.notes };
    modal.innerHTML = `<div class="upd-card"><img class="upd-bear" src="/brand/oso.svg" alt=""><h2>🎉 ¡Actualizado a la v${esc(d.to)}!</h2><p class="hint">Esto es lo nuevo:</p>
      <div class="upd-notes">${list(d.notes)}</div><div class="row" style="justify-content:flex-end;margin:14px 0 0"><button class="btn pri" data-m="x">¡Genial!</button></div></div>`;
    modal.hidden = false; bar.hidden = true;
    modal.querySelector('[data-m=x]').onclick = () => { modal.hidden = true; };
  });
  socket.on('connect', () => { if (!restarting) socket.emit('panel:hello'); }); if (socket.connected) socket.emit('panel:hello');
  // Ajustes: versión, buscar e instalar desde archivo
  let seenV = null;
  socket.on('hello', h => { const v = $('appVer'); if (v) v.textContent = 'v' + h.version; if (seenV && h.version !== seenV) return location.reload(); seenV = h.version; });
  $('updCheck')?.addEventListener('click', () => { socket.emit('update:check'); toast('Buscando actualizaciones…'); });
  socket.on('update:checked', r => { if (!r.found) toast(`✓ Ya tienes la última versión (v${r.current})`); });
  $('updFile')?.addEventListener('change', e => {
    const f = e.target.files[0]; if (!f) return;
    const r = new FileReader();
    r.onload = () => { toast('Revisando el archivo…'); socket.emit('update:upload', { name: f.name, data: String(r.result).split(',')[1] }, res => { if (res?.error) toast(res.error); }); e.target.value = ''; };
    r.readAsDataURL(f);
  });
})();

// Apagar el programa
$('appQuit')?.addEventListener('click', () => { if (confirm('¿Cerrar ChispaLive? Los overlays de OBS dejarán de funcionar hasta que lo abras otra vez.')) socket.emit('app:quit'); });
socket.on('app:closing', () => { document.body.innerHTML = '<div style="height:100vh;display:grid;place-items:center;text-align:center;font-family:Outfit,sans-serif;color:#fff;background:#0b0814"><div><img src="/brand/icon.png" width="96"><h2>ChispaLive se cerró</h2><p style="opacity:.7">Ábrelo otra vez desde el icono del escritorio.</p></div></div>'; });

// ---------- Aviso grande si se corta el LIVE ----------
// Si estabas conectado y TikTok corta, aparece arriba en rojo (y se reconecta solo)
const lbar = document.createElement('div'); lbar.className = 'live-alert'; lbar.hidden = true; document.body.appendChild(lbar);
let lbarT = null;
function liveAlert(ss) {
  const bad = ss.wantLive && ss.wasLive && ss.status !== 'live';
  lbar.hidden = !bad;
  clearInterval(lbarT);
  if (!bad) return;
  const paint = () => {
    const secs = ss.retryAt ? Math.max(0, Math.ceil((ss.retryAt - Date.now()) / 1000)) : 0;
    lbar.innerHTML = `<b>⚠️ No estás conectado a tu LIVE</b><span>${esc(ss.statusMsg || '')}${secs ? ` · reintento en ${secs} s` : ''}</span><small>Mientras esté así, las donaciones no cuentan en los juegos.</small>`;
  };
  paint(); lbarT = setInterval(paint, 1000);
}

// Conexión automática
socket.on('config', c => { const a = $('autoConn'); if (a) a.checked = c.autoConnect !== false; });
$('autoConn')?.addEventListener('change', e => socket.emit('saveConfig', { autoConnect: e.target.checked }));

// ---------- Sonido de las vistas previas (🔇 por defecto, para que no se escuche doble en el live) ----------
(function () {
  const b = document.getElementById('panelSnd'); if (!b) return;
  const paint = () => { const on = !!window.cfg?.panelSound; b.textContent = on ? '🔊' : '🔇'; b.classList.toggle('on', on);
    b.title = on ? 'Las vistas previas del panel suenan. Toca para silenciarlas (en tu live solo suena OBS / TikTok LIVE Studio)' : 'Vistas previas en silencio: el sonido solo sale en tu live. Toca para escucharlas aquí también'; };
  b.onclick = () => { const on = !window.cfg?.panelSound; window.cfg.panelSound = on; socket.emit('saveConfig', { panelSound: on }); paint();
    toast(on ? '🔊 Ahora el panel también suena (ojo: en el live se puede escuchar doble)' : '🔇 Panel en silencio: los sonidos solo salen en tu live'); };
  socket.on('config', paint); paint();
})();
